#pragma once
#ifndef _WEATHER_H_
#define _WEATHER_H_

#define MAX_WEATHER		32
#define charsmax(str)	(sizeof(str)-1)

class CWeatherManager
{
public:	// construct & destruct.
	void* operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void* ptr)
	{
		free(ptr);
	}
	CWeatherManager(void) { };
	~CWeatherManager(void) { };

public:	// const
	typedef enum { WEATHER_SUNNY = 1, WEATHER_DRIZZLE, WEATHER_THUNDERSTORM, WEATHER_TEMPEST, WEATHER_SNOW, WEATHER_FOG, WEATHER_BLACKFOG } WEATHER_TYPES;
	typedef enum { ReceiveW_Clear = 0, ReceiveW_Rain, ReceiveW_Snow } ReceiveW_Types;

public:	// related to weather control.
	virtual void	Precache(void);
	virtual void	OnServerActivate(void);
	virtual void	OnGameReset(void);
	virtual void	OnNewRound(void);
	virtual	void	WeatherChanged(void);	// public ChangeWeather()
	virtual	void	WeatherThink(void);	// public WeatherSystem()
	virtual void	SetWeather(WEATHER_TYPES iType);	// public native_set_weather(WeatherIndex)
	virtual	void	SetThunderLight(void);	// public SetThunderLight()
	virtual	bool	MakeThunderSpark(void);	// public MakeThunderSpark()
	virtual	void	Sunny(void);	// public sunny()
	virtual	void	Drizzle(void);	// public drizzle()
	virtual	void	Thunderstorm(void);	// public thunderstorm()
	virtual	void	Tempest(void);	// public tempest()
	virtual	void	Snow(void);	// public snow()
	virtual	void	Fog(void);	// public fog()
	virtual	void	BlackFog(void);	// public blackfog()

public:	// vars
	int		m_iCurrentWeatherInSeq;	// CurrentWeather
	char	m_cLightStyle[2];		// lightstyle
	WEATHER_TYPES m_iWeather;		// WeatherStyle
	float	m_flRainSoundThink;		// Float:WeatherThink[0]
	float	m_flThunderLightThink;	// Float:WeatherThink[1]
	float	m_flThunderClapThink;	// Float:WeatherThink[2]
	float	m_flThunderFlashThink;	// Float:WeatherThink[3]
	int		m_iThunderFlashCount;	// ThunderLight[0]
	bool	m_bThunderShouldFlash;	// ThunderLight[1]
};

extern CWeatherManager g_cWeatherManager;





















































#endif