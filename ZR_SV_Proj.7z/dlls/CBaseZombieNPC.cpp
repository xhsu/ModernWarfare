/***

Modern Warfare Develop Team
CBaseZombieNPC.cpp

Coder:		Luna the Reborn

Create Date: 2019/05/17

***/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "basemonster.h"
#include "player.h"
#include "CBaseZombieNPC.h"
#include "CWayPoint.h"
#include <algorithm>	// I LOVE THIS

lstznpc_t	CBaseZombieNPC::s_lstZombieNPCs;

void CBaseZombieNPC::OnPrecache(void)
{
	UTIL_PrecacheOther("monster_zombie");
}

bool CBaseZombieNPC::Command(CBasePlayer* pPlayer, const char* pcmd)
{
	pcmd = CMD_ARGV(1);

	if (!pcmd)
	{
	}
	else if (!strcmp(pcmd, "add"))
	{
		UTIL_MakeVectors(pPlayer->pev->v_angle);

		CBaseEntity::Create("monster_zombie", pPlayer->pev->origin + gpGlobals->v_forward * 200.0f, pPlayer->pev->angles);

		return true;
	}

	return false;
}

void CBaseZombieNPC::ServerActivate(void)
{
	s_lstZombieNPCs.clear();
}

void CBaseZombieNPC::ServerDeactivate(void)
{
	s_lstZombieNPCs.clear();
}

void CBaseZombieNPC::RoundRestart(void)
{
	for (auto pNPC : s_lstZombieNPCs)
	{
		UTIL_Remove(pNPC);
	}

	s_lstZombieNPCs.clear();
}

bool CBaseZombieNPC::AddToList(CBaseZombieNPC* pNPC)
{
	s_lstZombieNPCs.push_back(pNPC);
	return true;
}

bool CBaseZombieNPC::RemoveFromList(CBaseZombieNPC* pNPC)
{
	s_lstZombieNPCs.remove(pNPC);
	return true;
}

LINK_ENTITY_TO_CLASS(monster_zombie, CZombie);

void CZombie::Spawn(void)
{
	SET_MODEL(ENT(pev), "models/zombie.mdl");
	UTIL_SetSize(pev, VEC_HUMAN_HULL_MIN, VEC_HUMAN_HULL_MAX);

	pev->solid = SOLID_SLIDEBOX;
	pev->movetype = MOVETYPE_STEP;
	m_bloodColor = BLOOD_COLOR_GREEN;
	pev->health = 200.0f;
	pev->max_health = 200.0f;
	pev->view_ofs = VEC_VIEW;// position of the eyes relative to monster's origin.

	AddToList(this);
	MonsterInit();
}

void CZombie::Precache(void)
{
	PRECACHE_MODEL("models/zombie.mdl");
}

void CZombie::UpdateOnRemove(void)
{
	RemoveFromList(this);

	CBaseZombieNPC::UpdateOnRemove();
}
