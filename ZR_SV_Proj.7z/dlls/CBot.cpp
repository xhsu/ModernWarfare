/***

Modern Warfare Develop Team
CBot.cpp

Coder:		Luna the Reborn
Algorithm:	Usagi
Advisor:	Crsky
Advisor:	Fly

Create Date: 2019/05/02

***/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "player.h"
#include "CWayPoint.h"
#include "CBot.h"
#include "menus.h"
#include "gamerules.h"
#include "game.h"
#include <algorithm>	// I LOVE THIS

#ifdef _DEBUG_BOT
extern void DrawLine(CBasePlayer* pPlayer, const Vector& start, const Vector& end, const colorVec& color, int width, int noise, int speed, int life, int lineType);
#endif

extern DLL_FUNCTIONS gDllFunctionTable;

typedef std::list<CBot*>			lstpbot_t;
typedef std::vector<CBasePlayer*>	vppl_t;
typedef std::list<CBasePlayer*>		lstppl_t;

lstpbot_t	CBot::s_lstpBots;
float		CBot::s_flTimeNextAddBot;
int			CBot::s_iBotsToAdd;
bool		CBot::s_bBotsStop;
vppl_t		CBot::s_vZombies;
vppl_t		CBot::s_vHumans;
int			CBot::s_iZombieBotCount;
int			CBot::s_iHumanBotCount;
lstppl_t	CBot::s_lpZombieLieutenants;
lstppl_t	CBot::s_lpHumanLieutenants;
float		CBot::s_flTimeMinionAssignThink;

CBot* CBot::Create(void)
{
	if (!g_cWayPoint.m_uNodeCounts)
		return nullptr;	// no nodes, no bots.

	if (UTIL_ClientsInGame() >= gpGlobals->maxClients)
	{
		CONSOLE_ECHO("Unable to create bot: Server is full (%d/%d clients).\n", UTIL_ClientsInGame(), gpGlobals->maxClients);
		return nullptr;
	}

	edict_t* pentBot = g_engfuncs.pfnCreateFakeClient("BotTest");

	if (!pentBot)
	{
		CONSOLE_ECHO("Unable to create bot: pfnCreateFakeClient() returned null.\n");
		return nullptr;
	}

	// setup manager class.
	CBot* pBot = nullptr;
	FREE_PRIVATE(pentBot);
	pBot = GetClassPtr((CBot*)VARS(pentBot));

	// setup client info.
	char* pInfoKeyBuffer = g_engfuncs.pfnGetInfoKeyBuffer(pentBot);
	g_engfuncs.pfnSetClientKeyValue(pBot->entindex(), pInfoKeyBuffer, "_vgui_menus", "0");
	g_engfuncs.pfnSetClientKeyValue(pBot->entindex(), pInfoKeyBuffer, "*bot", "1");

	char szDummyStr[128];
	gDllFunctionTable.pfnClientConnect(pentBot, "Bot", "127.0.0.1", szDummyStr);	// actually we don't have a code to reject anyone.

	gDllFunctionTable.pfnClientPutInServer(pentBot);
	pBot->pev->flags = FL_FAKECLIENT;	// set this "player" as fakeclient

	// initialize msec value
	pBot->m_msecInterval = gpGlobals->time;
	pBot->m_msecVal = static_cast <uint8_t> (gpGlobals->frametime * 1000.0f);
	pBot->m_msecBuiltin = RANDOM_LONG(1, 4);

	// setup think func
	//pBot->pev->nextthink = gpGlobals->time;
	//pBot->SetThink(&CBot::JoinThink);

	// add to manager.
	s_lstpBots.push_back(pBot);
	s_flTimeMinionAssignThink = gpGlobals->time;

	// setup calculator
	pBot->m_cAStarCalculator.Initialize(pBot);
	pBot->m_lpnWayPoints.clear();

	return pBot;
}

bool CBot::Command(CBasePlayer* pCommander)
{
	const char* pcmd = CMD_ARGV(1);

	if (!pcmd)
	{
	}
	else if (!strcmp(pcmd, "add"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			Create();
		else
		{
			int iNum = atoi(pcmd);

			s_flTimeNextAddBot = gpGlobals->time + 0.1f;
			s_iBotsToAdd = iNum;
		}

		return true;
	}
	else if (!strcmp(pcmd, "wolfpacks"))
	{
		if (!s_lpHumanLieutenants.empty())
		{
			char szWords[128];

			for (auto pLieutenant : s_lpHumanLieutenants)
			{
				sprintf(szWords, "[HumanLieutenant]%s\n", STRING(pLieutenant->pev->netname));
				g_engfuncs.pfnServerPrint(szWords);

				for (auto pMinion : pLieutenant->m_lstMinions)
				{
					sprintf(szWords, "[HumanMinion]%s\n", STRING(pMinion->pev->netname));
					g_engfuncs.pfnServerPrint(szWords);
				}

				sprintf(szWords, "[----------------------------------]\n");
				g_engfuncs.pfnServerPrint(szWords);
			}
		}

		if (!s_lpZombieLieutenants.empty())
		{
			char szWords[128];

			for (auto pLieutenant : s_lpZombieLieutenants)
			{
				sprintf(szWords, "[ZombieLieutenant]%s\n", STRING(pLieutenant->pev->netname));
				g_engfuncs.pfnServerPrint(szWords);

				for (auto pMinion : pLieutenant->m_lstMinions)
				{
					sprintf(szWords, "[ZombieMinion]%s\n", STRING(pMinion->pev->netname));
					g_engfuncs.pfnServerPrint(szWords);
				}

				sprintf(szWords, "[----------------------------------]\n");
				g_engfuncs.pfnServerPrint(szWords);
			}
		}

		return true;
	}
	else if (!strcmp(pcmd, "stop"))
	{
		s_bBotsStop = !s_bBotsStop;
		return true;
	}

	return false;
}

void CBot::ServerActivate(void)
{
	s_lstpBots.clear();
	s_lpZombieLieutenants.clear();
	s_lpHumanLieutenants.clear();

	s_flTimeNextAddBot = 0;
	s_iBotsToAdd = 0;
	s_bBotsStop = false;

	s_vZombies.clear();
	s_vHumans.clear();

	s_iZombieBotCount = 0;
	s_iHumanBotCount = 0;
	s_flTimeMinionAssignThink = 0;
}

void CBot::ServerDeactivate(void)
{
	s_lstpBots.clear();
	s_lpZombieLieutenants.clear();
	s_lpHumanLieutenants.clear();

	s_flTimeNextAddBot = 0;
	s_iBotsToAdd = 0;
	s_bBotsStop = false;

	s_vZombies.clear();
	s_vHumans.clear();

	s_iZombieBotCount = 0;
	s_iHumanBotCount = 0;
	s_flTimeMinionAssignThink = 0;
}

void CBot::StartFrame(void)
{
	// fill up enemy candidates' pool
	s_vZombies.clear();
	s_vHumans.clear();
	s_iZombieBotCount = 0;
	s_iHumanBotCount = 0;
	CBasePlayer* pPlayer = nullptr;
	for (int i = 0; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

#ifdef _DEBUG_BOT
		if (!pPlayer || !pPlayer->IsAvailable() || (!pPlayer->IsAlive() && !pPlayer->m_bGhost))
			continue;
#else
		if (!pPlayer || !pPlayer->IsAvailable())	// bot cannot consider you as a threat if you are a ghost.
			continue;

		if (pPlayer->m_iTeam != TEAM_ZOMBIE && !pPlayer->IsAlive())
			continue;
#endif

		if (pPlayer->m_iTeam == TEAM_HUMAN)
		{
			s_vHumans.push_back(pPlayer);

			if (pPlayer->IsBot())
				s_iHumanBotCount++;
		}
		else if (pPlayer->m_iTeam == TEAM_ZOMBIE)
		{
			s_vZombies.push_back(pPlayer);

			if (pPlayer->IsBot())
				s_iZombieBotCount++;
		}
	}

	// add bots
	if (s_iBotsToAdd > 0 && s_flTimeNextAddBot < gpGlobals->time)
	{
		Create();

		s_iBotsToAdd--;
		s_flTimeNextAddBot = gpGlobals->time + 0.2f;
	}

	// nothing to explain.
	if (s_lstpBots.empty())
		return;

	// wolfpack think must before individual think.
	WolfPackThink();

	// bot base function.
	if (!s_bBotsStop)
	{
		for (auto pBot : s_lstpBots)
		{
			pBot->RunPlayerMove();
		}
	}
}

void CBot::RoundRestart(void)
{
	s_flTimeMinionAssignThink = gpGlobals->time + 0.1f;

	for (auto pBot : s_lstpBots)
	{
		// think frame
		pBot->m_flFrameInterval = 0;
		pBot->m_flLastThinkTime = 0;

		// bot movement.
		pBot->m_flForwardSpeed = 0;	// forward & backward
		pBot->m_flStrafeSpeed = 0;	// left & right
		pBot->m_vecRPMVAngle = g_vecZero;		// angle used in RunPlayerMove(). this angle should only related to movement, ignore any model, shooting problems. this angle don'have to equal to pev->v_angle.
		pBot->m_vecPreOrg = g_vecZero;
		pBot->m_cAStarCalculator.Initialize(pBot);	// each bot should hold one.
		pBot->m_lpnWayPoints.clear();	// a pathway to player.
		pBot->m_vecGoal = g_vecZero;	// the place where bot wants to go. DO NOT ASSIGN this value, it's a result, changing it will not changing anything.
		pBot->m_flTimeNextNodeAccessibilityCheck = 0;	// check whether the first node is really accessible.
		pBot->m_pChasingPlayer = nullptr;
		pBot->m_pChasingNode = nullptr;
		pBot->m_vecTargetLastSeenOrigin = g_vecZero;

		// scheme system.
		pBot->m_iMovementScheme = MOVEMENT_STAY;
		pBot->m_iFormationScheme = FORMATION_SKIRMISHERS;
		pBot->m_iCombatScheme = COMBAT_MELEE;

		// jump system.
		pBot->m_flNextJumpAttempt = 0;	// bot will attempt to perform another jump if still blocked.
		pBot->m_flTimeJumpDuck = 0;		// jump-duck performance.
		pBot->m_flTimeDuckRelease = 0;	// how long until jump-duck done?

		// deal with stupid ladders
		pBot->m_iLastMovetype = 0;
		pBot->m_bOnLadder = 0;
		pBot->m_vecSavedVAngle = g_vecZero;
		pBot->m_flTimeEnforceJump = 0;	// avoid being stuck by stupid ladders.

		// bot enemy system
		pBot->m_pEnemy = 0;

		// ghost spawn-searching system.
		pBot->m_lstGhostRespawnNodeCandidates.clear();
		pBot->m_lstGhostRespawnRegionCandidates.clear();
		pBot->m_lstGhostRespawnRegionClosed.clear();	// trashcan.
		pBot->m_flTimeNextGhostThink = 0;
		pBot->m_flTimeResetGhostSpawn = 0;

		// bot aiming system
		pBot->m_vecSeeingOrg = g_vecZero;	// the place where bot aiming at.
		pBot->m_vecIdealViewAngle = g_vecZero;	// the angle directly aiming to m_vecSeeingOrg.
		pBot->m_vecTargetingAngularSpeed = g_vecZero;	// aiming speed component of certain enemy.
		pBot->m_vecViewAngularSpeed = g_vecZero;	// overall view angular speed.
		pBot->m_vecInterferedViewAngle = g_vecZero;	// "ideal" view angle with some noise.
		pBot->m_flLastTargeting = 0;	// last time when attempt to aiming at someone.
		pBot->m_vecAngularDeviation = g_vecZero;	// look at my name, plz.
		pBot->m_flTimeInterfereAiming = 0;	// some random aiming mistake. more often when running.
		pBot->m_flTimeShootAttempt = 0;	// time interval of traceline determination.

#ifdef _DEBUG_BOT
		// debug vars
		pBot->m_flNextDrawPath = 0;
#endif
	}
}

void CBot::WolfPackThink(void)
{
	int iLieutenantMiniumNumber = 0, iLieutenantDemands = 0;

	// check lists
	s_lpHumanLieutenants.remove_if(
		[](const auto & pLieutenants)
		{
			return !!(pLieutenants->m_iTeam != TEAM_HUMAN || !pLieutenants->m_bLieutenant);
		}
	);

	s_lpZombieLieutenants.remove_if(
		[](const auto & pLieutenants)
		{
			return !!(pLieutenants->m_iTeam != TEAM_ZOMBIE || !pLieutenants->m_bLieutenant);
		}
	);

	// zombie wolfpack
	if (s_iZombieBotCount > 0)
	{
		// a lieutenant will rule 3 minions
		iLieutenantMiniumNumber = s_iZombieBotCount / 4;

		// if remainder existed, we could use an additional lieutenant.
		if (s_iZombieBotCount % 4 > 1)
			iLieutenantMiniumNumber++;

		// how many people we need?
		iLieutenantDemands = iLieutenantMiniumNumber - s_lpZombieLieutenants.size();

		// not enough lieutenants? promote some.
		if (iLieutenantDemands > 0)
		{
			std::list<CBasePlayer*> lstCandidates;
			lstCandidates.clear();

			// add all non-lieutenant player inside the list first. we can sort and remove some later.
			CBasePlayer* pPlayer = nullptr;
			for (int i = 1; i < gpGlobals->maxClients; i++)
			{
				pPlayer = UTIL_PlayerByIndex(i);

				if (!pPlayer || pPlayer->m_bLieutenant || !pPlayer->IsAvailable())	// you can't be promoted twice.
					continue;

				if (pPlayer->m_iTeam != TEAM_ZOMBIE)	// a human cannot become the leader of a bunch of zombies, obviously.
					continue;

				lstCandidates.push_back(pPlayer);
			}

			// sort them by
			// 1. real-human player
			// 2. KDA
			lstCandidates.sort(
				[](const auto& pFirst, const auto& pSecond)
				{
					if (pFirst->IsBot() != pSecond->IsBot())	// if one of them is bot, place real-human player before bot.
						return !pFirst->IsBot();

					float flKDA1 = pFirst->pev->frags / float(pFirst->m_iDeaths);
					float flKDA2 = pSecond->pev->frags / float(pSecond->m_iDeaths);

					return !!(flKDA1 > flKDA2);	// if pFirst is a better player than pSecond, we should put pFirst in front of pSecond.
				}
			);

			// remove the most-unqualified candidate, until the number is fit.
			while (lstCandidates.size() > (unsigned)iLieutenantDemands)
			{
				lstCandidates.pop_back();
			}

			// promote all lieutenant candidates.
			for (auto pCandidates : lstCandidates)
			{
				pCandidates->PromoteToLieutenant();
			}
		}
		
		// what if there are too many lieutenants?
		else if (iLieutenantDemands < 0)
		{
			// sort out the worst lieutenant
			s_lpZombieLieutenants.sort(
				[](const auto & pFirst, const auto & pSecond)
				{
					if (pFirst->IsBot() != pSecond->IsBot())	// if one of them is bot, place real-human player before bot.
						return !pFirst->IsBot();

					float flKDA1 = pFirst->pev->frags / float(pFirst->m_iDeaths);
					float flKDA2 = pSecond->pev->frags / float(pSecond->m_iDeaths);

					return !!(flKDA1 > flKDA2);	// if pFirst is a better player than pSecond, we should put pFirst in front of pSecond.
				}
			);

			// pop out the bad lieutenants until it matches the proper number.
			while (iLieutenantDemands < 0 && !s_lpZombieLieutenants.empty())
			{
				s_lpZombieLieutenants.back()->DisbandWolfpack();

				iLieutenantDemands = iLieutenantMiniumNumber - s_lpZombieLieutenants.size();
			}
		}

		// no problem if iLieutenantDemands == 0.
	}

	// human wolfpack
	if (s_iHumanBotCount > 0)
	{
		// a lieutenant will rule 3 minions
		iLieutenantMiniumNumber = s_iHumanBotCount / 4;

		// if remainder existed, we could use an additional lieutenant.
		if (s_iZombieBotCount % 4 > 1)
			iLieutenantMiniumNumber++;

		// how many people we need?
		iLieutenantDemands = iLieutenantMiniumNumber - s_lpHumanLieutenants.size();

		// not enough lieutenants? promote some.
		if (iLieutenantDemands > 0)
		{
			std::list<CBasePlayer*> lstCandidates;
			lstCandidates.clear();

			// add all non-lieutenant player inside the list first. we can sort and remove some later.
			CBasePlayer* pPlayer = nullptr;
			for (int i = 1; i < gpGlobals->maxClients; i++)
			{
				pPlayer = UTIL_PlayerByIndex(i);

				if (!pPlayer || pPlayer->m_bLieutenant || !pPlayer->IsAvailable())	// you can't be promoted twice.
					continue;

				if (pPlayer->m_iTeam != TEAM_HUMAN)	// a zombie cannot become the leader of a bunch of humans, obviously.
					continue;

				lstCandidates.push_back(pPlayer);
			}

			// sort them by
			// 1. real-human player
			// 2. KDA
			lstCandidates.sort(
				[](const auto & pFirst, const auto & pSecond)
				{
					if (pFirst->IsBot() != pSecond->IsBot())	// if one of them is bot, place real-human player before bot.
						return !pFirst->IsBot();

					float flKDA1 = pFirst->pev->frags / float(pFirst->m_iDeaths);
					float flKDA2 = pSecond->pev->frags / float(pSecond->m_iDeaths);

					return !!(flKDA1 > flKDA2);	// if pFirst is a better player than pSecond, we should put pFirst in front of pSecond.
				}
			);

			// remove the most-unqualified candidate, until the number is fit.
			while (lstCandidates.size() > (unsigned)iLieutenantDemands)
			{
				lstCandidates.pop_back();
			}

			// promote all lieutenant candidates.
			for (auto pCandidates : lstCandidates)
			{
				pCandidates->PromoteToLieutenant();
			}
		}

		// what if there are too many lieutenants?
		else if (iLieutenantDemands < 0)
		{
			// sort out the worst lieutenant
			s_lpHumanLieutenants.sort(
				[](const auto & pFirst, const auto & pSecond)
				{
					if (pFirst->IsBot() != pSecond->IsBot())	// if one of them is bot, place real-human player before bot.
						return !pFirst->IsBot();

					float flKDA1 = pFirst->pev->frags / float(pFirst->m_iDeaths);
					float flKDA2 = pSecond->pev->frags / float(pSecond->m_iDeaths);

					return !!(flKDA1 > flKDA2);	// if pFirst is a better player than pSecond, we should put pFirst in front of pSecond.
				}
			);

			// pop out the bad lieutenants until it matches the proper number.
			while (iLieutenantDemands < 0 && !s_lpHumanLieutenants.empty())
			{
				s_lpHumanLieutenants.back()->DisbandWolfpack();

				iLieutenantDemands = iLieutenantMiniumNumber - s_lpHumanLieutenants.size();
			}
		}

		// no problem if iLieutenantDemands == 0.
	}

	// assign bots into wolfpacks.
	if (!s_lstpBots.empty() && s_flTimeMinionAssignThink > 0 && s_flTimeMinionAssignThink < gpGlobals->time)
	{
		s_flTimeMinionAssignThink = 0;

		// pickout bots who should join/change a wolfpack. real-human players needn't to join one, thus we only think about our bots.
		std::list<CBasePlayer*> lstCandidates;
		lstCandidates.clear();

		for (auto pCandidates : s_lstpBots)
		{
			if (pCandidates->m_bLieutenant || pCandidates->m_pLieutenant)	// first filter: add all lone wolves into our list.
				continue;

			lstCandidates.push_back(pCandidates);
		}

		for (auto pCandidates : s_lstpBots)
		{
			if (pCandidates->m_bLieutenant && pCandidates->m_lstMinions.size() > 3)	// second filter: add wolves from overloaded wolfpack.
				lstCandidates.push_back(pCandidates->m_lstMinions.front());
		}

		// make all minions assigned to their lieutenants.
		for (auto pCandidates : lstCandidates)
		{
			// a safe conversion. it is a bot, really.
			((CBot*)pCandidates)->JoinWolfpack();	// use auto version of join wolfpack, to balance wolfpacks.
		}
	}
}

void CBot::PreThink(void)
{
	if (m_iJoiningState != JOINED)
	{
		JoinSelection();
		return CBasePlayer::PreThink();
	}

	m_flFrameInterval = gpGlobals->time - m_flLastThinkTime;
	m_flLastThinkTime = gpGlobals->time;

	m_vecPreOrg = pev->origin + pev->velocity * m_flFrameInterval;

	// think about enemy.
	ChooseEnemy();

	// choose a player to track down.
	ChooseChasingTarget();

	// TODO: maybe we shouldn't do this?
	if (!m_pChasingPlayer)
		return CBasePlayer::PreThink();

	// it's meaningless to call these function if you're not alive. (including ghost, since we have another function.)
	if (!IsAlive())
		return CBasePlayer::PreThink();

	// this function is called for attempting to both choose m_vecGoal and build pathway list.
	ChooseGoalOrg();

	// all the roads lead to ROME. with a checkpoint.
	m_vecRPMVAngle = (m_vecGoal - m_vecPreOrg).VectorAngles();
	m_vecRPMVAngle.ClampAngles();
	m_vecRPMVAngle.x *= -1.0f;

	// if we need to continuing ladder climb, we have to override m_vecRPMVAngle
	// why not make pev->v_angle to the climb angle as well? that's because we can shoot someone else while climbing...
	//if (m_bOnLadder)
		//m_vecRPMVAngle = m_vecSavedVAngle;

	// decide whether we sould press W button?
	ActForwardingButton();

	// decide whether we should jump?
	ActJumpAndDuck();

	// aim at enemy... or anything want to destory.
	ChooseViewAngle();
	ActViewAngle();

#ifdef _DEBUG_BOT
	if (!m_lpnWayPoints.empty() && m_flNextDrawPath <= gpGlobals->time)
	{
		m_flNextDrawPath = gpGlobals->time + 1.0f;

		colorVec tracecolor = { 255, 255, 255, 255 };

		for (auto iter = m_lpnWayPoints.cbegin(); iter != m_lpnWayPoints.cend();)
		{
			auto curr = iter;
			iter++;
			auto next = iter;

			if (next == m_lpnWayPoints.cend())
				break;

			DrawLine(UTIL_PlayerByIndex(1), (*curr)->m_vecOrigin, (*next)->m_vecOrigin, tracecolor, 15, 0, 0, 10, NULL);
		}
	}
#endif

	// decide whether we should attack?
	ActAttack();

	CBasePlayer::PreThink();
}

void CBot::PostThink(void)
{
	CBasePlayer::PostThink();

	if (pev->movetype != m_iLastMovetype)
	{
		m_iLastMovetype = pev->movetype;

		if (pev->movetype == MOVETYPE_FLY)	// start to clamb ladder.
		{
			m_bOnLadder = true;
			m_vecSavedVAngle = pev->v_angle;
			m_flTimeEnforceJump = gpGlobals->time + 10.0f;	// normally... I think...
		}
		else
		{
			m_bOnLadder = false;
			m_flTimeEnforceJump = 0;
		}
	}

	// if this bot is current a ghost, call ghost think will be sufficient.
	if (m_bGhost)
		GhostThink();
}

void CBot::JoinSelection(void)
{
	if (m_iMenu == Menu_ChooseTeam)
	{
		HandleMenu_ChooseTeam(this, 5);
	}
	else if (m_iMenu == Menu_ChooseAppearance)
	{
		// I suppose slot == 5 will trigger random selection.
		HandleMenu_ChooseAppearance(this, 5);
	}
}

void CBot::RunPlayerMove(void)
{
	// the purpose of this function is to compute, according to the specified computation
	// method, the msec value which will be passed as an argument of pfnRunPlayerMove. This
	// function is called every frame for every bot, since the RunPlayerMove is the function
	// that tells the engine to put the bot character model in movement. This msec value
	// tells the engine how long should the movement of the model extend inside the current
	// frame. It is very important for it to be exact, else one can experience bizarre
	// problems, such as bots getting stuck into each others. That's because the model's
	// bounding boxes, which are the boxes the engine uses to compute and detect all the
	// collisions of the model, only exist, and are only valid, while in the duration of the
	// movement. That's why if you get a pfnRunPlayerMove for one bot that lasts a little too
	// short in comparison with the frame's duration, the remaining time until the frame
	// elapses, that bot will behave like a ghost : no movement, but bullets and players can
	// pass through it. Then, when the next frame will begin, the stucking problem will arise !

	m_msecVal = static_cast <uint8_t> ((gpGlobals->time - m_msecInterval) * 1000.0f);
	m_msecInterval = gpGlobals->time;
	
	(*g_engfuncs.pfnRunPlayerMove) (
		edict(),
		m_vecRPMVAngle,
		m_flForwardSpeed,
		m_flStrafeSpeed,
		0.0f,
		static_cast <unsigned short> (pev->button),
		0,
		static_cast <uint8_t> (m_msecVal)
		);
}

bool CBasePlayer::LeaveWolfpack(bool bMyWolfpack)
{
	if (!bMyWolfpack)	// excuse myself from my lieutenant
	{
		if (m_pLieutenant)
		{
			for (auto iterMinion = m_pLieutenant->m_lstMinions.cbegin(); iterMinion != m_pLieutenant->m_lstMinions.cend(); iterMinion++)
			{
				if ((*iterMinion) == this)	// find myself in my lieutenant's list.
				{
					m_pLieutenant->m_lstMinions.erase(iterMinion);	// del it.
					break;
				}
			}

			m_pLieutenant = nullptr;
		}

		// successfully quit.
		return true;
	}
	else if (!m_lstMinions.empty())	// want to leave my own wolfpack.
	{
		// sort my wolves by KDA. pick the best one become my sucessor.
		m_lstMinions.sort(
			[](const auto& pFirst, const auto& pSecond)
			{
				if (pFirst->IsBot() != pSecond->IsBot())	// if one of them is bot, place real-human player before bot.
					return !pFirst->IsBot();

				float flKDA1 = pFirst->pev->frags / float(pFirst->m_iDeaths);
				float flKDA2 = pSecond->pev->frags / float(pSecond->m_iDeaths);

				return !!(flKDA1 > flKDA2);	// if pFirst is a better player than pSecond, we should put pFirst in front of pSecond.
			}
		);

		// successor is decided.
		CBasePlayer* pSuccessor = m_lstMinions.front();

		// kick the successor out of the wolfpack first.
		m_lstMinions.pop_front();
		
		// promote my successor and add him into the list, if he is a newly promoted lieutenant.
		if (!pSuccessor->m_bLieutenant)
			pSuccessor->PromoteToLieutenant();

		// reserve for future potential design: multiple management level.
		if (pSuccessor->m_pLieutenant == this)
			pSuccessor->m_pLieutenant = nullptr;

		// inhert the rest wolves from my wolfpack.
		pSuccessor->m_lstMinions.splice(pSuccessor->m_lstMinions.cend(), m_lstMinions);

		// the retirement paperwork for myself.
		m_bLieutenant = false;
		m_lstMinions.clear();

		// remove myself from lieutenant list.
		if (m_iTeam == TEAM_HUMAN)
		{
			/*for (auto iterLieutenant = CBot::s_lpHumanLieutenants.cbegin(); iterLieutenant != CBot::s_lpHumanLieutenants.cend(); iterLieutenant++)
			{
				if (*iterLieutenant == this)
				{
					CBot::s_lpHumanLieutenants.erase(iterLieutenant);
					break;
				}
			}*/

			CBot::s_lpHumanLieutenants.remove(this);
		}
		else if (m_iTeam == TEAM_ZOMBIE)
		{
			/*for (auto iterLieutenant = CBot::s_lpZombieLieutenants.cbegin(); iterLieutenant != CBot::s_lpZombieLieutenants.cend(); iterLieutenant++)
			{
				if (*iterLieutenant == this)
				{
					CBot::s_lpZombieLieutenants.erase(iterLieutenant);
					break;
				}
			}*/

			CBot::s_lpZombieLieutenants.remove(this);
		}

		// successfully quit.
		return true;
	}

	// it means nothing to quit.
	return false;
}

void CBasePlayer::DisbandWolfpack(void)
{
	// we don't even bother to start if I am not a lieutenant
	//if (!m_bLieutenant)
		//return;

	for (auto pMinion : m_lstMinions)
	{
		if (pMinion->m_pLieutenant == this)
			pMinion->m_pLieutenant = nullptr;
	}

	m_bLieutenant = false;
	m_lstMinions.clear();

	// remove myself from lieutenant list.
	if (m_iTeam == TEAM_HUMAN)
	{
		/*for (auto iterLieutenant = CBot::s_lpHumanLieutenants.cbegin(); iterLieutenant != CBot::s_lpHumanLieutenants.cend(); iterLieutenant++)
		{
			if (*iterLieutenant == this)
			{
				CBot::s_lpHumanLieutenants.erase(iterLieutenant);
				break;
			}
		}*/

		CBot::s_lpHumanLieutenants.remove(this);
	}
	else if (m_iTeam == TEAM_ZOMBIE)
	{
		/*for (auto iterLieutenant = CBot::s_lpZombieLieutenants.cbegin(); iterLieutenant != CBot::s_lpZombieLieutenants.cend(); iterLieutenant++)
		{
			if (*iterLieutenant == this)
			{
				CBot::s_lpZombieLieutenants.erase(iterLieutenant);
				break;
			}
		}*/

		CBot::s_lpZombieLieutenants.remove(this);
	}
}

bool CBasePlayer::PromoteToLieutenant(void)
{
	if (m_bLieutenant)	// you can't be promote twice.
		return false;

	if (m_iTeam == TEAM_HUMAN)
		CBot::s_lpHumanLieutenants.push_back(this);
	else if (m_iTeam == TEAM_ZOMBIE)
		CBot::s_lpZombieLieutenants.push_back(this);

	m_bLieutenant = true;
	return true;
}

bool CBot::JoinWolfpack(void)
{
	if (m_iTeam == TEAM_ZOMBIE && !s_lpZombieLieutenants.empty())
	{
		// sort all lieutenant by thier minions number. the less minion you have, the more prior you get.
		s_lpZombieLieutenants.sort(
			[](const auto& pFirst, const auto& pSecond)
			{
				return !!(pFirst->m_lstMinions.size() < pSecond->m_lstMinions.size());	// the less minion you have, the more prior you get.
			}
		);

		// join the most lonely lieutenant.
		JoinWolfpack(s_lpZombieLieutenants.front());

		// successful.
		return true;
	}
	else if (m_iTeam == TEAM_HUMAN && !s_lpHumanLieutenants.empty())
	{
		// sort all lieutenant by thier minions number. the less minion you have, the more prior you get.
		s_lpHumanLieutenants.sort(
			[](const auto & pFirst, const auto & pSecond)
			{
				return !!(pFirst->m_lstMinions.size() < pSecond->m_lstMinions.size());	// the less minion you have, the more prior you get.
			}
		);

		// join the most lonely lieutenant.
		JoinWolfpack(s_lpHumanLieutenants.front());

		// successful.
		return true;
	}

	// nobody can I join.
	return false;
}

bool CBot::JoinWolfpack(CBasePlayer* pLieutenant)
{
	if (pLieutenant->m_iTeam != m_iTeam)	// what the fuck these people want me to do? a traitor?
		return false;

	if (m_pLieutenant)	// already in another wolfpack? quit it first.
		LeaveWolfpack();

	if (pLieutenant->m_bLieutenant)	// join a existed wolfpack.
	{
	}
	else	// create a new wolf pack.
	{
		// promote him first.
		pLieutenant->PromoteToLieutenant();
	}

	// reassign var.
	m_pLieutenant = pLieutenant;

	// add myself into my lieutenant's list.
	pLieutenant->m_lstMinions.push_back(this);

	// successful.
	return true;
}

static Vector s_vecTemp = g_vecZero;

void CBot::ChooseEnemy(void)
{
	// TODO: this is a incomplete version.

	s_vecTemp = pev->origin;

	if (m_iTeam == TEAM_HUMAN && !s_vZombies.empty())	// UNDONE: for human bots, they should also attempt to attack barriers.
	{
		auto iterMin = std::min_element(s_vZombies.cbegin(), s_vZombies.cend(),
			[](const auto & pFirst, const auto & pSecond)
			{
				// we shouldn't see ghosts.
				if (pFirst->IsAlive() != pSecond->IsAlive())
					return !!pFirst->IsAlive();	// if you're alive, put ahead.

				return ((pFirst->pev->origin - s_vecTemp).LengthSquared() < (pSecond->pev->origin - s_vecTemp).LengthSquared());
			}
		);

		m_pEnemy = *iterMin;
	}
	else if (m_iTeam == TEAM_ZOMBIE && !s_vHumans.empty())
	{
		if (!m_pEnemy || !m_pEnemy->IsAlive())	// zombie will only reselect enemy when the enemy is dead.
		{
			auto iterMin = std::min_element(s_vHumans.cbegin(), s_vHumans.cend(),
				[](const auto & pFirst, const auto & pSecond)
				{
					return ((pFirst->pev->origin - s_vecTemp).LengthSquared() < (pSecond->pev->origin - s_vecTemp).LengthSquared());
				}
			);

			m_pEnemy = *iterMin;
		}
	}
	else
		m_pEnemy = nullptr;
}

void CBot::ChooseChasingTarget(void)
{
	// TODO: maybe we can change chasing target?

	// UNDONE: zombie should only chasing enemy when FORMATION_SKIRMISHERS
	if (m_pLieutenant && m_iTeam != TEAM_ZOMBIE)	// chasing own lieutenant could never be wrong.
	{
		m_pChasingPlayer = m_pLieutenant;
	}
	else	// or, just simply looking for enemies.
	{
		if (m_pEnemy && m_pEnemy->IsPlayer())
			m_pChasingPlayer = (CBasePlayer*)m_pEnemy;
	}

	// update targeting node. POTENTIAL BUG
	if (m_pChasingPlayer)
		m_pChasingNode = m_pChasingPlayer->m_pNearestNode->FindAvailable();
	else
		m_pChasingNode = g_cWayPoint.m_pnMapSpawn;
}

void CBot::ChooseGoalOrg(void)
{
	TraceResult tr;

	if (m_pChasingPlayer && Math::FltEqual(pev->origin.z, m_pChasingPlayer->pev->origin.z))	// if a target player existed, targeting him.
		UTIL_TraceHull(pev->origin, m_pChasingPlayer->pev->origin, dont_ignore_monsters, human_hull, m_pChasingPlayer->edict(), &tr);	// only do trace if they're in same height.
	else if (Math::FltEqual(pev->origin.z, m_pChasingNode->m_vecOrigin.z))
		UTIL_TraceHull(pev->origin, m_pChasingNode->m_vecOrigin.z, dont_ignore_monsters, human_hull, m_pChasingPlayer->edict(), &tr);
	else
		tr.flFraction = 0;	// otherwise, just give a random value other than 1.

	if (tr.flFraction >= 1.0f)	// can I directly see my chasing target?
	{
		if (m_pChasingPlayer)
		{
			m_vecTargetLastSeenOrigin = m_pChasingPlayer->pev->origin;	// remember their location when we can.
			m_vecGoal = m_pChasingPlayer->pev->origin;
		}
		else
		{
			m_vecTargetLastSeenOrigin = m_pChasingNode->m_vecOrigin;
			m_vecGoal = m_pChasingNode->m_vecOrigin;
		}

		// since we already saw the enemy, call off the searching operation will be fine.
		m_cAStarCalculator.ASBF_Cancel();

		// call off any accessibility check.
		m_flTimeNextNodeAccessibilityCheck = gpGlobals->time + 3.0f;

		// remove old pathway when we can see enemy, and very close to him.
		if (!m_lpnWayPoints.empty())
			m_lpnWayPoints.clear();
	}
	else	// no? so how can I reach there?
	{
		// if calculator is not running, then we should assign a job to it.
		if (!m_cAStarCalculator.m_bSearching)
		{
			m_cAStarCalculator.ASBF_Init(m_lpnWayPoints.empty() ? m_pNearestNode : m_lpnWayPoints.back(), m_pChasingNode, m_pChasingPlayer);	// make enemy become a tolerantable entity, or we can never find the path.
			m_cAStarCalculator.ASBF_Think();
		}
		else	// it is already handling a task. so call the Think()
		{
			for (int i = 0; i < 20; i++)	// think 20 times per frame.
			{
				m_cAStarCalculator.ASBF_Think();

				if (!m_cAStarCalculator.m_bSearching)	// if the result came out on halfway, stop the loop.
					break;
			}

			if (!m_cAStarCalculator.m_bSearching && m_cAStarCalculator.m_bAStarFound && !m_bOnLadder)	// the result is out, if there is one. you can't use a waypoint change while climbing a ladder.
			{
				// need a flag to determind whether this is a new built path.
				bool bNewPath = m_lpnWayPoints.empty();

				// the naming of list::splice() is totally wrong. it is just a function transfering elements. stupid STL.
				m_lpnWayPoints.splice(m_lpnWayPoints.cend(), m_cAStarCalculator.m_lpResultAsNodes);

				// after linking two lists, we need to simplify the path. remove all path sleeve.
				unsigned uIdJunction = 99999;
				for (auto base = m_lpnWayPoints.cbegin(); base != m_lpnWayPoints.cend(); base++)
				{
					auto check = base;
					check++;	// start with base + 1, since everything before base must already compared with base.

					while (check != m_lpnWayPoints.cend())
					{
						if (*base == *check)
						{
							uIdJunction = (*check)->m_uIndex;
							break;	// find the earliest loop junction.
						}
						else
						{
							check++;
						}
					}

					if (uIdJunction != 99999)
						break;
				}

				bool bShouldEat = false;
				for (auto iterator = m_lpnWayPoints.cbegin(); iterator != m_lpnWayPoints.cend(); /*DON'T STEP INCREASE HERE!*/)
				{
					if (uIdJunction == 99999)	// we don't need to eat anything if there are no path sleeve existed.
						break;

					if ((*iterator)->m_uIndex == uIdJunction)
						bShouldEat = !bShouldEat;

					if (!bShouldEat)
					{
						iterator++;	// manually increase iterator.
						continue;
					}

					iterator = m_lpnWayPoints.erase(iterator);	// erase function returns the next element of the one being deleted.
				}

				// LUNA: this part is disabled due to we decided to use elongate method rather then replace method.
				// these codes are useful in replace & recalculate method, but totally useless and efficiency-wasting in elongate method.
				// I won't delete it because I thought we might make another use of them.
				// ADD: fuck my life, I found the usage of this just 2 mins after I disable them. these codes should be applied on new built path.
				if (bNewPath)
				{
					// since there is a lag between the start and end of calculation, both bot and emeny could have already change their position.
					// thus, if bot is already departed for a distance, we should remove that part from calculated result.
					unsigned uDeathMarker = 99999;
					float flDis = 0, flLastDis = 99999;
					CWPNode* pLastNode = m_lpnWayPoints.front();
					for (auto pNode : m_lpnWayPoints)
					{
						// if player is standing on this node...
						if (pNode->m_pOccupyingEnt == this)
						{
							uDeathMarker = pNode->m_uIndex;
							break;
						}

						flDis = (pNode->m_vecOrigin - pev->origin).LengthSquared();

						if (flDis < flLastDis)	// it means that we are getting close to player.
						{
							flLastDis = flDis;
							pLastNode = pNode;
						}
						else	// getting far again. which means player probably standing between this two nodes.
						{
							uDeathMarker = pLastNode->m_uIndex;

							// anyway, as a alternative option, we shouldn't break here.
							// this line will be trigger due to some corner turn.
							// break;
							// LUNA: TESTED, break here will trigger bots forward-backward.
						}
					}

					// we got some nodes to be removed.
					if (uDeathMarker != 99999)
					{
						while (!m_lpnWayPoints.empty() && m_lpnWayPoints.front()->m_uIndex != uDeathMarker)
							m_lpnWayPoints.pop_front();	// eat from head, until we got the marker point.
					}

					// last pop, remove the DeathMarker.
					m_lpnWayPoints.pop_front();	// LUNA: I think it is safe here, since a result list must at least contain a m_pSrc and m_pEnd.
				}
			}

			// USAGI: now a new job, shorten our path. no rush, we can just simplify our node ahead.
			// actually it's under the consideration of efficiency and gaming fps.
			// we begin our work if there are 3 more nodes ahead.
			// note that this simplification could cause generation of unproper path, e.g. a path requires bot walks and floats in the air.
			if (m_lpnWayPoints.size() >= 4)
			{
				auto iterSrc = m_lpnWayPoints.cbegin(); iterSrc++;	// the first one, a.k.a. src, is the node toward which bot will walk.
				auto iterMeta = iterSrc; iterMeta++;	// this is the node we're consider whether we should get it removed.
				auto iterEnd = iterMeta; iterEnd++;	// this is our trace end.

				// only do this simplification when no ladder is on the corner.
				if (!((*iterMeta)->m_bitsNodeFlags & WP_N_FL_LADDER))
				{
					UTIL_TraceHull((*iterSrc)->m_vecOrigin, (*iterEnd)->m_vecOrigin, dont_ignore_monsters, head_hull, edict(), &tr);

					if ((tr.flFraction >= 1.0f || (m_pChasingPlayer && ENTINDEX(tr.pHit) == m_pChasingPlayer->entindex()))	// if tracehull hits enemy, that's fine.
						&& !tr.fStartSolid && !tr.fAllSolid && tr.fInOpen)	// make sure we're not penetrating anything.
					{
						m_lpnWayPoints.erase(iterMeta);	// this proves the metanode is useless, we should remove it.
					}
				}
			}

			// it is necessary that thing about whether our next node is really accessable, especially when it is not on the same height with us.
			if (!m_bOnLadder && m_lpnWayPoints.size() > 0 && m_flTimeNextNodeAccessibilityCheck < gpGlobals->time)
			{
				if (fabsf(m_lpnWayPoints.front()->m_vecOrigin.z - pev->origin.z) <= WP_STEP_HEIGHT + 0.1f)
					UTIL_TraceLine(pev->origin, m_lpnWayPoints.front()->m_vecOrigin, dont_ignore_monsters, ignore_glass, edict(), &tr);
				else
					tr.flFraction = 0;	// if the two points even not in the same height, we don't bother to take a trace check, just simply recalc.

				if (tr.flFraction < 1.0f || tr.fStartSolid || (tr.pHit && m_pChasingPlayer && ENTINDEX(tr.pHit) != m_pChasingPlayer->entindex()))	// it means our accessbility toward next node could have some problem.
					m_lpnWayPoints.clear();	// we have to delete them all. it's completely useless if we can't take use of it.

				// give a default cool down.
				m_flTimeNextNodeAccessibilityCheck = gpGlobals->time + RANDOM_FLOAT(7, 9);
			}

			// start map running! no matter we're currently using the old data, or the new one, this part should be the same.
			if (!m_lpnWayPoints.empty())
			{
				if (!m_lpnWayPoints.front()->m_pOccupyingEnt || m_lpnWayPoints.front()->m_pOccupyingEnt == m_pChasingPlayer || m_lpnWayPoints.front()->m_pOccupyingEnt == this)
					m_vecGoal = m_lpnWayPoints.front()->m_vecOrigin;	// only walk into this node if no one else is there.
				else
				{
					CWPNode* pnAlt = m_lpnWayPoints.front()->FindAvailable();	// or we should find an alternative node.

					if (pnAlt)
						m_vecGoal = pnAlt->m_vecOrigin;
					else
						m_vecGoal = m_vecTargetLastSeenOrigin;
				}

				if (fabsf(m_lpnWayPoints.front()->m_vecOrigin.z - pev->origin.z) < 5.0f && (m_lpnWayPoints.front()->m_vecOrigin - pev->origin).LengthSquared() < 256.0f)
				{
					m_lpnWayPoints.pop_front();	// we're so close to this node. remove it to the next.
					m_flTimeNextNodeAccessibilityCheck = gpGlobals->time + RANDOM_FLOAT(7, 9);	// if we are able to remove a node, it means the accessibility is currently fine for us.
				}
			}
			else
				m_vecGoal = m_vecTargetLastSeenOrigin;	// "wait, I am sorry, where is him you just said ?!"
		}
	}
}

void CBot::ActJumpAndDuck(void)
{
	// jump key should never held longer than 1 frame.
	if (pev->button & IN_JUMP)
		pev->button &= ~IN_JUMP;

	// jump system.
	TraceResult tr, tr2;
	UTIL_MakeVectors(Vector(0, pev->v_angle.y));
	UTIL_TraceLine(pev->origin - Vector(0, 0, WP_STEP_HEIGHT), pev->origin + gpGlobals->v_forward * 48.0f, dont_ignore_monsters, dont_ignore_glass, edict(), &tr2);	// test from foot(subtract the stairs height) to front of hip.

	if (tr2.flFraction < 1.0f)	// only run second test if the first test actually hit something.
		UTIL_TraceLine(pev->origin + Vector(0, 0, WP_JUMP_CROUCH_HEIGHT - 36.0f), pev->origin + Vector(0, 0, WP_JUMP_CROUCH_HEIGHT - 36.0f) + gpGlobals->v_forward * 48.0f, dont_ignore_monsters, dont_ignore_glass, edict(), &tr);	// test directly forward. test on the line where maxium jump height can be reached.
	else
		tr.flFraction = 0;

	// these are the situations which bot should jump.
	if (!m_bOnLadder &&	// we shouldn't jump while we climbing ladders, that's DANGEROUS.
		((tr.flFraction >= 1.0f && tr2.flFraction < 1.0f && m_flNextJumpAttempt <= gpGlobals->time) ||	// a jumpable floor is in front of you. very likely.
		(m_pNearestNode->m_bitsNodeFlags & WP_N_FL_JUMP)))	// or, there's a jump flag on your node.
	{
		pev->button |= IN_JUMP;
		m_flNextJumpAttempt = gpGlobals->time + 1.5f;
		m_flTimeJumpDuck = gpGlobals->time;		// without any delay. I don't know how much time we human take.
	}

	// but something special only require a space bar hit, rather than skilled jump.
	if (m_flTimeEnforceJump > 0 && m_flTimeEnforceJump <= gpGlobals->time)
	{
		pev->button |= IN_JUMP;

		if (m_bOnLadder)
			m_flTimeEnforceJump = gpGlobals->time + 10.0f;
		else
			m_flTimeEnforceJump = 0;
	}

	// jump-duck
	if (m_flTimeJumpDuck > 0 && m_flTimeJumpDuck <= gpGlobals->time)
	{
		m_flTimeJumpDuck = 0;
		m_flTimeDuckRelease = gpGlobals->time + 0.2f;
		pev->button |= IN_DUCK;
	}
	else if (m_flTimeDuckRelease > 0 && m_flTimeDuckRelease <= gpGlobals->time)
	{
		m_flTimeDuckRelease = 0;
		pev->button &= ~IN_DUCK;
	}

	// duck nodes. jump-duck has a higher priority than regular ducking.
	else if (m_pNearestNode->m_bitsNodeFlags & WP_N_FL_CROUCH)
	{
		pev->button |= IN_DUCK;
	}
	else if (m_flTimeJumpDuck <= 0 && m_flTimeDuckRelease <= 0)
	{
		pev->button &= ~IN_DUCK;
	}
}

void CBot::ActForwardingButton(void)
{
	// if we are close to our goal, that's no necessary to press W.
	if ((pev->origin - m_vecGoal).LengthSquared() > 16.0f * 16.0f)
	{
		m_flForwardSpeed = pev->maxspeed;
		pev->button |= IN_FORWARD;
	}
	else
	{
		m_flForwardSpeed = pev->maxspeed / 2.0f;
		pev->button &= ~IN_FORWARD;
	}
}

void CBot::ChooseViewAngle(void)
{
	// UNDONE: this is the model angle, and it is not necessary to make it equal to m_vecRPMVAngle. this angle should only related to aiming enemies.

	if (m_pEnemy)
		m_vecSeeingOrg = m_pEnemy->BodyTarget(pev->origin);
	else
		m_vecSeeingOrg = m_vecGoal;
}

void CBot::ActViewAngle(void)
{
	// adjust all body and view angles to face an absolute vector
	Vector vecDir = (m_vecSeeingOrg - EyePosition()).VectorAngles() - pev->punchangle;	// LUNA: in order to control the gun, we should subtract punchangle(recoil)
	vecDir.x *= -1.0f; // invert for engine

	Vector vecDeviation = (vecDir - pev->v_angle);

	vecDir.ClampAngles();
	vecDeviation.ClampAngles();

	// SyPB Pro P.37 - Aim OS
	bool bGodAiming = false;

	// SyPB Pro P.40 - Aim OS improve
	if (m_pEnemy && !FNullEnt(m_pEnemy->edict()))
	{
		if (FInViewCone(m_pEnemy->BodyTarget(pev->origin)))
		{
			if (m_pActiveItem->m_iId == WEAPON_AWP || m_pActiveItem->m_iId == WEAPON_SCOUT)
				bGodAiming = true;
			else if (m_iTeam == TEAM_ZOMBIE)	// you know the drill.
				bGodAiming = true;
		}
	}

	if (bGodAiming)
		pev->v_angle = vecDir;
	else
	{
		Vector vecSpringStiffness(4.0f, 4.0f, 0.0f);  // SyPB Pro P.34 - Game think change

		// SyPB Pro P.40 - Aim OS improve
		if (m_pEnemy && !FNullEnt(m_pEnemy->edict()))
		{
			if (FInViewCone(m_vecSeeingOrg))
				vecSpringStiffness = Vector(5.0f, 5.0f, 0.0f);
			else
				vecSpringStiffness = Vector(10.0f, 10.0f, 0.0f);
		}
		else if (!FInViewCone(m_vecSeeingOrg))
			vecSpringStiffness = Vector(8.0f, 8.0f, 0.0f);

		Vector vecStiffness = g_vecZero;

		m_vecIdealViewAngle = Vector(vecDir.x, vecDir.y);
		m_vecTargetingAngularSpeed.ClampAngles();
		m_vecIdealViewAngle.ClampAngles();

		if (m_pEnemy && !FNullEnt(m_pEnemy->edict()))	// LUNA: I reduce it to only check whether that is the entity we want to shoot.
		//if (m_aimFlags & (AIM_ENEMY | AIM_ENTITY | AIM_GRENADE | AIM_LASTENEMY) || GetCurrentTask()->taskID == TASK_DESTROYBREAKABLE)
		{
			m_flLastTargeting = gpGlobals->time;
			m_vecInterferedViewAngle = m_vecIdealViewAngle;

			//if (IsValidPlayer(m_enemy))
			// SyPB Pro P.40 - NPC Fixed
			if (m_pEnemy && !FNullEnt (m_pEnemy->edict()))
			{
				m_vecTargetingAngularSpeed = ((m_vecSeeingOrg - pev->origin + 1.5f * m_flFrameInterval * (1.0f * m_pEnemy->pev->velocity) - 0.0f * gpGlobals->frametime * pev->velocity).VectorAngles() - (m_vecSeeingOrg - pev->origin).VectorAngles()) * 0.45f * 2.2f/*multiple aiming speed factor, e.g. bot skill, right here.*/;

				if (m_vecAngularDeviation.LengthSquared() < 5.0f*5.0f)
					vecSpringStiffness = (5.0f - m_vecAngularDeviation.Length()) * 0.25f /*multiple bot skill here.*/ * vecSpringStiffness + vecSpringStiffness;

				m_vecTargetingAngularSpeed.x = -m_vecTargetingAngularSpeed.x;

				if (pev->fov < 90 && m_vecTargetingAngularSpeed.LengthSquared() >= 5.0f*5.0f)
					vecSpringStiffness = vecSpringStiffness * 2.0f;

				m_vecTargetingAngularSpeed.ClampAngles();
			}
			else
				m_vecTargetingAngularSpeed = g_vecZero;

			vecStiffness = vecSpringStiffness * (0.2f + /*replace 100.0f by bot skill here.*/100.0f / 125.0f);
		}
		else
		{
			// is it time for bot to randomize the aim direction again (more often where moving) ?
			if (m_flTimeInterfereAiming < gpGlobals->time && ((pev->velocity.LengthSquared() > 1.0f && m_vecAngularDeviation.LengthSquared() < 5.0f*5.0f) || m_vecAngularDeviation.LengthSquared() < 1.0f))
			{
				// randomize targeted location a bit (slightly towards the ground)
				m_vecInterferedViewAngle = m_vecIdealViewAngle + Vector(RANDOM_FLOAT(-2.0f, 2.0f), RANDOM_FLOAT(-2.0f, 2.0f));

				// set next time to do this
				m_flTimeInterfereAiming = gpGlobals->time + RANDOM_FLOAT(0.4f, 0.5f);
			}

			float flStiffnessMultiplier = 0.35f;

			// take in account whether the bot was targeting someone in the last N seconds
			if (gpGlobals->time - (m_flLastTargeting + 0.5f) < 2.0f)
			{
				flStiffnessMultiplier = 1.0f - (gpGlobals->time - m_flLastFired) * 0.1f;

				// don't allow that stiffness multiplier less than zero
				if (flStiffnessMultiplier < 0.0f)
					flStiffnessMultiplier = 0.5f;
			}

			// also take in account the remaining deviation (slow down the aiming in the last 10?
			if (/*bot skill check here. m_skill >= 80 && */(m_vecAngularDeviation.LengthSquared() < 10.0f*10.0f))
				flStiffnessMultiplier *= m_vecAngularDeviation.Length() * 0.1f;

			// slow down even more if we are not moving
			if (/*bot skill check here. m_skill < 80 && */pev->velocity.LengthSquared() < 1.0f/*bot task check here. && GetCurrentTask()->taskID != TASK_CAMP && GetCurrentTask()->taskID != TASK_FIGHTENEMY*/)
				flStiffnessMultiplier *= 0.5f;

			// but don't allow getting below a certain value
			if (flStiffnessMultiplier < 0.35f)
				flStiffnessMultiplier = 0.35f;

			vecStiffness = vecSpringStiffness * flStiffnessMultiplier; // increasingly slow aim

			// no target means no angular speed to take in account
			m_vecTargetingAngularSpeed = g_vecZero;
		}

		// compute randomized angle deviation this time
		m_vecAngularDeviation = m_vecInterferedViewAngle + m_vecTargetingAngularSpeed - pev->v_angle;
		m_vecAngularDeviation.ClampAngles();

		// spring/damper model aiming
		m_vecViewAngularSpeed.x = (vecStiffness.x * m_vecAngularDeviation.x);
		m_vecViewAngularSpeed.y = (vecStiffness.y * m_vecAngularDeviation.y);

		// move the aim cursor
		pev->v_angle += m_flFrameInterval * Vector(m_vecViewAngularSpeed.x, m_vecViewAngularSpeed.y, 0);
		pev->v_angle.ClampAngles();
	}

	// these are old time debug codes
	/*pev->v_angle = (m_vecSeeingOrg - (m_vecPreOrg + pev->view_ofs)).VectorAngles();
	pev->v_angle.ClampAngles();
	pev->v_angle.x *= -1.0f;*/

	// set the body angles to point the gun correctly
	pev->angles.x = -pev->v_angle.x * (1.0f / 3.0f);
	pev->angles.y = pev->v_angle.y;

	pev->v_angle.ClampAngles();
	pev->angles.ClampAngles();

	pev->angles.z = pev->v_angle.z = 0.0f; // ignore Z component
}

void CBot::GhostThink(void)
{
	if (!m_bGhost || m_flTimeNextGhostThink >= gpGlobals->time)
		return;

	m_flTimeNextGhostThink = gpGlobals->time + 0.002f;

	// set a time limit.
	if (m_flTimeResetGhostSpawn <= 0)
		m_flTimeResetGhostSpawn = gpGlobals->time + 15.0f;

	// we can't risk that some client.dll with large lag could make a melee attack.
	m_flNextAttack = 99999;

	// in this phase, we don't want to start using spawn point pool.
	if (g_pGameRules->m_iRoundPhase != CHalfLifeMultiplay::ROUND_STARTED)
		return;

	// we need to teleport to some place first.
	// LUNA: I made a plan for worst situation at which no regions in the map.

	if (m_flTimeResetGhostSpawn > 0 && m_flTimeResetGhostSpawn < gpGlobals->time)
	{
		m_lstGhostRespawnRegionClosed.clear();
		m_lstGhostRespawnNodeCandidates.clear();
		m_lstGhostRespawnRegionCandidates.clear();

		m_flTimeResetGhostSpawn = gpGlobals->time + 15.0f;
	}

	if (!m_lstGhostRespawnRegionClosed.empty() && m_pChasingNode->m_prParent != m_lstGhostRespawnRegionClosed.front())	// if the player we're chasing is changing his location, we should attempt to empty all our spawn location candidates as well.
	{
		m_lstGhostRespawnRegionClosed.clear();
		m_lstGhostRespawnNodeCandidates.clear();
		m_lstGhostRespawnRegionCandidates.clear();
	}

	if (m_lstGhostRespawnNodeCandidates.empty() && m_lstGhostRespawnRegionCandidates.empty())	// if everything is empty, rebuild region-based searching chain first.
	{
		if (m_pChasingNode->m_prParent)	// if region system is working.
		{
			CWPRegion* pRegion = m_pChasingNode->m_prParent;

			// empty the trashcan.
			m_lstGhostRespawnRegionClosed.clear();

			// since the definition of regions is all node inside could see each other, there is no point to attempting spawn in the current region.
			m_lstGhostRespawnRegionClosed.push_back(pRegion);

			// but what we should do is add his nearby regions.
			for (unsigned i = 0; i < pRegion->m_uKinCounts; i++)
				m_lstGhostRespawnRegionCandidates.push_back((CWPRegion*)pRegion->m_rgpnNextKins[i]);
		}
		else
			m_lstGhostRespawnNodeCandidates.push_back(m_pChasingNode);
	}

	if (m_lstGhostRespawnNodeCandidates.empty() && !m_lstGhostRespawnRegionCandidates.empty())	// this means that this map has region databse.
	{
		// add all nodes belong to this region to node candidate list.
		for (auto node : m_lstGhostRespawnRegionCandidates.front()->m_lstnChildren)
		{
			m_lstGhostRespawnNodeCandidates.push_back(node);
		}

		// add all nearby regions into list.
		for (unsigned i = 0; i < m_lstGhostRespawnRegionCandidates.front()->m_uKinCounts; i++)
		{
			bool bClosed = false;

			for (auto trash : m_lstGhostRespawnRegionClosed)	// check whether this candidate region is already checked.
			{
				if (trash == m_lstGhostRespawnRegionCandidates.front()->m_rgpnNextKins[i])
				{
					bClosed = true;
					break;
				}
			}

			if (bClosed)
				continue;

			m_lstGhostRespawnRegionCandidates.push_back((CWPRegion*)m_lstGhostRespawnRegionCandidates.front()->m_rgpnNextKins[i]);
		}

		// move checked region into trashcan.
		m_lstGhostRespawnRegionClosed.splice(m_lstGhostRespawnRegionClosed.cend(), m_lstGhostRespawnRegionCandidates, m_lstGhostRespawnRegionCandidates.cbegin());
	}

	if (!m_lstGhostRespawnNodeCandidates.empty())
	{
		// force bot ducking.
		pev->flags |= FL_DUCKING;
		SET_SIZE(edict(), Vector(-16.0f, -16.0f, -18.0f), Vector(16.0f, 16.0f, 32.0f));
		pev->view_ofs = Vector(0.0, 0.0, 12.0);

		// then teleport
		pev->origin = m_lstGhostRespawnNodeCandidates.front()->m_vecOrigin/*m_pChasingNode->m_vecOrigin*/;
		//SET_ORIGIN(edict(), /*m_pChasingNode->m_vecOrigin*/m_lstGhostRespawnNodeCandidates.front()->m_vecOrigin);

		// remove the first one.
		m_lstGhostRespawnNodeCandidates.pop_front();
	}

	CBasePlayer* pPlayer = nullptr;
	TraceResult tr;
	bool bCanRespawn = true;

	if (IsStuck())
	{
		bCanRespawn = false;
	}

	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		if (!bCanRespawn)	// with the knowledge of cannot spawn but still waste time in traceline is very stupid.
			break;

		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || !pPlayer->IsAvailable() || !pPlayer->IsAlive() || i == entindex())
			continue;

		if (pPlayer->m_iTeam == TEAM_ZOMBIE)
			continue;

		if ((pPlayer->pev->origin - pev->origin).LengthSquared() < cvar_spawndistance.value * cvar_spawndistance.value)	// too close
		{
			bCanRespawn = false;
			break;
		}

		UTIL_TraceLine(pPlayer->EyePosition(), pev->origin, ignore_monsters, ignore_glass, pPlayer->edict(), &tr);

		if (tr.flFraction >= 1.0f)	// humans can see.
		{
			bCanRespawn = false;
			break;
		}
	}

	if (bCanRespawn)	// attempt to spawn if it can.
	{
		SetGhost(false);

		m_lstGhostRespawnNodeCandidates.clear();
		m_lstGhostRespawnRegionCandidates.clear();
		m_lstGhostRespawnRegionClosed.clear();

		m_flTimeNextGhostThink = -1;
		m_flTimeResetGhostSpawn = 0;
		return;
	}
}

void CBot::ActAttack(void)
{
	if (!m_pActiveItem)
		return;

	if (m_iTeam == TEAM_ZOMBIE)
		m_iCombatScheme = COMBAT_MELEE;
	else if (m_iTeam == TEAM_HUMAN)	// UNDONE
		m_iCombatScheme = COMBAT_AUTOMATIC_FIREARM;

	if (m_flTimeShootAttempt <= gpGlobals->time)
	{
		m_flTimeShootAttempt = gpGlobals->time + 0.05f;

		switch (m_iCombatScheme)
		{
			case COMBAT_MELEE:
			{
				TraceResult tr;
				UTIL_MakeVectors(pev->v_angle + pev->punchangle);
				
				int bitsButtonToPress = 0;
				if (((CBasePlayerWeapon*)m_pActiveItem)->m_flNextSecondaryAttack <= 0)
				{
					bitsButtonToPress = IN_ATTACK2;
					UTIL_TraceHull(GetGunPosition(), GetGunPosition() + gpGlobals->v_forward * g_rgflPlayerClassStabDist[m_iClass], dont_ignore_monsters, head_hull, edict(), &tr);
				}
				else if (((CBasePlayerWeapon*)m_pActiveItem)->m_flNextPrimaryAttack <= 0)
				{
					bitsButtonToPress = IN_ATTACK;
					UTIL_TraceHull(GetGunPosition(), GetGunPosition() + gpGlobals->v_forward * g_rgflPlayerClassSlashDist[m_iClass], dont_ignore_monsters, head_hull, edict(), &tr);
				}
				else
					tr.flFraction = 1.0f;

				if (tr.flFraction < 1.0f && !FNullEnt(tr.pHit))
				{
					if (FClassnameIs(tr.pHit, "func_breakable"))
						pev->button |= bitsButtonToPress;

					if (FClassnameIs(tr.pHit, "player") && g_pGameRules->PlayerRelationship(this, CBaseEntity::Instance(tr.pHit)) == GR_NOTTEAMMATE)
						pev->button |= bitsButtonToPress;
				}
				else
					pev->button &= ~(IN_ATTACK | IN_ATTACK2);

				break;
			}
			default:
			{
				TraceResult tr;
				UTIL_MakeVectors(pev->v_angle + pev->punchangle);

				int bitsButtonToPress = 0;
				if (((CBasePlayerWeapon*)m_pActiveItem)->m_flNextPrimaryAttack <= 0)
				{
					bitsButtonToPress = IN_ATTACK;
					UTIL_TraceLine(GetGunPosition(), GetGunPosition() + gpGlobals->v_forward * 8192.0f, dont_ignore_monsters, dont_ignore_glass, edict(), &tr);
				}
				else
					tr.flFraction = 1.0f;

				if (tr.flFraction < 1.0f && !FNullEnt(tr.pHit))
				{
					if (FClassnameIs(tr.pHit, "func_breakable"))
						pev->button |= bitsButtonToPress;

					if (FClassnameIs(tr.pHit, "player") && g_pGameRules->PlayerRelationship(this, CBaseEntity::Instance(tr.pHit)) == GR_NOTTEAMMATE)
						pev->button |= bitsButtonToPress;
				}
				else
					pev->button &= ~IN_ATTACK;

				// awp, scout, sg550, g3sg1
				if ((1 << m_pActiveItem->m_iId) & ((1 << WEAPON_AWP) | (1 << WEAPON_SCOUT) | (1 << WEAPON_SG550) | (1 << WEAPON_G3SG1)))
				{
					// if bot wants to fire these sniper rifle, zoom them first.
					if ((pev->button & IN_ATTACK))
					{
						// if not zooming
						if (m_iFOV > 40)
							((CBasePlayerWeapon*)m_pActiveItem)->SecondaryAttack();
					}

					// if not attempt to shooting
					else if (m_iFOV < 90)
					{
						// two more calls to reset to normal fov.
						((CBasePlayerWeapon*)m_pActiveItem)->SecondaryAttack();
						((CBasePlayerWeapon*)m_pActiveItem)->SecondaryAttack();
					}
				}

				break;
			}
		}
	}
}
