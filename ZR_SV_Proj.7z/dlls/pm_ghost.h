#pragma once
#ifndef _PM_GHOST_H_
#define _PM_GHOST_H_


void PM_PhyentsFilter(struct playermove_s* ppmove);















#endif