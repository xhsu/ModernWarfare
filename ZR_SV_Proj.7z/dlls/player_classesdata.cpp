/*

Zombie Riot Rebirth Project
Based on ZombieRiot version 1.18

Original Author:
	DSHGFHDS

Transcription Coder of C++ Integrated Version:
	Luna the Reborn, the disciple of DSHGFHDS, in memory of him.

*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"

char* g_rgszPlayerClassNames[CLASSES_COUNTS] =
{
	"UNASSIGNED",	// CLASS_UNASSIGNED

	// HUMANS
	"Commando",		// CLASS_HUMAN_LUNA_COMMANDO = 1,
	"Support",		// CLASS_HUMAN_MAT_SUPPORT,
	"Sharpshooter",	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	"Zweihander",	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	"Steel Helmet",	// CLASS_ZOMBIE_STEEL_HELMET
	"Wild Fire",	// CLASS_ZOMBIE_WILD_FIRE
	"Beast",		// CLASS_ZOMBIE_BEAST
	"Poison Evil",	// CLASS_ZOMBIE_POISON_EVIL
};

char* g_rgszPlayerClassModels[CLASSES_COUNTS] =
{
	"stormtrooper",	// CLASS_UNASSIGNED

	// HUMANS
	"stormtrooper",	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	"juggernaut",	// CLASS_HUMAN_MAT_SUPPORT,
	"bomber",		// CLASS_HUMAN_BLUE_SHARPSHOOTER
	"berserker",	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	"zr_super",		// CLASS_ZOMBIE_STEEL_HELMET
	"zr_wildfire",	// CLASS_ZOMBIE_WILD_FIRE
	"zr_beast",		// CLASS_ZOMBIE_BEAST
	"zr_poisonevil",// CLASS_ZOMBIE_POISON_EVIL
};

char* g_rgszPlayerClassModelsPath[CLASSES_COUNTS] =
{
	"models/player/stormtrooper/stormtrooper.mdl",	// CLASS_UNASSIGNED

	// HUMANS
	"models/player/stormtrooper/stormtrooper.mdl",	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	"models/player/juggernaut/juggernaut.mdl",		// CLASS_HUMAN_MAT_SUPPORT,
	"models/player/bomber/bomber.mdl",				// CLASS_HUMAN_BLUE_SHARPSHOOTER
	"models/player/berserker/berserker.mdl",		// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	"models/player/zr_super/zr_super.mdl",			// CLASS_ZOMBIE_STEEL_HELMET
	"models/player/zr_wildfire/zr_wildfire.mdl",	// CLASS_ZOMBIE_WILD_FIRE
	"models/player/zr_beast/zr_beast.mdl",			// CLASS_ZOMBIE_BEAST
	"models/player/zr_poisonevil/zr_poisonevil.mdl",// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgiPlayerClassMaxHealth[CLASSES_COUNTS] =
{
	100.0f,	// CLASS_UNASSIGNED

	// HUMANS
	2000.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	4000.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	1200.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	1500.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	3000.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	250.0f,		// CLASS_ZOMBIE_WILD_FIRE
	1000.0f,	// CLASS_ZOMBIE_BEAST
	2000.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgiPlayerClassMaxArmor[CLASSES_COUNTS] =
{
	100.0f,	// CLASS_UNASSIGNED

	// HUMANS
	1000.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	4000.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	600.0f,		// CLASS_HUMAN_BLUE_SHARPSHOOTER
	750.0f,		// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	3000.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	250.0f,		// CLASS_ZOMBIE_WILD_FIRE
	1000.0f,	// CLASS_ZOMBIE_BEAST
	2000.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

char* g_rgszPlayerClassKnifeVModel[CLASSES_COUNTS] =
{
	"models/v_knife.mdl",	// CLASS_UNASSIGNED

	// HUMANS
	"models/v_knife.mdl",	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	"models/v_knife.mdl",	// CLASS_HUMAN_MAT_SUPPORT,
	"models/v_knife.mdl",	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	"models/v_knife.mdl",	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	"models/zombieriot/v_super.mdl",		// CLASS_ZOMBIE_STEEL_HELMET
	"models/zombieriot/v_wildfire.mdl",		// CLASS_ZOMBIE_WILD_FIRE
	"models/zombieriot/v_beast.mdl",		// CLASS_ZOMBIE_BEAST
	"models/zombieriot/v_poisonevil.mdl",	// CLASS_ZOMBIE_POISON_EVIL
};

char* g_rgszPlayerClassKnifePModel[CLASSES_COUNTS] =
{
	"models/p_knife.mdl",	// CLASS_UNASSIGNED

	// HUMANS
	"models/p_knife.mdl",	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	"models/p_knife.mdl",	// CLASS_HUMAN_MAT_SUPPORT,
	"models/p_knife.mdl",	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	"models/p_knife.mdl",	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	"",		// CLASS_ZOMBIE_STEEL_HELMET
	"",		// CLASS_ZOMBIE_WILD_FIRE
	"",		// CLASS_ZOMBIE_BEAST
	"",		// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassWalkSpeed[CLASSES_COUNTS] =
{
	300.0f,	// CLASS_UNASSIGNED

	// HUMANS
	245.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	190.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	230.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	240.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	200.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	260.0f,	// CLASS_ZOMBIE_WILD_FIRE
	280.0f,	// CLASS_ZOMBIE_BEAST
	245.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassGravity[CLASSES_COUNTS] =
{
	1.0f,	// CLASS_UNASSIGNED

	// HUMANS
	1.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	1.5f,	// CLASS_HUMAN_MAT_SUPPORT,
	1.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	1.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	1.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	1.0f,	// CLASS_ZOMBIE_WILD_FIRE
	1.0f,	// CLASS_ZOMBIE_BEAST
	1.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassSlashSpeed[CLASSES_COUNTS] =	// divide by 0.875 when hit.
{
	0.35f,	// CLASS_UNASSIGNED

	// HUMANS
	0.35f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	0.35f,	// CLASS_HUMAN_MAT_SUPPORT,
	0.35f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	0.35f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	0.6f,	// CLASS_ZOMBIE_STEEL_HELMET
	0.4f,	// CLASS_ZOMBIE_WILD_FIRE
	0.6f,	// CLASS_ZOMBIE_BEAST
	0.5f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassStabSpeed[CLASSES_COUNTS] =	// mul by 1.1 when hit.
{
	1.0f,	// CLASS_UNASSIGNED

	// HUMANS
	1.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	1.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	1.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	1.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	1.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	0.7f,	// CLASS_ZOMBIE_WILD_FIRE
	0.6f,	// CLASS_ZOMBIE_BEAST
	0.9f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassSlashDist[CLASSES_COUNTS] =
{
	48.0f,	// CLASS_UNASSIGNED

	// HUMANS
	48.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	48.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	48.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	48.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	48.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	48.0f,	// CLASS_ZOMBIE_WILD_FIRE
	50.0f,	// CLASS_ZOMBIE_BEAST
	52.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassStabDist[CLASSES_COUNTS] =
{
	32.0f,	// CLASS_UNASSIGNED

	// HUMANS
	32.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	32.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	32.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	32.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	32.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	32.0f,	// CLASS_ZOMBIE_WILD_FIRE
	48.0f,	// CLASS_ZOMBIE_BEAST
	38.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassMeleeDmgMul[CLASSES_COUNTS] =
{
	1.0f,	// CLASS_UNASSIGNED

	// HUMANS
	1.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	1.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	1.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	1.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	10.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	3.5f,	// CLASS_ZOMBIE_WILD_FIRE
	3.0f,	// CLASS_ZOMBIE_BEAST
	2.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassDamageResistance[CLASSES_COUNTS] =
{
	1.0f,	// CLASS_UNASSIGNED

	// HUMANS
	1.0f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	1.1f,	// CLASS_HUMAN_MAT_SUPPORT,
	1.0f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	1.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	1.1f,	// CLASS_ZOMBIE_STEEL_HELMET
	1.0f,	// CLASS_ZOMBIE_WILD_FIRE
	1.0f,	// CLASS_ZOMBIE_BEAST
	1.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

float g_rgflPlayerClassKnockResistance[CLASSES_COUNTS] =
{
	1.0f,	// CLASS_UNASSIGNED

	// HUMANS
	2.5f,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	100.0f,	// CLASS_HUMAN_MAT_SUPPORT,
	2.5f,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	4.0f,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	10.0f,	// CLASS_ZOMBIE_STEEL_HELMET
	1.4f,	// CLASS_ZOMBIE_WILD_FIRE
	10.0f,	// CLASS_ZOMBIE_BEAST
	4.0f,	// CLASS_ZOMBIE_POISON_EVIL
};

const char* g_pszClawMiss[] = { "zombieriot/claw_miss_1.wav", "zombieriot/claw_miss_2.wav" };
const char* g_pszClawHitWall[] = { "zombieriot/claw_scrape_1.wav", "zombieriot/claw_scrape_2.wav", "zombieriot/claw_scrape_3.wav" };
const char* g_pszClawSlash[] = { "zombieriot/claw_hit_flesh_1.wav", "zombieriot/claw_hit_flesh_2.wav", "zombieriot/claw_hit_flesh_3.wav" };
const char* g_pszClawStab[] = { "zombieriot/zombie_slice_1.wav", "zombieriot/zombie_slice_2.wav" };
const char* g_pszZombieShot[] = { "zombieriot/been_shot_01.wav", "zombieriot/been_shot_02.wav", "zombieriot/been_shot_03.wav", "zombieriot/been_shot_04.wav" };
const char* g_pszZombieDeath[] = { "zombieriot/headless_1.wav", "zombieriot/headless_2.wav", "zombieriot/headless_3.wav", "zombieriot/headless_4.wav" };
const char* g_pszBossShot[] = { "zombieriot/bm_inj_04.wav", "zombieriot/bm_inj_05.wav", "zombieriot/bm_inj_06.wav", "zombieriot/bm_inj_07.wav" };
const char* g_pszBossDeath[] = { "zombieriot/bm_death_01.wav", "zombieriot/bm_death_02.wav", "zombieriot/bm_death_03.wav" };

const char* g_pszKnifeDeploy[] = { "weapons/knife_deploy1.wav" };
const char* g_pszKnifeMiss[] = { "weapons/knife_slash1.wav", "weapons/knife_slash2.wav" };
const char* g_pszKnifeHitWall[] = { "weapons/knife_hitwall1.wav" };
const char* g_pszKnifeSlash[] = { "weapons/knife_hit1.wav", "weapons/knife_hit2.wav", "weapons/knife_hit3.wav", "weapons/knife_hit4.wav" };
const char* g_pszKnifeStab[] = { "weapons/knife_stab.wav" };
const char* g_pszHumanShot[] = { "player/bhit_flesh-1.wav", "player/bhit_flesh-2.wav", "player/bhit_flesh-3.wav" };
const char* g_pszHumanDeath[] = { "player/die1.wav", "player/die2.wav", "player/die3.wav", "player/death6.wav" };

CSoundEfxSet* g_pcClawMissSoundSet = new CSoundEfxSet(g_pszClawMiss, ARRAYSIZE(g_pszClawMiss));
CSoundEfxSet* g_pcClawHitWallSoundSet = new CSoundEfxSet(g_pszClawHitWall, ARRAYSIZE(g_pszClawHitWall));
CSoundEfxSet* g_pcClawHitFleshSoundSet = new CSoundEfxSet(g_pszClawSlash, ARRAYSIZE(g_pszClawSlash));
CSoundEfxSet* g_pcClawStabSoundSet = new CSoundEfxSet(g_pszClawStab, ARRAYSIZE(g_pszClawStab));
CSoundEfxSet* g_pcZbPainSoundSet = new CSoundEfxSet(g_pszZombieShot, ARRAYSIZE(g_pszZombieShot));
CSoundEfxSet* g_pcZbDeathSoundSet = new CSoundEfxSet(g_pszZombieDeath, ARRAYSIZE(g_pszZombieDeath));
CSoundEfxSet* g_pcBossPainSoundSet = new CSoundEfxSet(g_pszBossShot, ARRAYSIZE(g_pszBossShot));
CSoundEfxSet* g_pcBossDeathSoundSet = new CSoundEfxSet(g_pszBossDeath, ARRAYSIZE(g_pszBossDeath));

CSoundEfxSet* g_pcKnifeDeploySoundSet = new CSoundEfxSet(g_pszKnifeDeploy, ARRAYSIZE(g_pszKnifeDeploy));
CSoundEfxSet* g_pcKnifeMissSoundSet = new CSoundEfxSet(g_pszKnifeMiss, ARRAYSIZE(g_pszKnifeMiss));
CSoundEfxSet* g_pcKnifeHitWallSoundSet = new CSoundEfxSet(g_pszKnifeHitWall, ARRAYSIZE(g_pszKnifeHitWall));
CSoundEfxSet* g_pcKnifeHitFleshSoundSet = new CSoundEfxSet(g_pszKnifeSlash, ARRAYSIZE(g_pszKnifeSlash));
CSoundEfxSet* g_pcKnifeStabSoundSet = new CSoundEfxSet(g_pszKnifeStab, ARRAYSIZE(g_pszKnifeStab));
CSoundEfxSet* g_pcHumanPainSoundSet = new CSoundEfxSet(g_pszHumanShot, ARRAYSIZE(g_pszHumanShot));
CSoundEfxSet* g_pcHumanDeathSoundSet = new CSoundEfxSet(g_pszHumanDeath, ARRAYSIZE(g_pszHumanDeath));

void PrecachePlayerClassSounds(void)
{
	PRECACHE_SOUND_ARRAY(g_pszZombieShot);
	PRECACHE_SOUND_ARRAY(g_pszZombieDeath);
	PRECACHE_SOUND_ARRAY(g_pszBossShot);
	PRECACHE_SOUND_ARRAY(g_pszBossDeath);
	PRECACHE_SOUND_ARRAY(g_pszHumanShot);
	PRECACHE_SOUND_ARRAY(g_pszHumanDeath);
}

void PrecachePlayerClassMeleeSounds(void)
{
	PRECACHE_SOUND_ARRAY(g_pszKnifeDeploy);
	PRECACHE_SOUND_ARRAY(g_pszKnifeMiss);
	PRECACHE_SOUND_ARRAY(g_pszKnifeHitWall);
	PRECACHE_SOUND_ARRAY(g_pszKnifeSlash);
	PRECACHE_SOUND_ARRAY(g_pszKnifeStab);
	PRECACHE_SOUND_ARRAY(g_pszClawMiss);
	PRECACHE_SOUND_ARRAY(g_pszClawHitWall);
	PRECACHE_SOUND_ARRAY(g_pszClawSlash);
	PRECACHE_SOUND_ARRAY(g_pszClawStab);
}

CSoundEfxSet* g_rgcPlayerClassPainSounds[CLASSES_COUNTS] =
{
	g_pcHumanPainSoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcHumanPainSoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcHumanPainSoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcHumanPainSoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcHumanPainSoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	g_pcBossPainSoundSet,	// CLASS_ZOMBIE_STEEL_HELMET
	g_pcBossPainSoundSet,	// CLASS_ZOMBIE_WILD_FIRE
	g_pcBossPainSoundSet,	// CLASS_ZOMBIE_BEAST
	g_pcBossPainSoundSet,	// CLASS_ZOMBIE_POISON_EVIL
};

CSoundEfxSet* g_rgcPlayerClassDeathSounds[CLASSES_COUNTS] =
{
	g_pcHumanDeathSoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcHumanDeathSoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcHumanDeathSoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcHumanDeathSoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcHumanDeathSoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	g_pcBossDeathSoundSet,	// CLASS_ZOMBIE_STEEL_HELMET
	g_pcBossDeathSoundSet,	// CLASS_ZOMBIE_WILD_FIRE
	g_pcBossDeathSoundSet,	// CLASS_ZOMBIE_BEAST
	g_pcBossDeathSoundSet,	// CLASS_ZOMBIE_POISON_EVIL
};

CSoundEfxSet* g_rgcPlayerClassMeleeDeploySounds[CLASSES_COUNTS] =
{
	g_pcKnifeDeploySoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcKnifeDeploySoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcKnifeDeploySoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcKnifeDeploySoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcKnifeDeploySoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	nullptr,	// CLASS_ZOMBIE_STEEL_HELMET
	nullptr,	// CLASS_ZOMBIE_WILD_FIRE
	nullptr,	// CLASS_ZOMBIE_BEAST
	nullptr,	// CLASS_ZOMBIE_POISON_EVIL
};

CSoundEfxSet* g_rgcPlayerClassMeleeMissSounds[CLASSES_COUNTS] =
{
	g_pcKnifeMissSoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcKnifeMissSoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcKnifeMissSoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcKnifeMissSoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcKnifeMissSoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	g_pcClawMissSoundSet,	// CLASS_ZOMBIE_STEEL_HELMET
	g_pcClawMissSoundSet,	// CLASS_ZOMBIE_WILD_FIRE
	g_pcClawMissSoundSet,	// CLASS_ZOMBIE_BEAST
	g_pcClawMissSoundSet,	// CLASS_ZOMBIE_POISON_EVIL
};

CSoundEfxSet* g_rgcPlayerClassMeleeHitWallSounds[CLASSES_COUNTS] =
{
	g_pcKnifeHitWallSoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcKnifeHitWallSoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcKnifeHitWallSoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcKnifeHitWallSoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcKnifeHitWallSoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	g_pcClawHitWallSoundSet,	// CLASS_ZOMBIE_STEEL_HELMET
	g_pcClawHitWallSoundSet,	// CLASS_ZOMBIE_WILD_FIRE
	g_pcClawHitWallSoundSet,	// CLASS_ZOMBIE_BEAST
	g_pcClawHitWallSoundSet,	// CLASS_ZOMBIE_POISON_EVIL
};

CSoundEfxSet* g_rgcPlayerClassMeleeSlashSounds[CLASSES_COUNTS] =
{
	g_pcKnifeHitFleshSoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcKnifeHitFleshSoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcKnifeHitFleshSoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcKnifeHitFleshSoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcKnifeHitFleshSoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	g_pcClawHitFleshSoundSet,	// CLASS_ZOMBIE_STEEL_HELMET
	g_pcClawHitFleshSoundSet,	// CLASS_ZOMBIE_WILD_FIRE
	g_pcClawHitFleshSoundSet,	// CLASS_ZOMBIE_BEAST
	g_pcClawHitFleshSoundSet,	// CLASS_ZOMBIE_POISON_EVIL
};

CSoundEfxSet* g_rgcPlayerClassMeleeStabSounds[CLASSES_COUNTS] =
{
	g_pcKnifeStabSoundSet,	// CLASS_UNASSIGNED

	// HUMANS
	g_pcKnifeStabSoundSet,	// CLASS_HUMAN_LUNA_COMMANDO = 1,
	g_pcKnifeStabSoundSet,	// CLASS_HUMAN_MAT_SUPPORT,
	g_pcKnifeStabSoundSet,	// CLASS_HUMAN_BLUE_SHARPSHOOTER
	g_pcKnifeStabSoundSet,	// CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	g_pcClawStabSoundSet,	// CLASS_ZOMBIE_STEEL_HELMET
	g_pcClawStabSoundSet,	// CLASS_ZOMBIE_WILD_FIRE
	g_pcClawStabSoundSet,	// CLASS_ZOMBIE_BEAST
	g_pcClawStabSoundSet,	// CLASS_ZOMBIE_POISON_EVIL
};