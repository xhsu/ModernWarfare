#pragma once
#ifndef _MENUS_H_
#define _MENUS_H_

// dummy
class CBasePlayer;

// menu list
typedef enum
{
	Menu_OFF,
	Menu_ChooseTeam,
	Menu_IGChooseTeam,
	Menu_ChooseAppearance,
	Menu_Radio1,
	Menu_Radio2,
	Menu_Radio3,
	Menu_ChooeseClasses,
	Menu_CWayPointMain,
	Menu_CWayPointAStar,
	Menu_CWayPointRegion1,
	Menu_CWayPointRegion2,
	Menu_CWayPointNodeFlags1,
	Menu_CWayPointNodeFlags2
}
Menu;

// call menu
extern void ShowMenu(CBasePlayer* pPlayer, int bitsValidSlots, int nDisplayTime, int fNeedMore, char* pszText);
extern void ShowVGUIMenu(CBasePlayer* pPlayer, int MenuType, int BitMask, char* szOldMenu);

// menu handler
extern void HandleMenu_ChooseAppearance(CBasePlayer* player, int slot);
extern BOOL HandleMenu_ChooseTeam(CBasePlayer* pPlayer, int slot);
extern void Radio1(CBasePlayer* player, int slot);
extern void Radio2(CBasePlayer* player, int slot);
extern void Radio3(CBasePlayer* player, int slot);
extern BOOL HandleRadioAliasCommands(CBasePlayer* pPlayer, const char* pszCommand);
extern void HandleMenu_ChooseClasses(CBasePlayer* pPlayer, int slot);





















































#endif