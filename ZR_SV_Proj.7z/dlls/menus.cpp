#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "gamerules.h"
#include "game.h"
#include "client.h"
#include "sypb/interface.h"
#include "menus.h"

extern int gmsgMoney;
extern int gmsgScoreInfo;
extern int gmsgTeamInfo;
extern int gmsgSpectator;

void ShowMenu(CBasePlayer* pPlayer, int bitsValidSlots, int nDisplayTime, int fNeedMore, char* pszText)
{
	MESSAGE_BEGIN(MSG_ONE, gmsgShowMenu, NULL, pPlayer->pev);
	WRITE_SHORT(bitsValidSlots);
	WRITE_CHAR(nDisplayTime);
	WRITE_BYTE(fNeedMore);
	WRITE_STRING(pszText);
	MESSAGE_END();
}

void ShowVGUIMenu(CBasePlayer* pPlayer, int MenuType, int BitMask, char* szOldMenu)
{
	if (pPlayer->m_bVGUIMenus == true || MenuType > MENU_MENUTYPE_MAX)
	{
		MESSAGE_BEGIN(MSG_ONE, gmsgVGUIMenu, NULL, pPlayer->pev);
		WRITE_BYTE(MenuType);
		WRITE_SHORT(BitMask);
		WRITE_CHAR(-1);
		WRITE_BYTE(0);
		WRITE_STRING(" ");
		MESSAGE_END();
	}
	else
		ShowMenu(pPlayer, BitMask, -1, 0, szOldMenu);
}

#define PLAYERMODEL_COUNT (sizeof(g_rgszPlayerClassModels) / sizeof(g_rgszPlayerClassModels[0]))

void HandleMenu_ChooseAppearance(CBasePlayer* player, int slot)
{
	if (player->m_iTeam == TEAM_ZOMBIE)
	{
		// zombie classes index starts from CLASS_ZOMBIE_FIRST, we need to add a base offset value.
		slot = slot - 1 + CLASS_ZOMBIE_FIRST;

		// now we can normally determind whether this value is resonable.
		if (slot < CLASS_ZOMBIE_FIRST || slot > CLASS_ZOMBIE_LAST)
		{
			slot = RANDOM_LONG(CLASS_ZOMBIE_FIRST, CLASS_ZOMBIE_LAST);
		}

		// player didn't choose a human class currently, let's help him.
		player->m_iNextHumanClass = (ZOMBIERIOT_CLASSES)RANDOM_LONG(CLASS_HUMAN_FIRST, CLASS_HUMAN_LAST);

		// he will continue to use this zombie class next respawn.
		player->m_iNextZombieClass = (ZOMBIERIOT_CLASSES)slot;
	}
	else if (player->m_iTeam == TEAM_HUMAN)
	{
		// wrong choice? doesn't matter.
		if (slot < CLASS_HUMAN_FIRST || slot > CLASS_HUMAN_LAST)
			slot = RANDOM_LONG(CLASS_HUMAN_FIRST, CLASS_HUMAN_LAST);

		// player didn't choose a zombie class currently, let's help him.
		player->m_iNextZombieClass = (ZOMBIERIOT_CLASSES)RANDOM_LONG(CLASS_ZOMBIE_FIRST, CLASS_ZOMBIE_LAST);

		// he will continue to use this human class next round.
		player->m_iNextHumanClass = (ZOMBIERIOT_CLASSES)slot;
	}
	else	// you can't choose a class when you're a spectator.
		slot = CLASS_UNASSIGNED;

	player->m_iClass = (ZOMBIERIOT_CLASSES)slot;
	player->m_iMenu = Menu_OFF;

	if (player->m_iJoiningState != JOINED)
	{
		if (player->m_iJoiningState == PICKINGTEAM)
		{
			player->m_iJoiningState = GETINTOGAME;
		}
	}
	else
		g_pGameRules->CheckWinConditions();

	player->pev->body = 0;
	player->SetPlayerModel();
}

BOOL HandleMenu_ChooseTeam(CBasePlayer* pPlayer, int slot)
{
	int team;
	int oldTeam;

	switch (slot)
	{
	default: return FALSE;

	case 1:
	{
		team = TEAM_ZOMBIE;
		break;
	}

	case 2:
	{
		team = TEAM_HUMAN;
		break;
	}

	case 3:
	{
		return FALSE;
	}

	case 5:
	{
		team = g_pGameRules->SelectDefaultTeam();

		if (team == TEAM_UNASSIGNED)
		{
			ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#All_Teams_Full");
			return FALSE;
		}

		break;
	}

	case 6:
	{
		if (!allow_spectators.value)
		{
			if (!FBitSet(pPlayer->pev->flags, FL_PROXY))
			{
				ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Cannot_Be_Spectator");
				CLIENT_COMMAND(ENT(pPlayer->pev), "slot10\n");
				return FALSE;
			}
		}

		if (pPlayer->m_iTeam == TEAM_SPECTATOR)
			return TRUE;

		if (pPlayer->m_iTeam != TEAM_UNASSIGNED)
		{
			if (pPlayer->pev->deadflag == DEAD_NO)
				ClientKill(pPlayer->edict());
		}

		pPlayer->RemoveAllItems(TRUE);

		if (pPlayer->m_iTeam != TEAM_SPECTATOR)
			UTIL_LogPrintf("\"%s<%i><%s><%s>\" joined team \"SPECTATOR\"\n", STRING(pPlayer->pev->netname), GETPLAYERUSERID(pPlayer->edict()), GETPLAYERAUTHID(pPlayer->edict()), g_pGameRules->GetTeam(pPlayer->m_iTeam));

		pPlayer->m_iTeam = TEAM_SPECTATOR;
		pPlayer->m_iJoiningState = JOINED;
		pPlayer->m_iAccount = 0;

		MESSAGE_BEGIN(MSG_ONE, gmsgMoney, NULL, pPlayer->pev);
		WRITE_LONG(pPlayer->m_iAccount);
		WRITE_BYTE(0);
		MESSAGE_END();

		MESSAGE_BEGIN(MSG_BROADCAST, gmsgScoreInfo);
		WRITE_BYTE(ENTINDEX(pPlayer->edict()));
		WRITE_SHORT((int)pPlayer->pev->frags);
		WRITE_SHORT(pPlayer->m_iDeaths);
		WRITE_SHORT(0);
		WRITE_SHORT(0);
		MESSAGE_END();

		pPlayer->m_pIntroCamera = NULL;
		pPlayer->m_bTeamChanged = true;

		MESSAGE_BEGIN(MSG_ALL, gmsgTeamInfo);
		WRITE_BYTE(ENTINDEX(pPlayer->edict()));
		WRITE_STRING(g_pGameRules->GetTeam(pPlayer->m_iTeam));
		MESSAGE_END();

		if (pPlayer->m_iTeam != TEAM_UNASSIGNED)
			pPlayer->SetScoreboardAttributes();

		edict_t * pentSpawnSpot = g_pGameRules->GetPlayerSpawnSpot(pPlayer);
		pPlayer->StartObserver(VARS(pentSpawnSpot)->origin, VARS(pentSpawnSpot)->angles);

		MESSAGE_BEGIN(MSG_ALL, gmsgSpectator);
		WRITE_BYTE(ENTINDEX(pPlayer->edict()));
		WRITE_BYTE(1);
		MESSAGE_END();

		if (fadetoblack.value)
			UTIL_ScreenFade(pPlayer, Vector(0, 0, 0), 0.001, 0, 0, 0);

		return TRUE;
	}
	}

	if (g_pGameRules->TeamFull(team))
	{
		if (team == TEAM_ZOMBIE)
			ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Zombies_Full");
		else
			ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Humans_Full");

		return FALSE;
	}

	if (g_pGameRules->TeamStacked(team, pPlayer->m_iTeam))
	{
		if (team == TEAM_ZOMBIE)
			ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Too_Many_Zombies");
		else
			ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Too_Many_Humans");

		return FALSE;
	}

	if (!pPlayer->IsBot() && team != TEAM_SPECTATOR)
	{
		if (!stricmp(humans_join_team.string, "HM"))
		{
			if (team != TEAM_HUMAN)
			{
				if (team == TEAM_HUMAN)
					ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Humans_Join_Team_Humans");
				else
					ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Humans_Join_Team_Zombies");

				return FALSE;
			}
		}
		else if (!stricmp(humans_join_team.string, "ZB"))
		{
			if (team != TEAM_ZOMBIE)
			{
				if (team == TEAM_HUMAN)
					ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Humans_Join_Team_Humans");
				else
					ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Humans_Join_Team_Zombies");

				return FALSE;
			}
		}
	}

	if (pPlayer->m_bTeamChanged)
	{
		if (pPlayer->pev->deadflag != DEAD_NO)
		{
			ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Only_1_Team_Change");
			return FALSE;
		}
	}

	if (pPlayer->m_iTeam == TEAM_SPECTATOR && team != TEAM_SPECTATOR)
	{
		pPlayer->m_bNotKilled = true;
		pPlayer->m_iIgnoreGlobalChat = IGNOREMSG_NONE;
		pPlayer->m_iTeamKills = 0;

		g_pGameRules->CheckStartMoney();

		pPlayer->m_iAccount = (int)startmoney.value;
		pPlayer->pev->solid = SOLID_NOT;
		pPlayer->pev->movetype = MOVETYPE_NOCLIP;
		pPlayer->pev->effects = EF_NODRAW;
		pPlayer->pev->effects |= EF_NOINTERP;
		pPlayer->pev->takedamage = DAMAGE_NO;
		pPlayer->pev->deadflag = DEAD_DEAD;
		pPlayer->pev->velocity = g_vecZero;
		pPlayer->pev->punchangle = g_vecZero;
		pPlayer->m_bHasNightVision = false;
		pPlayer->m_fDeadTime = 0;
		pPlayer->has_disconnected = false;
		pPlayer->m_iJoiningState = GETINTOGAME;

		SendItemStatus(pPlayer);
		g_engfuncs.pfnSetClientMaxspeed(ENT(pPlayer->pev), 1);
		SET_MODEL(ENT(pPlayer->pev), PLAYER_DEFAULT_MODEL);
	}

	if (team == TEAM_ZOMBIE)
	{
		char sz[] =
			"\\ySelect your class\\w\n"
			"\n"
			"1. Steel Helmet\n"
			"2. Wild Fire\n"
			"3. Beast\n"
			"4. Poison Evil\n"
			"\n"
			"5. Auto - select\n"
			;

		ShowMenu(pPlayer, MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5, -1, FALSE, sz);

#ifdef USING_SYPB
		if (pPlayer->IsBot())
			gISypbFuncs.SetBotStartAction(pPlayer->edict(), SYPB_CMENU_CLASS);
#endif
	}
	else if (team == TEAM_HUMAN)
	{
		char sz[] =
			"\\ySelect your class\\w\n"
			"\n"
			"1. Commando\n"
			"2. Support\n"
			"3. Sharpshooter\n"
			"4. Zweihander\n"
			"\n"
			"5. Auto - select\n"
			;

		ShowMenu(pPlayer, MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5, -1, FALSE, sz);

#ifdef USING_SYPB
		if (pPlayer->IsBot())
			gISypbFuncs.SetBotStartAction(pPlayer->edict(), SYPB_CMENU_CLASS);
#endif
	}

	pPlayer->m_iMenu = Menu_ChooseAppearance;

	if (pPlayer->pev->deadflag == DEAD_NO)
		ClientKill(pPlayer->edict());

	pPlayer->m_bTeamChanged = true;
	oldTeam = pPlayer->m_iTeam;
	pPlayer->m_iTeam = team;

	MESSAGE_BEGIN(MSG_ALL, gmsgTeamInfo);
	WRITE_BYTE(ENTINDEX(pPlayer->edict()));
	WRITE_STRING(g_pGameRules->GetTeam(team));
	MESSAGE_END();

	if (team != TEAM_UNASSIGNED)
		pPlayer->SetScoreboardAttributes();

	const char* name = pPlayer->pev->netname ? STRING(pPlayer->pev->netname) : "<unconnected>";

	if (!name[0])
		name = "<unconnected>";

	if (team == TEAM_ZOMBIE)
		UTIL_ClientPrintAll(HUD_PRINTNOTIFY, "#Game_join_terrorist", name);	// UNDONE
	else
		UTIL_ClientPrintAll(HUD_PRINTNOTIFY, "#Game_join_ct", name);

	UTIL_LogPrintf("\"%s<%i><%s><%s>\" joined team \"%s\"\n", STRING(pPlayer->pev->netname), GETPLAYERUSERID(pPlayer->edict()), GETPLAYERAUTHID(pPlayer->edict()), g_pGameRules->GetTeam(oldTeam), g_pGameRules->GetTeam(team));
	return TRUE;
}

void Radio1(CBasePlayer * player, int slot)
{
	if (gpGlobals->time <= player->m_flRadioTime)
		return;

	if (player->m_iRadioMessages <= 0)
		return;

	player->m_iRadioMessages--;
	player->m_flRadioTime = gpGlobals->time + 1.5;

	switch (slot)
	{
	case 1: player->Radio("%!MRAD_COVERME", "#Cover_me"); break;
	case 2: player->Radio("%!MRAD_TAKEPOINT", "#You_take_the_point"); break;
	case 3: player->Radio("%!MRAD_POSITION", "#Hold_this_position"); break;
	case 4: player->Radio("%!MRAD_REGROUP", "#Regroup_team"); break;
	case 5: player->Radio("%!MRAD_FOLLOWME", "#Follow_me"); break;
	case 6: player->Radio("%!MRAD_HITASSIST", "#Taking_fire"); break;
	}
}

void Radio2(CBasePlayer * player, int slot)
{
	if (gpGlobals->time <= player->m_flRadioTime)
		return;

	if (player->m_iRadioMessages <= 0)
		return;

	player->m_iRadioMessages--;
	player->m_flRadioTime = gpGlobals->time + 1.5;

	switch (slot)
	{
	case 1: player->Radio("%!MRAD_GO", "#Go_go_go"); break;
	case 2: player->Radio("%!MRAD_FALLBACK", "#Team_fall_back"); break;
	case 3: player->Radio("%!MRAD_STICKTOG", "#Stick_together_team"); break;
	case 4: player->Radio("%!MRAD_GETINPOS", "#Get_in_position_and_wait"); break;
	case 5: player->Radio("%!MRAD_STORMFRONT", "#Storm_the_front"); break;
	case 6: player->Radio("%!MRAD_REPORTIN", "#Report_in_team"); break;
	}
}

void Radio3(CBasePlayer * player, int slot)
{
	if (gpGlobals->time <= player->m_flRadioTime)
		return;

	if (player->m_iRadioMessages <= 0)
		return;

	player->m_iRadioMessages--;
	player->m_flRadioTime = gpGlobals->time + 1.5;

	switch (slot)
	{
	case 1:
	{
		if (RANDOM_LONG(0, 1))
			player->Radio("%!MRAD_AFFIRM", "#Affirmative");
		else
			player->Radio("%!MRAD_ROGER", "#Roger_that");

		break;
	}

	case 2: player->Radio("%!MRAD_ENEMYSPOT", "#Enemy_spotted"); break;
	case 3: player->Radio("%!MRAD_BACKUP", "#Need_backup"); break;
	case 4: player->Radio("%!MRAD_CLEAR", "#Sector_clear"); break;
	case 5: player->Radio("%!MRAD_INPOS", "#In_position"); break;
	case 6: player->Radio("%!MRAD_REPRTINGIN", "#Reporting_in"); break;
	case 7: player->Radio("%!MRAD_BLOW", "#Get_out_of_there"); break;
	case 8: player->Radio("%!MRAD_NEGATIVE", "#Negative"); break;
	case 9: player->Radio("%!MRAD_ENEMYDOWN", "#Enemy_down"); break;
	}
}

BOOL HandleRadioAliasCommands(CBasePlayer* pPlayer, const char* pszCommand)
{
	BOOL bRetVal = FALSE;

	if (!strcmp(pszCommand, "coverme"))
	{
		bRetVal = TRUE;
		Radio1(pPlayer, 1);
	}
	else if (!strcmp(pszCommand, "takepoint"))
	{
		bRetVal = TRUE;
		Radio1(pPlayer, 2);
	}
	else if (!strcmp(pszCommand, "holdpos"))
	{
		bRetVal = TRUE;
		Radio1(pPlayer, 3);
	}
	else if (!strcmp(pszCommand, "regroup"))
	{
		bRetVal = TRUE;
		Radio1(pPlayer, 4);
	}
	else if (!strcmp(pszCommand, "followme"))
	{
		bRetVal = TRUE;
		Radio1(pPlayer, 5);
	}
	else if (!strcmp(pszCommand, "takingfire"))
	{
		bRetVal = TRUE;
		Radio1(pPlayer, 6);
	}
	else if (!strcmp(pszCommand, "go"))
	{
		bRetVal = TRUE;
		Radio2(pPlayer, 1);
	}
	else if (!strcmp(pszCommand, "fallback"))
	{
		bRetVal = TRUE;
		Radio2(pPlayer, 2);
	}
	else if (!strcmp(pszCommand, "sticktog"))
	{
		bRetVal = TRUE;
		Radio2(pPlayer, 3);
	}
	else if (!strcmp(pszCommand, "getinpos"))
	{
		bRetVal = TRUE;
		Radio2(pPlayer, 4);
	}
	else if (!strcmp(pszCommand, "stormfront"))
	{
		bRetVal = TRUE;
		Radio2(pPlayer, 5);
	}
	else if (!strcmp(pszCommand, "report"))
	{
		bRetVal = TRUE;
		Radio2(pPlayer, 6);
	}
	else if (!strcmp(pszCommand, "roger"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 1);
	}
	else if (!strcmp(pszCommand, "enemyspot"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 2);
	}
	else if (!strcmp(pszCommand, "needbackup"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 3);
	}
	else if (!strcmp(pszCommand, "sectorclear"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 4);
	}
	else if (!strcmp(pszCommand, "inposition"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 5);
	}
	else if (!strcmp(pszCommand, "reportingin"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 6);
	}
	else if (!strcmp(pszCommand, "getout"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 7);
	}
	else if (!strcmp(pszCommand, "negative"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 8);
	}
	else if (!strcmp(pszCommand, "enemydown"))
	{
		bRetVal = TRUE;
		Radio3(pPlayer, 9);
	}

	return bRetVal;
}

void HandleMenu_ChooseClasses(CBasePlayer* pPlayer, int slot)
{
	if (slot == 0)
	{
		pPlayer->m_iMenu = Menu_OFF;
		return;
	}

	if (slot <= CLASS_ZOMBIE_LAST && slot >= CLASS_ZOMBIE_FIRST)
	{
		pPlayer->m_iNextZombieClass = (ZOMBIERIOT_CLASSES)slot;
	}

	if (slot <= CLASS_HUMAN_LAST && slot >= CLASS_HUMAN_FIRST)
	{
		pPlayer->m_iNextHumanClass = (ZOMBIERIOT_CLASSES)slot;
	}

	if (slot == 9)
	{
		pPlayer->m_iNextZombieClass = (ZOMBIERIOT_CLASSES)RANDOM_LONG(CLASS_ZOMBIE_FIRST, CLASS_ZOMBIE_LAST);
		pPlayer->m_iNextHumanClass = (ZOMBIERIOT_CLASSES)RANDOM_LONG(CLASS_HUMAN_FIRST, CLASS_HUMAN_LAST);
	}

	if (g_pGameRules->m_iRoundPhase == CHalfLifeMultiplay::ROUND_COUNTINGDOWN)
	{
		// changing your current class during counting down phase is allowed and encouraged.
		pPlayer->ChangeClass((ZOMBIERIOT_CLASSES)slot);
	}

	CLIENT_COMMAND(pPlayer->edict(), "chooseclasses\n");
	pPlayer->m_iMenu = Menu_OFF;
}