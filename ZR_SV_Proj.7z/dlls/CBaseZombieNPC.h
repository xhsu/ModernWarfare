#pragma once
#ifndef _CBASE_ZOMBIE_NPC_H_
#define _CBASE_ZOMBIE_NPC_H_

#define _DEBUG_ZNPC	1

class CBaseEntity;
class CBaseMonster;
class CBasePlayer;
class CBaseZombieNPC;

typedef std::list<CBaseZombieNPC*>	lstznpc_t;

class CBaseZombieNPC : public CBaseMonster
{
public:
	enum CLASSES
	{
		CLASS_NORMAL = 0,
		CLASS_HEALER,
	};

public:	// overall control vars
	static	lstznpc_t	s_lstZombieNPCs;

public:	// overall control functions
	static	void	OnPrecache		(void);
	static	bool	Command			(CBasePlayer* pPlayer, const char* pcmd);
	static	void	ServerActivate	(void);	// reset npc manager.
	static	void	ServerDeactivate(void);	// reset npc manager.
	static	void	RoundRestart	(void);	// remove all npcs.
	static	bool	AddToList		(CBaseZombieNPC* pNPC);	// add a npc into overall list.
	static	bool	RemoveFromList	(CBaseZombieNPC* pNPC);	// remove a npc fromoverall list

public:	// vars for individual
	CLASSES	m_iClass;

public:	// common function for all zombies.

protected:
private:
};

class CZombie : public CBaseZombieNPC
{
public:
	virtual	void	Spawn			(void);
	virtual	void	Precache		(void);
	virtual	void	UpdateOnRemove	(void);

protected:
private:
};




















































#endif