/***

Modern Warfare Develop Team
CWayPoint.cpp

Coder:		Luna the Reborn
Algorithm:	Usagi
Advisor:	Crsky

Create Date: 2019/04/28

***/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "CWayPoint.h"
#include "menus.h"
#include <algorithm>	// I LOVE THIS

CWayPoint g_cWayPoint;

unsigned CWPBase::FindFarthestKin(void)
{
	unsigned iFarthest = 0;

	for (unsigned j = 0; j < m_uKinCounts; j++)
	{
		// if another node is farther than the current marked one, replace it.
		if (m_rgflNextKinsDist[iFarthest] > m_rgflNextKinsDist[j])
			continue;

		iFarthest = j;
	}

	return iFarthest;
}

CWPBase* CWPBase::FindNearestKin(void)
{
	unsigned iNearest = 0;

	for (unsigned j = 0; j < m_uKinCounts; j++)
	{
		// if another node is nearer than the current marked one, replace it.
		if (m_rgflNextKinsDist[iNearest] < m_rgflNextKinsDist[j])
			continue;

		iNearest = j;
	}

	return m_rgpnNextKins[iNearest];
}

void CWPBase::Clear(void)
{
	m_uIndex = 0;
	m_vecOrigin = g_vecZero;
	m_iStructuralLevel = WP_NODE_ERROR;
	memset(&m_rgpnNextKins, NULL, sizeof(m_rgpnNextKins));
	memset(&m_rgflNextKinsDist, NULL, sizeof(m_rgflNextKinsDist));
	m_uKinCounts = 0;
	m_bitsNodeFlags = 0;
}

void CWPNode::Clear(void)
{
	CWPBase::Clear();

	m_iStructuralLevel = WP_NODE_PRIMARY;
	m_prParent = nullptr;
	m_pOccupyingEnt = nullptr;
}

CWPNode* CWPNode::FindAvailable(void)
{
	std::list<CWPNode*> lCandidates;
	lCandidates.clear();
	lCandidates.push_back(this);	// first one is current.

	while (!lCandidates.empty())
	{
		if (!lCandidates.front()->m_pOccupyingEnt)
			return lCandidates.front();	// if we got a unoccupied node, return it.

		// otherwise, add its all kins into the test list.
		for (unsigned i = 0; i < lCandidates.front()->m_uKinCounts; i++)
			lCandidates.push_back((CWPNode *)lCandidates.front()->m_rgpnNextKins[i]);	// a kin of node must be a node.

		// and remove this occupied node.
		lCandidates.pop_front();
	}

	return nullptr;
}

void CWPRegion::Clear(void)
{
	CWPBase::Clear();

	m_iStructuralLevel = WP_NODE_SECONDARY;

	m_lpNPCs.clear();
	m_lpHumans.clear();
	m_lpZombies.clear();
	m_lstnChildren.clear();

	a = b = c = 0;
	memset(m_szName, NULL, sizeof(m_szName));
	m_pnCenter = nullptr;
}

void CWPRegion::UpdateEntityList(void)
{
	// UNDONE. NPCs part.

	m_lpHumans.clear();
	m_lpZombies.clear();

	CBasePlayer* pPlayer = nullptr;
	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || !pPlayer->IsAvailable() || !pPlayer->IsAlive())
			continue;

		if (pPlayer->m_pRegion != this)
			continue;

		// switch have a better efficiency than if...elseif...else ?
		switch (pPlayer->m_iTeam)
		{
			case TEAM_ZOMBIE:
			{
				m_lpZombies.push_back(pPlayer);
				break;
			}
			case TEAM_HUMAN:
			{
				m_lpHumans.push_back(pPlayer);
				break;
			}
			default:
				continue;
		}
	}
}

bool CWPRegion::InCuboid(const Vector& vecOrigin)
{
	// check your math textbook if you can't understand this.

	float x = fabs(vecOrigin.x - m_vecOrigin.x);
	float y = fabs(vecOrigin.y - m_vecOrigin.y);
	float z = fabs(vecOrigin.z - m_vecOrigin.z);

	return !!(
		(x < a || Math::FltEqual(x, a)) &&
		(y < b || Math::FltEqual(y, b)) &&
		(z < c || Math::FltEqual(z, c))
		);
}

static char szSaveFile[256];

void CWayPoint::Load(void)
{
#define COPY_NODE(x)	m_rgnNodes[i].x = sNode.x
#define COPY_NODE_M(x)	memcpy(&m_rgnNodes[i].x, &sNode.x, sizeof(m_rgnNodes[i].x))
#define COPY_REGION(x)		m_rgRegions[i].x = sRegion.x
#define COPY_REGION_M(x)	memcpy(&m_rgRegions[i].x, &sRegion.x, sizeof(m_rgRegions[i].x))

	char szModName[24];
	GET_GAME_DIR(szModName);
	sprintf(szSaveFile, "%s//maps//%s.mwnav", szModName, STRING(gpGlobals->mapname));

	FILE* m_phFile = fopen(szSaveFile, "rb");
	if (!m_phFile)
		return;

	wp_file_header_t sHeader;

	fread(&sHeader, sizeof(sHeader), 1, m_phFile);

	if (sHeader.m_iVersion != WP_VERSION)
		return;

	wp_file_region_t sRegion;
	for (unsigned i = 0; i < sHeader.m_uRegionCounts; i++)
	{
		fread(&sRegion, sizeof(wp_file_region_t), 1, m_phFile);

		COPY_REGION(m_uIndex);
		COPY_REGION(m_vecOrigin);

		// from uId to pointer.
		for (unsigned j = 0; j < sRegion.m_uKinCounts; j++)
			m_rgRegions[i].m_rgpnNextKins[j] = &m_rgRegions[sRegion.m_rguIdNextKins[j]];

		COPY_REGION_M(m_rgflNextKinsDist);
		COPY_REGION(m_uKinCounts);
		COPY_REGION(m_bitsNodeFlags);
		COPY_REGION(a);
		COPY_REGION(b);
		COPY_REGION(c);
		COPY_REGION_M(m_szName);

		// from uId to pointer.
		if (sRegion.m_uIdCenterNode < MAX_WP_NODES)
			m_rgRegions[i].m_pnCenter = &m_rgnNodes[sRegion.m_uIdCenterNode];
	}

	m_uRegionCounts = sHeader.m_uRegionCounts;

	wp_file_node_t sNode;
	for (unsigned i = 0; i < sHeader.m_uNodeCounts; i++)
	{
		fread(&sNode, sizeof(wp_file_node_s), 1, m_phFile);

		COPY_NODE(m_uIndex);
		COPY_NODE(m_vecOrigin);
		
		// m_uIdParent = 999999 is a marker of orphan
		if (sNode.m_uIdParent < MAX_WP_NODES)
			m_rgnNodes[i].m_prParent = &m_rgRegions[sNode.m_uIdParent];
		else
			m_rgnNodes[i].m_prParent = nullptr;

		// from uId to pointer.
		for (unsigned j = 0; j < sNode.m_uKinCounts; j++)
			m_rgnNodes[i].m_rgpnNextKins[j] = &m_rgnNodes[sNode.m_rguIdNextKins[j]];

		COPY_NODE_M(m_rgflNextKinsDist);
		COPY_NODE(m_uKinCounts);
		COPY_NODE(m_bitsNodeFlags);
	}

	m_uNodeCounts = sHeader.m_uNodeCounts;

	fclose(m_phFile);

	// before we entering game, we should rebuild regions' child nodes pool
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		if (m_rgnNodes[i].m_prParent)
		{
			m_rgnNodes[i].m_prParent->m_lstnChildren.push_back(&m_rgnNodes[i]);
		}
	}

#undef COPY_NODE
#undef COPY_NODE_M
#undef COPY_REGION
#undef COPY_REGION_M
}

void CWayPoint::Save(void)
{
#define COPY_NODE(x)	sNode.x = m_rgnNodes[i].x
#define COPY_NODE_M(x)	memcpy(&sNode.x, &m_rgnNodes[i].x, sizeof(sNode.x))
#define COPY_REGION(x)		sRegion.x = m_rgRegions[i].x
#define COPY_REGION_M(x)	memcpy(&sRegion.x, &m_rgRegions[i].x, sizeof(sRegion.x))

	char szModName[24];
	GET_GAME_DIR(szModName);
	sprintf(szSaveFile, "%s//maps//%s.mwnav", szModName, STRING(gpGlobals->mapname));

	FILE* m_phFile = fopen(szSaveFile, "wb");
	if (!m_phFile)
		return;

	wp_file_header_t sHeader = { WP_VERSION, m_uNodeCounts, m_uRegionCounts };

	// write header first.
	fwrite(&sHeader, sizeof(sHeader), 1, m_phFile);

	// next, write region info.
	wp_file_region_t sRegion;
	for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		// empty container first.
		memset(&sRegion, NULL, sizeof(sRegion));

		COPY_REGION(m_uIndex);
		COPY_REGION(m_vecOrigin);

		// from pointer to uId.
		for (unsigned j = 0; j < m_rgRegions[i].m_uKinCounts; j++)
			sRegion.m_rguIdNextKins[j] = m_rgRegions[i].m_rgpnNextKins[j]->m_uIndex;

		COPY_REGION_M(m_rgflNextKinsDist);
		COPY_REGION(m_uKinCounts);
		COPY_REGION(m_bitsNodeFlags);
		COPY_REGION(a);
		COPY_REGION(b);
		COPY_REGION(c);
		COPY_REGION_M(m_szName);

		// from pointer to uId.
		if (m_rgRegions[i].m_pnCenter)
			sRegion.m_uIdCenterNode = m_rgRegions[i].m_pnCenter->m_uIndex;
		else
			sRegion.m_uIdCenterNode = 99999;	// marker for region without center. normally it shouldn't happened. it's very likely that some bug is occuring here.

		fwrite(&sRegion, sizeof(wp_file_region_t), 1, m_phFile);
	}

	// then, write node info one by one.
	wp_file_node_t sNode;
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		COPY_NODE(m_uIndex);
		COPY_NODE(m_vecOrigin);
		
		// m_uIdParent = 999999 is a marker of orphan
		if (m_rgnNodes[i].m_prParent)
			sNode.m_uIdParent = m_rgnNodes[i].m_prParent->m_uIndex;
		else
			sNode.m_uIdParent = 999999;

		// from pointer to uId.
		for (unsigned j = 0; j < m_rgnNodes[i].m_uKinCounts; j++)
			sNode.m_rguIdNextKins[j] = m_rgnNodes[i].m_rgpnNextKins[j]->m_uIndex;

		COPY_NODE_M(m_rgflNextKinsDist);
		COPY_NODE(m_uKinCounts);
		COPY_NODE(m_bitsNodeFlags);

		fwrite(&sNode, sizeof(wp_file_node_s), 1, m_phFile);
	}

	fclose(m_phFile);

#undef COPY_NODE
#undef COPY_NODE_M
#undef COPY_REGION
#undef COPY_REGION_M
}

void CWayPoint::ServerActivate(void)
{
	for (int i = 0; i < MAX_WP_NODES; i++)
		m_rgnNodes[i].Clear();

	for (int i = 0; i < MAX_WP_REGIONS; i++)
		m_rgRegions[i].Clear();

	m_uNodeCounts = 0;
	m_bShowNodes = false;
	m_flDrawNodesThink = 0;
	m_pSrc = nullptr;
	m_pEnd = nullptr;
	m_lpResult.clear();
	memset(&m_AStarTableN, NULL, sizeof(m_AStarTableN));
	m_bAStarFound = false;
	m_lvCandidates.clear();
	m_vecMapSpawn = g_vecZero;
	m_pnMapSpawn = nullptr;
	memset(&m_szServerPrintWords, NULL, sizeof(m_szServerPrintWords));
	m_uRegionCounts = 0;
	memset(&m_AStarTableR, NULL, sizeof(m_AStarTableR));
	m_bShowRegions = false;
	m_flDrawRegionsThink = 0;
	memset(&m_sDeRedundant, NULL, sizeof(m_sDeRedundant));
	memset(&m_sMeshing, NULL, sizeof(m_sMeshing));
	memset(&m_sPathGenerator, NULL, sizeof(m_sPathGenerator));

	Load();

	CBaseEntity *pEntity = UTIL_FindEntityByClassname(nullptr, "info_player_start");
	if (pEntity)
	{
		m_vecMapSpawn = pEntity->pev->origin;
		m_pnMapSpawn = FindNode(m_vecMapSpawn);
	}
}

void CWayPoint::StartFrame(void)
{
	// we can have only one function about trace.
	// but it seems that multiple think of pure math work is absolutely fine.

	MeshingThink();
	DRThink();
	DRThink();
	DRThink();
	DRThink();
	DRThink();
	DRThink();
	PGThink();
}

bool CWayPoint::Command(CBasePlayer* pPlayer)
{
	const char* pcmd = CMD_ARGV(1);

	if (!pcmd)
	{
		return true;
	}
	else if (!strcmp(pcmd, "addnode"))
	{
		AddNode(pPlayer);
		return true;
	}
	else if (!strcmp(pcmd, "delnode"))
	{
		DelNode(pPlayer);
		return true;
	}
	else if (!strcmp(pcmd, "save"))
	{
		Save();
		return true;
	}
	else if (!strcmp(pcmd, "load"))
	{
		Load();
		return true;
	}
	else if (!strcmp(pcmd, "showN"))
	{
		m_bShowNodes = !m_bShowNodes;
		m_flDrawNodesThink = 0;
		return true;
	}
	else if (!strcmp(pcmd, "showR"))
	{
		m_bShowRegions = !m_bShowRegions;
		m_flDrawRegionsThink = 0;
		return true;
	}
	else if (!strcmp(pcmd, "clear"))
	{
		for (unsigned i = 0; i < m_uNodeCounts; i++)
		{
			m_rgnNodes[i].Clear();
		}

		m_uNodeCounts = 0;
		m_lpResult.clear();
		return true;
	}
	else if (!strcmp(pcmd, "pg"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			return false;

		if (!strcmp(pcmd, "begin"))
			PGInit();
		else if (!strcmp(pcmd, "stop"))
			m_sPathGenerator.m_flThink = -1;
		else if (!strcmp(pcmd, "atonce"))
			GenerateNodePath();
		else
			return false;

		return true;
	}
	else if (!strcmp(pcmd, "tp"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			return false;

		unsigned node = atoi(pcmd);
		SET_ORIGIN(pPlayer->edict(), m_rgnNodes[node].m_vecOrigin);

		return true;
	}
	else if (!strcmp(pcmd, "menu"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			Menu_Main(pPlayer);
		else if (!strcmp(pcmd, "A*"))
			Menu_AStar(pPlayer);
		else if (!strcmp(pcmd, "r"))
			Menu_Region_1(pPlayer);
		else if (!strcmp(pcmd, "r2"))
			Menu_Region_2(pPlayer);
		else if (!strcmp(pcmd, "fl"))
			Menu_NodeFlagEditor_1(pPlayer);
		else if (!strcmp(pcmd, "fl2"))
			Menu_NodeFlagEditor_2(pPlayer);
		else
			Menu_Main(pPlayer);

		return true;
	}
	else if (!strcmp(pcmd, "mesh"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			return false;

		if (!strcmp(pcmd, "begin"))
			MeshingInit(pPlayer);
		else if (!strcmp(pcmd, "clear"))
		{
			m_sMeshing.m_flThink = -1;
			m_lvCandidates.clear();
		}
		else if (!strcmp(pcmd, "atonce"))
			Meshing(pPlayer);
		else
			return false;
		
		return true;
	}
	else if (!strcmp(pcmd, "dr"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			return false;

		if (!strcmp(pcmd, "begin"))
			DRInit();
		else if (!strcmp(pcmd, "stop"))
			m_sDeRedundant.m_flThink = -1;
		else if (!strcmp(pcmd, "atonce"))
			DeRedundant();
		else
			return false;

		return true;
	}
	else if (!strcmp(pcmd, "delcand"))
	{
		m_lpResult.clear();
		return true;
	}
	else if (!strcmp(pcmd, "impcand"))
	{
		ImportCandidates();
		return true;
	}
	else if (!strcmp(pcmd, "calb"))
	{
		pPlayer->SetCurrentNode(FindNode(pPlayer->pev->origin));
		return true;
	}
	else if (!strcmp(pcmd, "ucn"))
	{
		UpdateNode(pPlayer->m_pNearestNode);
		return true;
	}
	else if (!strcmp(pcmd, "rm"))
	{
		pcmd = CMD_ARGV(2);

		if (!pcmd)
			return false;

		if (!strcmp(pcmd, "sz"))
		{
			pcmd = CMD_ARGV(3);
			int value = atoi(CMD_ARGV(4));

			if (!strcmp(pcmd, "x"))
				pPlayer->m_pRegion->a += value;
			else if (!strcmp(pcmd, "y"))
				pPlayer->m_pRegion->b += value;
			else if (!strcmp(pcmd, "z"))
				pPlayer->m_pRegion->c += value;

		}
		else if (!strcmp(pcmd, "sft"))
		{
			pcmd = CMD_ARGV(3);
			int value = atoi(CMD_ARGV(4));

			if (!strcmp(pcmd, "x"))
				pPlayer->m_pRegion->m_vecOrigin.x += value;
			else if (!strcmp(pcmd, "y"))
				pPlayer->m_pRegion->m_vecOrigin.y += value;
			else if (!strcmp(pcmd, "z"))
				pPlayer->m_pRegion->m_vecOrigin.z += value;
		}
		else if (!strcmp(pcmd, "adj"))
		{
			pcmd = CMD_ARGV(3);
			float value = atof(CMD_ARGV(4)) / 2.0f;

			if (!strcmp(pcmd, "x"))
			{
				pPlayer->m_pRegion->a += value;
				pPlayer->m_pRegion->m_vecOrigin.x -= value;
			}
			else if (!strcmp(pcmd, "y"))
			{
				pPlayer->m_pRegion->b += value;
				pPlayer->m_pRegion->m_vecOrigin.y -= value;
			}
			else if (!strcmp(pcmd, "z"))
			{
				pPlayer->m_pRegion->c += value;
				pPlayer->m_pRegion->m_vecOrigin.z -= value;
			}
		}
		else if (!strcmp(pcmd, "adji"))
		{
			pcmd = CMD_ARGV(3);
			float value = atof(CMD_ARGV(4)) / 2.0f;

			if (!strcmp(pcmd, "x"))
			{
				pPlayer->m_pRegion->a += value;
				pPlayer->m_pRegion->m_vecOrigin.x += value;
			}
			else if (!strcmp(pcmd, "y"))
			{
				pPlayer->m_pRegion->b += value;
				pPlayer->m_pRegion->m_vecOrigin.y += value;
			}
			else if (!strcmp(pcmd, "z"))
			{
				pPlayer->m_pRegion->c += value;
				pPlayer->m_pRegion->m_vecOrigin.z += value;
			}
		}
		else if (!strcmp(pcmd, "rectr"))
		{
			Vector vecs[6];
			
			// up/down
			vecs[0] = pPlayer->pev->origin + Vector(0, 0, 200);
			vecs[1] = pPlayer->pev->origin - Vector(0, 0, 200);

			// left/right
			vecs[2] = pPlayer->pev->origin + Vector(400, 0, 0);
			vecs[3] = pPlayer->pev->origin - Vector(400, 0, 0);

			// forward/backward
			vecs[4] = pPlayer->pev->origin + Vector(0, 400, 0);
			vecs[5] = pPlayer->pev->origin - Vector(0, 400, 0);

			TraceResult tr[6];
			for (short i = 0; i < 6; i++)
			{
				UTIL_TraceLine(pPlayer->pev->origin, vecs[i], ignore_monsters, ignore_glass, pPlayer->edict(), &tr[i]);
			}

			pPlayer->m_pRegion->m_vecOrigin = pPlayer->pev->origin;
			pPlayer->m_pRegion->a = min(tr[2].flFraction, tr[3].flFraction) * 400.0f;
			pPlayer->m_pRegion->b = min(tr[4].flFraction, tr[5].flFraction) * 400.0f;
			pPlayer->m_pRegion->c = min(tr[0].flFraction, tr[1].flFraction) * 200.0f;
		}
		else if (!strcmp(pcmd, "auto"))
		{
			Vector vecs[6];

			// up/down
			vecs[0] = pPlayer->pev->origin + Vector(0, 0, 200);
			vecs[1] = pPlayer->pev->origin - Vector(0, 0, 200);

			// left/right
			vecs[2] = pPlayer->pev->origin + Vector(400, 0, 0);
			vecs[3] = pPlayer->pev->origin - Vector(400, 0, 0);

			// forward/backward
			vecs[4] = pPlayer->pev->origin + Vector(0, 400, 0);
			vecs[5] = pPlayer->pev->origin - Vector(0, 400, 0);

			TraceResult tr[6];
			for (short i = 0; i < 6; i++)
			{
				UTIL_TraceLine(pPlayer->pev->origin, vecs[i], ignore_monsters, ignore_glass, pPlayer->edict(), &tr[i]);
			}

			pPlayer->m_pRegion->m_vecOrigin = pPlayer->pev->origin;
			pPlayer->m_pRegion->a = (tr[2].flFraction + tr[3].flFraction) / 2.0f * 400.0f;
			pPlayer->m_pRegion->b = (tr[4].flFraction + tr[5].flFraction) / 2.0f * 400.0f;
			pPlayer->m_pRegion->c = (tr[0].flFraction + tr[1].flFraction) / 2.0f * 200.0f;

			pPlayer->m_pRegion->m_vecOrigin.x = (tr[2].vecEndPos.x + tr[3].vecEndPos.x) / 2.0f;
			pPlayer->m_pRegion->m_vecOrigin.y = (tr[4].vecEndPos.y + tr[5].vecEndPos.y) / 2.0f;
			pPlayer->m_pRegion->m_vecOrigin.z = (tr[0].vecEndPos.z + tr[1].vecEndPos.z) / 2.0f;
		}

		// no matter how you adjust region, the region center will be reassign.
		pPlayer->m_pRegion->m_pnCenter = FindNode(pPlayer->m_pRegion->m_vecOrigin);

		return true;
	}
	else if (!strcmp(pcmd, "linkN"))
	{
		TraceResult tr;
		UTIL_TraceLine(pPlayer->pev->origin + pPlayer->pev->view_ofs, pPlayer->pev->origin + pPlayer->pev->view_ofs + gpGlobals->v_forward * 500.0f, ignore_monsters, ignore_glass, pPlayer->edict(), &tr);

		CWPNode* node = FindNode(tr.vecEndPos);
		EnforcePath(pPlayer->m_pNearestNode, node);
		EnforcePath(node, pPlayer->m_pNearestNode);	// �Y������
	}
	else if (!strcmp(pcmd, "linkR"))
	{
		TraceResult tr;
		UTIL_TraceLine(pPlayer->pev->origin + pPlayer->pev->view_ofs, pPlayer->pev->origin + pPlayer->pev->view_ofs + gpGlobals->v_forward * 500.0f, ignore_monsters, ignore_glass, pPlayer->edict(), &tr);

		CWPRegion* region = FindRegion(tr.vecEndPos);
		EnforcePath(pPlayer->m_pRegion, region);
		EnforcePath(region, pPlayer->m_pRegion);
	}
	else if (!strcmp(pcmd, "indexN"))
	{
		sprintf(m_szServerPrintWords, "[Waypoint] Current node index: %d\n", pPlayer->m_pNearestNode->m_uIndex);
		g_engfuncs.pfnServerPrint(m_szServerPrintWords);

		return true;
	}
	else if (!strcmp(pcmd, "indexR"))
	{
	sprintf(m_szServerPrintWords, "[Waypoint] Current region index: %d, name: %s\n", pPlayer->m_pRegion->m_uIndex, pPlayer->m_pRegion->m_szName);
	g_engfuncs.pfnServerPrint(m_szServerPrintWords);

	return true;
	}
	else if (!strcmp(pcmd, "rg"))
	{
		RegionGenerator();	// luna's scheme
		return true;
	}
	else if (!strcmp(pcmd, "rg2"))
	{
		RegionGenerator2();	// usagi's scheme
		return true;
	}
	else if (!strcmp(pcmd, "grp"))
	{
		GenerateRegnPath();
		return true;
	}

	return false;
}

inline void CWayPoint::AddNode(CBaseEntity* pEntity)
{
	AddNode(pEntity->pev->origin);

	if (pEntity->pev->flags & FL_DUCKING)
		m_rgnNodes[m_uNodeCounts - 1].m_bitsNodeFlags |= WP_N_FL_CROUCH;
}

void CWayPoint::AddNode(Vector& vecOrigin)
{
	CWPNode* p = &m_rgnNodes[m_uNodeCounts];

	p->m_uIndex = m_uNodeCounts;
	p->m_vecOrigin = vecOrigin;
	p->m_prParent = nullptr;
	p->m_bitsNodeFlags = 0;

	m_uNodeCounts++;
}

void CWayPoint::DelNode(CBaseEntity* pEntity)
{
	CWPNode* p = FindNode(pEntity->pev->origin);

	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		if (i == p->m_uIndex)
			continue;

		for (unsigned j = 0; j < m_rgnNodes[i].m_uKinCounts; j++)
		{
			// if the current node have a relationship with the node to be del
			if (m_rgnNodes[i].m_rgpnNextKins[j]->m_uIndex == p->m_uIndex)
				DelPath(&m_rgnNodes[i], j);	// then just del it.
		}
	}

	// since node can't be a parent, thus we only need to consider CWPRegion.
	if (p->m_prParent)
	{
		for (auto iter = p->m_prParent->m_lstnChildren.cbegin(); iter != p->m_prParent->m_lstnChildren.cend(); iter++)
		{
			if ((*iter)->m_uIndex == p->m_uIndex)
			{
				p->m_prParent->m_lstnChildren.erase(iter);
				break;
			}
		}

		p->m_prParent = nullptr;
	}
	
	// then we need to clean it from the array.
	unsigned uIndex = p->m_uIndex;
	memmove(&m_rgnNodes[uIndex], &m_rgnNodes[uIndex + 1], sizeof(CWPNode) * (MAX_WP_NODES - uIndex - 1));
	m_uNodeCounts--;

	// a re-index is needed. the +1 is for the original "last" element.
	for (unsigned i = 0; i < m_uNodeCounts + 1; i++)
		m_rgnNodes[i].m_uIndex = i;

	// there two steps cannot be merged.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		// so does a re-oriented of pointers.
		for (unsigned j = 0; j < m_rgnNodes[i].m_uKinCounts; j++)
		{
			// since there is no index == p->m_uIndex. so we can use a m_uIndex >= uIndex. this is because that the new p->m_uIndex must came from the re-index above.
			if (m_rgnNodes[i].m_rgpnNextKins[j]->m_uIndex >= uIndex)
				m_rgnNodes[i].m_rgpnNextKins[j] = &m_rgnNodes[m_rgnNodes[i].m_rgpnNextKins[j]->m_uIndex - 1];
		}
	}
}

// from weather.cpp
extern int	g_hSparkSpr;

void DrawLine(CBasePlayer *pPlayer, const Vector& start, const Vector& end, const colorVec& color, int width, int noise, int speed, int life, int lineType)
{
	g_engfuncs.pfnMessageBegin (MSG_ONE_UNRELIABLE, SVC_TEMPENTITY, g_vecZero, pPlayer->edict());
	g_engfuncs.pfnWriteByte (TE_BEAMPOINTS);

	g_engfuncs.pfnWriteCoord (start.x);
	g_engfuncs.pfnWriteCoord (start.y);
	g_engfuncs.pfnWriteCoord (start.z);

	g_engfuncs.pfnWriteCoord (end.x);
	g_engfuncs.pfnWriteCoord (end.y);
	g_engfuncs.pfnWriteCoord (end.z);

	switch (lineType)
	{
	case 0:	//LINE_SIMPLE:
		g_engfuncs.pfnWriteShort (g_hSparkSpr);
		break;

	case 1:	//LINE_ARROW:
		g_engfuncs.pfnWriteShort (g_hSparkSpr/*g_modelIndexArrow*/);
		break;
	}

	g_engfuncs.pfnWriteByte (0);
	g_engfuncs.pfnWriteByte (10);

	g_engfuncs.pfnWriteByte (life);
	g_engfuncs.pfnWriteByte (width);
	g_engfuncs.pfnWriteByte (noise);

	g_engfuncs.pfnWriteByte (color.r);
	g_engfuncs.pfnWriteByte (color.g);
	g_engfuncs.pfnWriteByte (color.b);

	g_engfuncs.pfnWriteByte (color.a); // alpha as brightness here
	g_engfuncs.pfnWriteByte (speed);

	g_engfuncs.pfnMessageEnd ();
}

#define WP_LINE_TIME	7

void CWayPoint::DrawNodes(CBasePlayer* pPlayer)
{
	if (!m_bShowNodes || !m_uNodeCounts)
		return;

	if (pPlayer->pev->flags & FL_FAKECLIENT)
		return;

	if (m_flDrawNodesThink > gpGlobals->time)
		return;

	m_flDrawNodesThink = gpGlobals->time + float(WP_LINE_TIME) / 10.0f;

	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		// don't draw nodes which are far away.
		if ((m_rgnNodes[i].m_vecOrigin - pPlayer->pev->origin).LengthSquared() > 10000.0f)
			continue;

		float nodeHeight = (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_CROUCH) ? 36.0f : 72.0f; // check the node height
		float nodeHalfHeight = nodeHeight * 0.5f;

		// all waypoints are by default are green
		colorVec nodeColor = { 0, 255, 0, 255 };

		// colorize all other waypoints
		if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_END | WP_N_FL_START | WP_N_FL_SECTION)
			nodeColor = { 128, 0, 255, 255 };
		else if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_LADDER)
			nodeColor = { 128, 64, 0, 255 };

		// colorize additional flags
		colorVec nodeFlagColor = { 999, 999, 999, 0 };

		// check the colors
		if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_SNIPER)
			nodeFlagColor = { 130, 87, 0, 0 };
		else if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_SECTION)
			nodeFlagColor = { 255, 255, 255, 0 };
		else if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_ZOMBIE)
			nodeFlagColor = { 255, 0, 0, 0 };
		else if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_HUMAN)
			nodeFlagColor = { 0, 0, 255, 0 };

		// SyPB Pro P.24 - Zombie Mod Human Camp
		if (m_rgnNodes[i].m_bitsNodeFlags & WP_N_FL_CAMP)
		{
			nodeColor = { 199, 69, 209, 255 };
			nodeFlagColor = { 0, 0, 255, 0 };
		}

		nodeColor.a = 250;
		nodeFlagColor.a = 250;

		// draw node without additional flags
		if (nodeFlagColor.r == 999)
			DrawLine(pPlayer, m_rgnNodes[i].m_vecOrigin - Vector(0.0f, 0.0f, nodeHalfHeight), m_rgnNodes[i].m_vecOrigin + Vector(0.0f, 0.0f, nodeHalfHeight), nodeColor, 15, 0, 0, WP_LINE_TIME, NULL);
		else // draw node with flags
		{
			DrawLine(pPlayer, m_rgnNodes[i].m_vecOrigin - Vector(0.0f, 0.0f, nodeHalfHeight), m_rgnNodes[i].m_vecOrigin - Vector(0.0f, 0.0f, nodeHalfHeight - nodeHeight * 0.75f), nodeColor, 14, 0, 0, WP_LINE_TIME, NULL); // draw basic path
			DrawLine(pPlayer, m_rgnNodes[i].m_vecOrigin - Vector(0.0f, 0.0f, nodeHalfHeight - nodeHeight * 0.75f), m_rgnNodes[i].m_vecOrigin + Vector(0.0f, 0.0f, nodeHalfHeight), nodeFlagColor, 14, 0, 0, WP_LINE_TIME, NULL); // draw additional path
		}

		// if we are drawing the nearest node of this player, show him the path.
		if (m_rgnNodes[i].m_pOccupyingEnt == pPlayer)
		{
			nodeColor = { 0, 255, 0, 255 };

			for (unsigned j = 0; j < m_rgnNodes[i].m_uKinCounts; j++)
			{
				DrawLine(pPlayer, m_rgnNodes[i].m_vecOrigin, m_rgnNodes[i].m_rgpnNextKins[j]->m_vecOrigin, nodeColor, 15, 0, 0, j == pPlayer->m_uSelectedPath ? WP_LINE_TIME / 2 : WP_LINE_TIME, NULL);
			}
		}
	}

	if (!m_lpResult.empty())
	{
		colorVec tracecolor = { 255, 255, 255, 255 };

		for (auto iter = m_lpResult.cbegin(); iter != m_lpResult.cend();)
		{
			auto curr = iter;
			iter++;
			auto next = iter;

			if (next == m_lpResult.cend())
				break;

			DrawLine(pPlayer, (*curr)->m_vecOrigin, (*next)->m_vecOrigin, tracecolor, 15, 0, 0, 10, NULL);
		}
	}
}

void CWayPoint::DrawRegions(CBasePlayer* pPlayer)
{
	if (!m_bShowRegions || !m_uRegionCounts)
		return;

	if (pPlayer->pev->flags & FL_FAKECLIENT)
		return;

	if (m_flDrawRegionsThink > gpGlobals->time)
		return;

	m_flDrawRegionsThink = gpGlobals->time + float(WP_LINE_TIME) / 10.0f;

	// we only draw regions which related to our current region.
	if (!pPlayer->m_pRegion)
		return;

	// draw our current region in bright green color.
	colorVec sColor = { 0, 255, 153, 255 };
	Vector vecs[8];

	// upper 4
	vecs[0] = pPlayer->m_pRegion->m_vecOrigin + Vector(pPlayer->m_pRegion->a, pPlayer->m_pRegion->b, pPlayer->m_pRegion->c);
	vecs[1] = pPlayer->m_pRegion->m_vecOrigin + Vector(pPlayer->m_pRegion->a, -pPlayer->m_pRegion->b, pPlayer->m_pRegion->c);
	vecs[2] = pPlayer->m_pRegion->m_vecOrigin + Vector(-pPlayer->m_pRegion->a, -pPlayer->m_pRegion->b, pPlayer->m_pRegion->c);
	vecs[3] = pPlayer->m_pRegion->m_vecOrigin + Vector(-pPlayer->m_pRegion->a, pPlayer->m_pRegion->b, pPlayer->m_pRegion->c);

	DrawLine(pPlayer, vecs[0], vecs[1], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[1], vecs[2], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[2], vecs[3], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[3], vecs[0], sColor, 15, 0, 0, WP_LINE_TIME, NULL);

	// lower 4
	vecs[4] = pPlayer->m_pRegion->m_vecOrigin + Vector(pPlayer->m_pRegion->a, pPlayer->m_pRegion->b, -pPlayer->m_pRegion->c);
	vecs[5] = pPlayer->m_pRegion->m_vecOrigin + Vector(pPlayer->m_pRegion->a, -pPlayer->m_pRegion->b, -pPlayer->m_pRegion->c);
	vecs[6] = pPlayer->m_pRegion->m_vecOrigin + Vector(-pPlayer->m_pRegion->a, -pPlayer->m_pRegion->b, -pPlayer->m_pRegion->c);
	vecs[7] = pPlayer->m_pRegion->m_vecOrigin + Vector(-pPlayer->m_pRegion->a, pPlayer->m_pRegion->b, -pPlayer->m_pRegion->c);

	DrawLine(pPlayer, vecs[4], vecs[5], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[5], vecs[6], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[6], vecs[7], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[7], vecs[4], sColor, 15, 0, 0, WP_LINE_TIME, NULL);

	// edges
	DrawLine(pPlayer, vecs[0], vecs[4], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[1], vecs[5], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[2], vecs[6], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	DrawLine(pPlayer, vecs[3], vecs[7], sColor, 15, 0, 0, WP_LINE_TIME, NULL);

	// draw region path with yellow.
	sColor = { 255, 204, 102, 255 };
	for (unsigned j = 0; j < pPlayer->m_pRegion->m_uKinCounts; j++)
		DrawLine(pPlayer, pPlayer->m_pRegion->m_vecOrigin, pPlayer->m_pRegion->m_rgpnNextKins[j]->m_vecOrigin, sColor, 15, 0, 0, WP_LINE_TIME, NULL);

	// draw nodes belong to this region with purple.
	sColor = { 102, 0, 255, 255 };
	for (auto pNode : pPlayer->m_pRegion->m_lstnChildren)
	{
		if ((pNode->m_vecOrigin - pPlayer->pev->origin).LengthSquared() > 10000.0f)
			continue;

		DrawLine(pPlayer, pNode->m_vecOrigin - Vector(0.0f, 0.0f, 36.0f), pNode->m_vecOrigin + Vector(0.0f, 0.0f, 36.0f), sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	}

	// draw kin regions with purple.
	sColor = { 102, 0, 255, 255 };
	for (unsigned i = 0; i < pPlayer->m_pRegion->m_uKinCounts; i++)
	{
		// upper 4
		vecs[0] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);
		vecs[1] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);
		vecs[2] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(-((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);
		vecs[3] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(-((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);

		DrawLine(pPlayer, vecs[0], vecs[1], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[1], vecs[2], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[2], vecs[3], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[3], vecs[0], sColor, 15, 0, 0, WP_LINE_TIME, NULL);

		// lower 4
		vecs[4] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);
		vecs[5] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);
		vecs[6] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(-((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);
		vecs[7] = ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->m_vecOrigin + Vector(-((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->a, ((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->b, -((CWPRegion *)pPlayer->m_pRegion->m_rgpnNextKins[i])->c);

		DrawLine(pPlayer, vecs[4], vecs[5], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[5], vecs[6], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[6], vecs[7], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[7], vecs[4], sColor, 15, 0, 0, WP_LINE_TIME, NULL);

		// edges
		DrawLine(pPlayer, vecs[0], vecs[4], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[1], vecs[5], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[2], vecs[6], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
		DrawLine(pPlayer, vecs[3], vecs[7], sColor, 15, 0, 0, WP_LINE_TIME, NULL);
	}

	if (!m_lpResult.empty())
	{
		colorVec tracecolor = { 255, 255, 255, 255 };

		for (auto iter = m_lpResult.cbegin(); iter != m_lpResult.cend();)
		{
			auto curr = iter;
			iter++;
			auto next = iter;

			if (next == m_lpResult.cend())
				break;

			DrawLine(pPlayer, (*curr)->m_vecOrigin, (*next)->m_vecOrigin, tracecolor, 15, 0, 0, WP_LINE_TIME, NULL);
		}
	}
}

CWPNode* CWayPoint::FindNode(Vector& vOrigin)
{
	unsigned iNearest = 0;
	float flRecord = 99999.0f;
	float flDist = flRecord;

	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		flDist = (m_rgnNodes[i].m_vecOrigin - vOrigin).Length();
		
		// if the current distance is smaller than recorded dist, replace it.
		if (flDist < flRecord)
		{
			iNearest = i;
			flRecord = flDist;
		}
	}

	return &m_rgnNodes[iNearest];
}

CWPRegion* CWayPoint::FindRegion(Vector& v)
{
	// theoretically, regions are not intercepting with each other.
	// so, we can break the loop once we got a hit.

	for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		if (m_rgRegions[i].InCuboid(v))
			return &m_rgRegions[i];
	}

	return nullptr;
}

void CWayPoint::GenerateNodePath(void)
{
	// remove all existed node path first.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		memset(&m_rgnNodes[i].m_rgflNextKinsDist, NULL, sizeof(m_rgnNodes[i].m_rgflNextKinsDist));
		memset(&m_rgnNodes[i].m_rgpnNextKins, NULL, sizeof(m_rgnNodes[i].m_rgpnNextKins));
		m_rgnNodes[i].m_uKinCounts = 0;
	}

	// we need to update the kin status of all nodes. it's not bounded to the current one we are adding.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		for (unsigned j = 0; j < m_uNodeCounts; j++)
			AddPath(&m_rgnNodes[i], &m_rgnNodes[j]);
	}
}

void CWayPoint::GenerateRegnPath(void)
{
	// remove all existed region path first.
	for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		memset(&m_rgRegions[i].m_rgflNextKinsDist, NULL, sizeof(m_rgRegions[i].m_rgflNextKinsDist));
		memset(&m_rgRegions[i].m_rgpnNextKins, NULL, sizeof(m_rgRegions[i].m_rgpnNextKins));
		m_rgRegions[i].m_uKinCounts = 0;
	}

	// we need to update the kin status of all regions. it's not bounded to the current one we are adding.
	// there are some list we need to prepared: node's kin from each region.
	std::list<CWPRegion*> lAjcRegions;

	for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		// clear list for each loop.
		lAjcRegions.clear();

		for (auto pNode : m_rgRegions[i].m_lstnChildren)
		{
			for (unsigned j = 0; j < pNode->m_uKinCounts; j++)
			{
				// if this kin have a different parent from CURnode, then it must be the border.
				if (((CWPNode*)pNode->m_rgpnNextKins[j])->m_prParent != &m_rgRegions[i])
					lAjcRegions.push_back(((CWPNode*)pNode->m_rgpnNextKins[j])->m_prParent);
			}
		}

		for (auto pRegion : lAjcRegions)
		{
			// prevent some accident...
			if (pRegion && pRegion != &m_rgRegions[i])
				EnforcePath(&m_rgRegions[i], pRegion);	// we don't need to do both way. you can jump down from a bridge doesn't means that you can climb up.
		}
	}

	// this is the old way, for reference only.
	/*for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		for (unsigned j = 0; j < m_uRegionCounts; j++)
			AddPath(&m_rgRegions[i], &m_rgRegions[j]);
	}*/
}

void CWayPoint::PGInit(void)
{
	// this is a job which even harder than de-redundant.
	// path is different from redundant nodes, a path downward doesn't necessary means there is a path upward.
	// thus this time, we really need to trace each node with all other nodes.

	// remove all existed node path first.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		memset(&m_rgnNodes[i].m_rgflNextKinsDist, NULL, sizeof(m_rgnNodes[i].m_rgflNextKinsDist));
		memset(&m_rgnNodes[i].m_rgpnNextKins, NULL, sizeof(m_rgnNodes[i].m_rgpnNextKins));
		m_rgnNodes[i].m_uKinCounts = 0;
	}

	// start from first one.
	m_sPathGenerator.m_uCurrent = 0;

	// since we are using trace here, try once per frame.
	m_sPathGenerator.m_flThink = gpGlobals->time;
}

void CWayPoint::PGThink(void)
{
	// first, we need to make sure we are not thinking ahead.
	if (m_sPathGenerator.m_flThink <= 0 || m_sPathGenerator.m_flThink > gpGlobals->time)
		return;

	// if we're running overhead, get back before too late, i.e. CTD.
	if (m_sPathGenerator.m_uCurrent >= m_uNodeCounts)
	{
		m_sPathGenerator.m_flThink = -1;
		return;
	}

	// we need to update the kin status of all nodes. it's not bounded to the current one we are adding.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
		AddPath(&m_rgnNodes[m_sPathGenerator.m_uCurrent], &m_rgnNodes[i]);

	// making a hint at server console to confort user.
	sprintf(m_szServerPrintWords, "[PathGenerator] %.1f%%, %d/%d\n", (float(m_sPathGenerator.m_uCurrent) / float(m_uNodeCounts)) * 100.0f, m_sPathGenerator.m_uCurrent, m_uNodeCounts);
	g_engfuncs.pfnServerPrint(m_szServerPrintWords);

	// increase one then.
	m_sPathGenerator.m_uCurrent++;
}

void CWayPoint::UpdateNode(CWPNode* pNode)
{
	memset(&pNode->m_rgflNextKinsDist, NULL, sizeof(pNode->m_rgflNextKinsDist));
	memset(&pNode->m_rgpnNextKins, NULL, sizeof(pNode->m_rgpnNextKins));
	pNode->m_uKinCounts = 0;

	for (unsigned i = 0; i < m_uNodeCounts; i++)
		AddPath(pNode, &m_rgnNodes[i]);
}

void CWayPoint::AStar(void)
{
#define CUR	m_AStarTableN[pCur->m_uIndex]
#define AJC	m_AStarTableN[pCur->m_rgpnNextKins[i]->m_uIndex]

	m_bAStarFound = false;	// default value.
	m_lpResult.clear();	// otherwise our memory will explode.

	// declare vars outside a loop to save efficiency.
	CWPBase* trace = nullptr;
	float potentialG = 0, potentialF = 0;
	unsigned iLowest = 0, i = 0;

	std::vector<CWPBase*> vOpen;
	vOpen.clear();	// we need a open list btw, we already got our candidate pool, m_rgnNodes

	// initialise A* table.
	memset(&m_AStarTableN, NULL, sizeof(m_AStarTableN));

	// the current vertex is the src
	CWPBase* pCur = m_pSrc;

	// calc H value of src
	CUR.h = (m_pEnd->m_vecOrigin - m_pSrc->m_vecOrigin).Length();

	// calc F value of src
	CUR.f = CUR.g + CUR.h;

	// the key point and the terminal condition.
	while (pCur != m_pEnd)
	{
		// for each vertex adjacent to current
		for (i = 0; i < pCur->m_uKinCounts; i++)
		{
			// it must be an unclosed one.
			if (!AJC.m_bClosed)
			{
				// add to open list
				// for those who already in the open list, just update their H value.
				if (!AJC.m_bOpened)
				{
					AJC.m_bOpened = true;
					vOpen.push_back((CWPNode *)pCur->m_rgpnNextKins[i]);
				}

				// calc G, the distance from start
				trace = pCur;	// we need to assmue that it comes from the current one. for the 2nd meeting verteces, especially.
				potentialG = 0;
				while (trace)
				{
					potentialG += m_AStarTableN[trace->m_uIndex].m_flDistFrom;
					trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
				}

				// calc H. it's a constant, so we can just assign value without an "if"
				AJC.h = (pCur->m_rgpnNextKins[i]->m_vecOrigin - m_pEnd->m_vecOrigin).Length();

				// calc F = G + H
				potentialF = potentialG + AJC.h;

				// if potential F is smaller than the existed F, replace whole database.
				if (potentialF < AJC.f || AJC.f <= 0 || !AJC.m_pFrom)
				{
					AJC.f = potentialF;
					AJC.g = potentialG;
					AJC.m_pFrom = pCur;
					AJC.m_flDistFrom = pCur->m_rgflNextKinsDist[i];
				}
			}
		}

		// after all adjacent verteces has been scanned, add the pCur to the close list.
		CUR.m_bClosed = true;

		// find the vertex with lowest F value in open list as the successor.
		iLowest = 0;
		for (i = 0; i < vOpen.size(); i++)
		{
			if (m_AStarTableN[vOpen[iLowest]->m_uIndex].f < m_AStarTableN[vOpen[i]->m_uIndex].f)
				continue;

			iLowest = i;
		}

		// before we access vOpen, it could be just can't find a proper path due to a isolated node.
		if (iLowest >= vOpen.size())
		{
			// the only thing we can do, is just save a partial path & return.

			trace = m_AStarTableN[pCur->m_uIndex].m_pFrom;
			while (trace)
			{
				m_lpResult.push_front(trace);
				trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
			}

			m_bAStarFound = false;

			return;
		}

		// make it current
		pCur = vOpen[iLowest];

		// remove it from open list.
		auto iterator = vOpen.begin();
		while (*iterator != pCur)
		{
			iterator++;
		}
		vOpen.erase(iterator);
	}

	// saving result.
	m_lpResult.clear();
	m_lpResult.push_front(m_pEnd);

	trace = m_AStarTableN[m_pEnd->m_uIndex].m_pFrom;
	while (trace)
	{
		m_lpResult.push_front(trace);
		trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
	}

	m_bAStarFound = true;

#undef CUR
#undef AJC
}

void CWayPoint::Meshing(CBasePlayer *pPlayer)
{
	// what we trying to do is meshing the entire ground under the "roof" where our player currently stand.
	// the player entity has a boxy size of 32*32*72
	// thus we divide our boxes to some chunks with exact same size of player.
	// the Z coord will be determind by tracehull up and down.

	TraceResult tr;
	UTIL_TraceHull(pPlayer->pev->origin, pPlayer->pev->origin + Vector(0, 0, 8192), ignore_monsters, human_hull, pPlayer->edict(), &tr);

	// get the roof Z coord, then we can TraceHull down from it.
	float flSkyHeight = tr.vecEndPos.z;

	// some vars. for efficiency, declare it outside can avoid constructing and destructing.
	Vector vecSrc, vecEnd;

	for (float i = -8192; i <= 8192; i += 32)
	{
		for (float j = -8192; j <= 8192; j += 32)
		{
			for (float k = flSkyHeight; k >= -8192; k -= 36)	// subtract a crouching height of a person each time.
			{
				vecSrc = Vector(i, j, k);	// the roof
				vecEnd = Vector(i, j, k - 8192);	// trace down.

				UTIL_TraceHull(vecSrc, vecEnd, ignore_monsters, human_hull, pPlayer->edict(), &tr);	// the first hull is for a ground coord.
				UTIL_TraceHull(tr.vecEndPos, tr.vecEndPos, ignore_monsters, human_hull, pPlayer->edict(), &tr); // the second hull is for stuck test.

				if (tr.fAllSolid || !tr.fInOpen || tr.flFraction < 1.0f || tr.fStartSolid)	// this should not be a buggy location.
					continue;

				m_lvCandidates.push_back(tr.vecEndPos);	// push it into candidate list.
			}
		}
	}
}

void CWayPoint::MeshingInit(CBasePlayer* pPlayer)
{
	// what we trying to do is meshing the entire ground under the "roof" where our player currently stand.
	// the player entity has a boxy size of 32*32*72
	// thus we divide our boxes to some chunks with exact same size of player.
	// the Z coord will be determind by tracehull up and down.

	// now we divide this long task into frames, with hint printed in console
	// not only we won't be disconnect from game, but also users can know the percentage.

	// clean up all old meshing data.
	memset(&m_sMeshing, NULL, sizeof(m_sMeshing));
	m_lvCandidates.clear();

	// reset x and y positions
	m_sMeshing.i = m_sMeshing.j = -8192;

	// reset z to player's current "roof"
	UTIL_TraceHull(pPlayer->pev->origin, pPlayer->pev->origin + Vector(0, 0, 8192), ignore_monsters, human_hull, pPlayer->edict(), &m_sMeshing.tr);

	// get the roof Z coord, then we can TraceHull down from it.
	m_sMeshing.m_flSkyHeight = m_sMeshing.tr.vecEndPos.z;

	// as for the time inteval, let's just use default frame rate.
	m_sMeshing.m_flThink = gpGlobals->time;
}

void CWayPoint::MeshingThink(void)
{
	// now after the setup, we can do our job.
	// let's do it slowly, one X axis step per frame.
	// since we are doing a FOR loop by ourselves, so this function should only contain the part we want to loop.
	// using j and other vars as usual, but manully add i value at the end.

	// first, we need to make sure we are not thinking ahead.
	if (m_sMeshing.m_flThink <= 0 || m_sMeshing.m_flThink > gpGlobals->time)
		return;

	// if i is greater than border value, stop thinking, marking end and return.
	if (m_sMeshing.i > 8192.0f)
	{
		m_sMeshing.m_flThink = -1;
		return;
	}

	// let's get start.
	for (m_sMeshing.j = -8192; m_sMeshing.j <= 8192; m_sMeshing.j += 32)
	{
		for (m_sMeshing.k = m_sMeshing.m_flSkyHeight; m_sMeshing.k >= -8192; m_sMeshing.k -= 36)	// subtract a crouching height of a person each time.
		{
			m_sMeshing.vecSrc = Vector(m_sMeshing.i, m_sMeshing.j, m_sMeshing.k);	// the roof
			m_sMeshing.vecEnd = Vector(m_sMeshing.i, m_sMeshing.j, m_sMeshing.k - 72);	// trace down. LUNA: originally I subtract 8192, but I thought this behaviour could lead to millions of node candidates.

			UTIL_TraceHull(m_sMeshing.vecSrc, m_sMeshing.vecEnd, ignore_monsters, human_hull, nullptr, &m_sMeshing.tr);	// the first hull is for a ground coord.

			// LUNA: added due to changing the vecEnd to only k-72.
			if (m_sMeshing.tr.flFraction >= 1.0f)	// if the first trace hits nothing, we shall move on. this vecEndPos is in the air and totally worthless.
				continue;

			// from PM_WalkMove() function. any surface cannot be pass if its Z component of surface normal vector is smaller than 0.7f.
			if (m_sMeshing.tr.vecPlaneNormal.z < 0.7f)
				continue;

			UTIL_TraceHull(m_sMeshing.tr.vecEndPos, m_sMeshing.tr.vecEndPos, ignore_monsters, human_hull, nullptr, &m_sMeshing.tr); // the second hull is for stuck test.

			if (m_sMeshing.tr.fAllSolid || !m_sMeshing.tr.fInOpen || m_sMeshing.tr.flFraction < 1.0f || m_sMeshing.tr.fStartSolid)	// this should not be a buggy location.
				continue;

			m_lvCandidates.push_back(m_sMeshing.tr.vecEndPos);	// push it into candidate list.
		}
	}

	// making a hint at server console to confort user.
	sprintf(m_szServerPrintWords, "[Meshing] %.1f%%, %d/16384\n", ((m_sMeshing.i + 8192.0f) / 16384.0f) * 100.0f, int(m_sMeshing.i + 8192.0f));
	g_engfuncs.pfnServerPrint(m_szServerPrintWords);

	// manully take a increase step.
	m_sMeshing.i += 32.0f;
}

void CWayPoint::DeRedundant(void)
{
	for (auto base = m_lvCandidates.cbegin(); base != m_lvCandidates.cend(); base++)
	{
		auto check = base;
		check++;	// start with base + 1, since everything before base must already compared with base.

		while (check != m_lvCandidates.cend())
		{
			if ((*base - *check).LengthSquared() <= 4.0f)
			{
				check = m_lvCandidates.erase(check);	// erase function returns the next element of the one being deleted.
			}
			else
			{
				check++;
			}
		}
	}
}

void CWayPoint::DRInit(void)
{
	// this is really a hard work. if we don't tare it apart into lots of frames, it will stuck the game and eventually triggers disconnection.
	// thus, we need to do this job part by part, like meshing map.

	// if we don't have any elements, stop this initialization process.
	if (m_lvCandidates.empty())
		return;

	// first, empty our container.
	memset(&m_sDeRedundant, NULL, sizeof(m_sDeRedundant));

	// assign our base iterator
	m_sDeRedundant.base = m_lvCandidates.cbegin();

	// setup think time. try one scan per frame now.
	m_sDeRedundant.m_flThink = gpGlobals->time;
}

void CWayPoint::DRThink(void)
{
	// first, we need to make sure we are not thinking ahead.
	if (m_sDeRedundant.m_flThink <= 0 || m_sDeRedundant.m_flThink > gpGlobals->time)
		return;

	// if the current base is the end of std::list, then we shall stop.
	if (m_sDeRedundant.base == m_lvCandidates.cend())
	{
		m_sDeRedundant.m_flThink = -1;
		return;
	}

	m_sDeRedundant.check = m_sDeRedundant.base;
	m_sDeRedundant.check++;	// start with base + 1, since everything before base must already compared with base.

	// then check all elements after current, whether they are duplicator of our current one.
	// why we don't checking elements before is because that we already check the relation between them and current one in former loop.
	while (m_sDeRedundant.check != m_lvCandidates.cend())
	{
		if ((*m_sDeRedundant.base - *m_sDeRedundant.check).LengthSquared() <= 4.0f)
		{
			m_sDeRedundant.check = m_lvCandidates.erase(m_sDeRedundant.check);	// erase function returns the next element of the one being deleted.
		}
		else
		{
			m_sDeRedundant.check++;
		}
	}

	// print some hint word to comfort user.
	// unlike what we done in meshing, we cant give a percentage. sorry for that.
	m_sDeRedundant.m_uProgress++;
	sprintf(m_szServerPrintWords, "[DeRedundant] %.1f%%, %d of %d node(s) left.\n", float(m_sDeRedundant.m_uProgress) / float(m_lvCandidates.size()) * 100.0f, m_sDeRedundant.m_uProgress, m_lvCandidates.size());
	g_engfuncs.pfnServerPrint(m_szServerPrintWords);

	// after everything, increase base safely.
	m_sDeRedundant.base++;
}

bool CWayPoint::AddPath(CWPBase* pCenter, CWPBase* pnKin)
{
	// you can't make yourself the nearest node.
	if (pCenter->m_uIndex == pnKin->m_uIndex)
		return false;

	// you can't link nodes with different level.
	if (pCenter->m_iStructuralLevel != pnKin->m_iStructuralLevel)
		return false;

	// you can't connect to same node twice.
	bool bDup = false;
	for (unsigned k = 0; k < pCenter->m_uKinCounts; k++)
	{
		if (pCenter->m_rgpnNextKins[k]->m_uIndex != pnKin->m_uIndex)
			continue;

		bDup = true;
		break;
	}

	if (bDup)
		return false;
	
	//m_sPathGenerator.tr;	// we need to check the visibility before tie them together.

	// becore checking visibility, we have to check the height difference, then make some fix for it.
	m_sPathGenerator.flZDelta = pCenter->m_vecOrigin.z - pnKin->m_vecOrigin.z;

	// since this two is a global var, we need to reset it each time, avoid residue data from last height test interfering current one.
	m_sPathGenerator.vecOffset1 = g_vecZero;
	m_sPathGenerator.vecOffset2 = g_vecZero;

	if (m_sPathGenerator.flZDelta > 0 && m_sPathGenerator.flZDelta <= WP_DEATH_DROP)	// in this case, it means pCenter is higher than pnKin. but unlike clamb, you can just jump down. we set the compensation limit to lethal height, 200.0f
	{
		// it doesn't matter their exact difference. we just need to make sure they have same height.
		m_sPathGenerator.vecOffset1 = g_vecZero;
		m_sPathGenerator.vecOffset2 = Vector(0, 0, m_sPathGenerator.flZDelta);
	}
	else if (m_sPathGenerator.flZDelta < 0 && (-m_sPathGenerator.flZDelta) <= WP_JUMP_CROUCH_HEIGHT)	// however, when it comes to here, it indecates that pnKin is higher than pCenter. this is a totally different circumstances due to the fact you can't clamb up.
	{
		// remember, we don't want to make origin stuck in ground, so inverse the number.
		m_sPathGenerator.vecOffset1 = Vector(0, 0, -m_sPathGenerator.flZDelta);
		m_sPathGenerator.vecOffset2 = g_vecZero;
	}

	// then we can take a traceline, with those offset value.
	//if ((pCenter->m_bitsNodeFlags & WP_N_FL_CROUCH) || (pnKin->m_bitsNodeFlags & WP_N_FL_CROUCH))
		UTIL_TraceHull(pCenter->m_vecOrigin + m_sPathGenerator.vecOffset1, pnKin->m_vecOrigin + m_sPathGenerator.vecOffset2, ignore_monsters, head_hull, nullptr, &m_sPathGenerator.tr);
	//else
		//UTIL_TraceHull(pCenter->m_vecOrigin + m_sPathGenerator.vecOffset1, pnKin->m_vecOrigin + m_sPathGenerator.vecOffset2, ignore_monsters, human_hull, nullptr, &m_sPathGenerator.tr);
	//UTIL_TraceLine(pCenter->m_vecOrigin + m_sPathGenerator.vecOffset1, pnKin->m_vecOrigin + m_sPathGenerator.vecOffset2, ignore_monsters, ignore_glass, nullptr, &m_sPathGenerator.tr);

	if (m_sPathGenerator.tr.fAllSolid || m_sPathGenerator.tr.fStartSolid || !m_sPathGenerator.tr.fInOpen || m_sPathGenerator.tr.flFraction < 1.0f)
		return false;	// we can't use it as a path.
	
	// still need distance. if the distance we attempt to adding is further than its all kins, there will be no points.
	float flDistance = (pnKin->m_vecOrigin - pCenter->m_vecOrigin).Length();
	unsigned iFarthest = pCenter->FindFarthestKin();

	// if the kins of pCenter is smaller than 8, just add it.
	if (pCenter->m_uKinCounts < 8)
	{
		pCenter->m_rgpnNextKins[pCenter->m_uKinCounts] = pnKin;	// assign node pointer to the kins list of pCenter.
		pCenter->m_rgflNextKinsDist[pCenter->m_uKinCounts] = flDistance;	// assign distance value to the kins list of pCenter.
		pCenter->m_uKinCounts++;	// increase his kin counts.
	}
	else if (flDistance < pCenter->m_rgflNextKinsDist[iFarthest])	// if it is really better then one of these nodes
	{
		// in that case, we need to find out which one is the farthest, then replace it.

		pCenter->m_rgpnNextKins[iFarthest] = pnKin;
		pCenter->m_rgflNextKinsDist[iFarthest] = flDistance;

		// this time, we don't need to increase his kin counts. it's already 8.
	}
	else
		return false;	// if's farther than the farthest kin node. don't add it.

	return true;
}

void CWayPoint::EnforcePath(CWPBase* pCenter, CWPBase* pnKin)
{
	// in this situation, we don't need to consider anything about whether they are fit, etc...
	// just link them together.

	if (!pCenter || !pnKin)
		return;

	// you can't connect to same node twice, even in a enforced situation.
	bool bDup = false;
	for (unsigned k = 0; k < pCenter->m_uKinCounts; k++)
	{
		if (pCenter->m_rgpnNextKins[k]->m_uIndex != pnKin->m_uIndex)
			continue;

		bDup = true;
		break;
	}

	if (bDup)
		return;

	unsigned iFarthest = pCenter->FindFarthestKin();

	// if the kins of pCenter is smaller than 8, just add it.
	if (pCenter->m_uKinCounts < 8)
	{
		pCenter->m_rgpnNextKins[pCenter->m_uKinCounts] = pnKin;	// assign node pointer to the kins list of pCenter.
		pCenter->m_rgflNextKinsDist[pCenter->m_uKinCounts] = (pCenter->m_vecOrigin - pnKin->m_vecOrigin).Length();	// assign distance value to the kins list of pCenter.
		pCenter->m_uKinCounts++;	// increase his kin counts.
	}
	else
	{
		// in that case, we need to find out which one is the farthest, then replace it.

		pCenter->m_rgpnNextKins[iFarthest] = pnKin;
		pCenter->m_rgflNextKinsDist[iFarthest] = (pCenter->m_vecOrigin - pnKin->m_vecOrigin).Length();

		// this time, we don't need to increase his kin counts. it's already 8.
	}
}

void CWayPoint::DelPath(CWPBase* pNode, unsigned uSiblingIndex)
{
	if (uSiblingIndex == 7)
	{
		// if it's the last element, use a different method to avoid potential bug.
		pNode->m_rgpnNextKins[uSiblingIndex] = nullptr;
		pNode->m_rgflNextKinsDist[uSiblingIndex] = 0;
		pNode->m_uKinCounts--;
	}
	else
	{
		// normally, we del it and memmove.
		memmove(&pNode->m_rgpnNextKins[uSiblingIndex], &pNode->m_rgpnNextKins[uSiblingIndex + 1], sizeof(void*) * (8 - uSiblingIndex - 1));
		memmove(&pNode->m_rgflNextKinsDist[uSiblingIndex], &pNode->m_rgflNextKinsDist[uSiblingIndex + 1], sizeof(float) * (8 - uSiblingIndex - 1));
		pNode->m_uKinCounts--;
	}
}

void CWayPoint::ImportCandidates(void)
{
	// what can we do without any candidates ??
	if (m_lvCandidates.empty())
		return;

	for (auto vecCandidate : m_lvCandidates)
	{
		// overflow is not allowed.
		if (m_uNodeCounts >= MAX_WP_NODES)
			break;

		AddNode(vecCandidate);
	}

	// release memory after we done.
	m_lvCandidates.clear();
}

void CWayPoint::AddRegion(Vector& vecOrigin)
{
	CWPRegion* p = &m_rgRegions[m_uRegionCounts];

	p->m_uIndex = m_uRegionCounts;
	p->m_vecOrigin = Vector(vecOrigin.x, vecOrigin.y, vecOrigin.z + 64.0f);
	p->m_bitsNodeFlags = 0;
	p->a = p->b = 200;
	p->c = 100;
	sprintf(p->m_szName, "region_%d", m_uRegionCounts);

	m_uRegionCounts++;
}

void CWayPoint::DelRegion(CBaseEntity* pEntity)
{
	CWPRegion* p = FindRegion(pEntity->pev->origin);

	for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		if (i == p->m_uIndex)
			continue;

		for (unsigned j = 0; j < m_rgRegions[i].m_uKinCounts; j++)
		{
			// if the current region have a relationship with the region to be del
			if (m_rgRegions[i].m_rgpnNextKins[j]->m_uIndex == p->m_uIndex)
				DelPath(&m_rgRegions[i], j);	// then just del it.
		}
	}

	// we need another loop to make its child nodes orphan.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		if (m_rgnNodes[i].m_prParent && m_rgnNodes[i].m_prParent->m_uIndex == p->m_uIndex)
			m_rgnNodes[i].m_prParent = nullptr;
	}

	// then we need to clean it from the array.
	unsigned uIndex = p->m_uIndex;
	memmove(&m_rgRegions[uIndex], &m_rgRegions[uIndex + 1], sizeof(CWPRegion) * (MAX_WP_REGIONS - uIndex - 1));
	m_uRegionCounts--;

	// a re-index is needed. the +1 is for the original "last" element.
	for (unsigned i = 0; i < m_uRegionCounts + 1; i++)
		m_rgRegions[i].m_uIndex = i;

	// there two steps cannot be merged.
	for (unsigned i = 0; i < m_uRegionCounts; i++)
	{
		// so does a re-oriented of pointers.
		for (unsigned j = 0; j < m_rgRegions[i].m_uKinCounts; j++)
		{
			// since there is no index == p->m_uIndex. so we can use a m_uIndex >= uIndex. this is because that the new p->m_uIndex must came from the re-index above.
			if (m_rgRegions[i].m_rgpnNextKins[j]->m_uIndex >= uIndex)
				m_rgRegions[i].m_rgpnNextKins[j] = &m_rgRegions[m_rgRegions[i].m_rgpnNextKins[j]->m_uIndex - 1];
		}
	}
}

void CWayPoint::AssignNodeToRgn(void)
{
#define CUR_RGN	m_rgRegions[j]
#define CUR_NOD	m_rgnNodes[i]

	// clear old data.
	for (unsigned i = 0; i < m_uNodeCounts; i++)
		CUR_NOD.m_prParent = nullptr;

	for (unsigned j = 0; j < m_uRegionCounts; j++)
		CUR_RGN.m_lstnChildren.clear();

	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		for (unsigned j = 0; j < m_uRegionCounts; j++)
		{
			// if this node is in this region
			if (CUR_RGN.InCuboid(CUR_NOD.m_vecOrigin))
			{
				// orphan? adoption!
				if (!CUR_NOD.m_prParent)
					CUR_NOD.m_prParent = &CUR_RGN;

				// add to family.
				CUR_RGN.m_lstnChildren.push_back(&CUR_NOD);

				// stop this loop once we found one region as parent.
				break;
			}
		}
	}

#undef CUR_RGN
#undef CUR_NOD
}

void CWayPoint::RegionGenerator(void)	// Algorithm by: Luna
{
	// clear the tool set. this tool set is different, a std::list is included, we can't just simply use memset.
	m_sRegionGenerator.m_lstOrphans.clear();
	m_sRegionGenerator.m_lstBuffer.clear();

	// clear all existed regions
	for (unsigned i = 0; i < m_uRegionCounts; i++)
		m_rgRegions[i].Clear();
	m_uRegionCounts = 0;

	// clear all records of existed regions
	for (unsigned i = 0; i < m_uNodeCounts; i++)
	{
		m_rgnNodes[i].m_prParent = nullptr;

		// by the way, add all nodes into waiting (a.k.a. orphan) list.
		m_sRegionGenerator.m_lstOrphans.push_back(&m_rgnNodes[i]);
	}

	// no stop until we have all orphans adopted.
	while (!m_sRegionGenerator.m_lstOrphans.empty())
	{
		// if the region buffer is empty, we should start over.
		if (m_sRegionGenerator.m_lstBuffer.empty())
		{
			// move the first orphan in list into buffer.
			m_sRegionGenerator.m_lstBuffer.splice(m_sRegionGenerator.m_lstBuffer.cend(), m_sRegionGenerator.m_lstOrphans, m_sRegionGenerator.m_lstOrphans.cbegin());
		}
		
		// for all orphans waiting in the list, check them whether they fit in this region?
		// this is the core of this algorithm, all criteria would be here.
		for (auto iterOrphan = m_sRegionGenerator.m_lstOrphans.cbegin(); iterOrphan != m_sRegionGenerator.m_lstOrphans.cend();/*NOTHING HERE*/)
		{
			// reset to default value;
			m_sRegionGenerator.bCanAdopt = true;

			// need to check with all future brothers.
			for (auto pNodeInRgn : m_sRegionGenerator.m_lstBuffer)
			{
				// get the height difference. < 0 for a node below region, > 0 for a node above region.
				m_sRegionGenerator.deltaZ = (*iterOrphan)->m_vecOrigin.z - pNodeInRgn->m_vecOrigin.z;

				// if there are too much height difference, we may should exclude this node from current processing region.
				if (fabsf(m_sRegionGenerator.deltaZ) > WP_JUMP_CROUCH_HEIGHT)
				{
					m_sRegionGenerator.bCanAdopt = false;
					break;	// LUNA: I thinks there is no need to "continue" if any or these point is unreachable from this orphan node.
				}

				// take a trace.
				UTIL_TraceHull(pNodeInRgn->m_vecOrigin, (*iterOrphan)->m_vecOrigin, ignore_monsters, head_hull, nullptr, &m_sRegionGenerator.tr);

				// unreachable?
				if (m_sRegionGenerator.tr.fAllSolid || m_sRegionGenerator.tr.fInWater || !m_sRegionGenerator.tr.fInOpen || m_sRegionGenerator.tr.flFraction < 1.0f || m_sRegionGenerator.tr.fStartSolid)
				{
					m_sRegionGenerator.bCanAdopt = false;
					break;
				}
			}

			// adoption failed, wait for next round.
			if (!m_sRegionGenerator.bCanAdopt)
			{
				iterOrphan++;
				continue;
			}

			// transfer orphan into his new parent's custody
			// LUNA: careful, splice can't used in a iterator-based loop.
			m_sRegionGenerator.m_lstBuffer.push_back(*iterOrphan);
			iterOrphan = m_sRegionGenerator.m_lstOrphans.erase(iterOrphan);
		}

		// after this for loop, all orphans who fit with the first one in the buffer is transfered.
		// it is time to build a new region base on these.

		CWPRegion* p = &m_rgRegions[m_uRegionCounts];

		// for the origin of this region, take average value.
		p->m_vecOrigin = g_vecZero;
		for (auto pNodeInRgn : m_sRegionGenerator.m_lstBuffer)
			p->m_vecOrigin += pNodeInRgn->m_vecOrigin / float(m_sRegionGenerator.m_lstBuffer.size());

		p->m_uIndex = m_uRegionCounts;
		p->m_bitsNodeFlags = 0;

		// for the size(a, b and c) of this region, find the max and min of the corresponding component, and subtract max by min.
		auto result = std::minmax_element(m_sRegionGenerator.m_lstBuffer.cbegin(), m_sRegionGenerator.m_lstBuffer.cend(),
			[](const auto& pFirst, const auto& pSecond)
			{
				return (pFirst->m_vecOrigin.x < pSecond->m_vecOrigin.x);
			}
		);
		p->a = fabsf((*result.second)->m_vecOrigin.x - (*result.first)->m_vecOrigin.x) / 2.0f;	// "first" is the min, "second" is the max.

		result = std::minmax_element(m_sRegionGenerator.m_lstBuffer.cbegin(), m_sRegionGenerator.m_lstBuffer.cend(),
			[](const auto & pFirst, const auto & pSecond)
			{
				return (pFirst->m_vecOrigin.y < pSecond->m_vecOrigin.y);
			}
		);
		p->b = fabsf((*result.second)->m_vecOrigin.y - (*result.first)->m_vecOrigin.y) / 2.0f;

		result = std::minmax_element(m_sRegionGenerator.m_lstBuffer.cbegin(), m_sRegionGenerator.m_lstBuffer.cend(),
			[](const auto & pFirst, const auto & pSecond)
			{
				return (pFirst->m_vecOrigin.z < pSecond->m_vecOrigin.z);
			}
		);
		p->c = fabsf((*result.second)->m_vecOrigin.z - (*result.first)->m_vecOrigin.z) / 2.0f;

		// print its name.
		sprintf(p->m_szName, "region_%d", m_uRegionCounts);

		// setup children list.
		p->m_lstnChildren.splice(p->m_lstnChildren.cend(), m_sRegionGenerator.m_lstBuffer);

		// tell children who is their parent.
		for (auto pChild : p->m_lstnChildren)
			pChild->m_prParent = p;

		// region registration complete.
		m_uRegionCounts++;
	}
}

void CWayPoint::RegionGenerator2(void)	// Algorithm by: Usagi
{
	// clear the tool set. this tool set is different, a std::list is included, we can't just simply use memset.
	lstn_t	lstnInvited;
	lstn_t	lstnBuffer;
	lstnInvited.clear();
	lstnBuffer.clear();

	// clear all existed regions
	for (unsigned i = 0; i < m_uRegionCounts; i++)
		m_rgRegions[i].Clear();
	m_uRegionCounts = 0;

	// clear all records of existed regions
	for (unsigned i = 0; i < m_uNodeCounts; i++)
		m_rgnNodes[i].m_prParent = nullptr;

	// add the first node (uIndex == 0) into list as a start.
	lstnBuffer.push_back(&m_rgnNodes[0]);

	// and we should invite all kins of m_rgnNodes[0] into candidates.
	for (unsigned i = 0; i < m_rgnNodes[0].m_uKinCounts; i++)
		lstnInvited.push_back((CWPNode*)m_rgnNodes[0].m_rgpnNextKins[i]);

	// assign parent: prevent from assign a node repeatly.
	m_rgnNodes[0].m_prParent = &m_rgRegions[m_uRegionCounts];

	TraceResult tr;
	CWPNode* pCandidate;
	bool bCanAdopt = true;

	// do until all invited candidates are processed.
	while (!lstnInvited.empty())
	{
		pCandidate = lstnInvited.front();
		bCanAdopt = true;

		// we need to check whether all brother already in this family is agreed.
		for (auto pNodeInRgn : lstnBuffer)
		{
			if (pCandidate == pNodeInRgn)	// something must be wrong here.
			{
				bCanAdopt = false;
				break;
			}

			UTIL_TraceLine(pCandidate->m_vecOrigin, pNodeInRgn->m_vecOrigin, ignore_monsters, ignore_glass, nullptr, &tr);

			// base rule of generating a region: pick two node in the region, they can always see each other.
			if (tr.fAllSolid || !tr.fInOpen || tr.flFraction < 1.0f || tr.fStartSolid)
			{
				bCanAdopt = false;
				break;	// LUNA: I thinks there is no need to "continue" if anyone in family can't directly reach this candidate.
			}

			// a region should not include both land node and water node.
			if (tr.fInWater && (POINT_CONTENTS(pCandidate->m_vecOrigin) != CONTENT_WATER || POINT_CONTENTS(pNodeInRgn->m_vecOrigin) != CONTENT_WATER))
			{
				bCanAdopt = false;
				break;
			}
		}

		if (bCanAdopt)
		{
			// add this candidate into adoption list.
			lstnBuffer.push_back(pCandidate);

			// pre-assign its parent.
			pCandidate->m_prParent = &m_rgRegions[m_uRegionCounts];

			// remove this adopted candidate from list.
			lstnInvited.pop_front();

			// invite only adopted candidate's kins.
			for (unsigned i = 0; i < pCandidate->m_uKinCounts; i++)
			{
				if (!((CWPNode*)pCandidate->m_rgpnNextKins[i])->m_prParent)	// is his kin an orphan?
					lstnInvited.push_back(((CWPNode*)pCandidate->m_rgpnNextKins[i]));
			}
		}
		else	// otherwise, we just simply need to remove it.
			lstnInvited.pop_front();

		// if we run out of candidates, it means we can officially announce a new region.
		if (lstnInvited.empty())
		{
LAB_AUTOREGION2_DECLARE_NEW_REGION:

			CWPRegion* p = &m_rgRegions[m_uRegionCounts];

			// for the origin of this region, take average value.
			p->m_vecOrigin = g_vecZero;
			for (auto pNodeInRgn : lstnBuffer)
				p->m_vecOrigin += pNodeInRgn->m_vecOrigin / float(lstnBuffer.size());

			p->m_uIndex = m_uRegionCounts;
			p->m_bitsNodeFlags = 0;

			// for the size(a, b and c) of this region, find the max and min of the corresponding component, and subtract max by min.
			auto result = std::minmax_element(lstnBuffer.cbegin(), lstnBuffer.cend(),
				[](const auto & pFirst, const auto & pSecond)
				{
					return (pFirst->m_vecOrigin.x < pSecond->m_vecOrigin.x);
				}
			);
			p->a = fabsf((*result.second)->m_vecOrigin.x - (*result.first)->m_vecOrigin.x) / 2.0f;	// "first" is the min, "second" is the max.

			result = std::minmax_element(lstnBuffer.cbegin(), lstnBuffer.cend(),
				[](const auto & pFirst, const auto & pSecond)
				{
					return (pFirst->m_vecOrigin.y < pSecond->m_vecOrigin.y);
				}
			);
			p->b = fabsf((*result.second)->m_vecOrigin.y - (*result.first)->m_vecOrigin.y) / 2.0f;

			result = std::minmax_element(lstnBuffer.cbegin(), lstnBuffer.cend(),
				[](const auto & pFirst, const auto & pSecond)
				{
					return (pFirst->m_vecOrigin.z < pSecond->m_vecOrigin.z);
				}
			);
			p->c = fabsf((*result.second)->m_vecOrigin.z - (*result.first)->m_vecOrigin.z) / 2.0f;

			// print its name.
			sprintf(p->m_szName, "region_%d", m_uRegionCounts);

			// setup children list.
			p->m_lstnChildren.splice(p->m_lstnChildren.cend(), lstnBuffer);

			// tell children who is their parent.
			for (auto pChild : p->m_lstnChildren)
				pChild->m_prParent = p;

			// region registration complete.
			m_uRegionCounts++;

			// and now, is our duty to start building another region.
			// just like we initilize this process by assign m_rgRegion[0] as a starter.
			unsigned uIdOrphan = 0;
			for (uIdOrphan = 0; uIdOrphan < m_uNodeCounts; uIdOrphan++)
			{
				if (!m_rgnNodes[uIdOrphan].m_prParent)	// find an orphan.
				{
					lstnBuffer.push_back(&m_rgnNodes[uIdOrphan]);
					break;	// stop with this one, since we still need to use uIdOrphan.
				}
			}

			// if we can't find any orphan, it means our job is done.
			if (lstnBuffer.empty())
				break;

			// and we should invite all kins of m_rgnNodes[0] into candidates.
			for (unsigned i = 0; i < m_rgnNodes[uIdOrphan].m_uKinCounts; i++)
			{
				if (!((CWPNode*)m_rgnNodes[uIdOrphan].m_rgpnNextKins[i])->m_prParent)	// is his kin an orphan?
					lstnInvited.push_back((CWPNode*)m_rgnNodes[uIdOrphan].m_rgpnNextKins[i]);
			}

			// assign parent: prevent from assign a node repeatly.
			m_rgnNodes[uIdOrphan].m_prParent = &m_rgRegions[m_uRegionCounts];

			// WTF? all kins are already belong to something?
			if (lstnInvited.empty())
				goto LAB_AUTOREGION2_DECLARE_NEW_REGION;
		}
	}
}

void CWayPoint::Menu_Main(CBasePlayer* pPlayer)
{
	char sz[] =
		"\\yCWayPoint Editor\\w\n"
		"\n"
		"1. Add Node\n"
		"2. Del Node\n"
		"3. Auto Path\n"
		"4. Add Path\n"
		"5. Del Path\n"
		"6. Clear Nodes\n"
		"7. A* Menu\n"
		"8. Save\n"
		"9. Load\n"
		"\n"
		"0. Exit\n"
		;

	ShowMenu(pPlayer, MENU_KEY_0 | MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5 | MENU_KEY_6 | MENU_KEY_7 | MENU_KEY_8 | MENU_KEY_9, -1, FALSE, sz);
	pPlayer->m_iMenu = Menu_CWayPointMain;
	g_cWayPoint.m_bShowNodes = true;
}

void CWayPoint::Menu_AStar(CBasePlayer* pPlayer)
{
	char sz[] =
		"\\yA* Demonstrator\\w\n"
		"\n"
		"1. Set Start Node\n"
		"2. Set End Node\n"
		"3. Set Start Region\n"
		"4. Set End Region\n"
		"5. Run Arithmetic\n"
		"6. Clear Result\n"
		"\n"
		"0. Exit\n"
		;

	ShowMenu(pPlayer, MENU_KEY_0 | MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5 | MENU_KEY_6, -1, FALSE, sz);
	pPlayer->m_iMenu = Menu_CWayPointAStar;
	g_cWayPoint.m_bShowNodes = true;
}

void CWayPoint::Menu_Region_1(CBasePlayer* pPlayer)
{
	char sz[] =
		"\\ySecondary Node (Region) Editor\\w\n"
		"(Page 1/2)\n"
		"\n"
		"1. Add Region\n"
		"2. Del Region\n"
		"3. Auto Path\n"
		"4. Auto Node Assignment\n"
		"\\d5. \\w\n"
		"6. Clear Regions\n"
		"7. Save\n"
		"8. Load\n"
		"\n"
		"9. Next Page\n"
		"0. Exit\n"
		;

	ShowMenu(pPlayer, MENU_KEY_0 | MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5 | MENU_KEY_6 | MENU_KEY_7 | MENU_KEY_8 | MENU_KEY_9, -1, FALSE, sz);
	pPlayer->m_iMenu = Menu_CWayPointRegion1;
	g_cWayPoint.m_bShowRegions = true;
}

void CWayPoint::Menu_Region_2(CBasePlayer* pPlayer)
{
	char sz[] =
		"\\ySecondary Node (Region) Editor\\w\n"
		"(Page 2/2)\n"
		"\n"
		"1. Expand X\n"
		"2. Shrink X\n"
		"3. Expand Y\n"
		"4. Shrink Y\n"
		"5. Expand Z\n"
		"6. Shrink Z\n"
		"7. Forward Shift\n"
		"8. Backward Shift\n"
		"\n"
		"9. Next Page\n"
		"0. Exit\n"
		;

	ShowMenu(pPlayer, MENU_KEY_0 | MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5 | MENU_KEY_6 | MENU_KEY_7 | MENU_KEY_8 | MENU_KEY_9, -1, FALSE, sz);
	pPlayer->m_iMenu = Menu_CWayPointRegion2;
	g_cWayPoint.m_bShowRegions = true;
}

void CWayPoint::Menu_NodeFlagEditor_1(CBasePlayer* pPlayer)
{
#define PL_NODE_FL	pPlayer->m_pNearestNode->m_bitsNodeFlags
#define FL_WORDS(FL, words)	if (PL_NODE_FL & FL) \
								strcat(sz, "\\d"words"\\w\n"); \
							else \
								strcat(sz, words"\n")

	if (!pPlayer->m_pNearestNode)
		return;

	/*char sz[] =
		"\\yNode Flag Editor\\w\n"
		"\n"
		"1. Normal\n"
		"2. Camp\n"
		"3. Crouch\n"
		"4. Section (ES)\n"
		"5. Start (ES)\n"
		"6. End (ES)\n"
		"7. Ladder\n"
		"8. Sniper\n"
		"\n"
		"9. Next Page\n"
		"0. Exit\n"
		;*/

	char sz[512];
	strcpy(sz, "\\yNode Flag Editor\\w\n");
	strcat(sz, "(1/2)\n");
	strcat(sz, "\n");
	strcat(sz, "1. Normal\n");

	// ignore the redlines from stupit VS2019.
	FL_WORDS(WP_N_FL_CAMP,		"2. Camp");
	FL_WORDS(WP_N_FL_CROUCH,	"3. Crouch");
	FL_WORDS(WP_N_FL_SECTION,	"4. Section (ES)");
	FL_WORDS(WP_N_FL_START,		"5. Start (ES)");
	FL_WORDS(WP_N_FL_END,		"6. End (ES)");
	FL_WORDS(WP_N_FL_LADDER,	"7. Ladder");
	FL_WORDS(WP_N_FL_SNIPER,	"8. Sniper");

	strcat(sz, "\n");
	strcat(sz, "9. Next Page\n");
	strcat(sz, "0. Exit");

	ShowMenu(pPlayer, MENU_KEY_0 | MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5 | MENU_KEY_6 | MENU_KEY_7 | MENU_KEY_8 | MENU_KEY_9, -1, FALSE, sz);
	pPlayer->m_iMenu = Menu_CWayPointNodeFlags1;

#undef PL_NODE_FL
#undef FL_WORDS
}

void CWayPoint::Menu_NodeFlagEditor_2(CBasePlayer* pPlayer)
{
#define PL_NODE_FL	pPlayer->m_pNearestNode->m_bitsNodeFlags
#define FL_WORDS(FL, words)	if (PL_NODE_FL & FL) \
								strcat(sz, "\\d"words"\\w\n"); \
							else \
								strcat(sz, words"\n")

	if (!pPlayer->m_pNearestNode)
		return;

	/*char sz[] =
		"\\yNode Flag Editor\\w\n"
		"\n"
		"1. Normal\n"
		"2. Zombie Exclusive\n"
		"3. Human Exclusive\n"
		"4. Jump\n"
		"\n"
		"9. Next Page\n"
		"0. Exit\n"
		;*/

	char sz[512];
	strcpy(sz, "\\yNode Flag Editor\\w\n");
	strcat(sz, "(2/2)\n");
	strcat(sz, "\n");
	strcat(sz, "1. Normal\n");

	// ignore the redlines from stupit VS2019.
	FL_WORDS(WP_N_FL_ZOMBIE,	"2. Zombie Exclusive");
	FL_WORDS(WP_N_FL_HUMAN,		"3. Human Exclusive");
	FL_WORDS(WP_N_FL_JUMP,		"4. Jump");

	strcat(sz, "\n");
	strcat(sz, "9. Next Page\n");
	strcat(sz, "0. Exit");

	ShowMenu(pPlayer, MENU_KEY_0 | MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_3 | MENU_KEY_4 | MENU_KEY_5 | MENU_KEY_6 | MENU_KEY_7 | MENU_KEY_8 | MENU_KEY_9, -1, FALSE, sz);
	pPlayer->m_iMenu = Menu_CWayPointNodeFlags2;

#undef PL_NODE_FL
#undef FL_WORDS
}

void CWayPoint::HandleMenu_Main(CBasePlayer* pPlayer, int iSlot)
{
	switch (iSlot)
	{
		case 1:
		{
			g_cWayPoint.AddNode(pPlayer);
			break;
		}
		case 2:
		{
			g_cWayPoint.DelNode(pPlayer);
			break;
		}
		case 3:
		{
			g_cWayPoint.PGInit();
			break;
		}
		case 4:
		{
			UTIL_MakeVectors(pPlayer->pev->v_angle);
			
			TraceResult tr;
			UTIL_TraceLine(pPlayer->pev->origin + pPlayer->pev->view_ofs, pPlayer->pev->origin + pPlayer->pev->view_ofs + gpGlobals->v_forward * 500.0f, ignore_monsters, ignore_glass, pPlayer->edict(), &tr);

			// if we really using this option, it seems like that we're ran out of methods.
			g_cWayPoint.EnforcePath(pPlayer->m_pNearestNode, g_cWayPoint.FindNode(tr.vecEndPos));	// so, just use enforce.
			break;
		}
		case 5:
		{
			if (pPlayer->m_pNearestNode && pPlayer->m_uSelectedPath < pPlayer->m_pNearestNode->m_uKinCounts)
				g_cWayPoint.DelPath(pPlayer->m_pNearestNode, pPlayer->m_uSelectedPath);

			break;
		}
		case 6:
		{
			for (unsigned i = 0; i < g_cWayPoint.m_uNodeCounts; i++)
			{
				g_cWayPoint.m_rgnNodes[i].Clear();
			}

			g_cWayPoint.m_uNodeCounts = 0;
			g_cWayPoint.m_lpResult.clear();
			break;
		}
		case 7:
		{
			Menu_AStar(pPlayer);
			return;
		}
		case 8:
		{
			g_cWayPoint.Save();
			break;
		}
		case 9:
		{
			g_cWayPoint.Load();
			break;
		}
		case 0:
		default:
		{
			g_cWayPoint.m_bShowNodes = false;
			pPlayer->m_iMenu = Menu_OFF;
			return;
		}
	}

	Menu_Main(pPlayer);
}

void CWayPoint::HandleMenu_AStar(CBasePlayer* pPlayer, int iSlot)
{
	switch (iSlot)
	{
		case 1:
		{
			g_cWayPoint.m_pSrc = g_cWayPoint.FindNode(pPlayer->pev->origin);
			break;
		}
		case 2:
		{
			g_cWayPoint.m_pEnd = g_cWayPoint.FindNode(pPlayer->pev->origin);
			break;
		}
		case 3:
		{
			g_cWayPoint.m_pSrc = g_cWayPoint.FindRegion(pPlayer->pev->origin);
			break;
		}
		case 4:
		{
			g_cWayPoint.m_pEnd = g_cWayPoint.FindRegion(pPlayer->pev->origin);
			break;
		}
		case 5:
		{
			g_cWayPoint.AStar();
			break;
		}
		case 6:
		{
			g_cWayPoint.m_lpResult.clear();
			break;
		}
		case 0:
		default:
		{
			g_cWayPoint.m_bShowNodes = false;
			pPlayer->m_iMenu = Menu_OFF;
			return;
		}
	}

	Menu_AStar(pPlayer);
}

void CWayPoint::HandleMenu_Region_1(CBasePlayer* pPlayer, int iSlot)
{
	switch (iSlot)
	{
		case 1:
		{
			g_cWayPoint.AddRegion(pPlayer->pev->origin);
			break;
		}
		case 2:
		{
			g_cWayPoint.DelRegion(pPlayer);
			break;
		}
		case 3:
		{
			g_cWayPoint.GenerateRegnPath();
			break;
		}
		case 4:
		{
			g_cWayPoint.AssignNodeToRgn();
			break;
		}
		case 6:
		{
			for (unsigned i = 0; i < g_cWayPoint.m_uRegionCounts; i++)
			{
				g_cWayPoint.m_rgRegions[i].Clear();
			}

			g_cWayPoint.m_uRegionCounts = 0;
			g_cWayPoint.m_lpResult.clear();
			break;
		}
		case 7:
		{
			g_cWayPoint.Save();
			break;
		}
		case 8:
		{
			g_cWayPoint.Load();
			break;
		}
		case 9:
		{
			Menu_Region_2(pPlayer);
			return;
		}
		case 5:
		case 0:
		default:
		{
			g_cWayPoint.m_bShowRegions = false;
			pPlayer->m_iMenu = Menu_OFF;
			return;
		}
	}

	Menu_Region_1(pPlayer);
}

void CWayPoint::HandleMenu_Region_2(CBasePlayer* pPlayer, int iSlot)
{
	switch (iSlot)
	{
		case 1:
		{
			pPlayer->m_pRegion->a += 5;
			break;
		}
		case 2:
		{
			pPlayer->m_pRegion->a -= 5;
			break;
		}
		case 3:
		{
			pPlayer->m_pRegion->b += 5;
			break;
		}
		case 4:
		{
			pPlayer->m_pRegion->b -= 5;
			break;
		}
		case 5:
		{
			pPlayer->m_pRegion->c += 5;
			break;
		}
		case 6:
		{
			pPlayer->m_pRegion->c -= 5;
			break;
		}
		case 7:
		{
			UTIL_MakeVectors(pPlayer->pev->v_angle);
			pPlayer->m_pRegion->m_vecOrigin += gpGlobals->v_forward * 5;
			break;
		}
		case 8:
		{
			UTIL_MakeVectors(pPlayer->pev->v_angle);
			pPlayer->m_pRegion->m_vecOrigin -= gpGlobals->v_forward * 5;
			break;
		}
		case 9:
		{
			Menu_Region_1(pPlayer);
			return;
		}
		case 0:
		default:
		{
			g_cWayPoint.m_bShowRegions = false;
			pPlayer->m_iMenu = Menu_OFF;
			return;
		}
	}

	Menu_Region_2(pPlayer);
}

void CWayPoint::HandleMenu_NodeFlagEditor_1(CBasePlayer* pPlayer, int iSlot)
{
	switch (iSlot)
	{
		case 1:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags = 0;
			break;
		}
		case 2:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_CAMP;
			break;
		}
		case 3:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_CROUCH;
			break;
		}
		case 4:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_SECTION;
			break;
		}
		case 5:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_START;
			break;
		}
		case 6:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_END;
			break;
		}
		case 7:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_LADDER;
			break;
		}
		case 8:
		{
			pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_SNIPER;
			break;
		}
		case 9:
		{
			Menu_NodeFlagEditor_2(pPlayer);
			return;
		}
		case 0:
		default:
		{
			pPlayer->m_iMenu = Menu_OFF;
			return;
		}
	}

	Menu_NodeFlagEditor_1(pPlayer);
}

void CWayPoint::HandleMenu_NodeFlagEditor_2(CBasePlayer* pPlayer, int iSlot)
{
	switch (iSlot)
	{
	case 1:
	{
		pPlayer->m_pNearestNode->m_bitsNodeFlags = 0;
		break;
	}
	case 2:
	{
		pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_ZOMBIE;
		break;
	}
	case 3:
	{
		pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_HUMAN;
		break;
	}
	case 4:
	{
		pPlayer->m_pNearestNode->m_bitsNodeFlags |= WP_N_FL_JUMP;
		break;
	}
	case 9:
	{
		Menu_NodeFlagEditor_1(pPlayer);
		return;
	}
	case 0:
	default:
	{
		pPlayer->m_iMenu = Menu_OFF;
		return;
	}
	}

	Menu_NodeFlagEditor_2(pPlayer);
}

void CAStarCalculator::Initialize(CBasePlayer* pPlayer)
{
	vOpen.reserve(100);

	m_lpResult.clear();
	m_lpResultAsNodes.clear();
	m_lpResultAsRegions.clear();

	m_AStarTableN.clear();
	m_AStarTableN.shrink_to_fit();
	m_AStarTableN.reserve(g_cWayPoint.m_uNodeCounts);

	m_pSrc = nullptr;
	m_pEnd = nullptr;
	m_bAStarFound = false;

	m_pIgnoreEnt = nullptr;
	m_pPlayer = pPlayer;

	m_iScanLevel = WP_NODE_ERROR;
	m_bSearching = false;
}

bool CAStarCalculator::AStar(void)
{
#define CUR	m_AStarTableN[pCur->m_uIndex]
#define AJC	m_AStarTableN[pCur->m_rgpnNextKins[i]->m_uIndex]

	m_bSearching = true;
	m_bAStarFound = false;	// default value.
	m_lpResult.clear();	// otherwise our memory will explode.

	// choose the one we'd like to use.
	if (m_pSrc->m_iStructuralLevel == WP_NODE_PRIMARY)
	{
		m_lpResultAsNodes.clear();
		m_iScanLevel = WP_NODE_PRIMARY;
	}
	else if (m_pSrc->m_iStructuralLevel == WP_NODE_SECONDARY)
	{
		m_lpResultAsRegions.clear();
		m_iScanLevel = WP_NODE_SECONDARY;
	}

	// declare vars outside a loop to save efficiency.
	CWPBase* trace = nullptr;
	float potentialG = 0, potentialF = 0;
	unsigned iLowest = 0, i = 0;

	vOpen.clear();	// we need a open list btw, we already got our candidate pool, m_rgnNodes

	// initialise A* table.
	m_AStarTableN.clear();
	wp_astar_table_t sDummy = { 0, 0, 0, 0, 0, 0, 0 };
	for (unsigned i = 0; i < g_cWayPoint.m_uNodeCounts; i++)
		m_AStarTableN.push_back(sDummy);

	// the current vertex is the src
	CWPBase* pCur = m_pSrc;

	// calc H value of src
	CUR.h = (m_pEnd->m_vecOrigin - m_pSrc->m_vecOrigin).Length();

	// calc F value of src
	CUR.f = CUR.g + CUR.h;

	// the key point and the terminal condition.
	while (pCur != m_pEnd)
	{
		// for each vertex adjacent to current
		for (i = 0; i < pCur->m_uKinCounts; i++)
		{
			// it must be an unclosed one.
			if (!AJC.m_bClosed &&
				(pCur->m_iStructuralLevel == WP_NODE_SECONDARY ||	/* if this is a region, that's find. nothing to worry about being occupied. */
				(pCur->m_iStructuralLevel == WP_NODE_PRIMARY && (!((CWPNode*)pCur)->m_pOccupyingEnt || ((CWPNode*)pCur)->m_pOccupyingEnt == m_pIgnoreEnt || ((CWPNode*)pCur)->m_pOccupyingEnt == m_pPlayer)))
				)	// if you're a node, then this node should not be occupied or it's occupying ent is tolerantable, which includes a custom ent and owner of this calculator.
			{
				// add to open list
				// for those who already in the open list, just update their H value.
				if (!AJC.m_bOpened)
				{
					AJC.m_bOpened = true;
					vOpen.push_back((CWPNode *)pCur->m_rgpnNextKins[i]);
				}

				// calc G, the distance from start
				trace = pCur;	// we need to assmue that it comes from the current one. for the 2nd meeting verteces, especially.
				potentialG = 0;
				while (trace)
				{
					potentialG += m_AStarTableN[trace->m_uIndex].m_flDistFrom;
					trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
				}

				// calc H. it's a constant, so we can just assign value without an "if"
				AJC.h = (pCur->m_rgpnNextKins[i]->m_vecOrigin - m_pEnd->m_vecOrigin).Length();

				// calc F = G + H
				potentialF = potentialG + AJC.h;

				// if potential F is smaller than the existed F, replace whole database.
				if (potentialF < AJC.f || AJC.f <= 0 || !AJC.m_pFrom)
				{
					AJC.f = potentialF;
					AJC.g = potentialG;
					AJC.m_pFrom = pCur;
					AJC.m_flDistFrom = pCur->m_rgflNextKinsDist[i];
				}
			}
		}

		// after all adjacent verteces has been scanned, add the pCur to the close list.
		CUR.m_bClosed = true;

		// find the vertex with lowest F value in open list as the successor.
		iLowest = 0;
		for (i = 0; i < vOpen.size(); i++)
		{
			if (m_AStarTableN[vOpen[iLowest]->m_uIndex].f < m_AStarTableN[vOpen[i]->m_uIndex].f)
				continue;

			iLowest = i;
		}

		// before we access vOpen, it could be just can't find a proper path due to a isolated node.
		if (iLowest >= vOpen.size())
		{
			// the only thing we can do, is just save a partial path & return.

			trace = m_AStarTableN[pCur->m_uIndex].m_pFrom;
			while (trace)
			{
				m_lpResult.push_front(trace);
				trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
			}

			m_bSearching = false;
			m_bAStarFound = false;
			return m_bAStarFound;
		}

		// make it current
		pCur = vOpen[iLowest];

		// remove it from open list.
		auto iterator = vOpen.begin();
		while (*iterator != pCur)
		{
			iterator++;
		}
		vOpen.erase(iterator);
	}

	// saving result.
	m_lpResult.clear();
	m_lpResult.push_front(m_pEnd);

	trace = m_AStarTableN[m_pEnd->m_uIndex].m_pFrom;
	while (trace)
	{
		// save to public container.
		m_lpResult.push_front(trace);

		// save to specific container
		if (m_iScanLevel == WP_NODE_PRIMARY)
			m_lpResultAsNodes.push_front((CWPNode*)trace);
		else if (m_iScanLevel == WP_NODE_SECONDARY)
			m_lpResultAsRegions.push_front((CWPRegion*)trace);

		// move on.
		trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
	}

	m_bSearching = false;
	m_bAStarFound = true;
	return m_bAStarFound;

#undef CUR
#undef AJC
}

void CAStarCalculator::ASBF_Init(CWPBase* src, CWPBase* end, CBaseEntity *pIgnoreEnt)
{
	// sometimes this A* searching could be extremely difficult.
	// this difficulty could become a loss in game fps.
	// that's why we want to spread the calculation into frames, to lighten the load of CPU.

#define CUR	m_AStarTableN[pCur->m_uIndex]
#define AJC	m_AStarTableN[pCur->m_rgpnNextKins[i]->m_uIndex]

	// assign src and end. or this could become a CTD.
	m_pSrc = src;
	m_pEnd = end;
	m_pIgnoreEnt = pIgnoreEnt;

	m_bAStarFound = false;	// default value.
	m_lpResult.clear();	// otherwise our memory will explode.

	// choose the one we'd like to use.
	if (m_pSrc->m_iStructuralLevel == WP_NODE_PRIMARY)
	{
		m_lpResultAsNodes.clear();
		m_iScanLevel = WP_NODE_PRIMARY;
	}
	else if (m_pSrc->m_iStructuralLevel == WP_NODE_SECONDARY)
	{
		m_lpResultAsRegions.clear();
		m_iScanLevel = WP_NODE_SECONDARY;
	}

	// reset vars that only asscess when we're processing.
	trace = nullptr;
	potentialG = 0;
	potentialF = 0;
	iLowest = 0;
	i = 0;

	vOpen.clear();	// we need a open list btw, we already got our candidate pool, m_rgnNodes

	// initialise A* table.
	m_AStarTableN.clear();
	wp_astar_table_t sDummy = { 0, 0, 0, 0, 0, 0, 0 };
	for (unsigned i = 0; i < g_cWayPoint.m_uNodeCounts; i++)
		m_AStarTableN.push_back(sDummy);

	// the current vertex is the src
	pCur = m_pSrc;

	// calc H value of src
	CUR.h = (m_pEnd->m_vecOrigin - m_pSrc->m_vecOrigin).Length();

	// calc F value of src
	CUR.f = CUR.g + CUR.h;

	// rise the flag of processing.
	m_bSearching = true;

#undef CUR
#undef AJC
}

void CAStarCalculator::ASBF_Think(void)
{
#define CUR	m_AStarTableN[pCur->m_uIndex]
#define AJC	m_AStarTableN[pCur->m_rgpnNextKins[i]->m_uIndex]

	// we can't take the risk that run a unvalid searching.
	if (!m_bSearching)
		return;

	// the key point and the terminal condition.
	if (pCur != m_pEnd)
	{
		// for each vertex adjacent to current
		for (i = 0; i < pCur->m_uKinCounts; i++)
		{
			// it must be an unclosed one.
			if (!AJC.m_bClosed &&
				(pCur->m_iStructuralLevel == WP_NODE_SECONDARY ||	/* if this is a region, that's find. nothing to worry about being occupied. */
				(pCur->m_iStructuralLevel == WP_NODE_PRIMARY && (!((CWPNode *)pCur)->m_pOccupyingEnt || ((CWPNode*)pCur)->m_pOccupyingEnt == m_pIgnoreEnt || ((CWPNode*)pCur)->m_pOccupyingEnt == m_pPlayer)) )
					)	// if you're a node, then this node should not be occupied or it's occupying ent is tolerantable, which includes a custom ent and owner of this calculator.
			{
				// add to open list
				// for those who already in the open list, just update their H value.
				if (!AJC.m_bOpened)
				{
					AJC.m_bOpened = true;
					vOpen.push_back((CWPNode *)pCur->m_rgpnNextKins[i]);
				}

				// calc G, the distance from start
				trace = pCur;	// we need to assmue that it comes from the current one. for the 2nd meeting verteces, especially.
				potentialG = 0;
				while (trace)
				{
					potentialG += m_AStarTableN[trace->m_uIndex].m_flDistFrom;
					trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
				}

				// calc H. it's a constant, so we can just assign value without an "if"
				AJC.h = (pCur->m_rgpnNextKins[i]->m_vecOrigin - m_pEnd->m_vecOrigin).Length();

				// calc F = G + H
				potentialF = potentialG + AJC.h;

				// if potential F is smaller than the existed F, replace whole database.
				if (potentialF < AJC.f || AJC.f <= 0 || !AJC.m_pFrom)
				{
					AJC.f = potentialF;
					AJC.g = potentialG;
					AJC.m_pFrom = pCur;
					AJC.m_flDistFrom = pCur->m_rgflNextKinsDist[i];
				}
			}
		}

		// after all adjacent verteces has been scanned, add the pCur to the close list.
		CUR.m_bClosed = true;

		// find the vertex with lowest F value in open list as the successor.
		iLowest = 0;
		for (i = 0; i < vOpen.size(); i++)
		{
			if (m_AStarTableN[vOpen[iLowest]->m_uIndex].f < m_AStarTableN[vOpen[i]->m_uIndex].f)
				continue;

			iLowest = i;
		}

		// before we access vOpen, it could be just can't find a proper path due to a isolated node.
		if (iLowest >= vOpen.size())
		{
			// the only thing we can do, is just save a partial path & return.

			trace = m_AStarTableN[pCur->m_uIndex].m_pFrom;
			while (trace)
			{
				// it is not worth to save the fail data to specific container.
				m_lpResult.push_front(trace);
				trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
			}

			m_bAStarFound = false;
			m_bSearching = false;	// remember to terminate search.
			return;
		}

		// make it current
		pCur = vOpen[iLowest];

		// remove it from open list.
		auto iterator = vOpen.begin();
		while (*iterator != pCur)
		{
			iterator++;
		}
		vOpen.erase(iterator);
	}
	else	// this means that pCur == m_pEnd. we reached our goal.
	{
		m_lpResult.clear();
		m_lpResult.push_front(m_pEnd);

		trace = m_AStarTableN[m_pEnd->m_uIndex].m_pFrom;
		while (trace)
		{
			// save to public container.
			m_lpResult.push_front(trace);

			// save to specific container
			if (m_iScanLevel == WP_NODE_PRIMARY)
				m_lpResultAsNodes.push_front((CWPNode*)trace);
			else if (m_iScanLevel == WP_NODE_SECONDARY)
				m_lpResultAsRegions.push_front((CWPRegion *)trace);

			// move on.
			trace = m_AStarTableN[trace->m_uIndex].m_pFrom;
		}

		m_bAStarFound = true;
		m_bSearching = false;	// remove the flag. our job is done.
	}

#undef CUR
#undef AJC
}
