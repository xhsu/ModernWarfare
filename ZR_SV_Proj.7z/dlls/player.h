/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#ifndef PLAYER_H
#define PLAYER_H

#include "pm_materials.h"
#include "hintmessage.h"
#include "weapons.h"

// waypoint system dummy
class CWayPoint;
class CWPBase;
class CWPNode;
class CWPRegion;

#define MAX_PLAYER_NAME_LENGTH 32
#define MAX_AUTOBUY_LENGTH 256
#define MAX_REBUY_LENGTH 256
#define MAX_LACTION_LENGTH 32

#define PLAYER_FATAL_FALL_SPEED (float)1100
#define PLAYER_MAX_SAFE_FALL_SPEED (float)500
#define DAMAGE_FOR_FALL_SPEED (float)100.0 / (PLAYER_FATAL_FALL_SPEED - PLAYER_MAX_SAFE_FALL_SPEED)
#define PLAYER_MIN_BOUNCE_SPEED (float)350
#define PLAYER_FALL_PUNCH_THRESHHOLD (float)250.0

#define PFLAG_ONLADDER (1<<0)
#define PFLAG_ONSWING (1<<0)
#define PFLAG_ONTRAIN (1<<1)
#define PFLAG_ONBARNACLE (1<<2)
#define PFLAG_DUCKING (1<<3)
#define PFLAG_USING (1<<4)
#define PFLAG_OBSERVER (1<<5)

#define TRAIN_ACTIVE 0x80
#define TRAIN_NEW 0xc0
#define TRAIN_OFF 0x00
#define TRAIN_NEUTRAL 0x01
#define TRAIN_SLOW 0x02
#define TRAIN_MEDIUM 0x03
#define TRAIN_FAST 0x04
#define TRAIN_BACK 0x05

#define DHF_ROUND_STARTED (1<<1)
#define DHF_HOSTAGE_SEEN_FAR (1<<2)
#define DHF_HOSTAGE_SEEN_NEAR (1<<3)
#define DHF_HOSTAGE_USED (1<<4)
#define DHF_HOSTAGE_INJURED (1<<5)
#define DHF_HOSTAGE_KILLED (1<<6)
#define DHF_FRIEND_SEEN (1<<7)
#define DHF_ENEMY_SEEN (1<<8)
#define DHF_FRIEND_INJURED (1<<9)
#define DHF_FRIEND_KILLED (1<<10)
#define DHF_ENEMY_KILLED (1<<11)
#define DHF_BOMB_RETRIEVED (1<<12)
#define DHF_AMMO_EXHAUSTED (1<<15)
#define DHF_IN_TARGET_ZONE (1<<16)
#define DHF_IN_RESCUE_ZONE (1<<17)
#define DHF_IN_ESCAPE_ZONE (1<<18)
#define DHF_IN_VIPSAFETY_ZONE (1<<19)
#define DHF_NIGHTVISION (1<<20)
#define DHF_HOSTAGE_CTMOVE (1<<21)
#define	DHF_SPEC_DUCK (1<<22)

#define DHM_ROUND_CLEAR (DHF_ROUND_STARTED | DHF_HOSTAGE_KILLED | DHF_FRIEND_KILLED | DHF_BOMB_RETRIEVED)
#define DHM_CONNECT_CLEAR (DHF_HOSTAGE_SEEN_FAR | DHF_HOSTAGE_SEEN_NEAR | DHF_HOSTAGE_USED | DHF_HOSTAGE_INJURED | DHF_FRIEND_SEEN | DHF_ENEMY_SEEN | DHF_FRIEND_INJURED | DHF_ENEMY_KILLED | DHF_AMMO_EXHAUSTED | DHF_IN_TARGET_ZONE | DHF_IN_RESCUE_ZONE | DHF_IN_ESCAPE_ZONE | DHF_IN_VIPSAFETY_ZONE | DHF_HOSTAGE_CTMOVE | DHF_SPEC_DUCK)

#define IGNOREMSG_NONE 0
#define IGNOREMSG_ENEMY 1
#define IGNOREMSG_TEAM 2

#define CSUITPLAYLIST 4

#define SUIT_GROUP TRUE
#define SUIT_SENTENCE FALSE

#define SUIT_REPEAT_OK 0
#define SUIT_NEXT_IN_30SEC 30
#define SUIT_NEXT_IN_1MIN 60
#define SUIT_NEXT_IN_5MIN 300
#define SUIT_NEXT_IN_10MIN 600
#define SUIT_NEXT_IN_30MIN 1800
#define SUIT_NEXT_IN_1HOUR 3600

#define CSUITNOREPEAT 32

#define SOUND_FLASHLIGHT_ON "items/flashlight1.wav"
#define SOUND_FLASHLIGHT_OFF "items/flashlight1.wav"

#define TEAM_NAME_LENGTH 16

typedef enum
{
	PLAYER_IDLE,
	PLAYER_WALK,
	PLAYER_JUMP,
	PLAYER_SUPERJUMP,
	PLAYER_DIE,
	PLAYER_ATTACK1,
	PLAYER_ATTACK2,
	PLAYER_FLINCH,
	PLAYER_LARGE_FLINCH,
	PLAYER_RELOAD,
	PLAYER_HOLDBOMB,
	PLAYER_CUSTOM	// DS's scheme, for zombie/human skill anims.
}
PLAYER_ANIM;

typedef enum
{
	JOINED,
	SHOWLTEXT,
	READINGLTEXT,
	SHOWTEAMSELECT,
	PICKINGTEAM,
	GETINTOGAME
}
JoinState;

typedef enum
{
	THROW_NONE,
	THROW_FORWARD,
	THROW_BACKWARD,
	THROW_HITVEL,
	THROW_BOMB,
	THROW_GRENADE,
	THROW_HITVEL_MINUS_AIRVEL
}
ThrowDirection;

#define MAX_ID_RANGE 2048
#define MAX_SPECTATOR_ID_RANGE 8192
#define SBAR_STRING_SIZE 128

#define SBAR_TARGETTYPE_TEAMMATE 1
#define SBAR_TARGETTYPE_ENEMY 2
#define SBAR_TARGETTYPE_HOSTAGE 3

enum sbar_data
{
	SBAR_ID_TARGETTYPE = 1,
	SBAR_ID_TARGETNAME,
	SBAR_ID_TARGETHEALTH,
	SBAR_END
};

#define CHAT_INTERVAL 1.0

class CBasePlayer : public CBaseMonster
{
public:
	virtual void Spawn(void);	// use it in each zombie respawn, etc.
	virtual void Precache(void);
	virtual void Restart(void);
	virtual int Save(CSave &save);
	virtual int Restore(CRestore &restore);
	virtual int ObjectCaps(void) { return CBaseMonster::ObjectCaps() & ~FCAP_ACROSS_TRANSITION; }
	virtual int Classify(void);
	virtual void TraceAttack(entvars_t *pevAttacker, float flDamage, Vector vecDir, TraceResult *ptr, int bitsDamageType);
	virtual int TakeDamage(entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType);
	virtual int TakeHealth(float flHealth, int bitsDamageType);
	virtual void Killed(entvars_t *pevAttacker, int iGib);
	virtual void AddPoints(int score, BOOL bAllowNegativeScore);
	virtual void AddPointsToTeam(int score, BOOL bAllowNegativeScore);
	virtual BOOL AddPlayerItem(CBasePlayerItem *pItem);
	virtual BOOL RemovePlayerItem(CBasePlayerItem *pItem);
	virtual int GiveAmmo(int iAmount, char *szName, int iMax);
	virtual BOOL IsAlive(void) { return pev->deadflag == DEAD_NO && pev->health > 0; }
	virtual BOOL IsPlayer(void) { return TRUE; }
	virtual BOOL IsNetClient(void) { return TRUE; }
	virtual const char *TeamID(void);
	virtual BOOL FBecomeProne(void);
	virtual Vector BodyTarget(const Vector& posSrc) { return Center() + pev->view_ofs * RANDOM_FLOAT(0.9, 1.1); }
	virtual int Illumination(void);
	virtual BOOL ShouldFadeOnDeath(void) { return FALSE; }
	virtual void ResetMaxSpeed(void);
	virtual void Jump(void);
	virtual void Duck(void);
	virtual void PreThink(void);
	virtual void PostThink(void);
	virtual Vector GetGunPosition(void);
	virtual BOOL IsBot(void);
	virtual void UpdateClientData(void);
	virtual void ImpulseCommands(void);
	virtual void RoundRespawn(void);	// only called when a brand new round begins.
	virtual Vector GetAutoaimVector(float flDelta);
	virtual void Blind(float flUntilTime, float flHoldTime, float flFadeTime, int iAlpha);

public:
	virtual void Pain(int hitgroup, bool hitkevlar);
	virtual void PackDeadPlayerItems(void);
	virtual void RemoveAllItems(BOOL removeSuit);
	virtual void SwitchTeam(void);
	virtual BOOL SwitchWeapon(CBasePlayerItem *pWeapon);
	virtual BOOL IsOnLadder(void);
	virtual BOOL FlashlightIsOn(void);
	virtual void FlashlightTurnOn(void);
	virtual void FlashlightTurnOff(void);
	virtual void UpdatePlayerSound(void);
	virtual void DeathSound(void);
	virtual void SetAnimation(PLAYER_ANIM playerAnim);
	virtual void CheatImpulseCommands(int iImpulse);
	virtual void StartObserver(Vector vecPosition, Vector vecViewAngle);
	virtual CBaseEntity *Observer_IsValidTarget(int iTarget, bool bOnlyTeam);
	virtual void Observer_FindNextPlayer(bool bReverse, char *name = NULL);
	virtual void Observer_HandleButtons(void);
	virtual void Observer_SetMode(int iMode);
	virtual void Observer_CheckTarget(void);
	virtual void Observer_CheckProperties(void);
	virtual int IsObserver(void) { return pev->iuser1; }
	virtual bool IsObservingPlayer(CBasePlayer *pTarget);
	virtual void SetObserverAutoDirector(bool bState);
	virtual BOOL CanSwitchObserverModes(void);
	virtual void DropPlayerItem(const char *pszItemName);
	virtual void ThrowPrimary(void);
	virtual void ThrowWeapon(char *pszWeaponName);
	virtual BOOL HasPlayerItem(CBasePlayerItem *pCheckItem);
	virtual BOOL HasNamedPlayerItem(const char *pszItemName);
	virtual BOOL HasWeapons(void);
	virtual void SelectPrevItem(int iItem);
	virtual void SelectNextItem(int iItem);
	virtual void SelectLastItem(void);
	virtual void SelectItem(const char *pstr);
	virtual void ItemPreFrame(void);
	virtual void ItemPostFrame(void);
	virtual void GiveNamedItem(const char *szName);
	virtual void EnableControl(BOOL fControl);
	virtual void SendAmmoUpdate(void);
	virtual void SendFOV(int iFOV);
	virtual void SendWeatherInfo(void);
	virtual void WaterMove(void);
	virtual void EXPORT PlayerDeathThink(void);
	virtual void PlayerUse(void);
	virtual void CheckTimeBasedDamage(void);
	static int GetAmmoIndex(const char *psz);
	virtual int AmmoInventory(int iAmmoIndex);
	virtual void ResetAutoaim(void);
	virtual Vector AutoaimDeflection(Vector &vecSrc, float flDist, float flDelta);
	virtual void ForceClientDllUpdate(void);
	virtual void SetCustomDecalFrames(int nFrames);
	virtual int GetCustomDecalFrames(void);
	virtual void TabulateAmmo(void);
	virtual void SetProgressBarTime(int iTime);
	virtual void SetProgressBarTime2(int iTime, float flLastTime);
	virtual void SetPlayerModel(void);
	virtual void SetNewPlayerModel(const char *model);
	virtual void CheckPowerups(entvars_t *pev);
	virtual void Radio(const char *msg_id, const char *msg_verbose, int pitch = 100, bool showIcon = true);
	virtual void GiveDefaultItems(void);
	virtual void SetScoreAttrib(CBasePlayer *dest);
	virtual void SetScoreboardAttributes(CBasePlayer *pPlayer = NULL);
	virtual BOOL ShouldDoLargeFlinch(int nHitGroup, int nGunType);
	virtual BOOL IsArmored(int nHitGroup);
	virtual bool HintMessage(const char *pMessage, BOOL bDisplayIfDead = FALSE, BOOL bOverrideClientSettings = FALSE);
	virtual void AddAccount(int amount, bool bTrackChange = true);
	virtual void UpdateGeigerCounter(void);
	virtual void MenuPrint(const char *text);
	virtual void ResetMenu(void);
	virtual void JoiningThink(void);
	virtual void ResetStamina(void);
	virtual void Disappear(void);
	virtual void RemoveLevelText(void);
	virtual void MoveToNextIntroCamera(void);
	virtual void DropPrimary(void);
	virtual void DropSecondary(void);
	virtual void SpawnClientSideCorpse(void);
	virtual void SetPrefsFromUserinfo(char *infobuffer);
	virtual void StudioEstimateGait(void);
	virtual void CalculatePitchBlend(void);
	virtual void CalculateYawBlend(void);
	virtual void StudioProcessGait(void);
	virtual void InitStatusBar(void);
	virtual void UpdateStatusBar(void);
	virtual bool IsHittingShield(const Vector &vecDirection, TraceResult *ptr);
	virtual bool IsReloading(void);
	virtual bool IsThrowingGrenade(void);
	virtual void StopReload(void);
	virtual void DrawnShiled(void);
	virtual bool HasShield(void);
	virtual void UpdateShieldCrosshair(bool bShieldDrawn);
	virtual void DropShield(bool bDeploy);
	virtual void GiveShield(bool bRetire);
	virtual bool IsProtectedByShield(void);
	virtual void RemoveShield(void);
	virtual void UpdateLocation(bool bForceUpdate);
	virtual void ClientCommand(const char *arg0, const char *arg1 = NULL, const char *arg2 = NULL, const char *arg3 = NULL);

	// new funcs.

	virtual void SetCustomAnimation(float flTime, int iAnim, int iGaitAnim);
	virtual void RespawnToZombie(void);
	virtual bool IsAvailable(void) { return !(FNullEnt(pev) || has_disconnected || pev->flags == FL_DORMANT); }
	virtual void GhostThink(void);
	virtual bool IsStuck(void);
	virtual void SetGhost(bool bGhost);
	virtual void ChangeClass(ZOMBIERIOT_CLASSES iNewClass);
	virtual void NVGSwitch(bool bOn, bool bPlaySound = true);

	// waypoint think functions
	virtual void SetCurrentNode(CWPNode* pNew = nullptr);
	virtual void UpdateWaypointNode(void);
	virtual	void UpdateWaypointRegion(void);

	// wolf pack functions
	virtual void DisbandWolfpack	(void);
	virtual bool PromoteToLieutenant(void);
	virtual bool LeaveWolfpack		(bool bMyWolfpack = false);	// fill a true if you wish a successor.

public:
	static TYPEDESCRIPTION m_playerSaveData[];

public:
	int random_seed;
	unsigned short m_usPlayerBleed;
	EHANDLE m_hObserverTarget;
	float m_flNextObserverInput;
	int m_iObserverWeapon;
	int m_iObserverLastMode;
	float m_flFlinchTime;
	float m_flAnimTime;
	bool m_bHighDamage;
	float m_flVelocityModifier;
	int m_iLastZoom;
	bool m_bResumeZoom;
	float m_flEjectBrass;
	bool m_bNotKilled;
	int m_iTeam;
	int m_iAccount;
	bool m_bHasPrimary;
	float m_flDeathThrowTime;
	int m_iThrowDirection;
	float m_flLastTalk;
	bool m_bJustConnected;
	bool m_bContextHelp;
	JoinState m_iJoiningState;
	CBaseEntity *m_pIntroCamera;
	float m_fIntroCamTime;
	float m_fLastMovement;
	bool m_bMissionBriefing;
	bool m_bTeamChanged;
	int m_iTeamKills;
	int m_iIgnoreGlobalChat;
	bool m_bHasNightVision;
	bool m_bNightVisionOn;
	float m_flIdleCheckTime;
	float m_flRadioTime;
	int m_iRadioMessages;
	bool m_bIgnoreRadio;
	Vector m_vBlastVector;
	bool m_bKilledByGrenade;
	CHintMessageQueue m_hintMessageQueue;
	int m_flDisplayHistory;
	int m_iMenu;
	int m_iChaseTarget;
	BOOL m_fCamSwitch;
	float m_tmNextRadarUpdate;
	Vector m_vLastOrigin;
	int m_iCurrentKickVote;
	float m_flNextVoteTime;
	bool m_bJustKilledTeammate;
	int m_iMapVote;
	bool m_bCanShoot;
	float m_flLastFired;
	float m_flLastAttackedTeammate;
	bool m_bHeadshotKilled;
	bool m_bPunishedForTK;
	int m_iTimeCheckAllowed;
	bool m_bHasChangedName;
	char m_szNewName[MAX_PLAYER_NAME_LENGTH];
	int m_iPlayerSound;
	int m_iTargetVolume;
	int m_iWeaponVolume;
	int m_iExtraSoundTypes;
	int m_iWeaponFlash;
	float m_flStopExtraSoundTime;
	float m_flFlashLightTime;
	int m_iFlashBattery;
	int m_afButtonLast;
	int m_afButtonPressed;
	int m_afButtonReleased;
	edict_t *m_pentSndLast;
	float m_flSndRoomtype;
	float m_flSndRange;
	float m_flFallVelocity;
	int m_rgItems[MAX_ITEMS];
	unsigned int m_afPhysicsFlags;
	float m_fNextSuicideTime;
	float m_flTimeStepSound;
	float m_flSwimTime;
	float m_flDuckTime;
	float m_flWallJumpTime;
	int m_lastDamageAmount;
	float m_tbdPrev;
	float m_flgeigerRange;
	float m_flgeigerDelay;
	int m_igeigerRangePrev;
	int m_iStepLeft;
	char m_szTextureName[CBTEXTURENAMEMAX];
	char m_chTextureType;
	int m_idrowndmg;
	int m_idrownrestored;
	int m_bitsHUDDamage;
	BOOL m_fInitHUD;
	BOOL m_fGameHUDInitialized;
	int m_iTrain;
	BOOL m_fWeapon;
	EHANDLE m_pTank;
	float m_fDeadTime;
	BOOL m_fNoPlayerSound;
	BOOL m_fLongJump;
	int m_iUpdateTime;
	int m_iClientHealth;
	int m_iClientBattery;
	int m_iHideHUD;
	int m_iClientHideHUD;
	int m_iFOV;
	int m_iClientFOV;
	int m_iNumSpawns;
	CBaseEntity *m_pObserver;
	CBasePlayerItem *m_rgpPlayerItems[MAX_ITEM_TYPES];
	CBasePlayerItem *m_pActiveItem;
	CBasePlayerItem *m_pClientActiveItem;
	CBasePlayerItem *m_pLastItem;
	int m_rgAmmo[MAX_AMMO_SLOTS];
	int m_rgAmmoLast[MAX_AMMO_SLOTS];
	Vector m_vecAutoAim;
	BOOL m_fOnTarget;
	int m_iDeaths;
	int m_izSBarState[SBAR_END];
	float m_flNextSBarUpdateTime;
	float m_flStatusBarDisappearDelay;
	char m_SbarString0[SBAR_STRING_SIZE];
	int m_lastx, m_lasty;
	int m_nCustomSprayFrames;
	float m_flNextDecalTime;
	char m_szTeamName[TEAM_NAME_LENGTH];
	int m_modelIndexPlayer;
	char m_szAnimExtention[32];
	float m_flGaitframe;
	float m_flGaityaw;
	vec3_t m_prevgaitorigin;
	float m_flPitch;
	float m_flYaw;
	float m_flGaitMovement;
	int m_iAutoWepSwitch;
	bool m_bVGUIMenus;
	bool m_bShowHints;
	bool m_bShieldDrawn;
	bool m_bOwnsShield;
	bool m_bWasFollowing;
	float m_flNextFollowTime;
	float m_flYawModifier;
	float m_blindUntilTime;
	float m_blindStartTime;
	float m_blindHoldTime;
	float m_blindFadeTime;
	float m_blindAlpha;
	float m_flLastUpdateTime;
	char m_lastLocation[MAX_LACTION_LENGTH];
	int m_progressStart;
	int m_progressEnd;
	bool m_bObserverAutoDirector;
	bool m_canSwitchObserverModes;
	int m_flLastCommandTime[8];

	// new vars.

	ZOMBIERIOT_CLASSES	m_iClass;
	ZOMBIERIOT_CLASSES	m_iNextHumanClass;
	ZOMBIERIOT_CLASSES	m_iNextZombieClass;
	float	m_flCustomAnimTimeBase;	// float RecordTiime[33];
	float	m_flCustomAnimPlayTime;	// float PlayTime[33];
	int		m_iCustomAnimSeq;	// int Sequence[33];
	int		m_iCustomGaitSeq;	// int GaitSequence[33];
	bool	m_bSnapChange;
	float	m_flResurrectTime;
	bool	m_bGhost;
	bool	m_bGhostAllowedRespawn;
	bool	m_bReadySpawnSoundPlayed;
	float	m_flBotGhostThink;

	// waypoint vars
	CWPNode*	m_pNearestNode;
	unsigned	m_uSelectedPath;
	bool		m_bNeedToResetNode;
	CWPRegion*	m_pRegion;

	// wolf pack system. since real-human player is a prior Lieutenant candidate.
	bool			m_bLieutenant;	// am I a Lieutenant?
	CBasePlayer*	m_pLieutenant;	// the lieutenant of this player.
	std::list<CBasePlayer*>	m_lstMinions;	// my minion list.

	/*
	TODO: maybe we can pull m_bKilledByBomb back when we have new C4 ?
	*/
};

#define AUTOAIM_2DEGREES 0.0348994967025
#define AUTOAIM_5DEGREES 0.08715574274766
#define AUTOAIM_8DEGREES 0.1391731009601
#define AUTOAIM_10DEGREES 0.1736481776669

extern int gmsgHudText;
extern int gmsgShowMenu;
extern int gmsgVGUIMenu;
extern int gmsgScenarioIcon;
extern int gmsgBombDrop;

extern BOOL gInitHUD;

void SendItemStatus(CBasePlayer *pPlayer);

extern bool UseBotArgs;
extern const char *BotArgs[4];

extern char* g_rgszPlayerClassNames[CLASSES_COUNTS];
extern char* g_rgszPlayerClassModels[CLASSES_COUNTS];
extern char* g_rgszPlayerClassModelsPath[CLASSES_COUNTS];
#define PLAYER_DEFAULT_MODEL	g_rgszPlayerClassModelsPath[CLASS_UNASSIGNED]
extern float g_rgiPlayerClassMaxHealth[CLASSES_COUNTS];
extern float g_rgiPlayerClassMaxArmor[CLASSES_COUNTS];
extern char* g_rgszPlayerClassKnifeVModel[CLASSES_COUNTS];
extern char* g_rgszPlayerClassKnifePModel[CLASSES_COUNTS];
extern float g_rgflPlayerClassWalkSpeed[CLASSES_COUNTS];
extern float g_rgflPlayerClassGravity[CLASSES_COUNTS];
extern float g_rgflPlayerClassSlashSpeed[CLASSES_COUNTS];	// divide by 0.875 when hit.
extern float g_rgflPlayerClassStabSpeed[CLASSES_COUNTS];	// mul by 1.1 when hit.
extern float g_rgflPlayerClassSlashDist[CLASSES_COUNTS];
extern float g_rgflPlayerClassStabDist[CLASSES_COUNTS];
extern float g_rgflPlayerClassMeleeDmgMul[CLASSES_COUNTS];
extern float g_rgflPlayerClassDamageResistance[CLASSES_COUNTS];
extern float g_rgflPlayerClassKnockResistance[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassPainSounds[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassDeathSounds[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassMeleeDeploySounds[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassMeleeMissSounds[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassMeleeHitWallSounds[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassMeleeSlashSounds[CLASSES_COUNTS];
extern CSoundEfxSet* g_rgcPlayerClassMeleeStabSounds[CLASSES_COUNTS];

void PrecachePlayerClassSounds(void);

#endif