/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "weapons.h"
#include "gamerules.h"
#include "skill.h"
#include "game.h"
#include "items.h"
#include "hltv.h"
#include "client.h"
#include "shake.h"
#include "trains.h"
#include "vehicle.h"
#include "menus.h"
#include "weather.h"
#include "CWayPoint.h"
#include "CBot.h"
#include "CBaseZombieNPC.h"

extern DLL_GLOBAL CHalfLifeMultiplay *g_pGameRules;
extern DLL_GLOBAL BOOL g_fGameOver;
extern float g_flTimeLimit;
extern float g_flResetTime;

extern void ClearBodyQue(void);

extern int gmsgDeathMsg;
extern int gmsgScoreInfo;
extern int gmsgMOTD;
extern int gmsgServerName;
extern int gmsgSendAudio;
extern int gmsgBombPickup;
extern int gmsgTeamScore;
extern int gmsgForceCam;
extern int gmsgRadar;
extern int gmsgLocation;

extern int gmsgSayText;
extern int gmsgGameMode;
extern int gmsgAllowSpec;
extern int gmsgShowTimer;
extern int gmsgHLTV;

extern unsigned short m_usResetDecals;
extern float g_flWeaponCheat;

extern int gmsgViewMode;
extern int gmsgCheckModels;
extern int gmsgTeamInfo;

#define ITEM_RESPAWN_TIME 30
#define WEAPON_RESPAWN_TIME 20
#define AMMO_RESPAWN_TIME 20

#define ROUND_TIME		(int)(CVAR_GET_FLOAT("mp_roundtime") * 60)
#define COUNTDOWN_TIME	(int)CVAR_GET_FLOAT("mp_freezetime")

class CCStrikeGameMgrHelper : public IVoiceGameMgrHelper
{
public:
	virtual bool CanPlayerHearPlayer(CBasePlayer *pListener, CBasePlayer *pTalker)
	{
		if (pListener->m_iTeam != pTalker->m_iTeam)
			return false;

		BOOL pListenerAlive = pListener->IsAlive();
		BOOL pTalkerAlive = pTalker->IsAlive();

		if (pListener->IsObserver())
			return true;

		if (pListenerAlive)
		{
			if (!pTalkerAlive)
				return false;
		}
		else
		{
			if (pTalkerAlive)
				return true;
		}

		return pListenerAlive == pTalkerAlive;
	}
};

CCStrikeGameMgrHelper g_GameMgrHelper;

void Broadcast(const char *sentence)
{
	char text[256];

	if (!sentence)
		return;

	strcpy(text, "%!MRAD_");
	strcat(text, UTIL_VarArgs("%s", sentence));

	MESSAGE_BEGIN(MSG_BROADCAST, gmsgSendAudio);
	WRITE_BYTE(0);
	WRITE_STRING(text);
	WRITE_SHORT(100);
	MESSAGE_END();
}

char* CHalfLifeMultiplay::GetTeam(int teamNo)
{
	switch (teamNo)
	{
		case TEAM_ZOMBIE: return "TERRORIST";	// UNDONE: maybe this can only fix after integral with CL.
		case TEAM_HUMAN: return "CT";
		case TEAM_SPECTATOR: return "SPECTATOR";
	}

	return "UNASSIGNED";
}

void EndRoundMessage(const char *sentence, int event)
{
	char *team = NULL;
	bool teamTriggered = true;

	UTIL_ClientPrintAll(HUD_PRINTCENTER, sentence);

	switch (event)
	{
		case Zombies_Win: team = g_pGameRules->GetTeam(TEAM_ZOMBIE); break;
		case Humans_Win: team = g_pGameRules->GetTeam(TEAM_HUMAN); break;
		default: teamTriggered = false; break;
	}

	if (g_pGameRules)
	{
		if (teamTriggered == true)
			UTIL_LogPrintf("Team \"%s\" triggered \"%s\" (CT \"%i\") (T \"%i\")\n", team, &sentence[1], g_pGameRules->m_iNumHumansWins, g_pGameRules->m_iNumZombiesWins);
		else
			UTIL_LogPrintf("World triggered \"%s\" (CT \"%i\") (T \"%i\")\n", &sentence[1], g_pGameRules->m_iNumHumansWins, g_pGameRules->m_iNumZombiesWins);
	}

	UTIL_LogPrintf("World triggered \"Round_End\"\n");
}

void ReadMultiplayCvars(CHalfLifeMultiplay *mp);

cvar_t *sv_clienttrace;
CHalfLifeMultiplay *g_pMPGameRules;

CHalfLifeMultiplay::CHalfLifeMultiplay(void)
{
	int i;

	m_VoiceGameMgr.Init(&g_GameMgrHelper, gpGlobals->maxClients);
	RefreshSkillData();

	m_flIntermissionStartTime = 0;
	m_flIntermissionEndTime = 0;
	m_iRoundWinStatus = WINSTATUS_UNDETERMIND;
	m_iLastWonStatus = WINSTATUS_DRAW;
	m_iNumZombiesWins = m_iNumHumansWins = 0;
	m_iNumZombies = m_iNumHumans = 0;
	m_bMapHasCameras = 2;
	g_fGameOver = FALSE;
	m_iNumConsecutiveHumansLoses = 0;
	m_iNumConsecutiveZombiesLoses = 0;
	m_iRoundPhase = ROUND_DISCONTINUOUS;
	m_bLevelInitialized = false;
	m_flNextPeriodicThink = 0;
	m_bCompleteReset = false;
	m_iUnBalancedRounds = 0;
	m_iMaxRounds = (int)CVAR_GET_FLOAT("mp_maxrounds");
	m_flTimerThink = gpGlobals->time;
	m_iPrompt = 0;

	if (m_iMaxRounds < 0)
	{
		m_iMaxRounds = 0;
		CVAR_SET_FLOAT("mp_maxrounds", 0);
	}

	m_iTotalRoundsPlayed = 0;
	m_iMaxRoundsWon = (int)CVAR_GET_FLOAT("mp_winlimit");

	if (m_iMaxRoundsWon < 0)
	{
		m_iMaxRoundsWon = 0;
		CVAR_SET_FLOAT("mp_winlimit", 0);
	}

	for (i = 0; i < MAX_MAPS; i++)
		m_iMapVotes[i] = 0;

	m_iStoredSpectValue = allow_spectators.value;

	CVAR_SET_FLOAT("cl_himodels", 0);
	ReadMultiplayCvars(this);

	m_fMaxIdlePeriod = ROUND_TIME * 2;

	if (IS_DEDICATED_SERVER())
	{
		CVAR_SET_FLOAT("pausable", 0);
	}
	else
	{
		CVAR_SET_FLOAT("pausable", 0);

		const char *lservercfgfile = CVAR_GET_STRING("lservercfgfile");

		if (lservercfgfile && *lservercfgfile)
		{
			char szCommand[256];
			ALERT(at_console, "Executing listen server config file\n");
			sprintf(szCommand, "exec %s\n", lservercfgfile);
			SERVER_COMMAND(szCommand);
		}
	}

	static bool installedCommands = false;

	if (installedCommands == false)
	{
		g_engfuncs.pfnAddServerCommand("perf_test", loopPerformance);
		g_engfuncs.pfnAddServerCommand("print_ent", printEntities);
		installedCommands = true;
	}

	m_iPhaseTime = 0;

	sv_clienttrace = CVAR_GET_POINTER("sv_clienttrace");
	g_pMPGameRules = this;
}

void ReadMultiplayCvars(CHalfLifeMultiplay *mp)
{
	mp->m_iLimitTeams = (int)CVAR_GET_FLOAT("mp_limitteams");
	mp->m_iCurRoundMaxTime = ROUND_TIME;

	if (mp->m_iLimitTeams > 20)
	{
		CVAR_SET_FLOAT("mp_limitteams", 20);
		mp->m_iLimitTeams = 20;
	}
	else if (mp->m_iLimitTeams <= 0)
	{
		CVAR_SET_FLOAT("mp_limitteams", 0);
		mp->m_iLimitTeams = 20;
	}
}

void CHalfLifeMultiplay::RefreshSkillData(void)
{
	CGameRules::RefreshSkillData();

	gSkillData.agruntHealth = 12;
	gSkillData.apacheHealth = 12;
	gSkillData.bullsquidDmgWhip = 30;
	gSkillData.agruntDmgPunch = 40;
	gSkillData.barneyHealth = 100;
	gSkillData.bigmommaHealthFactor = 20;
	gSkillData.bigmommaDmgSlash = 20;
	gSkillData.bigmommaDmgBlast = 120;
}

void CHalfLifeMultiplay::RemoveGuns(void)
{
	CBaseEntity *toremove = NULL;

	while ((toremove = UTIL_FindEntityByClassname(toremove, "weaponbox")) != NULL)
		((CWeaponBox *)toremove)->Kill();

	toremove = NULL;

	while ((toremove = UTIL_FindEntityByClassname(toremove, "weapon_shield")) != NULL)
	{
		toremove->SetThink(&CBaseEntity::SUB_Remove);
		toremove->SetTouch(NULL);
		toremove->pev->nextthink = gpGlobals->time + 0.1;
	}
}

void CHalfLifeMultiplay::CleanUpMap(void)
{
	UTIL_RestartOther("multi_manager");

	// Recreate all the map entities from the map data (preserving their indices),
	// then remove everything else except the players.
	UTIL_RestartOther("cycler_sprite");
	UTIL_RestartOther("light");
	UTIL_RestartOther("func_breakable");
	UTIL_RestartOther("func_door");

	UTIL_RestartOther("func_button");
	UTIL_RestartOther("func_rot_button");
	UTIL_RestartOther("env_render");
	UTIL_RestartOther("env_spark");
	UTIL_RestartOther("trigger_push");

	UTIL_RestartOther("func_water");
	UTIL_RestartOther("func_door_rotating");
	UTIL_RestartOther("func_tracktrain");
	UTIL_RestartOther("func_vehicle");
	UTIL_RestartOther("func_train");
	UTIL_RestartOther("armoury_entity");
	UTIL_RestartOther("ambient_generic");
	UTIL_RestartOther("env_sprite");

	UTIL_RestartOther("trigger_once");
	UTIL_RestartOther("func_wall_toggle");
	UTIL_RestartOther("trigger_hurt");
	UTIL_RestartOther("multisource");
	UTIL_RestartOther("env_beam");
	UTIL_RestartOther("env_laser");
	UTIL_RestartOther("trigger_auto");

	// Remove grenades and C4
	UTIL_RemoveOther("grenade");

	UTIL_RemoveOther("gib");
	UTIL_RemoveOther("DelayedUse");

	RemoveGuns();
	PLAYBACK_EVENT((FEV_GLOBAL | FEV_RELIABLE), 0, m_usResetDecals);
}

void CHalfLifeMultiplay::TerminateRound(float tmDelay, WINSTATUS iWinStatus)
{
	if (m_iRoundPhase == ROUND_ENDING || iWinStatus == WINSTATUS_UNDETERMIND)	// you can't end a ended game.
		return;

	m_iRoundWinStatus = iWinStatus;
	m_iRoundPhase = ROUND_ENDING;
	m_iPhaseTime = int(tmDelay);

	if (iWinStatus == WINSTATUS_DRAW)
	{
		EndRoundMessage("#Round_Draw", Round_Draw);
		Broadcast("rounddraw");
		return;
	}

	CountPlayers();
	EndRoundMessage(iWinStatus == WINSTATUS_HUMANS ? "#Human_Win" : "#Zombie_Win", iWinStatus == WINSTATUS_HUMANS ? Humans_Win : Zombies_Win);
	UTIL_Broadcast(iWinStatus == WINSTATUS_HUMANS ? "zombieriot/win_human.wav" : "zombieriot/win_zombi.wav");
	iWinStatus == WINSTATUS_HUMANS ? m_iNumHumansWins++ : m_iNumZombiesWins++;
	iWinStatus == WINSTATUS_HUMANS ? m_iNumConsecutiveZombiesLoses++ : m_iNumConsecutiveHumansLoses++;
	UpdateTeamScores();

	CBasePlayer* pPlayer = nullptr;
	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || !pPlayer->IsAvailable())
			continue;

		if (pPlayer->m_iTeam != iWinStatus)
			continue;

		pPlayer->AddAccount(cvar_winmoney.value);
	}
}

int CHalfLifeMultiplay::TimeRemaining(void)
{
	return m_iPhaseTime;
}

bool CHalfLifeMultiplay::CheckWinConditions(void)
{
	if (m_iRoundPhase != ROUND_STARTED)
		return false;

	CBasePlayer* pPlayer = nullptr;
	bool	bHumanRemains = false;

	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || !pPlayer->IsAvailable())
			continue;

		if (pPlayer->m_iTeam == TEAM_HUMAN && pPlayer->IsAlive())	// dead human doesn't counted in.
		{
			bHumanRemains = true;
			break;
		}
	}

	if (!bHumanRemains)
	{
		TerminateRound(cvar_enddeploy.value, WINSTATUS_ZOMBIES);
		return true;
	}

	return false;
}

int CHalfLifeMultiplay::CountPlayers(void)
{
	m_iNumZombies = m_iNumHumans = 0;

	CBasePlayer *pPlayer = nullptr;

	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || FNullEnt(pPlayer->pev) || pPlayer->has_disconnected || pPlayer->pev->flags == FL_DORMANT)
			continue;

		if (pPlayer->m_iTeam == TEAM_HUMAN)
		{
			m_iNumHumans ++;
		}
		else if (pPlayer->m_iTeam == TEAM_ZOMBIE)
		{
			m_iNumZombies++;
		}
	}

	return m_iNumHumans + m_iNumZombies;
}

int CHalfLifeMultiplay::CountRealPlayers(int iTeam)
{
	int rgiResults[5];
	memset(&rgiResults, NULL, sizeof(rgiResults));

	CBasePlayer* pPlayer = nullptr;

	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || !pPlayer->IsAvailable() || pPlayer->IsBot())
			continue;

		rgiResults[pPlayer->m_iTeam] ++;
	}

	return iTeam >= 0 ? rgiResults[iTeam] : (rgiResults[TEAM_HUMAN] + rgiResults[TEAM_ZOMBIE] + rgiResults[TEAM_SPECTATOR] + rgiResults[TEAM_UNASSIGNED]);
}

void CHalfLifeMultiplay::BalanceTeams(void)
{
	int rgiAmount[2] = { 0, 0 }, iTeam;
	CBasePlayer* rgpPlayers[2][33];

	CBasePlayer* pPlayer = nullptr;
	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || !pPlayer->IsAvailable())
			continue;

		iTeam = pPlayer->m_iTeam - 1;

		rgiAmount[iTeam] ++;
		rgpPlayers[iTeam][rgiAmount[iTeam]] = pPlayer;
	}

	while (abs(rgiAmount[0] - rgiAmount[1]) > 1)
	{
		if (rgiAmount[0] > rgiAmount[1])	// zombies are more than humans
		{
			int iRandom = RANDOM_LONG(1, rgiAmount[0]);
			rgpPlayers[0][iRandom]->SwitchTeam();
			rgpPlayers[0][iRandom]->m_bSnapChange = false;	// remove snapchange flag to avoid some bugs.

			rgiAmount[0] --;
			rgiAmount[1] ++;
			rgpPlayers[1][rgiAmount[1]] = rgpPlayers[0][iRandom];
			memmove(&(rgpPlayers[0][iRandom]), &(rgpPlayers[0][iRandom + 1]), sizeof(void*) * (33 - iRandom + 1));	// LUNA: fucking true random.
		}
		else	// humans are more than zombies
		{
			int iRandom = RANDOM_LONG(1, rgiAmount[1]);
			rgpPlayers[1][iRandom]->SwitchTeam();
			rgpPlayers[1][iRandom]->m_bSnapChange = false;

			rgiAmount[1] --;
			rgiAmount[0] ++;
			rgpPlayers[0][rgiAmount[0]] = rgpPlayers[1][iRandom];
			memmove(&(rgpPlayers[1][iRandom]), &(rgpPlayers[1][iRandom + 1]), sizeof(void*) * (33 - iRandom + 1));	// LUNA: fucking true random.
		}
	}
}

void CHalfLifeMultiplay::CheckMapConditions(void)
{
}

void CHalfLifeMultiplay::UpdateTeamScores(void)
{
	MESSAGE_BEGIN(MSG_ALL, gmsgTeamScore);
	WRITE_STRING(GetTeam(TEAM_HUMAN));
	WRITE_SHORT(m_iNumHumansWins);
	MESSAGE_END();

	MESSAGE_BEGIN(MSG_ALL, gmsgTeamScore);
	WRITE_STRING(GetTeam(TEAM_ZOMBIE));
	WRITE_SHORT(m_iNumZombiesWins);
	MESSAGE_END();
}

void CHalfLifeMultiplay::SwapAllPlayers(void)
{
	CBaseEntity *pEntity = NULL;

	while ((pEntity = UTIL_FindEntityByClassname(pEntity, "player")) != NULL)
	{
		if (FNullEnt(pEntity->edict()))
			break;

		if (pEntity->pev->flags == FL_DORMANT)
			continue;

		GetClassPtr((CBasePlayer *)pEntity->pev)->SwitchTeam();
	}

	int iTemp = m_iNumZombiesWins;
	m_iNumZombiesWins = m_iNumHumansWins;
	m_iNumHumansWins = iTemp;
	UpdateTeamScores();
}

bool CHalfLifeMultiplay::CheckGameDiscontinuous(void)
{
	if (!m_iNumHumans || !m_iNumZombies)
	{
		EndRoundMessage("#Game_Break", Game_Commencing);
		return true;
	}

	return false;
}

void CHalfLifeMultiplay::RestartRound(void)
{
	m_iTotalRoundsPlayed++;
	ClearBodyQue();

	CVAR_SET_FLOAT("sv_accelerate", 5);
	CVAR_SET_FLOAT("sv_friction", 4);
	CVAR_SET_FLOAT("sv_stopspeed", 75);

	CBasePlayer* pPlayer = nullptr;

	// we need to restore any player who was force to be zombie come back to be a normal human.
	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || FNullEnt(pPlayer->pev)  || pPlayer->has_disconnected)
			continue;

		if (pPlayer->m_bSnapChange)	// give them their human identity back.
		{
			pPlayer->m_iTeam = TEAM_HUMAN;
			pPlayer->m_iClass = pPlayer->m_iNextHumanClass;

			// actually they ARE KILLED. give them a new set of human equipment.
			pPlayer->m_bNotKilled = false;
		}
	}

	MESSAGE_BEGIN(MSG_SPEC, gmsgHLTV);
	WRITE_BYTE(0);
	WRITE_BYTE(100 | 128);
	MESSAGE_END();

	MESSAGE_BEGIN(MSG_SPEC, gmsgHLTV);
	WRITE_BYTE(0);
	WRITE_BYTE(0);
	MESSAGE_END();

	// count first time to determind whether we should use a team balance.
	CountPlayers();

	if (CVAR_GET_FLOAT("mp_autoteambalance") != 0 && m_iUnBalancedRounds >= 1)
		BalanceTeams();

	if (m_iNumHumans - m_iNumZombies >= 2 || m_iNumZombies - m_iNumHumans >= 2)
		m_iUnBalancedRounds++;
	else
		m_iUnBalancedRounds = 0;

	if (CVAR_GET_FLOAT("mp_autoteambalance") != 0 && m_iUnBalancedRounds == 1)
		UTIL_ClientPrintAll(HUD_PRINTCENTER, "#Auto_Team_Balance_Next_Round");

	// we should count players after balance teams.
	CountPlayers();

	// not enough player? wait.
	if (CheckGameDiscontinuous())
		return;

	if (m_bCompleteReset)
	{
		if (timelimit.value < 0)
			CVAR_SET_FLOAT("mp_timelimit", 0);

		g_flResetTime = gpGlobals->time;

		if (timelimit.value)
			g_flTimeLimit = gpGlobals->time + timelimit.value * 60;

		m_iTotalRoundsPlayed = 0;
		m_iMaxRounds = (int)CVAR_GET_FLOAT("mp_maxrounds");

		if (m_iMaxRounds < 0)
		{
			m_iMaxRounds = 0;
			CVAR_SET_FLOAT("mp_maxrounds", 0);
		}

		m_iMaxRoundsWon = (int)CVAR_GET_FLOAT("mp_winlimit");

		if (m_iMaxRoundsWon < 0)
		{
			m_iMaxRoundsWon = 0;
			CVAR_SET_FLOAT("mp_winlimit", 0);
		}

		m_iRoundWinStatus = WINSTATUS_UNDETERMIND;
		m_iLastWonStatus = WINSTATUS_DRAW;
		m_iNumZombiesWins = 0;
		m_iNumHumansWins = 0;
		m_iNumConsecutiveZombiesLoses = 0;
		m_iNumConsecutiveHumansLoses = 0;
		UpdateTeamScores();

		for (int i = 1; i <= gpGlobals->maxClients; i++)
		{
			pPlayer = UTIL_PlayerByIndex(i);

			if (pPlayer && !FNullEnt(pPlayer->pev))
				pPlayer->Restart();
		}

		g_cWeatherManager.OnGameReset();
	}

	m_iRoundPhase = ROUND_COUNTINGDOWN;
	m_iPhaseTime = COUNTDOWN_TIME;
	ReadMultiplayCvars(this);
	m_fMaxIdlePeriod = ROUND_TIME * 2;
	m_flTimerThink = gpGlobals->time + 1.0f;
	m_flNextPeriodicThink = gpGlobals->time + 1.0f;
	m_iPrompt = 0;

	CheckMapConditions();

	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		pPlayer = UTIL_PlayerByIndex(i);

		if (!pPlayer || FNullEnt(pPlayer->pev) || pPlayer->has_disconnected || pPlayer->pev->flags == FL_DORMANT)
			continue;

		pPlayer->m_iNumSpawns = 0;
		pPlayer->m_bTeamChanged = false;

		// remove the temp zombie flag.
		pPlayer->m_bSnapChange = false;

		if (pPlayer->m_iTeam != TEAM_UNASSIGNED && pPlayer->m_iTeam != TEAM_SPECTATOR)
		{
			pPlayer->RoundRespawn();
		}
	}

	CleanUpMap();
	g_cWeatherManager.OnNewRound();

	m_flIntermissionEndTime = 0;
	m_flIntermissionStartTime = 0;
	m_iLastWonStatus = m_iRoundWinStatus;
	m_iRoundWinStatus = WINSTATUS_UNDETERMIND;
	m_bLevelInitialized = false;
	m_bCompleteReset = false;

	CBot::RoundRestart();
	CBaseZombieNPC::RoundRestart();
}

BOOL CHalfLifeMultiplay::TeamFull(int team_id)
{
	switch (team_id)
	{
		case TEAM_ZOMBIE: return m_iNumZombies >= m_iSpawnPointCount_Zombies;
		case TEAM_HUMAN: return m_iNumHumans >= m_iSpawnPointCount_Humans;
	}

	return false;
}

BOOL CHalfLifeMultiplay::TeamStacked(int newTeam_id, int curTeam_id)
{
	if (newTeam_id == curTeam_id)
		return FALSE;

	if (m_iLimitTeams == 0)
		return FALSE;

	switch (newTeam_id)
	{
		case TEAM_ZOMBIE:
		{
			if (curTeam_id != TEAM_UNASSIGNED && curTeam_id != TEAM_SPECTATOR)
			{
				if ((m_iNumZombies + 1) > (m_iNumHumans + m_iLimitTeams - 1))
					return TRUE;
				else
					return FALSE;
			}
			else
			{
				if ((m_iNumZombies + 1) > (m_iNumHumans + m_iLimitTeams))
					return TRUE;
				else
					return FALSE;
			}
		}

		case TEAM_HUMAN:
		{
			if (curTeam_id != TEAM_UNASSIGNED && curTeam_id != TEAM_SPECTATOR)
			{
				if ((m_iNumHumans + 1) > (m_iNumZombies + m_iLimitTeams - 1))
					return TRUE;
				else
					return FALSE;
			}
			else
			{
				if ((m_iNumHumans + 1) > (m_iNumZombies + m_iLimitTeams))
					return TRUE;
				else
					return FALSE;
			}
		}
	}

	return FALSE;
}

#define MAX_INTERMISSION_TIME 120

extern int gmsgRoundTime;
colorVec sPromptHintTextColorStart = { 255, 100, 255, 255 };
colorVec sPromptHintTextColorEnd = { 255, 100, 255, 0 };

void CHalfLifeMultiplay::Think(void)
{
	m_VoiceGameMgr.Update(gpGlobals->frametime);

	if (sv_clienttrace->value != 1)
		CVAR_SET_FLOAT("sv_clienttrace", 1);

	// reduce phase time by 1.0 steps.
	if (m_flTimerThink > 0 && m_flTimerThink <= gpGlobals->time)
	{
		m_iPhaseTime--;

		MESSAGE_BEGIN(MSG_BROADCAST, gmsgRoundTime);
		WRITE_SHORT(m_iPhaseTime + 1);
		MESSAGE_END();

		if (m_iPhaseTime < 0)
			m_iPhaseTime = 0;

		m_flTimerThink = gpGlobals->time + 1.0f;
	}

	if (m_flForceCameraValue != forcecamera.value || m_flForceChaseCamValue != forcechasecam.value || m_flFadeToBlackValue != fadetoblack.value)
	{
		MESSAGE_BEGIN(MSG_ALL, gmsgForceCam);
		WRITE_BYTE(forcecamera.value != 0);
		WRITE_BYTE(forcechasecam.value != 0);
		WRITE_BYTE(fadetoblack.value != 0);
		MESSAGE_END();

		m_flForceCameraValue = forcecamera.value;
		m_flForceChaseCamValue = forcechasecam.value;
		m_flFadeToBlackValue = fadetoblack.value;
	}

	if (CheckGameOver())
		return;

	if (CheckTimeLimit())
		return;

	if (CheckMaxRounds())
		return;

	if (CheckWinLimit())
		return;

	CheckAllowSpecator();

	if (CheckGameDiscontinuous())
	{
		m_iRoundPhase = ROUND_DISCONTINUOUS;
		m_iPhaseTime = 0;
	}

	CountPlayers();	// we need to count players each frame. make sure the values are flesh.
	CheckLevelInitialized();

	if (gpGlobals->time > m_flNextPeriodicThink)
	{
		m_flNextPeriodicThink = gpGlobals->time + 1;

		CheckGameCvar();
		CheckRestartServer();

		switch (m_iRoundPhase)
		{
			case ROUND_COUNTINGDOWN:
			{
				if (m_iPhaseTime <= 0)
				{
					UTIL_Broadcast("zombieriot/pickup_secret01.wav");

					m_iCurRoundMaxTime = ROUND_TIME;	// already mul by 60.
					m_iPhaseTime = ROUND_TIME;
					m_iPrompt = 1;
					m_iRoundPhase = ROUND_STARTED;
					return;
				}

				if (m_iPhaseTime <= 10)
					UTIL_Broadcast("zombieriot/beep07.wav");	// counting down beep sound efx.

				break;
			}
			
			case ROUND_DISCONTINUOUS:
			{
				if ((m_iNumHumans + m_iNumZombies) > 1)	// which means we can start a game through a team balance.
				{
					BalanceTeams();
					CVAR_SET_FLOAT("sv_restartround", 3);
					CheckRestartServer();	// I CAN'T WAIT IT !!!
				}

				break;
			}

			case ROUND_ENDING:
			{
				if (m_iPhaseTime <= 0)
					RestartRound();

				break;
			}

			case ROUND_STARTED:
			{
				if (m_iPhaseTime > 0)
				{
					// check zombie win conditions
					if (CheckWinConditions())
						break;

					float flTimePercent = 1.0f - float(m_iPhaseTime) / float(m_iCurRoundMaxTime);

					if (flTimePercent >= cvar_finish[0].value && m_iPrompt == 1)
					{
						UTIL_Broadcast("zombieriot/survival_medal.wav");
						UTIL_HudMessage(nullptr, HUD_MSG_CHAN_HINT, Vector2D(-1, 0.3f), sPromptHintTextColorStart, sPromptHintTextColorEnd, 0.1f, 0.2f, 6.0f, 6.0f, "Humans have completed %d%% progress", int(cvar_finish[0].value * 100));
						
						m_iPrompt++;
					}
					else if (flTimePercent >= cvar_finish[1].value && m_iPrompt == 2)
					{
						UTIL_Broadcast("zombieriot/survival_playerrec.wav");
						UTIL_HudMessage(nullptr, HUD_MSG_CHAN_HINT, Vector2D(-1, 0.3f), sPromptHintTextColorStart, sPromptHintTextColorEnd, 0.1f, 0.2f, 6.0f, 6.0f, "Humans have completed %d%% progress", int(cvar_finish[1].value * 100));

						m_iPrompt++;
					}
					else if (flTimePercent >= cvar_finish[2].value && m_iPrompt == 3)
					{
						UTIL_Broadcast("zombieriot/survival_teamrec.wav");
						UTIL_HudMessage(nullptr, HUD_MSG_CHAN_HINT, Vector2D(-1, 0.3f), sPromptHintTextColorStart, sPromptHintTextColorEnd, 0.1f, 0.2f, 6.0f, 6.0f, "Humans have completed %d%% progress.", int(cvar_finish[2].value * 100));

						m_iPrompt++;
					}

					// if m_iRoundTime > 0, we need to return anyway.
					break;
				}

				TerminateRound(cvar_enddeploy.value, WINSTATUS_HUMANS);
				break;
			}
		}
	}
}

void CHalfLifeMultiplay::CheckLevelInitialized(void)
{
	if (m_bLevelInitialized)
		return;

	m_iSpawnPointCount_Humans = 0;
	m_iSpawnPointCount_Zombies = 0;

	CBaseEntity *pEntity = NULL;

	while ((pEntity = UTIL_FindEntityByClassname(pEntity, "info_player_deathmatch")) != NULL)
		m_iSpawnPointCount_Zombies++;

	while ((pEntity = UTIL_FindEntityByClassname(pEntity, "info_player_start")) != NULL)
		m_iSpawnPointCount_Humans++;

	m_bLevelInitialized = true;
}

void CHalfLifeMultiplay::CheckRestartServer(void)
{
	int iRestartDelay = restartround.value;

	if (!iRestartDelay)
		iRestartDelay = sv_restart.value;

	if (iRestartDelay > 0)
	{
		if (iRestartDelay > 60)
			iRestartDelay = 60;

		UTIL_LogPrintf("World triggered \"Restart_Round_(%i_%s)\"\n", iRestartDelay, iRestartDelay == 1 ? "second" : "seconds");

		if (g_pGameRules)
		{
			UTIL_LogPrintf("Team \"CT\" scored \"%i\" with \"%i\" players\n", g_pGameRules->m_iNumHumansWins, g_pGameRules->m_iNumHumans);
			UTIL_LogPrintf("Team \"TERRORIST\" scored \"%i\" with \"%i\" players\n", g_pGameRules->m_iNumZombiesWins, g_pGameRules->m_iNumZombies);
		}

		UTIL_ClientPrintAll(HUD_PRINTCENTER, "#Game_will_restart_in", UTIL_dtos1(iRestartDelay), iRestartDelay == 1 ? "SECOND" : "SECONDS");
		UTIL_ClientPrintAll(HUD_PRINTCONSOLE, "#Game_will_restart_in_console", UTIL_dtos1(iRestartDelay), iRestartDelay == 1 ? "SECOND" : "SECONDS");

		m_bCompleteReset = true;
		m_iRoundPhase = ROUND_ENDING;
		m_iPhaseTime = iRestartDelay;

		CVAR_SET_FLOAT("sv_restartround", 0);
		CVAR_SET_FLOAT("sv_restart", 0);
	}
}

BOOL CHalfLifeMultiplay::CheckGameOver(void)
{
	if (!g_fGameOver)
		return FALSE;

	int time = (int)CVAR_GET_FLOAT("mp_chattime");

	if (time < 1)
		CVAR_SET_STRING("mp_chattime", "1");
	else if (time > MAX_INTERMISSION_TIME)
		CVAR_SET_STRING("mp_chattime", UTIL_dtos1(MAX_INTERMISSION_TIME));

	m_flIntermissionEndTime = m_flIntermissionStartTime + mp_chattime.value;

	if (m_flIntermissionEndTime < gpGlobals->time && (!UTIL_HumansInGame(false) || m_iEndIntermissionButtonHit || gpGlobals->time > m_flIntermissionStartTime + MAX_INTERMISSION_TIME))
		ChangeLevel();

	return TRUE;
}

BOOL CHalfLifeMultiplay::CheckTimeLimit(void)
{
	if (timelimit.value < 0)
	{
		CVAR_SET_FLOAT("mp_timelimit", 0);
		return FALSE;
	}

	if (timelimit.value)
	{
		g_flTimeLimit = g_flResetTime + timelimit.value * 60;

		if (g_flTimeLimit <= gpGlobals->time)
		{
			ALERT(at_console, "Changing maps because time limit has been met\n");
			GoToIntermission();
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CHalfLifeMultiplay::CheckMaxRounds(void)
{
	if (!m_iMaxRounds)
		return FALSE;

	if (m_iTotalRoundsPlayed < m_iMaxRounds)
		return FALSE;

	ALERT(at_console, "Changing maps due to maximum rounds have been met\n");
	GoToIntermission();
	return TRUE;
}

BOOL CHalfLifeMultiplay::CheckWinLimit(void)
{
	if (!m_iMaxRoundsWon)
		return FALSE;

	if (m_iNumHumansWins < m_iMaxRoundsWon && m_iNumZombiesWins < m_iMaxRoundsWon)
		return FALSE;

	ALERT(at_console, "Changing maps...one team has won the specified number of rounds\n");
	GoToIntermission();
	return TRUE;
}

void CHalfLifeMultiplay::CheckAllowSpecator(void)
{
	if (m_iStoredSpectValue != allow_spectators.value)
	{
		m_iStoredSpectValue = allow_spectators.value;

		MESSAGE_BEGIN(MSG_ALL, gmsgAllowSpec);
		WRITE_BYTE(allow_spectators.value);
		MESSAGE_END();
	}
}

void CHalfLifeMultiplay::CheckGameCvar(void)
{
	if (g_psv_accelerate->value != 5)
		CVAR_SET_FLOAT("sv_accelerate", 5);

	if (g_psv_friction->value != 4)
		CVAR_SET_FLOAT("sv_friction", 4);

	if (g_psv_stopspeed->value != 75)
		CVAR_SET_FLOAT("sv_stopspeed", 75);

	m_iMaxRounds = maxrounds.value;

	if (m_iMaxRounds < 0)
	{
		m_iMaxRounds = 0;
		CVAR_SET_FLOAT("mp_maxrounds", 0);
	}

	m_iMaxRoundsWon = winlimit.value;

	if (m_iMaxRoundsWon < 0)
	{
		m_iMaxRoundsWon = 0;
		CVAR_SET_FLOAT("mp_winlimit", 0);
	}

	CVAR_SET_FLOAT("sv_skycolor_r", 0);
	CVAR_SET_FLOAT("sv_skycolor_g", 0);
	CVAR_SET_FLOAT("sv_skycolor_b", 0);
	CVAR_SET_FLOAT("sv_maxvelocity", 99999.0);
	CVAR_SET_FLOAT("sv_maxspeed", 9999.0);
}

BOOL CHalfLifeMultiplay::FShouldSwitchWeapon(CBasePlayer *pPlayer, CBasePlayerItem *pWeapon)
{
	if (!pWeapon->CanDeploy())
		return FALSE;

	if (!pPlayer->m_pActiveItem)
		return TRUE;

	if (!pPlayer->m_iAutoWepSwitch)
		return FALSE;

	if (!pPlayer->m_pActiveItem->CanHolster())
		return FALSE;

	if (pWeapon->iWeight() > pPlayer->m_pActiveItem->iWeight())
		return TRUE;

	return FALSE;
}

BOOL CHalfLifeMultiplay::GetNextBestWeapon(CBasePlayer *pPlayer, CBasePlayerItem *pCurrentWeapon)
{
	if (!pCurrentWeapon->CanHolster())
		return FALSE;

	int iBestWeight = -1;
	CBasePlayerItem *pBest = NULL;

	for (int i = 0; i < MAX_ITEM_TYPES; i++)
	{
		CBasePlayerItem *pCheck = pPlayer->m_rgpPlayerItems[i];

		while (pCheck)
		{
			if (pCheck->iWeight() > iBestWeight && pCheck != pCurrentWeapon)
			{
				if (pCheck->CanDeploy())
				{
					iBestWeight = pCheck->iWeight();
					pBest = pCheck;
				}
			}

			pCheck = pCheck->m_pNext;
		}
	}

	if (!pBest)
		return FALSE;

	pPlayer->SwitchWeapon(pBest);
	return TRUE;
}

BOOL CHalfLifeMultiplay::ClientCommand(CBasePlayer *pPlayer, const char *pcmd)
{
	return FALSE;
}

BOOL CHalfLifeMultiplay::ClientCommand_DeadOrAlive(CBasePlayer *pPlayer, const char *pcmd)
{
	return m_VoiceGameMgr.ClientCommand(pPlayer, pcmd) != false;
}

BOOL CHalfLifeMultiplay::ClientConnected(edict_t *pEntity, const char *pszName, const char *pszAddress, char szRejectReason[128])
{
	m_VoiceGameMgr.ClientConnected(pEntity);
	return TRUE;
}

void CHalfLifeMultiplay::UpdateGameMode(CBasePlayer *pPlayer)
{
	MESSAGE_BEGIN(MSG_ONE, gmsgGameMode, NULL, pPlayer->edict());
	WRITE_BYTE(1);
	MESSAGE_END();
}

void CHalfLifeMultiplay::InitHUD(CBasePlayer *pl)
{
	int i;

	UTIL_LogPrintf("\"%s<%i><%s><>\" entered the game\n", STRING(pl->pev->netname), GETPLAYERUSERID(pl->edict()), GETPLAYERAUTHID(pl->edict()));
	UpdateGameMode(pl);

	if (g_flWeaponCheat == 0)
	{
		MESSAGE_BEGIN(MSG_ONE, gmsgViewMode, NULL, pl->edict());
		MESSAGE_END();
	}

	MESSAGE_BEGIN(MSG_ONE, gmsgScoreInfo, NULL, pl->edict());
	WRITE_BYTE(ENTINDEX(pl->edict()));
	WRITE_SHORT(0);
	WRITE_SHORT(0);
	WRITE_SHORT(0);
	WRITE_SHORT(pl->m_iTeam);
	MESSAGE_END();

	SendMOTDToClient(pl->edict());

	for (i = 1; i <= gpGlobals->maxClients; i++)
	{
		CBasePlayer *plr = UTIL_PlayerByIndex(i);

		if (plr)
		{
			MESSAGE_BEGIN(MSG_ONE, gmsgScoreInfo, NULL, pl->edict());
			WRITE_BYTE(i);
			WRITE_SHORT((int)plr->pev->frags);
			WRITE_SHORT(plr->m_iDeaths);
			WRITE_SHORT(0);
			WRITE_SHORT(plr->m_iTeam);
			MESSAGE_END();
		}
	}

	MESSAGE_BEGIN(MSG_ONE, gmsgTeamScore, NULL, pl->edict());
	WRITE_STRING(GetTeam(TEAM_ZOMBIE));
	WRITE_SHORT(m_iNumZombiesWins);
	MESSAGE_END();

	MESSAGE_BEGIN(MSG_ONE, gmsgTeamScore, NULL, pl->edict());
	WRITE_STRING(GetTeam(TEAM_HUMAN));
	WRITE_SHORT(m_iNumHumansWins);
	MESSAGE_END();

	MESSAGE_BEGIN(MSG_ONE, gmsgAllowSpec, NULL, pl->edict());
	WRITE_BYTE(allow_spectators.value);
	MESSAGE_END();

	MESSAGE_BEGIN(MSG_ONE, gmsgForceCam, NULL, pl->edict());
	WRITE_BYTE(forcecamera.value != 0);
	WRITE_BYTE(forcechasecam.value != 0);
	WRITE_BYTE(fadetoblack.value != 0);
	MESSAGE_END();

	if (g_fGameOver)
	{
		MESSAGE_BEGIN(MSG_ONE, SVC_INTERMISSION, NULL, pl->edict());
		MESSAGE_END();
	}

	for (i = 1; i <= gpGlobals->maxClients; i++)
	{
		CBasePlayer *plr = UTIL_PlayerByIndex(i);

		if (plr)
		{
			MESSAGE_BEGIN(MSG_ONE, gmsgTeamInfo, NULL, pl->edict());
			WRITE_BYTE(ENTINDEX(plr->edict()));
			WRITE_STRING(GetTeam(plr->m_iTeam));
			MESSAGE_END();

			plr->SetScoreboardAttributes(pl);

			if (i != ENTINDEX(pl->edict()))
			{
				if (plr->pev->flags == FL_DORMANT)
					continue;

				if (plr->pev->deadflag == DEAD_NO)
				{
					MESSAGE_BEGIN(MSG_ONE, gmsgRadar, NULL, pl->pev);
					WRITE_BYTE(ENTINDEX(plr->edict()));
					WRITE_COORD(plr->pev->origin.x);
					WRITE_COORD(plr->pev->origin.y);
					WRITE_COORD(plr->pev->origin.z);
					MESSAGE_END();
				}
			}
		}
	}
}

void CHalfLifeMultiplay::ClientDisconnected(edict_t *pClient)
{
	if (pClient)
	{
		CBasePlayer *pPlayer = (CBasePlayer *)CBaseEntity::Instance(pClient);

		if (pPlayer)
		{
			pPlayer->has_disconnected = true;
			pPlayer->pev->deadflag = DEAD_DEAD;
			pPlayer->SetScoreboardAttributes();

			pPlayer->m_iCurrentKickVote = 0;

			if (pPlayer->m_iCurrentKickVote)
			{
				m_iMapVotes[pPlayer->m_iMapVote]--;

				if (m_iMapVotes[pPlayer->m_iMapVote] < 0)
					m_iMapVotes[pPlayer->m_iMapVote] = 0;
			}

			MESSAGE_BEGIN(MSG_ALL, gmsgScoreInfo);
			WRITE_BYTE(ENTINDEX(pClient));
			WRITE_SHORT(0);
			WRITE_SHORT(0);
			WRITE_SHORT(0);
			WRITE_SHORT(0);
			MESSAGE_END();

			MESSAGE_BEGIN(MSG_ALL, gmsgTeamInfo);
			WRITE_BYTE(ENTINDEX(pClient));
			WRITE_STRING(GetTeam(TEAM_UNASSIGNED));
			MESSAGE_END();

			MESSAGE_BEGIN(MSG_ALL, gmsgLocation);
			WRITE_BYTE(ENTINDEX(pClient));
			WRITE_STRING("");
			MESSAGE_END();

			FireTargets("game_playerleave", pPlayer, pPlayer, USE_TOGGLE, 0);
			UTIL_LogPrintf("\"%s<%i><%s><%s>\" disconnected\n", STRING(pPlayer->pev->netname), GETPLAYERUSERID(pPlayer->edict()), GETPLAYERAUTHID(pPlayer->edict()), GetTeam(pPlayer->m_iTeam));
			pPlayer->RemoveAllItems(TRUE);

			if (pPlayer->m_pObserver)
				pPlayer->m_pObserver->SUB_Remove();

			CBasePlayer *client = NULL;

			while ((client = (CBasePlayer *)UTIL_FindEntityByClassname(client, "player")) != NULL)
			{
				if (FNullEnt(client->edict()))
					break;

				if (!client->pev || client == pPlayer)
					continue;

				if (client->m_hObserverTarget == pPlayer)
				{
					int iMode = client->pev->iuser1;
					client->pev->iuser1 = 0;
					client->Observer_SetMode(iMode);
				}
			}
		}
	}
}

float CHalfLifeMultiplay::FlPlayerFallDamage(CBasePlayer *pPlayer)
{
	// zombies are not afraid of fall damage.
	if (pPlayer->m_iTeam == TEAM_ZOMBIE)
		return 0.0f;

	pPlayer->m_flFallVelocity -= PLAYER_MAX_SAFE_FALL_SPEED;
	
	float flDamage = pPlayer->m_flFallVelocity * DAMAGE_FOR_FALL_SPEED * 1.25f;

	// use percentage damage for humans.
	flDamage = (flDamage / 100.0f) * pPlayer->pev->max_health;
	return flDamage;
}

BOOL CHalfLifeMultiplay::FPlayerCanTakeDamage(CBasePlayer *pPlayer, CBaseEntity *pAttacker)
{
	if (m_iRoundPhase != ROUND_STARTED)	// crazy time bonus
		return FALSE;

	if (!pAttacker)
		return TRUE;

	if (PlayerRelationship(pPlayer, pAttacker) != GR_TEAMMATE)
		return TRUE;

	if (CVAR_GET_FLOAT("mp_friendlyfire") != 0)
		return TRUE;

	if (pAttacker == pPlayer)
		return TRUE;

	return FALSE;
}

void ShowVGUIMenu(CBasePlayer *pPlayer, int MenuType, int BitMask, char *szOldMenu);
BOOL HandleMenu_ChooseTeam(CBasePlayer *pPlayer, int slot);
void HandleMenu_ChooseAppearance(CBasePlayer *player, int slot);

void CHalfLifeMultiplay::PlayerThink(CBasePlayer *pPlayer)
{
	if (g_fGameOver)
	{
		if (pPlayer->m_afButtonPressed & (IN_DUCK | IN_ATTACK | IN_ATTACK2 | IN_USE | IN_JUMP))
			m_iEndIntermissionButtonHit = TRUE;

		pPlayer->m_afButtonPressed = 0;
		pPlayer->pev->button = 0;
		pPlayer->m_afButtonReleased = 0;
	}

	if (!pPlayer->m_bCanShoot)
	{
		pPlayer->m_bCanShoot = true;
	}

	if (pPlayer->m_pActiveItem && pPlayer->m_pActiveItem->IsWeapon())
	{
		CBasePlayerWeapon *pWeapon = (CBasePlayerWeapon *)pPlayer->m_pActiveItem->GetWeaponPtr();

		if (pWeapon->m_iWeaponState & WPNSTATE_SHIELD_DRAWN)
			pPlayer->m_bCanShoot = false;
	}

	if (pPlayer->m_iMenu != Menu_ChooseTeam && pPlayer->m_iJoiningState == SHOWTEAMSELECT)
	{
		int slot = -1;

		if (!stricmp(humans_join_team.string, "T"))
		{
			slot = 1;
		}
		else if (!stricmp(humans_join_team.string, "CT"))
		{
			slot = 2;
		}
		else
		{
			if (!allow_spectators.value)
				ShowVGUIMenu(pPlayer, MENU_TEAM, MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_5, "#Team_Select");
			else
				ShowVGUIMenu(pPlayer, MENU_TEAM, MENU_KEY_1 | MENU_KEY_2 | MENU_KEY_5 | MENU_KEY_6, "#Team_Select_Spect");
		}

		pPlayer->m_iMenu = Menu_ChooseTeam;
		pPlayer->m_iJoiningState = PICKINGTEAM;

		if (slot > 0)
		{
			if (!pPlayer->IsBot())
			{
				HandleMenu_ChooseTeam(pPlayer, slot);
			}
		}
	}
}

void CHalfLifeMultiplay::PlayerSpawn(CBasePlayer *pPlayer)
{
	if (pPlayer->m_bJustConnected)
		return;

	pPlayer->pev->weapons |= (1 << WEAPON_SUIT);

	BOOL addDefault = TRUE;
	CBaseEntity *pWeaponEntity = NULL;

	while ((pWeaponEntity = UTIL_FindEntityByClassname(pWeaponEntity, "game_player_equip")) != NULL)
	{
		pWeaponEntity->Touch(pPlayer);
		addDefault = FALSE;
	}

	if (pPlayer->m_bNotKilled == true)
		addDefault = false;

	if (addDefault)
		pPlayer->GiveDefaultItems();

	pPlayer->SetPlayerModel();
}

BOOL CHalfLifeMultiplay::FPlayerCanRespawn(CBasePlayer *pPlayer)
{
	if (pPlayer->m_iNumSpawns > 0)
		return FALSE;

	if (m_iNumZombies > 0 && m_iNumHumans > 0 && m_iRoundPhase > ROUND_COUNTINGDOWN && m_iPhaseTime < (ROUND_TIME - 20))
	{
		if (fadetoblack.value != 0)
			UTIL_ScreenFade(pPlayer, Vector(0, 0, 0), 3, 3, 255, FFADE_OUT | FFADE_STAYOUT);

		return FALSE;
	}

	if (pPlayer->m_iMenu == Menu_ChooseAppearance)
		return FALSE;

	return TRUE;
}

float CHalfLifeMultiplay::FlPlayerSpawnTime(CBasePlayer *pPlayer)
{
	return gpGlobals->time;
}

BOOL CHalfLifeMultiplay::AllowAutoTargetCrosshair(void)
{
	return FALSE;
}

int CHalfLifeMultiplay::IPointsForKill(CBasePlayer *pAttacker, CBasePlayer *pKilled)
{
	return 1;
}

void CHalfLifeMultiplay::PlayerKilled(CBasePlayer *pVictim, entvars_t *pKiller, entvars_t *pInflictor)
{
	DeathNotice(pVictim, pKiller, pInflictor);
	CheckWinConditions();

	pVictim->m_afPhysicsFlags &= ~PFLAG_ONTRAIN;
	pVictim->m_iDeaths++;
	pVictim->m_bNotKilled = false;
	pVictim->m_iTrain = TRAIN_NEW | TRAIN_OFF;
	SET_VIEW(ENT(pVictim->pev), ENT(pVictim->pev));

	CBasePlayer *peKiller = NULL;
	CBaseEntity *ktmp = CBaseEntity::Instance(pKiller);

	if (ktmp && ktmp->Classify() == CLASS_PLAYER)
	{
		peKiller = (CBasePlayer *)ktmp;
	}
	else if (ktmp && ktmp->Classify() == CLASS_VEHICLE)
	{
		CBasePlayer *pDriver = (CBasePlayer *)((CFuncVehicle *)ktmp)->m_pDriver;

		if (pDriver)
		{
			pKiller = ktmp->pev;
			peKiller = (CBasePlayer *)pDriver;
		}
	}

	FireTargets("game_playerdie", pVictim, pVictim, USE_TOGGLE, 0);

	if (pVictim->pev == pKiller)
	{
		pKiller->frags -= 1;
	}
	else if (peKiller && peKiller->IsPlayer())
	{
		CBasePlayer *killer = GetClassPtr((CBasePlayer *)pKiller);

		if (killer->m_iTeam == pVictim->m_iTeam)
		{
			pKiller->frags -= IPointsForKill(peKiller, pVictim);
			killer->AddAccount(-3300);
			killer->m_iTeamKills++;
			killer->m_bJustKilledTeammate = true;

			ClientPrint(killer->pev, HUD_PRINTCENTER, "#Killed_Teammate");
			ClientPrint(killer->pev, HUD_PRINTCONSOLE, "#Game_teammate_kills", UTIL_dtos1(killer->m_iTeamKills));

			if (killer->m_iTeamKills >= 3)
			{
				if (CVAR_GET_FLOAT("mp_autokick") != 0)
				{
					ClientPrint(killer->pev, HUD_PRINTCONSOLE, "#Banned_For_Killing_Teamates");

					int iUserID = GETPLAYERUSERID(ENT(killer->pev));

					if (iUserID != -1)
						SERVER_COMMAND(UTIL_VarArgs("kick # %d\n", iUserID));
				}
			}

			if (!(killer->m_flDisplayHistory & DHF_FRIEND_KILLED))
			{
				killer->m_flDisplayHistory |= DHF_FRIEND_KILLED;
				killer->HintMessage("#Hint_careful_around_teammates");
			}
		}
		else
		{
			pKiller->frags += IPointsForKill(peKiller, pVictim);

			killer->AddAccount(killer->m_iTeam == TEAM_HUMAN ? cvar_humangetmoney.value : cvar_zombiegetmoney.value);

			if (!(killer->m_flDisplayHistory & DHF_ENEMY_KILLED))
			{
				killer->m_flDisplayHistory |= DHF_ENEMY_KILLED;
				killer->HintMessage("#Hint_win_round_by_killing_enemy");
			}
		}

		FireTargets("game_playerkill", peKiller, peKiller, USE_TOGGLE, 0);
	}
	else
		pKiller->frags -= 1;

	MESSAGE_BEGIN(MSG_BROADCAST, gmsgScoreInfo);
	WRITE_BYTE(ENTINDEX(pVictim->edict()));
	WRITE_SHORT((int)pVictim->pev->frags);
	WRITE_SHORT(pVictim->m_iDeaths);
	WRITE_SHORT(0);
	WRITE_SHORT(pVictim->m_iTeam);
	MESSAGE_END();

	if (ktmp && ktmp->Classify() == CLASS_PLAYER)
	{
		CBasePlayer *PK = (CBasePlayer *)ktmp;

		MESSAGE_BEGIN(MSG_ALL, gmsgScoreInfo);
		WRITE_BYTE(ENTINDEX(PK->edict()));
		WRITE_SHORT((int)PK->pev->frags);
		WRITE_SHORT(PK->m_iDeaths);
		WRITE_SHORT(0);
		WRITE_SHORT(PK->m_iTeam);
		MESSAGE_END();

		PK->m_flNextDecalTime = gpGlobals->time;
	}
}

void CHalfLifeMultiplay::DeathNotice(CBasePlayer *pVictim, entvars_t *pKiller, entvars_t *pevInflictor)
{
	CBaseEntity::Instance(pKiller);

	const char *killer_weapon_name = "world";
	int killer_index = 0;
	char *tau = "tau_cannon";
	char *gluon = "gluon gun";

	if (pKiller->flags & FL_CLIENT)
	{
		killer_index = ENTINDEX(ENT(pKiller));

		if (pevInflictor)
		{
			if (pevInflictor == pKiller)
			{
				CBasePlayer *pPlayer = (CBasePlayer *)CBaseEntity::Instance(pKiller);

				if (pPlayer->m_pActiveItem)
					killer_weapon_name = pPlayer->m_pActiveItem->pszName();
			}
			else
				killer_weapon_name = STRING(pevInflictor->classname);
		}
	}
	else
		killer_weapon_name = STRING(pevInflictor->classname);

	if (!strncmp(killer_weapon_name, "weapon_", 7))
		killer_weapon_name += 7;
	else if (!strncmp(killer_weapon_name, "monster_", 8))
		killer_weapon_name += 8;
	else if (!strncmp(killer_weapon_name, "func_", 5))
		killer_weapon_name += 5;

	int iGotHeadshot = FALSE;

	if (pVictim->m_bHeadshotKilled == true)
		iGotHeadshot = TRUE;

	MESSAGE_BEGIN(MSG_ALL, gmsgDeathMsg);
	WRITE_BYTE(killer_index);
	WRITE_BYTE(ENTINDEX(pVictim->edict()));
	WRITE_BYTE(iGotHeadshot);
	WRITE_STRING(killer_weapon_name);
	MESSAGE_END();

	if (!strcmp(killer_weapon_name, "egon"))
		killer_weapon_name = gluon;
	else if (!strcmp(killer_weapon_name, "gauss"))
		killer_weapon_name = tau;

	if (pVictim->pev == pKiller)
	{
		UTIL_LogPrintf("\"%s<%i><%s><%s>\" committed suicide with \"%s\"\n", STRING(pVictim->pev->netname), GETPLAYERUSERID(pVictim->edict()), GETPLAYERAUTHID(pVictim->edict()), GetTeam(pVictim->m_iTeam), killer_weapon_name);
	}
	else if (pKiller->flags & FL_CLIENT)
	{
		CBasePlayer *pPlayer = (CBasePlayer *)CBaseEntity::Instance(pKiller);
		UTIL_LogPrintf("\"%s<%i><%s><%s>\" killed \"%s<%i><%s><%s>\" with \"%s\"\n", STRING(pKiller->netname), GETPLAYERUSERID(ENT(pKiller)), GETPLAYERAUTHID(ENT(pKiller)), GetTeam(pPlayer->m_iTeam), STRING(pVictim->pev->netname), GETPLAYERUSERID(pVictim->edict()), GETPLAYERAUTHID(pVictim->edict()), GetTeam(pVictim->m_iTeam), killer_weapon_name);
	}
	else
		UTIL_LogPrintf("\"%s<%i><%s><%s>\" committed suicide with \"%s\" (world)\n", STRING(pVictim->pev->netname), GETPLAYERUSERID(pVictim->edict()), GETPLAYERAUTHID(pVictim->edict()), GetTeam(pVictim->m_iTeam), killer_weapon_name);

	MESSAGE_BEGIN(MSG_SPEC, SVC_DIRECTOR);
	WRITE_BYTE(9);
	WRITE_BYTE(DRC_CMD_EVENT);
	WRITE_SHORT(ENTINDEX(pVictim->edict()));

	if (pevInflictor)
		WRITE_SHORT(ENTINDEX(ENT(pevInflictor)));
	else
		WRITE_SHORT(ENTINDEX(ENT(pKiller)));

	if (iGotHeadshot)
		WRITE_LONG(15 | DRC_FLAG_DRAMATIC | DRC_FLAG_SLOWMOTION);
	else
		WRITE_LONG(7 | DRC_FLAG_DRAMATIC);

	MESSAGE_END();
}

void CHalfLifeMultiplay::PlayerGotWeapon(CBasePlayer *pPlayer, CBasePlayerItem *pWeapon)
{
}

float CHalfLifeMultiplay::FlWeaponRespawnTime(CBasePlayerItem *pWeapon)
{
	return gpGlobals->time + WEAPON_RESPAWN_TIME;
}

#define ENTITY_INTOLERANCE 100

float CHalfLifeMultiplay::FlWeaponTryRespawn(CBasePlayerItem *pWeapon)
{
	if (pWeapon && pWeapon->m_iId && (pWeapon->iFlags() & ITEM_FLAG_LIMITINWORLD))
	{
		if (NUMBER_OF_ENTITIES() < (gpGlobals->maxEntities - ENTITY_INTOLERANCE))
			return 0;

		return FlWeaponRespawnTime(pWeapon);
	}

	return 0;
}

Vector CHalfLifeMultiplay::VecWeaponRespawnSpot(CBasePlayerItem *pWeapon)
{
	return pWeapon->pev->origin;
}

int CHalfLifeMultiplay::WeaponShouldRespawn(CBasePlayerItem *pWeapon)
{
	if (pWeapon->pev->spawnflags & SF_NORESPAWN)
		return GR_WEAPON_RESPAWN_NO;

	return GR_WEAPON_RESPAWN_YES;
}

BOOL CHalfLifeMultiplay::CanHavePlayerItem(CBasePlayer *pPlayer, CBasePlayerItem *pItem)
{
	if (pPlayer->m_iTeam == TEAM_ZOMBIE && pItem->m_iId != WEAPON_KNIFE)
		return FALSE;

	return CGameRules::CanHavePlayerItem(pPlayer, pItem);
}

BOOL CHalfLifeMultiplay::CanHaveItem(CBasePlayer *pPlayer, CItem *pItem)
{
	return TRUE;
}

void CHalfLifeMultiplay::PlayerGotItem(CBasePlayer *pPlayer, CItem *pItem)
{
}

int CHalfLifeMultiplay::ItemShouldRespawn(CItem *pItem)
{
	if (pItem->pev->spawnflags & SF_NORESPAWN)
		return GR_ITEM_RESPAWN_NO;

	return GR_ITEM_RESPAWN_YES;
}

float CHalfLifeMultiplay::FlItemRespawnTime(CItem *pItem)
{
	return gpGlobals->time + ITEM_RESPAWN_TIME;
}

Vector CHalfLifeMultiplay::VecItemRespawnSpot(CItem *pItem)
{
	return pItem->pev->origin;
}

void CHalfLifeMultiplay::PlayerGotAmmo(CBasePlayer *pPlayer, char *szName, int iCount)
{
}

BOOL CHalfLifeMultiplay::IsAllowedToSpawn(CBaseEntity *pEntity)
{
	return TRUE;
}

int CHalfLifeMultiplay::AmmoShouldRespawn(CBasePlayerAmmo *pAmmo)
{
	if (pAmmo->pev->spawnflags & SF_NORESPAWN)
		return GR_AMMO_RESPAWN_NO;

	return GR_AMMO_RESPAWN_YES;
}

float CHalfLifeMultiplay::FlAmmoRespawnTime(CBasePlayerAmmo *pAmmo)
{
	return gpGlobals->time + AMMO_RESPAWN_TIME;
}

Vector CHalfLifeMultiplay::VecAmmoRespawnSpot(CBasePlayerAmmo *pAmmo)
{
	return pAmmo->pev->origin;
}

float CHalfLifeMultiplay::FlHealthChargerRechargeTime(void)
{
	return 60;
}

float CHalfLifeMultiplay::FlHEVChargerRechargeTime(void)
{
	return 30;
}

int CHalfLifeMultiplay::DeadPlayerWeapons(CBasePlayer *pPlayer)
{
	return GR_PLR_DROP_GUN_ACTIVE;
}

int CHalfLifeMultiplay::DeadPlayerAmmo(CBasePlayer *pPlayer)
{
	return GR_PLR_DROP_AMMO_ACTIVE;
}

edict_t *CHalfLifeMultiplay::GetPlayerSpawnSpot(CBasePlayer *pPlayer)
{
	edict_t* pentSpawnSpot = nullptr;

	if (pPlayer->m_iTeam == TEAM_HUMAN || !m_iNumHumans)	// only use map spawn point when no lived presence.
	{
		pentSpawnSpot = CGameRules::GetPlayerSpawnSpot(pPlayer);

		if (pentSpawnSpot->v.target)
			FireTargets(STRING(pentSpawnSpot->v.target), pPlayer, pPlayer, USE_TOGGLE, 0);
	}
	else	// yes, observers included this time.
	{
		CBasePlayer* pHuman = nullptr;
		int iHumanCounts = 0;
		CBasePlayer* rgpHumans[33];

		for (int i = 1; i < gpGlobals->maxClients; i++)
		{
			pHuman = UTIL_PlayerByIndex(i);

			if (!pHuman || !pHuman->IsAlive() || !pHuman->IsAvailable())
				continue;

			if (pHuman->m_iTeam != TEAM_HUMAN || pHuman->IsStuck())
				continue;

			iHumanCounts++;
			rgpHumans[iHumanCounts] = pHuman;
		}

		if (iHumanCounts)
		{
			// enforce ducking anyway.
			pPlayer->pev->flags |= FL_DUCKING;
			SET_SIZE(pPlayer->edict(), Vector(-16.0, -16.0, -18.0), Vector(16.0, 16.0, 32.0));
			pPlayer->pev->view_ofs = Vector(0.0, 0.0, 12.0);
			
			// pick a player then teleport.
			pentSpawnSpot = rgpHumans[RANDOM_LONG(1, iHumanCounts)]->edict();
			SET_ORIGIN(pPlayer->edict(), pentSpawnSpot->v.origin);
		}
		else	// why we were here? a dead human counted into m_iNumHumans?
			pentSpawnSpot = CGameRules::GetPlayerSpawnSpot(pPlayer);
	}

	return pentSpawnSpot;
}

int CHalfLifeMultiplay::PlayerRelationship(CBaseEntity *pPlayer, CBaseEntity *pTarget)
{
	if (!pPlayer || !pTarget)
		return GR_NOTTEAMMATE;

	if (!pTarget->IsPlayer())
		return GR_NOTTEAMMATE;

	if (GetClassPtr((CBasePlayer *)pPlayer->pev)->m_iTeam != GetClassPtr((CBasePlayer *)pTarget->pev)->m_iTeam)
		return GR_NOTTEAMMATE;

	return GR_TEAMMATE;
}

BOOL CHalfLifeMultiplay::FAllowFlashlight(void)
{
	static cvar_t *mp_flashlight = NULL;

	if (!mp_flashlight)
		mp_flashlight = CVAR_GET_POINTER("mp_flashlight");

	if (mp_flashlight)
		return mp_flashlight->value != 0;

	return FALSE;
}

BOOL CHalfLifeMultiplay::FAllowMonsters(void)
{
	return CVAR_GET_FLOAT("mp_allowmonsters") != 0;
}

void CHalfLifeMultiplay::GoToIntermission(void)
{
	if (g_fGameOver)
		return;

	if (g_pGameRules)
	{
		UTIL_LogPrintf("Team \"CT\" scored \"%i\" with \"%i\" players\n", g_pGameRules->m_iNumHumansWins, g_pGameRules->m_iNumHumans);
		UTIL_LogPrintf("Team \"TERRORIST\" scored \"%i\" with \"%i\" players\n", g_pGameRules->m_iNumZombiesWins, g_pGameRules->m_iNumZombies);
	}

	MESSAGE_BEGIN(MSG_ALL, SVC_INTERMISSION);
	MESSAGE_END();

	int time = (int)CVAR_GET_FLOAT("mp_chattime");

	if (time < 1)
		CVAR_SET_STRING("mp_chattime", "1");
	else if (time > MAX_INTERMISSION_TIME)
		CVAR_SET_STRING("mp_chattime", UTIL_dtos1(MAX_INTERMISSION_TIME));

	m_flIntermissionEndTime = gpGlobals->time + (int)mp_chattime.value;
	m_flIntermissionStartTime = gpGlobals->time;

	g_fGameOver = TRUE;
	m_iEndIntermissionButtonHit = FALSE;
	m_iSpawnPointCount_Zombies = 0;
	m_iSpawnPointCount_Humans = 0;
	m_bLevelInitialized = false;
}

void CHalfLifeMultiplay::ServerDeactivate(void)
{
}

#define MAX_RULE_BUFFER 1024

typedef struct mapcycle_item_s
{
	struct mapcycle_item_s *next;
	char mapname[32];
	int minplayers, maxplayers;
	char rulebuffer[MAX_RULE_BUFFER];
}
mapcycle_item_t;

typedef struct mapcycle_s
{
	struct mapcycle_item_s *items;
	struct mapcycle_item_s *next_item;
}
mapcycle_t;

void DestroyMapCycle(mapcycle_t *cycle)
{
	mapcycle_item_t *n, *start;
	mapcycle_item_t *p = cycle->items;

	if (p)
	{
		start = p;
		p = p->next;

		while (p != start)
		{
			n = p->next;
			delete p;
			p = n;
		}

		delete cycle->items;
	}

	cycle->items = NULL;
	cycle->next_item = NULL;
}

static char mp_com_token[1500];

char *MP_COM_GetToken(void)
{
	return mp_com_token;
}

char *MP_COM_Parse(char *data)
{
	int len = 0, c;
	mp_com_token[0] = '\0';

	if (!data)
		return NULL;

skipwhite:
	while ((c = *data) <= ' ')
	{
		if (c == 0)
			return NULL;

		data++;
	}

	if (c == '/' && data[1] == '/')
	{
		while (*data && *data != '\n')
			data++;

		goto skipwhite;
	}

	if (c == '\"')
	{
		data++;

		while (1)
		{
			c = *data++;

			if (c == '\"' || !c)
			{
				mp_com_token[len] = '\0';
				return data;
			}

			mp_com_token[len++] = c;
		}
	}

	if (c == '{' || c == '}'|| c == ')'|| c == '(' || c == '\'' || c == ',')
	{
		mp_com_token[len++] = c;
		mp_com_token[len] = '\0';
		return data + 1;
	}

	do
	{
		mp_com_token[len] = c;
		data++;
		len++;
		c = *data;

		if (c == '{' || c == '}'|| c == ')'|| c == '(' || c == '\'' || c == ',')
			break;
	}
	while (c > 32);

	mp_com_token[len] = '\0';
	return data;
}

int MP_COM_TokenWaiting(char *buffer)
{
	char *p = buffer;

	while (*p && *p != '\n')
	{
		if (!isspace(*p) || isalnum(*p))
			return 1;

		p++;
	}

	return 0;
}

int ReloadMapCycleFile(char *filename, mapcycle_t *cycle)
{
	int length;
	char *pFileList;
	char *aFileList = pFileList = (char *)LOAD_FILE_FOR_ME(filename, &length);
	mapcycle_item_s *item, *newlist = NULL, *next;

	if (pFileList && length)
	{
		while (1)
		{
			int hasbuffer = 0;
			char szBuffer[MAX_RULE_BUFFER];
			memset(szBuffer, 0, MAX_RULE_BUFFER);
			pFileList = MP_COM_Parse(pFileList);

			if (strlen(mp_com_token) == 0)
				break;

			char szMap[32];
			strcpy(szMap, mp_com_token);

			if (MP_COM_TokenWaiting(pFileList))
			{
				pFileList = MP_COM_Parse(pFileList);

				if (strlen(mp_com_token) != 0)
				{
					hasbuffer = 1;
					strcpy(szBuffer, mp_com_token);
				}
			}

			if (IS_MAP_VALID(szMap))
			{
				item = new mapcycle_item_s;
				strcpy(item->mapname, szMap);

				item->minplayers = 0;
				item->maxplayers = 0;

				memset(item->rulebuffer, 0, MAX_RULE_BUFFER);

				if (hasbuffer)
				{
					char *s = g_engfuncs.pfnInfoKeyValue(szBuffer, "minplayers");

					if (s && s[0])
					{
						item->minplayers = atoi(s);
						item->minplayers = max(item->minplayers, 0);
						item->minplayers = min(item->minplayers, gpGlobals->maxClients);
					}

					s = g_engfuncs.pfnInfoKeyValue(szBuffer, "maxplayers");

					if (s && s[0])
					{
						item->maxplayers = atoi(s);
						item->maxplayers = max(item->maxplayers, 0);
						item->maxplayers = min(item->maxplayers, gpGlobals->maxClients);
					}

					g_engfuncs.pfnInfo_RemoveKey(szBuffer, "minplayers");
					g_engfuncs.pfnInfo_RemoveKey(szBuffer, "maxplayers");
					strcpy(item->rulebuffer, szBuffer);
				}

				item->next = cycle->items;
				cycle->items = item;
			}
			else
				ALERT(at_console, "Skipping %s from mapcycle, not a valid map\n", szMap);
		}

		FREE_FILE(aFileList);
	}

	item = cycle->items;

	while (item)
	{
		next = item->next;
		item->next = newlist;
		newlist = item;
		item = next;
	}

	cycle->items = newlist;
	item = cycle->items;

	if (!item)
		return 0;

	while (item->next)
		item = item->next;

	item->next = cycle->items;
	cycle->next_item = item->next;
	return 1;
}

int CountPlayers(void)
{
	int num = 0;

	for (int i = 1; i <= gpGlobals->maxClients; i++)
	{
		CBasePlayer *pEnt = UTIL_PlayerByIndex(i);

		if (pEnt)
			num = num + 1;
	}

	return num;
}

void ExtractCommandString(char *s, char *szCommand)
{
	char pkey[512];
	char value[512];

	if (*s == '\\')
		s++;

	while (1)
	{
		char *o = pkey;

		while (*s != '\\')
		{
			if (!*s)
				return;

			*o++ = *s++;
		}

		*o = '\0';
		s++;
		o = value;

		while (*s != '\\' && *s)
		{
			if (!*s)
				return;

			*o++ = *s++;
		}

		*o = '\0';
		strcat(szCommand, pkey);

		if (strlen(value) != 0)
		{
			strcat(szCommand, " ");
			strcat(szCommand, value);
		}

		strcat(szCommand, "\n");

		if (!*s)
			return;

		s++;
	}
}

int GetMapCount(void)
{
	static mapcycle_t mapcycle;
	char *mapcfile = (char *)CVAR_GET_STRING("mapcyclefile");

	DestroyMapCycle(&mapcycle);
	ReloadMapCycleFile(mapcfile, &mapcycle);

	int num = 0;

	for (mapcycle_item_s *item = mapcycle.next_item; item->next != mapcycle.next_item; item = item->next)
		num = num + 1;

	return num;
}

void CHalfLifeMultiplay::DisplayMaps(CBasePlayer *pPlayer, int mapId)
{
	static mapcycle_t mapcycle;
	char *mapcfile = (char *)CVAR_GET_STRING("mapcyclefile");
	int index = 0, id = 0;
	char *pszNextMaps = NULL;

	DestroyMapCycle(&mapcycle);
	ReloadMapCycleFile(mapcfile, &mapcycle);

	for (mapcycle_item_s *item = mapcycle.next_item; item->next != mapcycle.next_item; item = item->next, index++)
	{
		id++;

		if (pPlayer)
		{
			if (m_iMapVotes[index] != 1)
				ClientPrint(pPlayer->pev, HUD_PRINTCONSOLE, "#Votes", UTIL_dtos1(index), item->mapname, UTIL_dtos2(m_iMapVotes[index]));
			else
				ClientPrint(pPlayer->pev, HUD_PRINTCONSOLE, "#Vote", UTIL_dtos1(index), item->mapname, UTIL_dtos2(1));
		}

		if (id == mapId)
			pszNextMaps = item->mapname;
	}

	if (!pszNextMaps || !mapId)
		return;

	if (strcmp(pszNextMaps, STRING(gpGlobals->mapname)))
	{
		CHANGE_LEVEL(pszNextMaps, NULL);
		return;
	}

	if (timelimit.value)
	{
		timelimit.value += 30;
		UTIL_ClientPrintAll(HUD_PRINTCENTER, "#Map_Vote_Extend");
	}

	ResetAllMapVotes();
}

void CHalfLifeMultiplay::ResetAllMapVotes(void)
{
	CBaseEntity *pEntity = NULL;

	while ((pEntity = UTIL_FindEntityByClassname(pEntity, "player")) != NULL)
	{
		if (FNullEnt(pEntity->edict()))
			break;

		CBasePlayer *pPlayer = GetClassPtr((CBasePlayer *)pEntity->pev);

		if (pPlayer->m_iTeam != TEAM_UNASSIGNED)
			pPlayer->m_iCurrentKickVote = 0;
	}

	for (int i = 0; i < MAX_MAPS; i++)
		m_iMapVotes[i] = 0;
}

void CHalfLifeMultiplay::ProcessMapVote(CBasePlayer *pPlayer, int mapId)
{
	CBaseEntity *pEntity = NULL;
	int playerCount = 0, count = 0;

	while ((pEntity = UTIL_FindEntityByClassname(pEntity, "player")) != NULL)
	{
		if (FNullEnt(pEntity->edict()))
			break;

		CBasePlayer *pPlayer = GetClassPtr((CBasePlayer *)pEntity->pev);

		if (pPlayer->m_iTeam != TEAM_UNASSIGNED)
		{
			playerCount++;

			if (pPlayer->m_iCurrentKickVote = mapId)
				count++;
		}
	}

	m_iMapVotes[mapId] = count;
	float radio = mapvoteratio.value;

	if (mapvoteratio.value > 1)
	{
		radio = 1;
		CVAR_SET_STRING("mp_mapvoteratio", "1.0");
	}
	else if (mapvoteratio.value < 0.35)
	{
		radio = 0.35;
		CVAR_SET_STRING("mp_mapvoteratio", "0.35");
	}

	int needCount;

	if (playerCount > 2)
		needCount = (int)(playerCount * radio + 0.5);
	else
		needCount = 2;

	if (count < needCount)
	{
		DisplayMaps(pPlayer, 0);
		ClientPrint(pPlayer->pev, HUD_PRINTCONSOLE, "#Game_required_votes", UTIL_dtos1(needCount));
	}
	else
		DisplayMaps(NULL, mapId);
}

void CHalfLifeMultiplay::ChangeLevel(void)
{
	static char szPreviousMapCycleFile[256];
	static mapcycle_t mapcycle;

	char szNextMap[32];
	char szFirstMapInList[32];
	char szCommands[1500];
	char szRules[1500];
	int minplayers = 0, maxplayers = 0;
	strcpy(szFirstMapInList, "hldm1");

	int curplayers;
	BOOL do_cycle = TRUE;
	char *mapcfile = (char *)CVAR_GET_STRING("mapcyclefile");

	szCommands[0] = '\0';
	szRules[0] = '\0';
	curplayers = CountPlayers();

	if (strcmp(mapcfile, szPreviousMapCycleFile))	// POTENTIAL BUG
	{
		strcpy(szPreviousMapCycleFile, mapcfile);
		DestroyMapCycle(&mapcycle);

		if (!ReloadMapCycleFile(mapcfile, &mapcycle) || !mapcycle.items)
		{
			ALERT(at_console, "Unable to load map cycle file %s\n", mapcfile);
			do_cycle = FALSE;
		}
	}

	if (do_cycle && mapcycle.items)
	{
		BOOL keeplooking = FALSE;
		BOOL found = FALSE;
		mapcycle_item_s *item;

		strcpy(szNextMap, STRING(gpGlobals->mapname));
		strcpy(szFirstMapInList, STRING(gpGlobals->mapname));

		for (item = mapcycle.next_item; item->next != mapcycle.next_item; item = item->next)
		{
			keeplooking = FALSE;

			if (item->minplayers)
			{
				if (curplayers >= item->minplayers)
				{
					found = TRUE;
					minplayers = item->minplayers;
				}
				else
					keeplooking = TRUE;
			}

			if (item->maxplayers)
			{
				if (curplayers <= item->maxplayers)
				{
					found = TRUE;
					maxplayers = item->maxplayers;
				}
				else
					keeplooking = TRUE;
			}

			if (keeplooking)
				continue;

			found = TRUE;
			break;
		}

		if (!found)
			item = mapcycle.next_item;

		mapcycle.next_item = item->next;
		strcpy(szNextMap, item->mapname);
		ExtractCommandString(item->rulebuffer, szCommands);
		strcpy(szRules, item->rulebuffer);
	}

	if (!IS_MAP_VALID(szNextMap))
		strcpy(szNextMap, szFirstMapInList);

	g_fGameOver = TRUE;
	ALERT(at_console, "CHANGE LEVEL: %s\n", szNextMap);

	if (minplayers || maxplayers)
		ALERT(at_console, "PLAYER COUNT:  min %i max %i current %i\n", minplayers, maxplayers, curplayers);

	if (strlen(szRules))
		ALERT(at_console, "RULES:  %s\n", szRules);

	CHANGE_LEVEL(szNextMap, NULL);

	if (strlen(szCommands))
		SERVER_COMMAND(szCommands);
}

#define MAX_MOTD_CHUNK 60
#define MAX_MOTD_LENGTH 1536

void CHalfLifeMultiplay::SendMOTDToClient(edict_t *client)
{
	int length, char_count = 0;
	char *pFileList;
	char *aFileList = pFileList = (char *)LOAD_FILE_FOR_ME((char *)CVAR_GET_STRING("motdfile"), &length);

	MESSAGE_BEGIN(MSG_ONE, gmsgServerName, NULL, client);
	WRITE_STRING(CVAR_GET_STRING("hostname"));
	MESSAGE_END();

	while (pFileList && *pFileList && char_count < MAX_MOTD_LENGTH)
	{
		char chunk[MAX_MOTD_CHUNK + 1];

		if (strlen(pFileList) < MAX_MOTD_CHUNK)
		{
			strcpy(chunk, pFileList);
		}
		else
		{
			strncpy(chunk, pFileList, MAX_MOTD_CHUNK);
			chunk[MAX_MOTD_CHUNK] = '\0';
		}

		char_count += strlen(chunk);

		if (char_count < MAX_MOTD_LENGTH)
			pFileList = aFileList + char_count;
		else
			*pFileList = '\0';

		MESSAGE_BEGIN(MSG_ONE, gmsgMOTD, NULL, client);
		WRITE_BYTE(*pFileList ? FALSE : TRUE);
		WRITE_STRING(chunk);
		MESSAGE_END();
	}

	FREE_FILE(aFileList);
}

void CHalfLifeMultiplay::ClientUserInfoChanged(CBasePlayer *pPlayer, char *infobuffer)
{
	pPlayer->SetPlayerModel();
	pPlayer->SetPrefsFromUserinfo(infobuffer);
}

bool CHalfLifeMultiplay::CanHaveShield(CBasePlayer* pPlayer)
{
	return false;
}

bool CHalfLifeMultiplay::CanUseArmoury(CBasePlayer* pPlayer, CArmoury* pArmoury)
{
	return false;
}

bool CHalfLifeMultiplay::CanBuyThis(CBasePlayer* pPlayer, int weaponId)
{
	if ((pPlayer->HasShield() && weaponId == WEAPON_ELITE) || (pPlayer->HasShield() && weaponId == WEAPON_SHIELDGUN))
		return false;

	if (pPlayer->m_rgpPlayerItems[WPNSLOT_SECONDARY] != NULL && pPlayer->m_rgpPlayerItems[WPNSLOT_SECONDARY]->m_iId == WEAPON_ELITE && weaponId == WEAPON_SHIELDGUN)
		return false;

	if (pPlayer->m_rgpPlayerItems[WPNSLOT_PRIMARY] && pPlayer->m_rgpPlayerItems[WPNSLOT_PRIMARY]->m_iId == weaponId)
	{
		ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Cstrike_Already_Own_Weapon");
		return false;
	}

	if (pPlayer->m_rgpPlayerItems[WPNSLOT_SECONDARY] && pPlayer->m_rgpPlayerItems[WPNSLOT_SECONDARY]->m_iId == weaponId)
	{
		ClientPrint(pPlayer->pev, HUD_PRINTCENTER, "#Cstrike_Already_Own_Weapon");
		return false;
	}

	return true;
}

int CHalfLifeMultiplay::SelectDefaultTeam(void)
{
	int team = TEAM_UNASSIGNED;

	if (m_iNumZombies < m_iNumHumans)
		team = TEAM_ZOMBIE;
	else if (m_iNumZombies > m_iNumHumans)
		team = TEAM_HUMAN;
	else if (m_iNumHumansWins > m_iNumZombiesWins)
		team = TEAM_ZOMBIE;
	else if (m_iNumHumansWins < m_iNumZombiesWins)
		team = TEAM_HUMAN;
	else
		team = RANDOM_LONG(0, 1) ? TEAM_ZOMBIE : TEAM_HUMAN;

	if (TeamFull(team))
	{
		if (team == TEAM_ZOMBIE)
			team = TEAM_HUMAN;
		else
			team = TEAM_ZOMBIE;

		if (TeamFull(team))
			return TEAM_UNASSIGNED;
	}

	return team;
}

void CHalfLifeMultiplay::CheckStartMoney(void)
{
	if ((int)startmoney.value > 16000)
		CVAR_SET_FLOAT("mp_startmoney", 16000);
	else if ((int)startmoney.value < 800)
		CVAR_SET_FLOAT("mp_startmoney", 800);
}

void CHalfLifeMultiplay::ProcessKickVote(CBasePlayer* pVotingPlayer, CBasePlayer* pKickPlayer)
{
	CBaseEntity* pTempEntity;
	CBasePlayer* pTempPlayer;
	int iValidVotes;
	int iVoteID;
	int iVotesNeeded;
	BOOL fKickPercent;

	if (!pVotingPlayer || !pKickPlayer)
		return;

	int iTeamCount = pVotingPlayer->m_iTeam == TEAM_HUMAN ? m_iNumHumans : m_iNumZombies;

	if (iTeamCount < 3)
		return;

	iValidVotes = 0;
	pTempEntity = NULL;
	iVoteID = pVotingPlayer->m_iCurrentKickVote;

	while ((pTempEntity = UTIL_FindEntityByClassname(pTempEntity, "player")) != NULL)
	{
		if (FNullEnt(pTempEntity->edict()))
			break;

		pTempPlayer = GetClassPtr((CBasePlayer*)pTempEntity->pev);

		if (!pTempPlayer || pTempPlayer->m_iTeam == TEAM_UNASSIGNED)
			continue;

		if (pTempPlayer->m_iTeam == pVotingPlayer->m_iTeam && pTempPlayer->m_iCurrentKickVote == iVoteID)
			iValidVotes++;
	}

	if (kick_percent.value < 0)
		CVAR_SET_STRING("mp_kickpercent", "0.0");
	else if (kick_percent.value > 1)
		CVAR_SET_STRING("mp_kickpercent", "1.0");

	iVotesNeeded = (int)(iTeamCount * kick_percent.value + 0.5);
	fKickPercent = iValidVotes >= iVotesNeeded;

	if (fKickPercent)
	{
		UTIL_ClientPrintAll(HUD_PRINTCENTER, "#Game_kicked", STRING(pKickPlayer->pev->netname));
		SERVER_COMMAND(UTIL_VarArgs("kick # %d\n", pVotingPlayer->m_iCurrentKickVote));
		pTempEntity = NULL;

		while ((pTempEntity = UTIL_FindEntityByClassname(pTempEntity, "player")) != NULL)
		{
			if (FNullEnt(pTempEntity->edict()))
				break;

			pTempPlayer = GetClassPtr((CBasePlayer*)pTempEntity->pev);

			if (!pTempPlayer || pTempPlayer->m_iTeam == TEAM_UNASSIGNED)
				continue;

			if (pTempPlayer->m_iTeam == pVotingPlayer->m_iTeam && pTempPlayer->m_iCurrentKickVote == iVoteID)
				pTempPlayer->m_iCurrentKickVote = 0;
		}
	}
}
