/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#ifndef GAME_H
#define GAME_H

extern void GameDLLInit(void);

extern cvar_t *g_psv_gravity, *g_psv_aim;
extern cvar_t *g_footsteps;
extern cvar_t *g_psv_accelerate, *g_psv_friction, *g_psv_stopspeed;

extern cvar_t displaysoundlist;

extern cvar_t timelimit;
extern cvar_t friendlyfire;
extern cvar_t flashlight;

extern cvar_t decalfrequency;

extern cvar_t allowmonsters;
extern cvar_t roundtime;
extern cvar_t buytime;
extern cvar_t freezetime;
extern cvar_t c4timer;

extern cvar_t ghostfrequency;
extern cvar_t autokick;

extern cvar_t restartround;
extern cvar_t sv_restart;

extern cvar_t limitteams;
extern cvar_t autoteambalance;
extern cvar_t tkpunish;
extern cvar_t hostagepenalty;
extern cvar_t mirrordamage;
extern cvar_t logmessages;

#define FORCECAMERA_SPECTATE_ANYONE 0
#define FORCECAMERA_SPECTATE_ONLY_TEAM 1
#define FORCECAMERA_ONLY_FRIST_PERSON 2

extern cvar_t forcecamera;
extern cvar_t forcechasecam;
extern cvar_t mapvoteratio;

#define LOG_ENEMYATTACK 0x1
#define LOG_TEAMMATEATTACK 0x2

extern cvar_t logdetail;
extern cvar_t startmoney;
extern cvar_t maxrounds;
extern cvar_t fadetoblack;

#define PLAYERID_EVERYONE 0
#define PLAYERID_TEAMONLY 1
#define PLAYERID_OFF 2

extern cvar_t playerid;
extern cvar_t winlimit;
extern cvar_t allow_spectators;
extern cvar_t mp_chattime;
extern cvar_t kick_percent;

extern cvar_t fragsleft;
extern cvar_t timeleft;

extern cvar_t humans_join_team;

extern cvar_t cvar_zombiespawn;
extern cvar_t cvar_reciprocal;
extern cvar_t cvar_ghostspeed;
extern cvar_t cvar_ghostgravity;
extern cvar_t cvar_ghostnvg[5];
extern cvar_t cvar_zombienvg[5];
extern cvar_t cvar_humannvg[5];
extern cvar_t cvar_spawndistance;
extern cvar_t cvar_winmoney;
extern cvar_t cvar_zombiegetmoney;
extern cvar_t cvar_humangetmoney;
extern cvar_t cvar_killedbossmoney;
extern cvar_t cvar_knifeaddition;
extern cvar_t cvar_headaddition;
extern cvar_t cvar_zombiehitmoney;
extern cvar_t cvar_holdTime;
extern cvar_t cvar_bosspbty;
extern cvar_t cvar_sparksize;
extern cvar_t cvar_enddeploy;
extern cvar_t cvar_humanrespawn;
extern cvar_t cvar_knockthreshold;
extern cvar_t cvar_gloweffect;
extern cvar_t cvar_modelindex;
extern cvar_t cvar_realfalldamage;
extern cvar_t cvar_finish[3];
extern cvar_t cvar_botbuy;
extern cvar_t cvar_botbuytime;
extern cvar_t cvar_hedamage;
extern cvar_t cvar_hudmessage;
extern cvar_t cvar_healthhud;
extern cvar_t cvar_armorhud;
extern cvar_t cvar_linehud;

#endif