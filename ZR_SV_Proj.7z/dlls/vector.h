/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification ofthissource code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#ifndef VECTOR_H
#define VECTOR_H

namespace Math
{
	const float MATH_ONEPSILON = 0.01f;
	const float MATH_EQEPSILON = 0.001f;
	const float MATH_FLEPSILON = 1.192092896e-07f;
	const double MATH_DBEPSILON = 2.2204460492503131e-016;

	const double MATH_PI = 3.141592653589793238462643383;

	const double MATH_D2R = MATH_PI / 180.0;
	const double MATH_R2D = 180.0 / MATH_PI;

	inline bool FltZero(float entry)
	{
		return fabsf(entry) <= MATH_FLEPSILON;
	}

	inline bool FltEqual(float entry1, float entry2)
	{
		return fabsf(entry1 - entry2) <= MATH_FLEPSILON;
	}

	inline bool DblZero(double entry)
	{
		return fabs(entry) <= MATH_DBEPSILON;
	}

	inline bool DblEqual(double entry1, double entry2)
	{
		return fabs(entry1 - entry2) <= MATH_DBEPSILON;
	}

	inline float RadianToDegree(float radian)
	{
		return radian * MATH_R2D;
	}

	inline float DegreeToRadian(float degree)
	{
		return degree * MATH_D2R;
	}

	inline float AngleMod(float angle)
	{
		return 360.0f / 65536.0f * (static_cast <int> (angle * (65536.0f / 360.0f)) & 65535);
	}

	inline float AngleNormalize(float angle)
	{
		return 360.0f / 65536.0f * (static_cast <int> ((angle + 180.0f) * (65536.0f / 360.0f)) & 65535) - 180.0f;
	}

	void inline SineCosine(float radians, float& sine, float& cosine)
	{
#if defined (PLATFORM_WIN32)
		__asm
		{
			fld uint32_t ptr[radians]
			fsincos

			mov edx, uint32_t ptr[cosine]
			mov eax, uint32_t ptr[sine]

			fstp uint32_t ptr[edx]
			fstp uint32_t ptr[eax]
		}
#else
		sine = sinf(radians);
		cosine = cosf(radians);
#endif
	}
}


//=========================================================
// 2DVector - used for many pathfinding and many other 
// operations that are treated as planar rather than 3d.
//=========================================================
class Vector2D
{
public:
	inline Vector2D(void) { x = 0.0f; y = 0.0f; }
	inline Vector2D(float X, float Y) { x = X; y = Y; }
	inline Vector2D(const float* rgfl) { x = rgfl[0]; y = rgfl[1]; }
	inline Vector2D operator-(void) 			const { return Vector2D(-x, -y); }
	inline bool operator==(const Vector2D & v)	const { return (Math::FltEqual(x, v.x) && Math::FltEqual(y, v.y)); }
	inline bool operator!=(const Vector2D & v)	const { return !(*this == v); }
	inline bool operator<(const Vector2D & v)	const { return !!(Length() < v.Length()); }
	inline bool operator<=(const Vector2D & v)	const { return !!(Length() <= v.Length()); }
	inline bool operator>(const Vector2D & v)	const { return !!(Length() > v.Length()); }
	inline bool operator>=(const Vector2D & v)	const { return !!(Length() >= v.Length()); }
	inline Vector2D operator+(const Vector2D & v)	const { return Vector2D(x + v.x, y + v.y); }
	inline Vector2D operator-(const Vector2D & v)	const { return Vector2D(x - v.x, y - v.y); }
	inline Vector2D operator*(float fl)				const { return Vector2D(x * fl, y * fl); }
	inline Vector2D operator/(float fl)				const { return Vector2D(x / fl, y / fl); }
	inline Vector2D operator+=(const Vector2D & v) { x += v.x; y += v.y; }
	inline Vector2D operator-=(const Vector2D & v) { x -= v.x; y -= v.y; }
	inline Vector2D operator*=(float fl) { x *= fl; y *= fl; }
	inline Vector2D operator/=(float fl) { x /= fl; y /= fl; }

	operator float* () { return &x; } // Vectors will now automatically convert to float * when needed
	operator const float* () const { return &x; } // Vectors will now automatically convert to float * when needed

	inline float Length(void)						const { return sqrtf(x * x + y * y); }

	inline Vector2D Normalize (void) const
	{
		Vector2D vec2;

		float flLen = Length();
		if (Math::FltZero(flLen))
		{
			return Vector2D(0, 0);
		}
		else
		{
			flLen = 1.0f / flLen;
			return Vector2D(x * flLen, y * flLen);
		}
	}

	vec_t	x, y;
};
inline float 	DotProduct	(const Vector2D & a, const Vector2D & b) { return(a.x * b.x + a.y * b.y); }
inline Vector2D	operator*	(float fl, const Vector2D & v) { return v * fl; }

//=========================================================
// 3D Vector
//=========================================================
class Vector						// same data-layout as engine's vec3_t,
{								//		which is a vec_t[3]
public:
	// Construction/destruction
	inline Vector(void) { x = 0.0f; y = 0.0f; z = 0.0f; }
	inline Vector(float X) { x = X; y = X; z = X; }
	inline Vector(float X, float Y) { x = X; y = Y; z = 0; }
	inline Vector(float X, float Y, float Z) { x = X; y = Y; z = Z; }
	inline Vector(const Vector& v) { x = v.x; y = v.y; z = v.z; }
	inline Vector(const float rgfl[3]) { x = rgfl[0]; y = rgfl[1]; z = rgfl[2]; }
	inline Vector(const double rgfl[3]) { x = rgfl[0]; y = rgfl[1]; z = rgfl[2]; }
	inline Vector(const Vector2D& v, float Z) { x = v.x; y = v.y; z = Z; }
	inline Vector(const Vector2D& v) { x = v.x; y = v.y; z = 0.0f; }

	// Operators
	inline Vector	operator-	(void) 				const { return Vector(-x, -y, -z); }
	inline bool		operator==	(const Vector & v)	const { return (Math::FltEqual(x, v.x) && Math::FltEqual(y, v.y) && Math::FltEqual(z, v.z)); }
	inline bool		operator!=	(const Vector & v)	const { return !(*this == v); }
	inline bool		operator<	(const Vector & v)	const { return !!(Length() < v.Length()); }
	inline bool		operator<=	(const Vector & v)	const { return !!(Length() <= v.Length()); }
	inline bool		operator>	(const Vector & v)	const { return !!(Length() > v.Length()); }
	inline bool		operator>=	(const Vector & v)	const { return !!(Length() >= v.Length()); }
	inline Vector	operator+	(const Vector & v)	const { return Vector(x + v.x, y + v.y, z + v.z); }
	inline Vector	operator-	(const Vector & v)	const { return Vector(x - v.x, y - v.y, z - v.z); }
	inline Vector	operator*	(float fl)			const { return Vector(x * fl, y * fl, z * fl); }
	inline Vector	operator/	(float fl)			const { return Vector(x / fl, y / fl, z / fl); }
	inline Vector	operator+=	(const Vector & v) { x += v.x; y += v.y; z += v.z;	return *this; }
	inline Vector	operator-=	(const Vector & v) { x -= v.x; y -= v.y; z -= v.z;	return *this; }
	inline Vector	operator*=	(float fl) { x *= fl; y *= fl; z *= fl;	return *this; }
	inline Vector	operator/=	(float fl) { x /= fl; y /= fl; z /= fl;	return *this; }

	inline Vector	operator+	(float fl)			const { return Normalize()* (Length() + fl); }
	inline Vector	operator-	(float fl)			const { return Normalize()* (Length() - fl); }
	inline Vector	operator+=	(float fl) { *this = SetLength(Length() + fl); return *this; }
	inline Vector	operator-=	(float fl) { *this = SetLength(Length() - fl); return *this; }

	/*inline float &operator[](unsigned int i)
	{
		if (i == 0)
			return this->x;
		else if (i == 1)
			return this->y;
		else
			return this->z;
	}*/

	// Methods
	inline void		CopyToArray(float* rgfl)	const { rgfl[0] = x, rgfl[1] = y, rgfl[2] = z; }
	inline float	Length(void)				const { return sqrtf(x * x + y * y + z * z); }
	inline float	LengthSquared(void)			const { return x * x + y * y + z * z; }

	operator float* () { return &x; } // Vectors will now automatically convert to float * when needed
	operator const float* () const { return &x; } // Vectors will now automatically convert to float * when needed

	inline Vector Normalize(void) const
	{
		float flLen = Length();

		if (Math::FltZero(flLen))
			return Vector();

		flLen = 1.0f / flLen;
		return Vector(x * flLen, y * flLen, z * flLen);
	}

	inline Vector2D	Make2D		(void)			const { return Vector2D(x, y); }
	inline float	Length2D	(void)			const { return sqrtf(x * x + y * y); }
	inline Vector	SetLength	(float len)		const { return Normalize()* len; }

	inline Vector	RotateByX	(double rad)	const { return Vector(x, y * cos(rad) - z * sin(rad), y * sin(rad) + z * cos(rad)); }
	inline Vector	RotateByY	(double rad)	const { return Vector(x * cos(rad) + z * sin(rad), y, -x * sin(rad) + z * cos(rad)); }
	inline Vector	RotateByZ	(double rad)	const { return Vector(x * cos(rad) - y * sin(rad), x * sin(rad) + y * cos(rad), z); }

	inline Vector	Rotate		(const Vector & OS, double rad)	const
	{
		double Sine = sin(rad);
		double Cosine = cos(rad);

		Vector Matrix[3];
		Matrix[0] = Vector(OS.x * OS.x + (1.0f - OS.x * OS.x) * Cosine, OS.x * OS.y * (1.0f - Cosine) - OS.z * Sine, OS.x * OS.z * (1.0f - Cosine) + OS.y * Sine);
		Matrix[1] = Vector(OS.y * OS.x * (1.0f - Cosine) + OS.z * Sine, OS.y * OS.y + (1.0f - OS.y * OS.y) * Cosine, OS.y * OS.z * (1.0f - Cosine) - OS.x * Sine);
		Matrix[2] = Vector(OS.z * OS.x * (1.0f - Cosine) - OS.y * Sine, OS.z * OS.y * (1.0f - Cosine) + OS.x * Sine, OS.z * OS.z + (1.0f - OS.z * OS.z) * Cosine);

		Vector vecResult;
		vecResult.x = x * Matrix[0].x + y * Matrix[0].y + z * Matrix[0].z;
		vecResult.y = x * Matrix[1].x + y * Matrix[1].y + z * Matrix[1].z;
		vecResult.z = x * Matrix[2].x + y * Matrix[2].y + z * Matrix[2].z;

		return vecResult;
	}

	inline void AngleVectors (Vector & forward, Vector & right, Vector & up) const
	{
		float		angle;
		float		sr, sp, sy, cr, cp, cy;

		angle = y * (Math::MATH_PI * 2 / 360);	// YAW
		sy = sin(angle);
		cy = cos(angle);
		angle = x * (Math::MATH_PI * 2 / 360);	// PITCH
		sp = sin(angle);
		cp = cos(angle);
		angle = z * (Math::MATH_PI * 2 / 360);	// ROLL
		sr = sin(angle);
		cr = cos(angle);

		if (forward)
		{
			forward[0] = cp * cy;
			forward[1] = cp * sy;
			forward[2] = -sp;
		}
		if (right)
		{
			right[0] = (-1 * sr * sp * cy + -1 * cr * -sy);
			right[1] = (-1 * sr * sp * sy + -1 * cr * cy);
			right[2] = -1 * sr * cp;
		}
		if (up)
		{
			up[0] = (cr * sp * cy + -sr * -sy);
			up[1] = (cr * sp * sy + -sr * cy);
			up[2] = cr * cp;
		}
	}

	inline Vector VectorAngles(void) const
	{
		// is the input vector absolutely vertical?
		if (Math::FltZero(x) && Math::FltZero(y))
			return Vector(z > 0.0f ? 90.0f : 270.0f, 0.0, 0.0f);

		// else it's another sort of vector compute individually the pitch and yaw corresponding to this vector.
		return Vector(Math::RadianToDegree(atan2f(z, Length2D())), Math::RadianToDegree(atan2f(y, x)), 0.0f);
	}

	inline Vector ClampAngles(void)
	{
		x = Math::AngleNormalize(x);
		y = Math::AngleNormalize(y);

		return *this;
	}

	// Members
	vec_t x, y, z;
};
inline Vector	operator*	(float fl, const Vector & v) { return v * fl; }
inline float	DotProduct	(const Vector & a, const Vector & b) { return (a.x * b.x + a.y * b.y + a.z * b.z); }
inline Vector	CrossProduct(const Vector & a, const Vector & b) { return Vector(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
inline float	operator^	(const Vector & v1, const Vector & v2) { return acosf(DotProduct(v1, v2) / (v1.Length() * v2.Length())); }

//=========================================================
// Plane
//=========================================================
class Plane
{
public:
	// Construction/destruction
	inline Plane(void) { norm = Vector(); d = 0.0f; }
	inline Plane(const Plane& pl) { norm = pl.norm; d = pl.d; }
	inline Plane(float X, float Y, float Z, float D) { norm = Vector(X, Y, Z); d = D; }
	inline Plane(const Vector& v, float D) { norm = v; d = D; }
	inline Plane(float rgfl[4]) { norm = Vector(rgfl[0], rgfl[1], rgfl[2]); d = rgfl[3]; }
	inline Plane(const Vector& point1, const Vector& point2, const Vector& point3)
	{
		norm = CrossProduct(point1 - point2, point3 - point2);
		d = -DotProduct(point1, norm);
	}

	// Operators
	inline bool operator==(const Plane & pl) const { return !!(norm == pl.norm && Math::FltEqual(d, pl.d)); }
	inline bool operator!=(const Plane & pl) const { return !(*this == pl); }

	// Methods
	inline void		CopyToArray	(float* rgfl)		const { rgfl[0] = norm.x, rgfl[1] = norm.y, rgfl[2] = norm.z, rgfl[3] = d; }
	inline float	GetSignedD	(const Vector & v)	const { return (DotProduct(norm, v) + d) / norm.Length(); }
	inline float	GetDistance	(const Vector & v)	const { return fabs(GetSignedD(v)); }
	inline Vector	Projection	(const Vector & v)	const { return (v + (-(DotProduct(v, norm) + d) / DotProduct(norm, norm)) * norm); }
	inline Vector	Symmetry	(const Vector & v)	const { return (2 * Projection(v) - v); }
	inline Vector	Refraction	(const Vector & v)	const { return (v - 2 * DotProduct(v, norm) / DotProduct(norm, norm) * norm); }
	inline float	operator^	(const Vector & v)	const { return asinf(fabs(DotProduct(v, norm)) / (v.Length() * norm.Length())); }
	inline float	operator^	(const Plane & pl)	const { return norm ^ pl.norm; }

	operator float* () { return &norm.x; } // Planes will now automatically convert to float * when needed
	operator const float* () const { return &norm.x; } // Planes will now automatically convert to float * when needed


	// Members
	Vector	norm;
	vec_t	d;
};

inline double	operator^	(const Vector & v, const Plane & pl) { return pl ^ v; }



#endif
