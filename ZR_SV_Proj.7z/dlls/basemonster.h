/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#ifndef BASEMONSTER_H
#define BASEMONSTER_H

// monster to monster relationship types
#define R_AL	-2 // (ALLY) pals. Good alternative to R_NO when applicable.
#define R_FR	-1// (FEAR)will run
#define	R_NO	0// (NO RELATIONSHIP) disregard
#define R_DL	1// (DISLIKE) will attack
#define R_HT	2// (HATE)will attack this character instead of any visible DISLIKEd characters
#define R_NM	3// (NEMESIS)  A monster Will ALWAYS attack its nemsis, no matter what


// these bits represent the monster's memory
#define MEMORY_CLEAR					0
#define bits_MEMORY_PROVOKED			( 1 << 0 )// right now only used for houndeyes.
#define bits_MEMORY_INCOVER				( 1 << 1 )// monster knows it is in a covered position.
#define bits_MEMORY_SUSPICIOUS			( 1 << 2 )// Ally is suspicious of the player, and will move to provoked more easily
#define bits_MEMORY_PATH_FINISHED		( 1 << 3 )// Finished monster path (just used by big momma for now)
#define bits_MEMORY_ON_PATH				( 1 << 4 )// Moving on a path
#define bits_MEMORY_MOVE_FAILED			( 1 << 5 )// Movement has already failed
#define bits_MEMORY_FLINCHED			( 1 << 6 )// Has already flinched
#define bits_MEMORY_KILLED				( 1 << 7 )// HACKHACK -- remember that I've already called my Killed()
#define bits_MEMORY_CUSTOM4				( 1 << 28 )	// Monster-specific memory
#define bits_MEMORY_CUSTOM3				( 1 << 29 )	// Monster-specific memory
#define bits_MEMORY_CUSTOM2				( 1 << 30 )	// Monster-specific memory
#define bits_MEMORY_CUSTOM1				( 1 << 31 )	// Monster-specific memory

class CBaseMonster : public CBaseToggle
{
public:
	virtual void KeyValue(KeyValueData *pkvd);
	virtual float ChangeYaw(int speed);
	virtual BOOL HasHumanGibs(void);
	virtual BOOL HasAlienGibs(void);
	virtual void FadeMonster(void);
	virtual void GibMonster(void);
	virtual Activity GetDeathActivity(void);
	virtual void BecomeDead(void);
	virtual BOOL ShouldFadeOnDeath(void);
	virtual int IRelationship(CBaseEntity *pTarget);
	virtual int TakeHealth(float flHealth, int bitsDamageType);
	virtual int TakeDamage(entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType);
	virtual void Killed(entvars_t *pevAttacker, int iGib);
	virtual void PainSound(void) { return; }
	virtual void ResetMaxSpeed(void) {};
	virtual void ReportAIState(void);
	virtual void MonsterInitDead(void);
	virtual void Look(int iDistance);
	virtual CBaseEntity *BestVisibleEnemy(void);
	virtual bool FInViewCone(CBaseEntity *pEntity);
	virtual bool FInViewCone(const Vector& vecOrigin);
	virtual int BloodColor(void) { return m_bloodColor; }
	virtual BOOL IsAlive(void) { return (pev->deadflag != DEAD_DEAD); }

	// monster use function
	virtual	void EXPORT	MonsterUse(CBaseEntity* pActivator, CBaseEntity* pCaller, USE_TYPE useType, float value);
	virtual	void EXPORT	CorpseUse(CBaseEntity* pActivator, CBaseEntity* pCaller, USE_TYPE useType, float value);

public:
	void MakeIdealYaw(Vector vecTarget);
	Activity GetSmallFlinchActivity(void);
	BOOL ShouldGibMonster(int iGib);
	void CallGibMonster(void);
	BOOL FCheckAITrigger(void);
	int DeadTakeDamage(entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType);
	float DamageForce(float damage);
	void RadiusDamage(entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int iClassIgnore, int bitsDamageType);
	void RadiusDamage(Vector vecSrc, entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int iClassIgnore, int bitsDamageType);
	void EXPORT CorpseFallThink(void);
	CBaseEntity *CheckTraceHullAttack(float flDist, int iDamage, int iDmgType);
	void TraceAttack(entvars_t *pevAttacker, float flDamage, Vector vecDir, TraceResult *ptr, int bitsDamageType);
	void MakeDamageBloodDecal(int cCount, float flNoise, TraceResult *ptr, const Vector &vecDir);
	void BloodSplat(const Vector &vecPos, const Vector &vecDir, int hitgroup, int iDamage);
	void SetEyePosition(void);
	virtual	void EXPORT MonsterInit(void);
	virtual	void EXPORT MonsterInitThink(void);
	virtual	void StartMonster(void);
	void EXPORT	CallMonsterThink(void) { this->MonsterThink(); }
	virtual void MonsterThink(void);
	virtual MONSTERSTATE GetIdealState(void);
	virtual void SetActivity (Activity NewActivity);
	virtual void SetSequenceByName (char* szSequence);
	virtual void SetState (MONSTERSTATE State);

public:
	inline void SetConditions(int iConditions) { m_afConditions |= iConditions; }
	inline void ClearConditions(int iConditions) { m_afConditions &= ~iConditions; }
	inline BOOL HasConditions(int iConditions) { if (m_afConditions & iConditions) return TRUE; return FALSE; }
	inline BOOL HasAllConditions(int iConditions) { if ((m_afConditions & iConditions) == iConditions) return TRUE; return FALSE; }
	inline void Remember(int iMemory) { m_afMemory |= iMemory; }
	inline void Forget(int iMemory) { m_afMemory &= ~iMemory; }
	inline BOOL HasMemory(int iMemory) { if (m_afMemory & iMemory) return TRUE; return FALSE; }
	inline BOOL HasAllMemories(int iMemory) { if ((m_afMemory & iMemory) == iMemory) return TRUE; return FALSE; }
	inline void StopAnimation(void) { pev->framerate = 0; }

public:
	Activity m_Activity;
	Activity m_IdealActivity;
	int m_LastHitGroup;
	int m_bitsDamageType;
	BYTE m_rgbTimeBasedDamage[CDMG_TIMEBASED];
	MONSTERSTATE m_MonsterState;
	MONSTERSTATE m_IdealMonsterState;
	int m_afConditions;
	int m_afMemory;
	float m_flNextAttack;
	EHANDLE m_hEnemy;
	EHANDLE m_hTargetEnt;
	float m_flFieldOfView;
	int m_bloodColor;
	Vector m_HackedGunPos;
	Vector m_vecEnemyLKP;

	float	m_flDistTooFar;	// if enemy farther away than this, bits_COND_ENEMY_TOOFAR set in CheckEnemy
	float	m_flDistLook;	// distance monster sees (Default 2048)
	int		m_afCapability;	// tells us what a monster can/can't do.
};
#endif