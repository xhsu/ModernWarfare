#pragma once
#ifndef _SYPB_INTERFACE_H_
#define _SYPB_INTERFACE_H_

enum SYPB_START_ACTIONS
{
	SYPB_CMENU_IDLE = 1,
	SYPB_CMENU_TEAM = 2,
	SYPB_CMENU_CLASS = 3,
	SYPB_CMENU_BUY = 100,
	SYPB_CMENU_RADIO = 200,
	SYPB_CMENU_SAY = 10000,
	SYPB_CMENU_TEAMSAY = 10001
};

typedef struct sypb_interface_funcs_s
{
	// core functions. dont randomlly call them.

	void	(*HookEngfuncs)		(enginefuncs_t *functionTable, globalvars_t *pGlobals);
	int		(*HookEntityAPI2)	(DLL_FUNCTIONS *functionTable, int * /*interfaceVersion*/);
	int		(*DllMain)			(void *arg1, unsigned long dwReason, void *arg3);

	// normal functions.

	void	(*SetBotStartAction)	(edict_t* ed, SYPB_START_ACTIONS action);
}
sypb_interface_funcs_t;

extern sypb_interface_funcs_t gISypbFuncs;
















































#endif