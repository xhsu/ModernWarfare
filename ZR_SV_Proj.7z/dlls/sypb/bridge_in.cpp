// Interface in.

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"

void CallGamePlayerEntity(entvars_t *vars)
{
	GetClassPtr((CBasePlayer *)vars);
}

//#include "core.h"
// we can't include that, which could cause a bunch of trouble.
extern bool IsValidBot (edict_t *ent);

BOOL CBasePlayer::IsBot(void)
{
#ifdef USING_SYPB
	return ((pev->flags & FL_FAKECLIENT) || IsValidBot(edict()));
#else
	return (pev->flags & FL_FAKECLIENT);
#endif
}

int GetTeamIDFromMP(edict_t* ent)
{
	CBaseEntity* p = CBaseEntity::Instance(ent);

	if (p->IsPlayer())
	{
		CBasePlayer* pPlayer = (CBasePlayer*)GET_PRIVATE(ent);

		return pPlayer->m_iTeam;
	}

	return TEAM_UNASSIGNED;
}