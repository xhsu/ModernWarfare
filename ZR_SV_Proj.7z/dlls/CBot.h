#pragma once
#ifndef _CBOT_H_
#define _CBOT_H_

//#define _DEBUG_BOT	1

class CBaseEntity;
class CBasePlayer;
class CWPBase;
class CWPNode;
class CAStarCalculator;

class CBot : public CBasePlayer
{
public:
	// bot management
	static std::list<CBot*>	s_lstpBots;
	static float	s_flTimeNextAddBot;
	static int		s_iBotsToAdd;
	static bool		s_bBotsStop;

	// RunPlayerMove()
	int m_msecBuiltin; // random msec method for this bot
	float m_msecVal;
	float m_msecInterval; // used for leon hartwig's method for msec calculation

	// think frame
	float m_flFrameInterval;
	float m_flLastThinkTime;

	// bot movement.
	float				m_flForwardSpeed;	// forward & backward
	float				m_flStrafeSpeed;	// left & right
	Vector				m_vecRPMVAngle;		// angle used in RunPlayerMove(). this angle should only related to movement, ignore any model, shooting problems. this angle don'have to equal to pev->v_angle.
	Vector				m_vecPreOrg;
	CAStarCalculator	m_cAStarCalculator;	// each bot should hold one.
	std::list<CWPNode*>	m_lpnWayPoints;	// a pathway to player.
	Vector				m_vecGoal;	// the place where bot wants to go. DO NOT ASSIGN this value, it's a result, changing it will not changing anything.
	float				m_flTimeNextNodeAccessibilityCheck;	// check whether the first node is really accessible.
	CBasePlayer*		m_pChasingPlayer;
	CWPNode*			m_pChasingNode;
	Vector				m_vecTargetLastSeenOrigin;

	// scheme system.
	enum MOVEMENT_SCHEME
	{
		MOVEMENT_STAY = 0,	// stay in current location. a.k.a. DON'T FUCKING MOVE.
		MOVEMENT_CHASINGPLAYER,	// follow someone/something
		MOVEMENT_DEFENSEREGION,	// move to specific location.

	}	m_iMovementScheme;
	enum FORMATION_SCHEME
	{
		FORMATION_SKIRMISHERS = 0,	// split in current region.
		FORMATION_LINEINFANTRY,		// line up, facing enemy direction.
		FORMATION_VOLLEYFIRE,		// by Tang military official Li Quan 

	}	m_iFormationScheme;
	enum COMBAT_SCHEME
	{
		COMBAT_MELEE = 0,
		COMBAT_SHOTGUN,
		COMBAT_AUTOMATIC_FIREARM,
		COMBAT_SNIPER,

	}		m_iCombatScheme;

	// jump system.
	float	m_flNextJumpAttempt;	// bot will attempt to perform another jump if still blocked.
	float	m_flTimeJumpDuck;		// jump-duck performance.
	float	m_flTimeDuckRelease;	// how long until jump-duck done?

	// deal with stupid ladders
	int		m_iLastMovetype;
	bool	m_bOnLadder;
	Vector	m_vecSavedVAngle;
	float	m_flTimeEnforceJump;	// avoid being stuck by stupid ladders.

	// bot enemy system
	static	std::vector<CBasePlayer*>	s_vZombies;
	static	std::vector<CBasePlayer*>	s_vHumans;
	CBaseEntity*	m_pEnemy;

	// wolf pack system
	/*
	the first two non-static vars are inherited from CBasePlayer.
	you must be either a Lieutenant or Minion, unless you are a real-human player.
	bool			m_bLieutenant;	// am I a Lieutenant?
	CBasePlayer*	m_pLieutenant;	// the lieutenant of this player.
	*/
	static	int	s_iZombieBotCount;
	static	int	s_iHumanBotCount;
	static	std::list<CBasePlayer*>	s_lpZombieLieutenants;
	static	std::list<CBasePlayer*>	s_lpHumanLieutenants;
	static	float	s_flTimeMinionAssignThink;

	// ghost spawn-searching system.
	std::list<CWPNode*>		m_lstGhostRespawnNodeCandidates;
	std::list<CWPRegion*>	m_lstGhostRespawnRegionCandidates;
	std::list<CWPRegion*>	m_lstGhostRespawnRegionClosed;	// trashcan.
	float	m_flTimeNextGhostThink;
	float	m_flTimeResetGhostSpawn;

	// bot aiming system
	Vector	m_vecSeeingOrg;	// the place where bot aiming at.
	Vector	m_vecIdealViewAngle;	// the angle directly aiming to m_vecSeeingOrg.
	Vector	m_vecTargetingAngularSpeed;	// aiming speed component of certain enemy.
	Vector	m_vecViewAngularSpeed;	// overall view angular speed.
	Vector	m_vecInterferedViewAngle;	// "ideal" view angle with some noise.
	float	m_flLastTargeting;	// last time when attempt to aiming at someone.
	Vector	m_vecAngularDeviation;	// look at my name, plz.
	float	m_flTimeInterfereAiming;	// some random aiming mistake. more often when running.
	float	m_flTimeShootAttempt;	// time interval of traceline determination.

#ifdef _DEBUG_BOT
	// debug vars
	float	m_flNextDrawPath;
#endif

public:	// manager funcs
	static	CBot*	Create			(void);	// bot creation
	static	bool	Command			(CBasePlayer* pCommander);	// this is using for process bot control commands.
	static	void	ServerActivate	(void);	// reset bot manager.
	static	void	ServerDeactivate(void);	// reset bot manager.
	static	void	StartFrame		(void);	// execute RunPlayerMove();
	static	void	RoundRestart	(void);	// rearrange wolfpack.

public:	// individual funcs
	virtual void	PreThink		(void);
	virtual void	PostThink		(void);
	virtual void	JoinSelection	(void);
	virtual void	RunPlayerMove	(void);	// called each frame to officially trigger PM_Move()
	virtual	BOOL	IsBot			(void) { return TRUE; }

public:	// wolf pack funcs
	// first few function stayed in CBasePlayer...
	static	void	WolfPackThink	(void);	// update Lieutenant status, reassign Minions, etc...
	virtual	bool	JoinWolfpack	(void);
	virtual	bool	JoinWolfpack	(CBasePlayer* pLieutenant);

public:	// movement funcs
	virtual	void	ChooseEnemy			(void);
	virtual	void	ChooseChasingTarget	(void);
	virtual	void	ChooseGoalOrg		(void);
	virtual	void	ActForwardingButton	(void);
	virtual	void	ActJumpAndDuck		(void);
	virtual	void	ChooseViewAngle		(void);
	virtual	void	ActViewAngle		(void);

public:	// ghost function
	virtual void	GhostThink			(void);

public:	// combat function
	virtual	void	ActAttack			(void);
};





































#endif