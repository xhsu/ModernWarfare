/***

Modern Warfare Develop Team
CWayPoint.h

Coder:	Luna the Reborn
Advisor:Crsky

Create Date: 2019/04/28

***/

#pragma once
#ifndef _CWAYPOINT_H_
#define _CWAYPOINT_H_

#define _DEBUG_WAYPOINT	1

#define WP_STEP_HEIGHT			18.0f	// if delta Z is greater than this, we have to jump to get up
#define WP_JUMP_HEIGHT			41.8f	// if delta Z is less than this, we can jump up on it
#define WP_JUMP_CROUCH_HEIGHT	48.0f	// (48) if delta Z is less than or equal to this, we can jumpcrouch up on it
#define WP_DEATH_DROP			200.0f	// (300) distance at which we will die if we fall - should be about 600, and pay attention to fall damage during pathfind

// some typedef...
typedef std::list<CWPNode*>		lstn_t;
typedef std::list<CWPRegion*>	lstr_t;

typedef enum
{
	WP_NODE_ERROR = 0,
	WP_NODE_PRIMARY = 1,
	WP_NODE_SECONDARY,
	WP_NODE_TETIARY,
	WP_NODE_QUATERNARY
}
wp_node_lvl;

typedef enum
{
	WP_N_FL_NORM = (1 << 0),
	WP_N_FL_CAMP = (1 << 1),
	WP_N_FL_CROUCH = (1 << 2),
	WP_N_FL_SECTION = (1 << 3),
	WP_N_FL_START = (1 << 4),
	WP_N_FL_END = (1 << 5),
	WP_N_FL_LADDER = (1 << 6),
	WP_N_FL_SNIPER = (1 << 7),
	WP_N_FL_ZOMBIE = (1 << 8),
	WP_N_FL_HUMAN = (1 << 9),
	WP_N_FL_JUMP = (1 << 10),
}
wp_node_flag;

class CWPBase
{
public:
	void* operator new(size_t size) { return calloc(1, size); }
	void operator delete(void* ptr) { free(ptr); }
	CWPBase(void) {}
	~CWPBase(void) {}

public:
	unsigned	m_uIndex;
	Vector		m_vecOrigin;
	wp_node_lvl	m_iStructuralLevel;
	CWPBase*	m_rgpnNextKins[8];
	float		m_rgflNextKinsDist[8];
	unsigned	m_uKinCounts;
	int			m_bitsNodeFlags;

public:
	virtual	unsigned	FindFarthestKin	(void);	// remember, this could be unsafe when it returns 0, since it could be no kin existed, thus m_rgpnNextKins[0] == nullptr
	virtual	CWPBase*	FindNearestKin	(void);	// remember, this could be unsafe when it returns nullptr
	virtual	void		Clear			(void);
};

class CWPNode : public CWPBase
{
public:
	CWPNode(void) { m_iStructuralLevel = WP_NODE_PRIMARY; }

public:
	CWPRegion*		m_prParent;
	CBaseEntity*	m_pOccupyingEnt;	// a flag to determind whether this node is occupied by any players or npcs.

public:
	virtual	void		Clear			(void);
	virtual	CWPNode*	FindAvailable	(void);	// this is used to search a point unoccupied by any entities.
};

class CWPRegion : public CWPBase
{
public:
	CWPRegion(void)	{ m_iStructuralLevel = WP_NODE_SECONDARY; }

public:
	std::list<CBaseEntity*>	m_lpNPCs;	// UNDONE, should replace by real NPC class.
	std::list<CBasePlayer*>	m_lpHumans;
	std::list<CBasePlayer*>	m_lpZombies;
	std::list<CWPNode*>		m_lstnChildren;
	float	a, b, c;	// corresponding to a half of length, width, height of cuboid region. the center will be m_vecOrigin;
	char	m_szName[32];
	CWPNode*	m_pnCenter;

public:
	virtual	void	Clear				(void);
	virtual	void	UpdateEntityList	(void);
	virtual	bool	InCuboid			(const Vector& vecOrigin);
};

typedef struct wp_file_header_s
{
	int			m_iVersion;
	unsigned	m_uNodeCounts;
	unsigned	m_uRegionCounts;
}
wp_file_header_t;

typedef struct wp_file_node_s
{
	unsigned	m_uIndex;
	Vector		m_vecOrigin;
	unsigned	m_uIdParent;	// we shouldn't save as pointer.
	unsigned	m_rguIdNextKins[8];	// we shouldn't save as pointer.
	float		m_rgflNextKinsDist[8];
	unsigned	m_uKinCounts;
	int			m_bitsNodeFlags;
}
wp_file_node_t;

typedef struct wp_file_region_s
{
	unsigned	m_uIndex;
	Vector		m_vecOrigin;
	unsigned	m_rguIdNextKins[8];	// we shouldn't save as pointer.
	float		m_rgflNextKinsDist[8];
	unsigned	m_uKinCounts;
	int			m_bitsNodeFlags;
	float		a, b, c;
	char		m_szName[32];
	unsigned	m_uIdCenterNode;

	// for future members.
	int			Reserved1;
	int			Reserved2;
	int			Reserved3;
	int			Reserved4;
}
wp_file_region_t;

typedef struct wp_astar_table_s
{
	bool		m_bOpened;
	bool		m_bClosed;
	CWPBase*	m_pFrom;
	float		m_flDistFrom;
	float		g;	// another vector to store our traveled distance.
	float		h;	// then we need a vector which contains all the nodes' distance from src to end.
	float		f;	// f = g + h, a expectation value towards end.
}
wp_astar_table_t;

#define MAX_WP_NODES	65536	// 8192*8192 / 32*32
#define MAX_WP_REGIONS	MAX_WP_NODES / 4
#define WP_VERSION		2

class CWayPoint
{
public:
	void* operator new(size_t size)	{ return calloc(1, size); }
	void operator delete(void* ptr)	{ free(ptr); }
	CWayPoint(void) {}
	~CWayPoint(void) {}

public:
	void		Load			(void);
	void		Save			(void);
	void		ServerActivate	(void);	// this is equal to "RESET EVERYTHING"
	void		StartFrame		(void);
	bool		Command			(CBasePlayer* pPlayer);
	void		AddNode			(Vector& vecOrigin);
	void		DelNode			(CBaseEntity* pEntity);
	void		DrawNodes		(CBasePlayer* pPlayer);
	void		DrawRegions		(CBasePlayer* pPlayer);
	CWPNode*	FindNode		(Vector& v);
	CWPRegion*	FindRegion		(Vector& v);
	void		GenerateNodePath(void);
	void		GenerateRegnPath(void);
	void		PGInit			(void);
	void		PGThink			(void);
	void		UpdateNode		(CWPNode* pNode);
	void		AStar			(void);
	void		Meshing			(CBasePlayer* pPlayer);
	void		MeshingInit		(CBasePlayer* pPlayer);
	void		MeshingThink	(void);
	void		DeRedundant		(void);
	void		DRInit			(void);
	void		DRThink			(void);
	bool		AddPath			(CWPBase* pCenter, CWPBase* pnKin);
	void		EnforcePath		(CWPBase* pCenter, CWPBase* pnKin);
	void		DelPath			(CWPBase* pNode, unsigned uSiblingIndex);
	void		ImportCandidates(void);
	void		AddRegion		(Vector& vecOrigin);
	void		DelRegion		(CBaseEntity* pEntity);
	void		AssignNodeToRgn	(void);	// this function automatically links all nodes to their corresponding region.
	void		RegionGenerator	(void);
	void		RegionGenerator2(void);

	// menu funcs.
	static	void	Menu_Main			(CBasePlayer* pPlayer);
	static	void	Menu_AStar			(CBasePlayer* pPlayer);
	static	void	Menu_Region_1		(CBasePlayer* pPlayer);
	static	void	Menu_Region_2		(CBasePlayer* pPlayer);
	static	void	Menu_NodeFlagEditor_1	(CBasePlayer* pPlayer);
	static	void	Menu_NodeFlagEditor_2	(CBasePlayer* pPlayer);
	static	void	HandleMenu_Main		(CBasePlayer* pPlayer, int iSlot);
	static	void	HandleMenu_AStar	(CBasePlayer* pPlayer, int iSlot);
	static	void	HandleMenu_Region_1	(CBasePlayer* pPlayer, int iSlot);
	static	void	HandleMenu_Region_2	(CBasePlayer* pPlayer, int iSlot);
	static	void	HandleMenu_NodeFlagEditor_1	(CBasePlayer* pPlayer, int iSlot);
	static	void	HandleMenu_NodeFlagEditor_2	(CBasePlayer* pPlayer, int iSlot);

	// inline funcs.
	inline	void	AddNode		(CBaseEntity* pEntity);

public:
	CWPNode				m_rgnNodes[MAX_WP_NODES];
	unsigned			m_uNodeCounts;
	bool				m_bShowNodes;
	float				m_flDrawNodesThink;
	CWPBase*			m_pSrc;
	CWPBase*			m_pEnd;
	std::list<CWPBase*>	m_lpResult;
	wp_astar_table_t	m_AStarTableN[MAX_WP_NODES];
	bool				m_bAStarFound;
	std::list<Vector>	m_lvCandidates;
	Vector				m_vecMapSpawn;
	CWPNode*			m_pnMapSpawn;
	char				m_szServerPrintWords[64];	// use for showing progress in console, conforting user.
	CWPRegion			m_rgRegions[MAX_WP_REGIONS];
	unsigned			m_uRegionCounts;
	wp_astar_table_t	m_AStarTableR[MAX_WP_REGIONS];
	bool				m_bShowRegions;
	float				m_flDrawRegionsThink;

	// these four are used for divide the task into lots of frames
	struct meshing_s 
	{
		float	m_flThink;
		float	m_flSkyHeight;

		// some vars. for efficiency, declare it outside can avoid constructing and destructing.
		Vector	vecSrc, vecEnd;
		float	i;
		float	j;
		float	k;
		TraceResult tr;

	} m_sMeshing;

	struct deredundant_s 
	{
		float		m_flThink;
		unsigned	m_uProgress;
		std::list<Vector>::const_iterator	base;
		std::list<Vector>::const_iterator	check;

	} m_sDeRedundant;

	struct pathgenerator_s
	{
		float		m_flThink;
		unsigned	m_uCurrent;
		TraceResult	tr;
		Vector		vecOffset1;
		Vector		vecOffset2;
		float		flZDelta;

	} m_sPathGenerator;

	struct regiongenerator_s
	{
		//CWPRegion	m_rBuffer;
		float		deltaZ;
		TraceResult	tr;
		bool		bCanAdopt;

		// careful with these, a std::list is here, we can't just simply use memset.
		std::list<CWPNode*>	m_lstOrphans;
		std::list<CWPNode*>	m_lstBuffer;

	} m_sRegionGenerator;	// careful with this one, a std::list is here, we shouldn't just simply use memset.
};

extern CWayPoint g_cWayPoint;

class CAStarCalculator
{
public:	// basis
	void* operator new(size_t size) { return calloc(1, size); }
	void operator delete(void* ptr) { free(ptr); }
	CAStarCalculator(void) { }
	~CAStarCalculator(void) { }

public:	// methods
	void	Initialize		(CBasePlayer *pPlayer);
	bool	AStar			(void);
	void	ASBF_Init		(CWPBase* src, CWPBase* end, CBaseEntity* pIgnoreEnt);
	void	ASBF_Think		(void);
	void	ASBF_Cancel		(void)	{ m_bSearching = false; }

public:	// vars
	std::list<CWPBase*>				m_lpResult;
	std::list<CWPNode*>				m_lpResultAsNodes;
	std::list<CWPRegion*>			m_lpResultAsRegions;
	std::vector<wp_astar_table_t>	m_AStarTableN;
	CWPBase*	m_pSrc;
	CWPBase*	m_pEnd;
	bool		m_bAStarFound;
	bool		m_bSearching;	// a status flag to determind whether this calculator is processing a quest.
	CBaseEntity* m_pIgnoreEnt;	// other entities will be consider as occupying node.
	CBasePlayer* m_pPlayer;		// the owner of this "calculator"
	wp_node_lvl	m_iScanLevel;	// we are looking at nodes or regions?

private:
	std::vector<CWPBase*>	vOpen;	// temp. don't use it outside. to keep the "open list" in A* algorism.
	CWPBase* pCur;					// temp. don't use it outside. to keep the process between frames.

	// temp. declare vars outside a loop to save efficiency. these vars will be assign a value before use in Think().
	CWPBase* trace;
	float potentialG, potentialF;
	unsigned iLowest, i;
};































#endif