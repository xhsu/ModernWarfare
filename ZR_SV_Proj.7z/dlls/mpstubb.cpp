/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "soundent.h"
#include "nodes.h"
#include "talkmonster.h"
#include "animation.h"

float CTalkMonster::g_talkWaitTime = 0;

CGraph WorldGraph;
void CGraph::InitGraph(void) {}
int CGraph::FLoadGraph(char *szMapName) { return FALSE; }
int CGraph::AllocNodes(void) { return FALSE; }
int CGraph::CheckNODFile(char *szMapName) { return FALSE; }
int CGraph::FSetGraphPointers(void) { return 0; }
void CGraph::ShowNodeConnections(int iNode) {}
int CGraph::FindNearestNode(const Vector &vecOrigin, int afNodeTypes) { return 0; }

void CBaseMonster::ReportAIState(void) {}
float CBaseMonster::ChangeYaw(int speed) { return 0; }
void CBaseMonster::MakeIdealYaw(Vector vecTarget) {}

void CBaseMonster::CorpseFallThink(void)
{
	if (pev->flags & FL_ONGROUND)
	{
		SetThink(NULL);
		SetSequenceBox();
		UTIL_SetOrigin(pev, pev->origin);
	}
	else
		pev->nextthink = gpGlobals->time + 0.1;
}

void CBaseMonster::MonsterInitDead(void)
{
	InitBoneControllers();

	pev->solid = SOLID_BBOX;
	pev->movetype = MOVETYPE_TOSS;

	pev->frame = 0;
	ResetSequenceInfo();
	pev->framerate = 0;

	pev->max_health = pev->health;
	pev->deadflag = DEAD_DEAD;

	UTIL_SetSize(pev, g_vecZero, g_vecZero);
	UTIL_SetOrigin(pev, pev->origin);

	BecomeDead();
	SetThink(&CBaseEntity::SUB_Remove);
	pev->nextthink = gpGlobals->time + 0.5;
}

BOOL CBaseMonster::ShouldFadeOnDeath(void)
{
	return FALSE;
}

BOOL CBaseMonster::FCheckAITrigger(void)
{
	return FALSE;
}

void CBaseMonster::KeyValue(KeyValueData *pkvd)
{
	CBaseToggle::KeyValue(pkvd);
}

int CBaseMonster::IRelationship(CBaseEntity *pTarget)
{
	static int iEnemy[14][14] =
	{
		{ R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO },
		{ R_NO, R_NO, R_DL, R_DL, R_NO, R_DL, R_DL, R_DL, R_DL, R_DL, R_NO, R_DL, R_DL, R_DL },
		{ R_NO, R_DL, R_NO, R_NO, R_DL, R_DL, R_DL, R_DL, R_DL, R_DL, R_NO, R_NO, R_DL, R_DL },
		{ R_NO, R_NO, R_AL, R_AL, R_HT, R_FR, R_NO, R_HT, R_DL, R_FR, R_NO, R_AL, R_NO, R_NO },
		{ R_NO, R_NO, R_HT, R_DL, R_NO, R_HT, R_DL, R_DL, R_DL, R_DL, R_NO, R_HT, R_NO, R_NO },
		{ R_NO, R_DL, R_HT, R_DL, R_HT, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_DL, R_NO, R_NO },
		{ R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO },
		{ R_NO, R_DL, R_DL, R_DL, R_DL, R_NO, R_NO, R_NO, R_NO, R_NO, R_NO, R_DL, R_NO, R_NO },
		{ R_NO, R_NO, R_DL, R_DL, R_DL, R_NO, R_NO, R_NO, R_NO, R_FR, R_NO, R_DL, R_NO, R_NO },
		{ R_NO, R_NO, R_DL, R_DL, R_DL, R_NO, R_NO, R_NO, R_HT, R_DL, R_NO, R_DL, R_NO, R_NO },
		{ R_FR, R_FR, R_FR, R_FR, R_FR, R_NO, R_FR, R_FR, R_FR, R_FR, R_NO, R_FR, R_NO, R_NO },
		{ R_NO, R_DL, R_AL, R_AL, R_DL, R_DL, R_DL, R_DL, R_DL, R_DL, R_NO, R_NO, R_NO, R_NO },
		{ R_NO, R_NO, R_DL, R_DL, R_DL, R_DL, R_DL, R_DL, R_DL, R_DL, R_NO, R_DL, R_NO, R_DL },
		{ R_NO, R_NO, R_DL, R_DL, R_DL, R_AL, R_NO, R_DL, R_DL, R_NO, R_NO, R_DL, R_DL, R_NO }
	};

	return iEnemy[Classify()][pTarget->Classify()];
}

void CBaseMonster::Look(int iDistance)
{
	int iSighted = 0;
	ClearConditions(bits_COND_SEE_HATE | bits_COND_SEE_DISLIKE | bits_COND_SEE_ENEMY | bits_COND_SEE_FEAR | bits_COND_SEE_NEMESIS | bits_COND_SEE_CLIENT);
	m_pLink = NULL;

	CBaseEntity *pSightEnt = NULL;
	CBaseEntity *pList[100];
	Vector delta = Vector(iDistance, iDistance, iDistance);
	int count = UTIL_EntitiesInBox(pList, 100, pev->origin - delta, pev->origin + delta, FL_CLIENT | FL_MONSTER);

	for (int i = 0; i < count; i++)
	{
		pSightEnt = pList[i];

		if (pSightEnt != this && pSightEnt->pev->health > 0)
		{
			if (IRelationship(pSightEnt) != R_NO && FInViewCone(pSightEnt) && !FBitSet(pSightEnt->pev->flags, FL_NOTARGET) && FVisible(pSightEnt))
			{
				if (pSightEnt->IsPlayer())
					iSighted |= bits_COND_SEE_CLIENT;

				pSightEnt->m_pLink = m_pLink;
				m_pLink = pSightEnt;

				if (pSightEnt == m_hEnemy)
					iSighted |= bits_COND_SEE_ENEMY;

				switch (IRelationship(pSightEnt))
				{
					case R_NM: iSighted |= bits_COND_SEE_NEMESIS; break;
					case R_HT: iSighted |= bits_COND_SEE_HATE; break;
					case R_DL: iSighted |= bits_COND_SEE_DISLIKE; break;
					case R_FR: iSighted |= bits_COND_SEE_FEAR; break;
					case R_AL: break;
				}
			}
		}
	}

	SetConditions(iSighted);
}

CBaseEntity *CBaseMonster::BestVisibleEnemy(void)
{
	int iNearest = 8192;
	CBaseEntity *pNextEnt = m_pLink;
	CBaseEntity *pReturn = NULL;
	int iBestRelationship = R_NO;

	while (pNextEnt)
	{
		if (pNextEnt->IsAlive())
		{
			if (IRelationship(pNextEnt) > iBestRelationship)
			{
				iBestRelationship = IRelationship(pNextEnt);
				iNearest = (int)((pNextEnt->pev->origin - pev->origin).Length());
				pReturn = pNextEnt;
			}
			else if (IRelationship(pNextEnt) == iBestRelationship)
			{
				int iDist = (int)((pNextEnt->pev->origin - pev->origin).Length());

				if (iDist <= iNearest)
				{
					iNearest = iDist;
					iBestRelationship = IRelationship(pNextEnt);
					pReturn = pNextEnt;
				}
			}
		}

		pNextEnt = pNextEnt->m_pLink;
	}

	return pReturn;
}

//=========================================================
// MonsterInitThink - Calls StartMonster. Startmonster is 
// virtual, but this function cannot be 
//=========================================================
void CBaseMonster::MonsterInitThink(void)
{
	StartMonster();
}

//=========================================================
// MonsterInit - after a monster is spawned, it needs to 
// be dropped into the world, checked for mobility problems,
// and put on the proper path, if any. This function does
// all of those things after the monster spawns. Any
// initialization that should take place for all monsters
// goes here.
//=========================================================
void CBaseMonster::MonsterInit(void)
{
	// Set fields common to all monsters
	pev->effects = 0;
	pev->takedamage = DAMAGE_AIM;
	pev->ideal_yaw = pev->angles.y;
	pev->max_health = pev->health;
	pev->deadflag = DEAD_NO;
	m_IdealMonsterState = MONSTERSTATE_IDLE;// Assume monster will be idle, until proven otherwise

	m_IdealActivity = ACT_IDLE;

	pev->flags |= FL_MONSTER;

	InitBoneControllers(); // FIX: should be done in Spawn

	m_afMemory = MEMORY_CLEAR;

	m_hEnemy = NULL;

	m_flDistTooFar = 1024.0;
	m_flDistLook = 2048.0;

	// set eye position
	SetEyePosition();

	SetThink(&CBaseMonster::MonsterInitThink);
	pev->nextthink = gpGlobals->time + 0.1;
	SetUse (&CBaseMonster::MonsterUse);
}

//=========================================================
// StartMonster - final bit of initization before a monster 
// is turned over to the AI. 
//=========================================================
void CBaseMonster::StartMonster(void)
{
	// update capabilities
	if (LookupActivity (ACT_RANGE_ATTACK1) != ACTIVITY_NOT_AVAILABLE)
	{
		m_afCapability |= bits_CAP_RANGE_ATTACK1;
	}
	if (LookupActivity (ACT_RANGE_ATTACK2) != ACTIVITY_NOT_AVAILABLE)
	{
		m_afCapability |= bits_CAP_RANGE_ATTACK2;
	}
	if (LookupActivity (ACT_MELEE_ATTACK1) != ACTIVITY_NOT_AVAILABLE)
	{
		m_afCapability |= bits_CAP_MELEE_ATTACK1;
	}
	if (LookupActivity (ACT_MELEE_ATTACK2) != ACTIVITY_NOT_AVAILABLE)
	{
		m_afCapability |= bits_CAP_MELEE_ATTACK2;
	}

	// Raise monster off the floor one unit, then drop to floor
	if (pev->movetype != MOVETYPE_FLY && !FBitSet(pev->spawnflags, SF_MONSTER_FALL_TO_GROUND))
	{
		pev->origin.z += 1;
		DROP_TO_FLOOR(ENT(pev));

		// Try to move the monster to make sure it's not stuck in a brush.
		if (!WALK_MOVE(ENT(pev), 0, 0, WALKMOVE_NORMAL))
		{
			ALERT(at_error, "Monster %s stuck in wall--level design error", STRING(pev->classname));
			pev->effects = EF_BRIGHTFIELD;
		}
	}
	else
	{
		pev->flags &= ~FL_ONGROUND;
	}

	// Delay drop to floor to make sure each door in the level has had its chance to spawn
	// Spread think times so that they don't all happen at the same time (Carmack)
	SetThink(&CBaseMonster::CallMonsterThink);
	pev->nextthink += RANDOM_FLOAT(0.1, 0.4); // spread think times.

	if (!FStringNull(pev->targetname))	// wait until triggered
	{
		SetState(MONSTERSTATE_IDLE);
		// UNDONE: Some scripted sequence monsters don't have an idle?
		SetActivity(ACT_IDLE);
		ChangeSchedule(GetScheduleOfType(SCHED_WAIT_TRIGGER));
	}
}

//=========================================================
// SetEyePosition
//
// queries the monster's model for $eyeposition and copies
// that vector to the monster's view_ofs
//
//=========================================================
void CBaseMonster::SetEyePosition (void)
{
	Vector  vecEyePosition;
	void* pmodel = GET_MODEL_PTR(ENT(pev));

	GetEyePosition(pmodel, vecEyePosition);

	pev->view_ofs = vecEyePosition;

	if (pev->view_ofs == g_vecZero)
	{
		ALERT (at_aiconsole, "%s has no view_ofs!\n", STRING (pev->classname));
	}
}

//=========================================================
// CBaseMonster - USE - will make a monster angry at whomever
// activated it.
//=========================================================
void CBaseMonster::MonsterUse (CBaseEntity* pActivator, CBaseEntity* pCaller, USE_TYPE useType, float value)
{
	m_IdealMonsterState = MONSTERSTATE_ALERT;
}

//=========================================================
// SetState
//=========================================================
void CBaseMonster::SetState(MONSTERSTATE State)
{
	/*
		if ( State != m_MonsterState )
		{
			ALERT ( at_aiconsole, "State Changed to %d\n", State );
		}
	*/

	switch (State)
	{

		// Drop enemy pointers when going to idle
	case MONSTERSTATE_IDLE:

		if (m_hEnemy != NULL)
		{
			m_hEnemy = NULL;// not allowed to have an enemy anymore.
			ALERT (at_aiconsole, "Stripped\n");
		}
		break;
	}

	m_MonsterState = State;
	m_IdealMonsterState = State;
}

//=========================================================
// SetActivity 
//=========================================================
void CBaseMonster::SetActivity (Activity NewActivity)
{
	int	iSequence;

	iSequence = LookupActivity (NewActivity);

	// Set to the desired anim, or default anim if the desired is not present
	if (iSequence > ACTIVITY_NOT_AVAILABLE)
	{
		if (pev->sequence != iSequence || !m_fSequenceLoops)
		{
			// don't reset frame between walk and run
			if (!(m_Activity == ACT_WALK || m_Activity == ACT_RUN) || !(NewActivity == ACT_WALK || NewActivity == ACT_RUN))
				pev->frame = 0;
		}

		pev->sequence = iSequence;	// Set to the reset anim (if it's there)
		ResetSequenceInfo();
		SetYawSpeed();
	}
	else
	{
		// Not available try to get default anim
		ALERT (at_aiconsole, "%s has no sequence for act:%d\n", STRING(pev->classname), NewActivity);
		pev->sequence = 0;	// Set to the reset anim (if it's there)
	}

	m_Activity = NewActivity; // Go ahead and set this so it doesn't keep trying when the anim is not present

	// In case someone calls this with something other than the ideal activity
	m_IdealActivity = m_Activity;
}

//=========================================================
// Monster Think - calls out to core AI functions and handles this
// monster's specific animation events
//=========================================================
void CBaseMonster::MonsterThink (void)
{
	pev->nextthink = gpGlobals->time + 0.1;// keep monster thinking.

	RunAI();

	float flInterval = StudioFrameAdvance(); // animate
// start or end a fidget
// This needs a better home -- switching animations over time should be encapsulated on a per-activity basis
// perhaps MaintainActivity() or a ShiftAnimationOverTime() or something.
	if (m_MonsterState != MONSTERSTATE_SCRIPT && m_MonsterState != MONSTERSTATE_DEAD && m_Activity == ACT_IDLE && m_fSequenceFinished)
	{
		int iSequence;

		if (m_fSequenceLoops)
		{
			// animation does loop, which means we're playing subtle idle. Might need to 
			// fidget.
			iSequence = LookupActivity (m_Activity);
		}
		else
		{
			// animation that just ended doesn't loop! That means we just finished a fidget
			// and should return to our heaviest weighted idle (the subtle one)
			iSequence = LookupActivityHeaviest (m_Activity);
		}
		if (iSequence != ACTIVITY_NOT_AVAILABLE)
		{
			pev->sequence = iSequence;	// Set to new anim (if it's there)
			ResetSequenceInfo();
		}
	}

	DispatchAnimEvents(flInterval);

	if (!MovementIsComplete())
	{
		Move(flInterval);
	}
#if _DEBUG	
	else
	{
		if (!TaskIsRunning() && !TaskIsComplete())
			ALERT(at_error, "Schedule stalled!!\n");
	}
#endif
}

//=========================================================
// GetIdealState - surveys the Conditions information available
// and finds the best new state for a monster.
//=========================================================
MONSTERSTATE CBaseMonster::GetIdealState (void)
{
	int	iConditions;

	iConditions = IScheduleFlags();

	// If no schedule conditions, the new ideal state is probably the reason we're in here.
	switch (m_MonsterState)
	{
	case MONSTERSTATE_IDLE:

		/*
		IDLE goes to ALERT upon hearing a sound
		-IDLE goes to ALERT upon being injured
		IDLE goes to ALERT upon seeing food
		-IDLE goes to COMBAT upon sighting an enemy
		IDLE goes to HUNT upon smelling food
		*/
	{
		if (iConditions & bits_COND_NEW_ENEMY)
		{
			// new enemy! This means an idle monster has seen someone it dislikes, or 
			// that a monster in combat has found a more suitable target to attack
			m_IdealMonsterState = MONSTERSTATE_COMBAT;
		}
		else if (iConditions & bits_COND_LIGHT_DAMAGE)
		{
			MakeIdealYaw (m_vecEnemyLKP);
			m_IdealMonsterState = MONSTERSTATE_ALERT;
		}
		else if (iConditions & bits_COND_HEAVY_DAMAGE)
		{
			MakeIdealYaw (m_vecEnemyLKP);
			m_IdealMonsterState = MONSTERSTATE_ALERT;
		}
		else if (iConditions & bits_COND_HEAR_SOUND)
		{
			CSound* pSound;

			pSound = PBestSound();
			ASSERT(pSound != NULL);
			if (pSound)
			{
				MakeIdealYaw (pSound->m_vecOrigin);
				if (pSound->m_iType & (bits_SOUND_COMBAT | bits_SOUND_DANGER))
					m_IdealMonsterState = MONSTERSTATE_ALERT;
			}
		}
		else if (iConditions & (bits_COND_SMELL | bits_COND_SMELL_FOOD))
		{
			m_IdealMonsterState = MONSTERSTATE_ALERT;
		}

		break;
	}
	case MONSTERSTATE_ALERT:
		/*
		ALERT goes to IDLE upon becoming bored
		-ALERT goes to COMBAT upon sighting an enemy
		ALERT goes to HUNT upon hearing a noise
		*/
	{
		if (iConditions & (bits_COND_NEW_ENEMY | bits_COND_SEE_ENEMY))
		{
			// see an enemy we MUST attack
			m_IdealMonsterState = MONSTERSTATE_COMBAT;
		}
		else if (iConditions & bits_COND_HEAR_SOUND)
		{
			m_IdealMonsterState = MONSTERSTATE_ALERT;
			CSound* pSound = PBestSound();
			ASSERT(pSound != NULL);
			if (pSound)
				MakeIdealYaw (pSound->m_vecOrigin);
		}
		break;
	}
	case MONSTERSTATE_COMBAT:
		/*
		COMBAT goes to HUNT upon losing sight of enemy
		COMBAT goes to ALERT upon death of enemy
		*/
	{
		if (m_hEnemy == NULL)
		{
			m_IdealMonsterState = MONSTERSTATE_ALERT;
			// pev->effects = EF_BRIGHTFIELD;
			ALERT (at_aiconsole, "***Combat state with no enemy!\n");
		}
		break;
	}
	case MONSTERSTATE_HUNT:
		/*
		HUNT goes to ALERT upon seeing food
		HUNT goes to ALERT upon being injured
		HUNT goes to IDLE if goal touched
		HUNT goes to COMBAT upon seeing enemy
		*/
	{
		break;
	}
	case MONSTERSTATE_SCRIPT:
		if (iConditions & (bits_COND_TASK_FAILED | bits_COND_LIGHT_DAMAGE | bits_COND_HEAVY_DAMAGE))
		{
			ExitScriptedSequence();	// This will set the ideal state
		}
		break;

	case MONSTERSTATE_DEAD:
		m_IdealMonsterState = MONSTERSTATE_DEAD;
		break;
	}

	return m_IdealMonsterState;
}