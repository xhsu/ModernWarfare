/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#ifndef CDLL_DLL_H
#define CDLL_DLL_H

#define MAX_WEAPONS 32
#define MAX_WEAPON_SLOTS 5
#define MAX_ITEM_TYPES 6
#define MAX_ITEMS 4

#define HIDEHUD_WEAPONS (1<<0)
#define HIDEHUD_FLASHLIGHT (1<<1)
#define HIDEHUD_ALL (1<<2)
#define HIDEHUD_HEALTH (1<<3)
#define HIDEHUD_TIMER (1<<4)
#define HIDEHUD_MONEY (1<<5)
#define HIDEHUD_CROSSHAIR (1<<6)

#define MAX_AMMO_TYPES 32
#define MAX_AMMO_SLOTS 32

#define HUD_PRINTNOTIFY 1
#define HUD_PRINTCONSOLE 2
#define HUD_PRINTTALK 3
#define HUD_PRINTCENTER 4
#define HUD_PRINTRADIO 5

#define SCOREATTRIB_DEAD (1<<0)
#define SCOREATTRIB_BOMB (1<<1)
#define SCOREATTRIB_VIP (1<<2)

#define STATUSICON_HIDE 0
#define STATUSICON_SHOW 1
#define STATUSICON_FLASH 2

#define TEAM_UNASSIGNED 0
#define TEAM_SPECTATOR 3
#define TEAM_HUMAN	2
#define TEAM_ZOMBIE	1

enum ZOMBIERIOT_CLASSES
{
#ifndef CLASS_UNASSIGNED
	CLASS_UNASSIGNED = 0,
#endif

	// HUMANS
	CLASS_HUMAN_LUNA_COMMANDO = 1,
	CLASS_HUMAN_MAT_SUPPORT,
	CLASS_HUMAN_BLUE_SHARPSHOOTER,
	CLASS_HUMAN_USAGI_ZWEIHANDER,

	// ZOMBIES
	CLASS_ZOMBIE_STEEL_HELMET,
	CLASS_ZOMBIE_WILD_FIRE,
	CLASS_ZOMBIE_BEAST,
	CLASS_ZOMBIE_POISON_EVIL,

	// CONST
	CLASSES_COUNTS
};

#define CLASS_HUMAN_FIRST	CLASS_HUMAN_LUNA_COMMANDO
#define CLASS_HUMAN_LAST	CLASS_HUMAN_USAGI_ZWEIHANDER
#define CLASS_ZOMBIE_FIRST	CLASS_ZOMBIE_STEEL_HELMET
#define CLASS_ZOMBIE_LAST	CLASS_ZOMBIE_POISON_EVIL

#define MENU_KEY_1 (1<<0)
#define MENU_KEY_2 (1<<1)
#define MENU_KEY_3 (1<<2)
#define MENU_KEY_4 (1<<3)
#define MENU_KEY_5 (1<<4)
#define MENU_KEY_6 (1<<5)
#define MENU_KEY_7 (1<<6)
#define MENU_KEY_8 (1<<7)
#define MENU_KEY_9 (1<<8)
#define MENU_KEY_0 (1<<9)

#define MENU_TEAM 2
#define MENU_MAPBRIEFING 4
#define MENU_CLASS_T 26
#define MENU_CLASS_CT 27
/*
#define MENU_BUY 28
#define MENU_BUY_PISTOL 29
#define MENU_BUY_SHOTGUN 30
#define MENU_BUY_RIFLE 31
#define MENU_BUY_SUBMACHINEGUN 32
#define MENU_BUY_MACHINEGUN 33
#define MENU_BUY_ITEM 34
*/
#define MENU_MENUTYPE_MAX	34	// FIXME: used in ShowVGUIMenu(), can be abandant after integral with CL.

#define IUSER3_CANSHOOT (1<<0)
#define IUSER3_FREEZETIMEOVER (1<<1)
#define IUSER3_INBOMBZONE (1<<2)
#define IUSER3_HOLDINGSHIELD (1<<3)

#define ITEMSTATE_HASNIGHTVISION (1<<0)

#define WEAPON_SUIT 31
#endif