#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "pm_defs.h"
#include "pm_ghost.h"
#include "player.h"

// any entity set with this value will not be consider a barrier of zombies.
#define ZR_FLAGVALUE_ZOMBIE_NOCLIP	242241

static int s_iPhyEntsCount = 0;
static physent_t s_sPhyEnts[MAX_PHYSENTS];

void PM_PhyentsFilter(struct playermove_s* ppmove)
{
	if (ppmove->spectator)
		return;

	CBasePlayer* pPlayer = UTIL_PlayerByIndex(ppmove->player_index + 1);	// hint by Crsky
	CBasePlayer* pOtherPlayer = nullptr;
	CBaseEntity* pEntity = nullptr;

	memset(&s_sPhyEnts, NULL, sizeof(s_sPhyEnts));

	s_sPhyEnts[0] = ppmove->physents[0];
	s_iPhyEntsCount = 1;	// at least we have world entity.

	if (pPlayer->m_bGhost)
	{
		for (int i = 1; i < ppmove->numphysent; i++)	// we need to at least protect world entity, so let's start from 1
		{
			if (ppmove->physents[i].skin != CONTENTS_LADDER)	// ladders.
				continue;

			s_sPhyEnts[s_iPhyEntsCount] = ppmove->physents[i];
			s_iPhyEntsCount++;
		}

		memcpy(&ppmove->physents, &s_sPhyEnts, sizeof(ppmove->physents));
		ppmove->numphysent = s_iPhyEntsCount;

		return;
	}

	// for normal players.

	for (int i = 1; i < ppmove->numphysent; i++)	// we need to at least protect world entity, so let's start from 1
	{
		if (ppmove->physents[i].info <= gpGlobals->maxClients)	// we need to kick ghost players out of phyents array of other players.
		{
			pOtherPlayer = UTIL_PlayerByIndex(ppmove->physents[i].info);

			if (pOtherPlayer && pOtherPlayer->m_bGhost)
				continue;
		}

		if (pPlayer->m_iTeam == TEAM_ZOMBIE && ppmove->physents[i].iuser2 == ZR_FLAGVALUE_ZOMBIE_NOCLIP)	// if this player is a normal zombie, he can still pass through certain walls.
			continue;

		s_sPhyEnts[s_iPhyEntsCount] = ppmove->physents[i];
		s_iPhyEntsCount++;
	}

	memcpy(&ppmove->physents, &s_sPhyEnts, sizeof(ppmove->physents));	// copy our filtered phyent set back.
	ppmove->numphysent = s_iPhyEntsCount;
}