#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "weather.h"
#include "game.h"
#include "player.h"

static char* g_szRainSound[] = { "ambience/rainsound.wav", "ambience/stormrain.wav" };
static char* g_szThunderSound[] = { "ambience/thunder1.wav", "ambience/thunder2.wav", "ambience/thunder3.wav" };
static char* g_szThunderClap[] = { "ambience/thunderflash1.wav", "ambience/thunderflash2.wav", "ambience/thunderflash3.wav", "ambience/thunderflash4.wav", "ambience/thunderflash5.wav" };
static const char* g_szLightLevels[] = { "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "#" };

static char szBuffer[512], szGameDir[64];

int g_iWeatherCounts = 5;
char g_szWeathers[MAX_WEATHER][3] = { "e1", "e2", "c3", "b4", "e7" };
char g_szSkyTextureName[] = "bsky";

int	g_hSparkSpr = 0;

CWeatherManager g_cWeatherManager;

void CWeatherManager::Precache(void)
{
	PRECACHE_SOUND_ARRAY(g_szThunderSound);
	PRECACHE_SOUND_ARRAY(g_szThunderClap);
	PRECACHE_SOUND_ARRAY(g_szRainSound);

	g_hSparkSpr = PRECACHE_MODEL("sprites/laserbeam.spr");

	CVAR_SET_STRING("sv_skyname", g_szSkyTextureName);
}

void CWeatherManager::OnServerActivate(void)
{
	m_iCurrentWeatherInSeq = 0;
}

void CWeatherManager::OnGameReset(void)
{
	// this is because OnNewRound() and WeatherChanged() will be called next to a game reset.
	// if we set it to 0 like we did in OnServerActivate(), it will increase to 1 rightaway.
	m_iCurrentWeatherInSeq = -1;
}

void CWeatherManager::OnNewRound(void)
{
	m_cLightStyle[0] = g_szWeathers[m_iCurrentWeatherInSeq][0];
	m_cLightStyle[1] = '\0';
	LIGHT_STYLE(0, m_cLightStyle);

	m_iWeather = (WEATHER_TYPES)atoi(&g_szWeathers[m_iCurrentWeatherInSeq][1]);
	SetWeather(m_iWeather);

	if (m_iWeather != WEATHER_TEMPEST)
	{
		CBasePlayer* pPlayer = NULL;

		for (int i = 1; i <= gpGlobals->maxClients; i++)
		{
			pPlayer = (CBasePlayer*)GET_PRIVATE(INDEXENT(i));

			if (!pPlayer || pPlayer->has_disconnected || pPlayer->IsBot())
				continue;

			CLIENT_COMMAND(pPlayer->edict(), "mp3 play %s\n", "sound/zombieriot/quarantine_01.mp3");
		}
	}

	WeatherChanged();
}

// public ChangeWeather()
void CWeatherManager::WeatherChanged(void)
{
	if (g_iWeatherCounts < 1)
		return;

	if (m_iCurrentWeatherInSeq < g_iWeatherCounts - 1)
	{
		m_iCurrentWeatherInSeq++;
		return;
	}

	m_iCurrentWeatherInSeq = 0;
}

// public WeatherSystem()
void CWeatherManager::WeatherThink(void)
{
	if (m_iWeather == WEATHER_SUNNY)
		return;

	if ((m_iWeather == WEATHER_DRIZZLE || m_iWeather == WEATHER_TEMPEST || m_iWeather == WEATHER_THUNDERSTORM) &&
		m_flRainSoundThink <= gpGlobals->time)
	{
		if (m_iWeather == WEATHER_TEMPEST)
		{
			UTIL_Broadcast(g_szRainSound[1]);
			m_flRainSoundThink = gpGlobals->time + 8.0f;
		}
		else
		{
			UTIL_Broadcast(g_szRainSound[0]);
			m_flRainSoundThink = gpGlobals->time + 5.0f;
		}
	}

	if (m_iWeather == WEATHER_THUNDERSTORM && m_flThunderLightThink <= gpGlobals->time)
	{
		m_flThunderLightThink = gpGlobals->time + RANDOM_FLOAT(10.0f, 15.0f);
		UTIL_Broadcast(RANDOM_IN_ARRAY(g_szThunderSound));
		SetThunderLight();
	}
	else if (m_iWeather == WEATHER_TEMPEST)
	{
		if (m_flThunderClapThink <= gpGlobals->time)
		{
			UTIL_Broadcast(RANDOM_IN_ARRAY(g_szThunderClap));
			m_flThunderClapThink = gpGlobals->time + RANDOM_FLOAT(2.0f, 2.5f);
			UTIL_SetFog(0, 0, 0, 0);
			SetThunderLight();
			MakeThunderSpark();
		}
	}

	if (m_flThunderFlashThink <= gpGlobals->time && m_iThunderFlashCount > 0)
	{
		m_iThunderFlashCount--;

		if (m_bThunderShouldFlash)
		{
			MESSAGE_BEGIN(MSG_BROADCAST, SVC_LIGHTSTYLE);
			WRITE_BYTE(0);
			WRITE_STRING("#");
			MESSAGE_END();

			m_flThunderFlashThink = gpGlobals->time + RANDOM_FLOAT(0.03f, 0.04f);
			m_bThunderShouldFlash = false;
			return;
		}

		if (m_iWeather == WEATHER_TEMPEST)
			UTIL_SetFog(5, 5, 5, 5);

		CBasePlayer * pPlayer = nullptr;
		while ((pPlayer = (CBasePlayer*)UTIL_FindEntityByClassname(pPlayer, "player")) != nullptr)
		{
			if (pPlayer->has_disconnected)
				continue;

			/*if (pPlayer->m_iTeam == TEAM_ZOMBIE)
				UTIL_SetLightStyle(pPlayer->edict(), g_szLightLevels[unsigned(cvar_zombienvg[4].value)]);
			else if (pPlayer->m_bNightVisionOn)
				UTIL_SetLightStyle(pPlayer->edict(), g_szLightLevels[unsigned(cvar_humannvg[4].value)]);
			else*/
				UTIL_SetLightStyle(pPlayer->edict(), m_cLightStyle);
		}

		if (m_iThunderFlashCount)
		{
			m_bThunderShouldFlash = true;
			m_flThunderFlashThink = gpGlobals->time + RANDOM_FLOAT(0.1f, 0.2f);
		}
	}
}

// public native_set_weather(WeatherIndex)
void CWeatherManager::SetWeather(WEATHER_TYPES iType)
{
	switch (iType)
	{
	case WEATHER_DRIZZLE:
		Drizzle();
		break;

	case WEATHER_THUNDERSTORM:
		Thunderstorm();
		break;

	case WEATHER_TEMPEST:
		Tempest();
		break;

	case WEATHER_SNOW:
		Snow();
		break;

	case WEATHER_FOG:
		Fog();
		break;

	case WEATHER_BLACKFOG:
		BlackFog();
		break;

	case WEATHER_SUNNY:
	default:
		Sunny();
		break;
	}
}

// public SetThunderLight()
void CWeatherManager::SetThunderLight(void)
{
	m_iThunderFlashCount = RANDOM_LONG(1, 2) * 2;
	m_bThunderShouldFlash = true;
	m_flThunderFlashThink = 0.0f;
}

// public MakeThunderSpark()
bool CWeatherManager::MakeThunderSpark(void)
{
	CBasePlayer* rgpPlayers[33];
	int iPlayers = 0;

	CBasePlayer* pPlayer = nullptr;
	while ((pPlayer = (CBasePlayer*)UTIL_FindEntityByClassname(pPlayer, "player")) != nullptr)
	{
		if (pPlayer->has_disconnected || !pPlayer->IsAlive())
			continue;

		if (!UTIL_UnderSky(pPlayer->pev->origin))
			continue;

		iPlayers++;
		rgpPlayers[iPlayers] = pPlayer;
	}

	if (!iPlayers)
		return false;

	Vector rgvSparkEnd[3];
	rgvSparkEnd[0] = rgpPlayers[RANDOM_LONG(1, iPlayers)]->pev->origin;
	rgvSparkEnd[1] = rgvSparkEnd[0] + Vector(RANDOM_FLOAT(-15.0f, 15.0f), RANDOM_FLOAT(-15.0f, 15.0f), RANDOM_FLOAT(-25.0f, 20.0f)) * cvar_sparksize.value;
	rgvSparkEnd[2] = rgvSparkEnd[0] + Vector(RANDOM_FLOAT(-1.0f, 1.0f), RANDOM_FLOAT(-1.0f, 1.0f), RANDOM_FLOAT(-35.0f, 30.0f)) * cvar_sparksize.value;

	for (int i = 1; i < 3; i++)
	{
		MESSAGE_BEGIN(MSG_BROADCAST, SVC_TEMPENTITY);
		WRITE_BYTE(TE_BEAMPOINTS);
		WRITE_COORD(rgvSparkEnd[i - 1][0]);
		WRITE_COORD(rgvSparkEnd[i - 1][1]);
		WRITE_COORD(rgvSparkEnd[i - 1][2]);
		WRITE_COORD(rgvSparkEnd[i][0]);
		WRITE_COORD(rgvSparkEnd[i][1]);
		WRITE_COORD(rgvSparkEnd[i][2]);
		WRITE_SHORT(g_hSparkSpr);
		WRITE_BYTE(0);
		WRITE_BYTE(2);
		WRITE_BYTE(2);
		WRITE_BYTE(15);
		WRITE_BYTE(150);
		WRITE_BYTE(255);
		WRITE_BYTE(255);
		WRITE_BYTE(255);
		WRITE_BYTE(255);
		WRITE_BYTE(RANDOM_LONG(20, 30));
		MESSAGE_END();
	}

	return true;
}

void CWeatherManager::Sunny(void)
{
	UTIL_StopBroadcast();
	UTIL_SetFog(0, 0, 0, 0);
	UTIL_SetReceiveW(ReceiveW_Clear);
}

void CWeatherManager::Drizzle(void)
{
	UTIL_StopBroadcast();
	UTIL_SetFog(0, 0, 0, 0);
	UTIL_SetReceiveW(ReceiveW_Rain);
	m_flRainSoundThink = 0;
}

void CWeatherManager::Thunderstorm(void)
{
	UTIL_StopBroadcast();
	UTIL_SetFog(0, 0, 0, 0);
	UTIL_SetReceiveW(ReceiveW_Rain);

	m_flThunderLightThink = gpGlobals->time + RANDOM_FLOAT(10.0f, 15.0f);
	m_flRainSoundThink = 0;
}

void CWeatherManager::Tempest(void)
{
	UTIL_StopBroadcast();
	UTIL_SetFog(5, 5, 5, 5);
	UTIL_SetReceiveW(ReceiveW_Rain);
	m_flRainSoundThink = 0;
}

void CWeatherManager::Snow(void)
{
	UTIL_StopBroadcast();
	UTIL_SetReceiveW(ReceiveW_Snow);
	UTIL_SetFog(200, 200, 200, 7);
}

void CWeatherManager::Fog(void)
{
	UTIL_StopBroadcast();
	UTIL_SetFog(100, 100, 100, 6);
	UTIL_SetReceiveW(ReceiveW_Clear);
}

void CWeatherManager::BlackFog(void)
{
	UTIL_StopBroadcast();
	UTIL_SetFog(0, 0, 0, 3);
	UTIL_SetReceiveW(ReceiveW_Clear);
}