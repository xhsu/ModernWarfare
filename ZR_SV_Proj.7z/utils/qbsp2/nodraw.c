/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
****/

#include "bsp5.h"

void Draw_ClearBounds (void)
{
}

void Draw_AddToBounds (vec3_t v)
{
}

void Draw_DrawFace (face_t *f)
{
}

void Draw_ClearWindow (void)
{
}

void Draw_SetRed (void)
{
}

void Draw_SetGrey (void)
{
}

void Draw_SetBlack (void)
{
}

void DrawPoint (vec3_t v)
{
}

void DrawLeaf (node_t *l, int color)
{
}

void DrawWinding (winding_t *w)
{
}

void DrawTri (vec3_t p1, vec3_t p2, vec3_t p3)
{
}

void DrawPortal (portal_t *portal)
{
}
