/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
****/

// cull.c

#include "bsp5.h"

/*

  removes unused planes and nodes

*/

/*
=============
CullStuff
=============
*/
void CullStuff (void)
{
}
