#ifndef __SYSDEF_HEADER_
#define __SYSDEF_HEADER_

#include <Windows.h>
#include <cstdlib>
#include <cmath>
#include <xtgmath.h>
#include <string.h>
#include <io.h>
#include <gl/gl.h>
#include <stdio.h>

#include "vector.h"
#include "encode.h"
#include "const.h"

#endif