/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//
// util.cpp
//
// implementation of class-less helper functions
//

#include "STDIO.H"
#include "STDLIB.H"
#include "MATH.H"

#include "hud.h"
#include "cl_util.h"
#include <string.h>
#include "event_api.h"
#include "cl_entity.h"
#include "encode.h"
#include "mh_import.h"

extern "C"
{
#include "pmtrace.h"
#include "pm_shared.h"
#include "pm_materials.h"
#include "pm_defs.h"
}

#ifndef M_PI
#define M_PI		3.14159265358979323846	// matches value in gcc v2 math.h
#endif

vec3_t vec3_origin( 0, 0, 0 );

double sqrt(double x);

double g_flClientTime = 0;
double g_flClientFrame = 0;

float Length(const float *v)
{
	int		i;
	float	length;
	
	length = 0;
	for (i=0 ; i< 3 ; i++)
		length += v[i]*v[i];
	length = sqrt (length);		// FIXME

	return length;
}

void VectorAngles( const float *forward, float *angles )
{
	float	tmp, yaw, pitch;
	
	if (forward[1] == 0 && forward[0] == 0)
	{
		yaw = 0;
		if (forward[2] > 0)
			pitch = 90;
		else
			pitch = 270;
	}
	else
	{
		yaw = (atan2(forward[1], forward[0]) * 180 / M_PI);
		if (yaw < 0)
			yaw += 360;

		tmp = sqrt (forward[0]*forward[0] + forward[1]*forward[1]);
		pitch = (atan2(forward[2], tmp) * 180 / M_PI);
		if (pitch < 0)
			pitch += 360;
	}
	
	angles[0] = pitch;
	angles[1] = yaw;
	angles[2] = 0;
}

Vector VectorAngles(Vector forward)
{
	float tmp, yaw, pitch;
	
	if (forward.y == 0 && forward.x == 0)
	{
		yaw = 0;
		if (forward.z > 0)
			pitch = 90;
		else
			pitch = 270;
	}
	else
	{
		yaw = (atan2(forward.y, forward.x) * 180 / M_PI);
		if (yaw < 0)
			yaw += 360;

		tmp = sqrt (forward.x * forward.x + forward.y * forward.y);
		pitch = (atan2(forward.z, tmp) * 180 / M_PI);
		if (pitch < 0)
			pitch += 360;
	}
	
	return Vector(pitch, yaw, 0.0f);
}

float VectorNormalize (float *v)
{
	float	length, ilength;

	length = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
	length = sqrt (length);		// FIXME

	if (length)
	{
		ilength = 1/length;
		v[0] *= ilength;
		v[1] *= ilength;
		v[2] *= ilength;
	}
		
	return length;

}

void VectorInverse ( float *v )
{
	v[0] = -v[0];
	v[1] = -v[1];
	v[2] = -v[2];
}

void VectorScale (const float *in, float scale, float *out)
{
	out[0] = in[0]*scale;
	out[1] = in[1]*scale;
	out[2] = in[2]*scale;
}

void VectorMA (const float *veca, float scale, const float *vecb, float *vecc)
{
	vecc[0] = veca[0] + scale*vecb[0];
	vecc[1] = veca[1] + scale*vecb[1];
	vecc[2] = veca[2] + scale*vecb[2];
}

/*
HSPRITE LoadSprite(const char *pszName)
{
	int i;
	char sz[256]; 

	if (ScreenWidth < 640)
		i = 320;
	else
		i = 640;

	sprintf(sz, pszName, i);

	return SPR_Load(sz);
}
*/

void lTrim(char *str)
{
    int i	= 0;
	int len	= (int)strlen(str);

    for (i = 0; i < len; i ++)
    {
        if (str[i] != ' ' && str[i] != '\t')
			break;
    }

    memmove(str, str + i, len - i + 1);
}

Vector GetVectorFromString(const char *src)
{
	char	szWords[64];
	strcpy(szWords, src);

	int		i			= 0;
	char	*pcParts	= strtok(szWords, ",");
	Vector	vecResult	= Vector();

	while( pcParts != NULL )
	{
		lTrim(pcParts);
		vecResult[i ++] = atof(pcParts);
		pcParts = strtok( NULL, "," );

		if (i >= 3)
			break;
	}

	return vecResult;
}

double CalcFov(double fov_x, double width, double height)
{
	if (fov_x < 1 || fov_x > 179)
		fov_x = 90;

	fov_x *= M_PI / 180.0;

	return 2.0 * atan((height/width) * tan(fov_x * 0.5));
}

void RationalizationAngle(float *vecAngle)
{
	if (vecAngle[1] < 0)
		vecAngle[1] += 360;
	else if (vecAngle[1] > 360)
		vecAngle[1] -= 360;
}

float	*g_pMins[4]	= { NULL, NULL, NULL, NULL };
float	*g_pMaxs[4] = { NULL, NULL, NULL, NULL };
static Vector s_vecMins	= Vector();
static Vector s_vecMaxs = Vector();

void UTIL_TraceLine(Vector vecSrc, Vector vecEnd, int traceFlags, int ignore_pe, struct pmtrace_s *ptr, int index, int hull)
{
	/*
	in order to have tents collide with players, we have to run the player prediction code so
	that the client has the player list. We run this code once when we detect any COLLIDEALL 
	tent, then set this BOOL to true so the code doesn't get run again if there's more than
	one COLLIDEALL ent for this update. (often are).
	*/
	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );

	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// index - 1 for specific player, -1 for all players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( index - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( hull );
	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecEnd, traceFlags, ignore_pe, ptr );

	// Restore state info
	gEngfuncs.pEventAPI->EV_PopPMStates();
}

void UTIL_SetHull(int iHull, Vector vecMins, Vector vecMaxs)
{
	s_vecMins = Vector(g_pMins[iHull]);
	s_vecMaxs = Vector(g_pMaxs[iHull]);

	g_pMins[iHull]	= vecMins;
	g_pMaxs[iHull]	= vecMaxs;
}

void UTIL_RestoreHull(int iHull)
{
	g_pMins[iHull]	= s_vecMins;
	g_pMaxs[iHull]	= s_vecMaxs;
}

color24 UnpackRGB( const unsigned long ulRGB )
{
	color24 color;
	color.r = (ulRGB & 0xFF0000) >> 16;
	color.g = (ulRGB & 0xFF00) >> 8;
	color.b = ulRGB & 0xFF;

	return color;
}

int *g_pPMUseHull = NULL;

bool UTIL_IsPlayerDucking(void)
{
	if (!g_pPMUseHull)
		return NULL;

	return !!(*g_pPMUseHull == 1);
}

Vector get_aim_origin_vector(Vector vAngle, Vector vOrigin, float forw, float right, float up)
{
	Vector vForward, vRight, vUp;
	gEngfuncs.pfnAngleVectors(vAngle, vForward, vRight, vUp);

	return (vOrigin + vForward * forw + vRight * right + vUp * up);
}

char UTIL_GetTextureType(pmtrace_t *ptr, Vector vecSrc, Vector vecEnd)
{
	// hit the world, try to play sound based on texture material type
	char chTextureType = CHAR_TEX_CONCRETE;
	int entity;
	char *pTextureName;
	char texname[ 64 ];
	char szbuffer[ 64 ];

	entity = gEngfuncs.pEventAPI->EV_IndexFromTrace( ptr );

	if ( entity >= 1 && entity <= gEngfuncs.GetMaxClients() )
	{
		// hit body
		chTextureType = CHAR_TEX_FLESH;
	}
	else if ( entity == 0 )
	{
		// get texture from entity or world (world is ent(0))
		pTextureName = (char *)gEngfuncs.pEventAPI->EV_TraceTexture( ptr->ent, vecSrc, vecEnd );
		
		if ( pTextureName )
		{
			strcpy( texname, pTextureName );
			pTextureName = texname;

			// strip leading '-0' or '+0~' or '{' or '!'
			if (*pTextureName == '-' || *pTextureName == '+')
			{
				pTextureName += 2;
			}

			if (*pTextureName == '{' || *pTextureName == '!' || *pTextureName == '~' || *pTextureName == ' ')
			{
				pTextureName++;
			}
			
			// '}}'
			strcpy( szbuffer, pTextureName );
			szbuffer[ CBTEXTURENAMEMAX - 1 ] = 0;
				
			// get texture type
			chTextureType = PM_FindTextureType( szbuffer );	
		}
	}

	return chTextureType;
}

int CalcBody( BodyEnumInfo_t *info, int count )
{
	int		body = 0;
	int		base;
	bool	valid;

	if ( count <= 0 )
		return 0;

	do
	{
		valid = true;

		for ( int i = 0; i < count; i++ )
		{
			if ( i )
				base *= info[i - 1].nummodels;
			else
				base = 1;

			if ( body / base % info[i].nummodels != info[i].body )
			{
				valid = false;
				break;
			}
		}

		if ( valid )
			return body;

		body++;
	}
	while ( body <= 2147483647 );	// originally: 255

	return 0;
}

bool fm_is_in_viewcone(const double fov, const Vector vecPoint)
{
	Vector vecDiff = vecPoint - Vector(gEngfuncs.GetLocalPlayer()->origin);
	vecDiff = vecDiff.Normalize();

	float flDotProduct = DotProduct(gHUD::TriDimnHud::m_vecForward, vecDiff);

	return !!(flDotProduct >= cos(fov * M_PI / 360.0));
}

bool UTIL_SearchInLocalize(const char *pToken, wchar_t *result, const char *pErrorToken)
{
	bool bFound;
	wchar_t	*pChars	= gpLocalize->Find(pToken);

	// result check.
	if (!pChars)
	{
		// using error hint text.
		pChars	= gpLocalize->Find(pErrorToken);
		bFound	= false;
	}
	else
	{
		bFound	= true;
	}

	if (pChars)
	{
		wcscpy(result, pChars);
	}
	else
	{
		wchar_t *sz = ANSIToUnicode(pToken);
		wcscpy(result, sz);
	}

	return bFound;
}

const wchar_t *UTIL_KeyNameByCommand(const char *cmd)
{
	static char szKeyname1[16];
	static wchar_t wszKeyname1[16];
	static const char *p = nullptr;

	if ((p = gMHSharedFuncs.Key_NameForBinding(cmd)) == nullptr)
		return L"";

	strncpy_s(szKeyname1, p, _TRUNCATE);	// get the keyname of speed selector.
	wcsncpy_s(wszKeyname1, ANSIToUnicode(szKeyname1), _TRUNCATE);

	return wszKeyname1;
}