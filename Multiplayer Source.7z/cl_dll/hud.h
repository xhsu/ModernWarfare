/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/

#ifndef _HUD_H_
#define _HUD_H_

#define RGB_YELLOWISH	0x00FFA000	// 255	160		0
#define RGB_REDISH		0x00FF1010	// 255	160		160
#define RGB_GREENISH	0x0000A000	// 0	160		0
#define RGB_WHITE		0x00FFFFFF	// 255	255		255
#define RGB_BLACK		0x00000000	// 0	0		0

#include "wrect.h"
#include "cl_dll.h"
#include "cvardef.h"
#include "ILocalize.h"
#include "..\Interface\IGameUIFuncs.h"

//STL
#include <vector>


extern vgui::ILocalize	*gpLocalize;
extern IGameUIFuncs *gpGameUIFuncs;

typedef struct
{
	unsigned char r,g,b,a;
}	RGBA;


#define HUD_ACTIVE			1
#define HUD_INTERMISSION	2

#define MAX_PLAYER_NAME_LENGTH		32

#define	MAX_MOTD_LENGTH				1536

enum 
{ 
	MAX_PLAYERS = 64,
	MAX_TEAMS = 64,
	MAX_TEAM_NAME = 16,
};



struct extra_player_info_t 
{
	short frags;
	short deaths;
	short playerclass;
	short teamnumber;
	char teamname[MAX_TEAM_NAME];
};

struct team_info_t 
{
	char name[MAX_TEAM_NAME];
	short frags;
	short deaths;
	short ping;
	short packetloss;
	short ownteam;
	short players;
	int already_drawn;
	int scores_overriden;
	int teamnumber;
};




extern hud_player_info_t	g_PlayerInfoList[MAX_PLAYERS+1];	// player info from the engine
extern extra_player_info_t  g_PlayerExtraInfo[MAX_PLAYERS+1];	// additional player info sent directly to the client dll
extern team_info_t			g_TeamInfo[MAX_TEAMS+1];
extern int					g_IsSpectator[MAX_PLAYERS+1];

extern int g_iPlayerClass;
extern int g_iTeamNumber;
extern int g_iUser1;
extern int g_iUser2;
extern int g_iUser3;

namespace gHUD
{
	extern Vector		m_vecOrigin;
	extern Vector		m_vecAngles;
	extern int			m_iKeyBits;
	extern float		m_iFOV;
	extern int			m_iConcussionEffect;
	extern SCREENINFO	m_sScreenInfo;
	extern cvar_t		*m_pCvarZoomSenRatio;
	extern cvar_t		*m_pCvarDefFOV;
	extern SCREENINFO	m_sScreenInfo;
	extern float		m_flMouseSensitivity;
	extern int			m_Teamplay;
	extern int			m_iIntermission;

	void	Init				( void );
	void	VidInit				( void );
	int		UpdateClientData	( client_data_t *cdata, float time );

	namespace	BiDimnHud
	{
		void		DrawBloodScreen	( void );
		void		DrawCalibrateDot( void );
		void		DrawScope		( unsigned iIdTexture, bool bCenter = false, float flWidth = 0, float flHeight = 0);
	};

	namespace	TriDimnHud
	{
		extern Vector	m_vecDrawCalcOrigin;
		extern Vector	m_vecForward;
		extern Vector	m_vecRight;
		extern Vector	m_vecUp;
		extern Vector	m_vecScreenCorner[4];
		extern Vector	m_vecLeanCenter;
		extern float	m_fl3DUIDistance;
		extern float	m_flVerticalFOV;
		extern float	m_flFrameRate;
		extern wchar_t	m_wszDisplayWpnName[128 * 2];
		extern wchar_t	m_wszAmmoWords[16];
		extern float	m_flFadeFactor;
		extern float	m_flMiscAlpha;

		void	CalcVectors	( void );
		void	DrawArmor	( void );
	};
};

class CHudHintText
{
public:
	CHudHintText	( void );
	~CHudHintText	( void );

	void	Think	( void );
	void	Draw	( void );

	typedef enum
	{
		HHT_FADEIN = 1,
		HHT_STAY,
		HHT_FADEOUT

	} HHT_PHASE;

	wchar_t		m_wszText[512];
	float		m_flAlpha;
	color24		m_sColor;
	double		m_flTimeRemove;
	float		m_flFadeFactor;
	HHT_PHASE	m_iPhase;

	CHudHintText	*m_pNext;
};

namespace gHUD
{
	CHudHintText	*AddHintText	( const char *sz );
	CHudHintText	*AddHintText	( const wchar_t *sz );
}

extern CHudHintText *g_pHudHintTextHeader;

class CScreenFade
{
public:	// avoid the complex memset();
	void *operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void *ptr)
	{
		free(ptr);
	}

	typedef enum
	{
		SF_FADEIN = 1,
		SF_STAY,
		SF_FADEOUT

	} SF_PHASE;

public:
	color24		m_sColor;
	float		m_flAlpha;
	SF_PHASE	m_iPhase;
	float		m_flTimeThink;
	float		m_flStayLength;
	float		m_flFadeSpeed;
	color24		m_sTargetColor;
	float		m_flTargetAlpha;

	void		Draw	( void );
	void		Think	( void );
	
	inline void	SetTargetColor(int r, int g, int b)			{ m_sTargetColor.r = r; m_sTargetColor.g = g; m_sTargetColor.b = b; }
	inline void	SetCurrentColor(int r, int g, int b)		{ m_sColor.r = r; m_sColor.g = g; m_sColor.b = b; }
	inline void	SetAlpha(float flTarget, float flCur = -1)	{ m_flTargetAlpha = flTarget; m_flAlpha = max(min(flCur, 255), 0); }
	inline void	Start(SF_PHASE phase = SF_FADEIN)			{ m_flTimeThink = 0; m_iPhase = phase; }
	inline void	SetFadeSpeed(float flSpeed)					{ m_flFadeSpeed = flSpeed; }
	inline void SetStayLength(float flLength = 0)			{ m_flStayLength = flLength; }
};

extern CScreenFade g_cScreenFade;


#define HUD_SIZE_GAP			8.0f
#define HUD_SIZE_GRENADEICON	45.0f
#define HUD_SIZE_NUM_SMALL		25.0f
#define HUD_SIZE_NUM_LARGE		45.0f
#define HUD_SIZE_BAR_WIDTH		15.0f
#define HUD_SIZE_BAR_LENGTH		(HUD_SIZE_WPNICON_LEN / 4.0f)
#define HUD_SIZE_STRING_TALL	HUD_SIZE_NUM_SMALL
#define HUD_SIZE_FIREMODE_ICON	HUD_SIZE_STRING_TALL
#define HUD_SIZE_RUNING_EDGE	40.0f
#define HUD_SIZE_WPNICON_LEN	(HUD_SIZE_NUM_SMALL * 22.0f / 3.0f)
#define HUD_SIZE_WPNICON_TALL	(float(HUD_SIZE_WPNICON_LEN) / 21.0f * 9.0f)
#define HUD_SIZE_ARMOR_ICON		HUD_SIZE_NUM_LARGE
#define HUD_SIZE_MAG_WIDTH		20.0f
#define HUD_SIZE_MAG_HEIGHT		((HUD_SIZE_MAG_WIDTH / 9.0f) * 16.0f)

#endif