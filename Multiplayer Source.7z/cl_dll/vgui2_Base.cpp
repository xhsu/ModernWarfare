
#include <string.h>
#include "IClientVGUI.h"
#include "ILocalize.h"
#include "..\Interface\IGameUIFuncs.h"

#define DLLEXPORT __declspec( dllexport )

extern "C" 
{
	void DLLEXPORT IN_ActivateMouse( void );
	void DLLEXPORT IN_DeactivateMouse( void );
	void DLLEXPORT IN_MouseEvent (int mstate);
	void DLLEXPORT IN_Accumulate (void);
	void DLLEXPORT IN_ClearStates (void);
}

EXPOSE_SINGLE_INTERFACE(CClientVGUI, IClientVGUI, CLIENTVGUI_INTERFACE_VERSION);

// this should controlled here.
extern bool	g_bDraw3DGUI;

vgui::ILocalize	*gpLocalize = NULL;
IGameUIFuncs *gpGameUIFuncs = NULL;

/*
========================== 
	INTERFACE
==========================
*/

extern "C"
{
	DLLEXPORT CreateInterfaceFn ClientFactory(void);
}

CreateInterfaceFn ClientFactory(void)
{
	return Sys_GetFactoryThis();
}

/*
========================== 
	CClientVGUI
==========================
*/

void CClientVGUI::Initialize(CreateInterfaceFn *factories, int count)
{
	gpLocalize = (vgui::ILocalize *)factories[FACTORY_VGUI2]( VGUI_LOCALIZE_INTERFACE_VERSION, NULL );
	gpGameUIFuncs = (IGameUIFuncs *)factories[FACTORY_HW]( VENGINE_GAMEUIFUNCS_VERSION, NULL );
}

void CClientVGUI::ActivateClientUI(void)
{
	IN_ActivateMouse();
	g_bDraw3DGUI = true;
}

void CClientVGUI::HideClientUI(void)
{
	IN_DeactivateMouse();
	g_bDraw3DGUI = false;
}