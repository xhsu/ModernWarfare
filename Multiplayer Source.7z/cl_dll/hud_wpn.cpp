#include <sysdef.h>

#include "hud.h"
#include "cl_util.h"
#include "cl_entity.h"
#include "view.h"
#include "cl_wpns.h"
#include "hud_wpn.h"
#include "hud_menu.h"
#include "wpn_cmd_shared.h"
#include "event_api.h"
#include "pm_defs.h"

#include <triangleapi.h>
#include "const.h"
#include <com_model.h>
#include "dxt.h"

#include "DrawFonts.h"


namespace gStdWpnHud
{
	const int	MAX_BACKUP	= 20;
	const float	LASER_SCALE	= 1.0f;

	unsigned int	m_iIdPistolAmmoIcons[CSMW_FIREMODE_COUNT];
	unsigned int	m_iIdRifleAmmoIcons[CSMW_FIREMODE_COUNT];
	unsigned int	m_iIdShotgunAmmoIcons[CSMW_FIREMODE_COUNT];
	unsigned int	m_iIdRocketAmmoIcon;
	unsigned int	m_iIdGrenadeAmmoIcon;

	// Laser.
	unsigned	m_iIdLaserDot		= 0;
	int			m_iLaserDotWidth	= 2;
	int			m_iLaserDotHeight	= 2;

	int	m_hFont;

	float	m_flFadeFactor	= 1;
	float	m_flMiscAlpha	= 255;

	Vector	m_vecForward;
	Vector	m_vecRight;
	Vector	m_vecUp;
	Vector	m_vecLeanCenter;

	Plane	m_clurWeaponIcon		= Plane(255, 255, 255, 255);
	Plane	m_clurSecondaryIcon		= Plane(255, 255, 255, 255);
	Plane	m_clurWeaponAmmoNum		= Plane(255, 255, 255, 255);
	Plane	m_clurSecondaryAmmoNum	= Plane(255, 255, 255, 255);

	wpnfxdb_s	m_sPriWpn	= { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };
	wpnfxdb_s	m_sSedWpn	= { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };

	wchar_t	m_wszDisplayWpnName[64]	= L"";
	wchar_t	m_wszAmmoWords[64]		= L"";

	void	Initialize		( void );
	void	VidInit			( void );
	void	CalcVectors		( void );
	void	CalcEffects		( void );
	void	UpdateWpnName	( void );
	void	DrawClip		( void );
	void	DrawAmmo		( void );
	void	DrawFiremode	( void );
	void	DrawCurWeapon	( void );

	Vector	GetWeaponNameOrigin	( void );

	Vector	GetAmmmoNameOrigin	( void );
	Vector	GetAmmmoNumOrigin	( void );
	Vector	GetWeaponIconOrigin	( void );
	Vector	GetFiremodeOrigin	( void );

	Vector	GetSecondaryAmmoNameOrigin	( void );
	Vector	GetSecondaryAmmoNumOrigin	( void );
	Vector	GetSecondaryIconOrigin		( void );
	Vector	GetSecondaryFiremodeOrigin	( void );
};

// for convient
using namespace gStdWpnHud;

CBaseMenuTable g_sItemsMenu;
CBaseMenuTable g_sGunCursor;
int	g_iCursorDistance = DEF_CURSOR_DIST;	// in yards.

// commonly used.
static Vector vecs[4];

void gStdWpnHud::Initialize(void)
{
	m_iIdPistolAmmoIcons[CSMW_FIREMODE_OFF]			= NULL;
	m_iIdPistolAmmoIcons[CSMW_FIREMODE_SINGLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_pistol_single.dds");
	m_iIdPistolAmmoIcons[CSMW_FIREMODE_DOUBLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_pistol_double.dds");
	m_iIdPistolAmmoIcons[CSMW_FIREMODE_TRIPLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_pistol_triple.dds");
	m_iIdPistolAmmoIcons[CSMW_FIREMODE_MULTIPLE]	= LoadDDS("modernwarfare//gfx//Ammunition//ammo_pistol_multiple.dds");

	m_iIdRifleAmmoIcons[CSMW_FIREMODE_OFF]			= NULL;
	m_iIdRifleAmmoIcons[CSMW_FIREMODE_SINGLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_rifle_single.dds");
	m_iIdRifleAmmoIcons[CSMW_FIREMODE_DOUBLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_rifle_double.dds");
	m_iIdRifleAmmoIcons[CSMW_FIREMODE_TRIPLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_rifle_triple.dds");
	m_iIdRifleAmmoIcons[CSMW_FIREMODE_MULTIPLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_rifle_multiple.dds");

	m_iIdShotgunAmmoIcons[CSMW_FIREMODE_OFF]		= NULL;
	m_iIdShotgunAmmoIcons[CSMW_FIREMODE_SINGLE]		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_shotgun_single.dds");
	m_iIdShotgunAmmoIcons[CSMW_FIREMODE_DOUBLE]		= NULL;
	m_iIdShotgunAmmoIcons[CSMW_FIREMODE_TRIPLE]		= NULL;
	m_iIdShotgunAmmoIcons[CSMW_FIREMODE_MULTIPLE]	= LoadDDS("modernwarfare//gfx//Ammunition//ammo_shotgun_multiple.dds"); 

	m_iIdRocketAmmoIcon		= LoadDDS("modernwarfare//gfx//Ammunition//ammo_rpgrocket.dds");
	m_iIdGrenadeAmmoIcon	= LoadDDS("modernwarfare//gfx//Ammunition//ammo_grenade.dds");

	for (int i = 1; i <= g_iAmmoTypes; i ++)
	{
		if (!strlen(g_sAmmoData[i].m_szIcon))
			continue;

		if (!strcmp(g_sAmmoData[i].m_szIcon, "grenade"))
		{
			for (int k = 0; k < CSMW_FIREMODE_COUNT; k ++)
				g_sAmmoData[i].m_iIdAmmoIcons[k] = m_iIdGrenadeAmmoIcon;
		}
		else if (!strcmp(g_sAmmoData[i].m_szIcon, "rocket"))
		{
			for (int k = 0; k < CSMW_FIREMODE_COUNT; k ++)
				g_sAmmoData[i].m_iIdAmmoIcons[k] = m_iIdRocketAmmoIcon;
		}
		else if (!strcmp(g_sAmmoData[i].m_szIcon, "pistol"))
		{
			for (int k = 0; k < CSMW_FIREMODE_COUNT; k ++)
				g_sAmmoData[i].m_iIdAmmoIcons[k] = m_iIdPistolAmmoIcons[k];
		}
		else if (!strcmp(g_sAmmoData[i].m_szIcon, "rifle"))
		{
			for (int k = 0; k < CSMW_FIREMODE_COUNT; k ++)
				g_sAmmoData[i].m_iIdAmmoIcons[k] = m_iIdRifleAmmoIcons[k];
		}
		else if (!strcmp(g_sAmmoData[i].m_szIcon, "shotgun"))
		{
			for (int k = 0; k < CSMW_FIREMODE_COUNT; k ++)
				g_sAmmoData[i].m_iIdAmmoIcons[k] = m_iIdShotgunAmmoIcons[k];
		}
	}

	for (int i = 1; i <= g_iSubsTypes; i ++)	// since the subitems is after the normal items, scan them too.
	{
		if (g_sItemData[i].m_iIdWeaponIcon)
			continue;

		char szPath[128];
		sprintf(szPath, "%s//gfx//Weapons//%s.dds", gEngfuncs.pfnGetGameDirectory(), g_sItemData[i].m_szClassname);
		g_sItemData[i].m_iIdWeaponIcon = LoadDDS(szPath);
	}

	// all weapon list here.
	for (int i = 1; i <= g_iItemTypes; i ++)
	{
		CBaseMenuWpn::AddItemByIndex(i)->AddParent(&g_sItemsMenu);
	}

	// list up all cursors
	CBaseCursor::AddByDistance(10)->AddParent(&g_sGunCursor);
	CBaseCursor::AddByDistance(25)->AddParent(&g_sGunCursor);
	CBaseCursor::AddByDistance(50)->AddParent(&g_sGunCursor);
	CBaseCursor::AddByDistance(75)->AddParent(&g_sGunCursor);
	CBaseCursor::AddByDistance(100)->AddParent(&g_sGunCursor);

	// fonts
	m_hFont = gFontFuncs.CreateFont();
	gFontFuncs.AddGlyphSetToFont(m_hFont, "Cambria", HUD_SIZE_STRING_TALL, FW_DONTCARE, 0, 0, 0, 0x0, 0xFFFF);

	// laser
	m_iIdLaserDot = LoadDDS("modernwarfare//gfx//aimdot.dds", &m_iLaserDotWidth, &m_iLaserDotHeight);
}

void gStdWpnHud::VidInit(void)
{
	// when re-load, we need to reset g_iCursorDistance. SV will do the same thing.
	g_iCursorDistance = DEF_CURSOR_DIST;

	// all scope texture list here.
	// since we need gHUD::m_sScreenInfo, so this is special.
	float flRatio = float(gHUD::m_sScreenInfo.iWidth) / float(gHUD::m_sScreenInfo.iHeight);
	const char *pChar = "1620_1080";
	if (fabs(flRatio - 16.0f / 9.0f) < 0.01f)
		pChar = "1920_1080";
	else if (fabs(flRatio - 4.0f / 3.0f) < 0.01f)
		pChar = "1440_1080";
	else if (fabs(flRatio - 16.0f / 10.0f) < 0.01f)
		pChar = "1728_1080";
	else if (fabs(flRatio - 3.0f / 2.0f) < 0.01f)
		pChar = "1620_1080";

	for (int i = 1; i <= g_iItemTypes; i ++)
	{
		if (g_sItemData[i].m_iIdScope)
			continue;

		if (strlen(g_sItemData[i].m_szScopeName))
		{
			char szPath[128];
			sprintf(szPath, "%s//gfx//Scope//%s.dds", gEngfuncs.pfnGetGameDirectory(), g_sItemData[i].m_szScopeName);
			g_sItemData[i].m_iIdScope = LoadDDS(szPath, &g_sItemData[i].m_iScopeCrosshairSize[0], &g_sItemData[i].m_iScopeCrosshairSize[1]);
		}

		if (strlen(g_sItemData[i].m_szScopeShadowName))
		{
			char szPath[128];
			sprintf(szPath, "%s//gfx//Scope//%s_%s.dds", gEngfuncs.pfnGetGameDirectory(), g_sItemData[i].m_szScopeShadowName, pChar);
			g_sItemData[i].m_iIdScopeShadow = LoadDDS(szPath);
		}
	}
}

void gStdWpnHud::CalcVectors(void)
{
	gEngfuncs.pfnAngleVectors(g_pparams.viewangles, m_vecForward, m_vecRight, m_vecUp);

	m_vecLeanCenter = (m_vecForward * 0.5 - m_vecRight).Normalize();
}

void gStdWpnHud::CalcEffects(void)
{
	// swap weapon effects.
	// triggered when no primary weapon or holstering
	if ( (m_sPriWpn.m_pbitsFlags && (*m_sPriWpn.m_pbitsFlags) & WPN_FLAG_HOLSTERING) || !m_sPriWpn.m_bDisplay )
		m_flFadeFactor = max(m_flFadeFactor + (0.0f - m_flFadeFactor) * g_pparams.frametime * 8, 0);
	else
		m_flFadeFactor = min(m_flFadeFactor + (1.0f - m_flFadeFactor) * g_pparams.frametime * 8, 1);

	m_flMiscAlpha = m_clurWeaponIcon.d = m_clurSecondaryIcon.d = m_clurWeaponAmmoNum.d = m_clurSecondaryAmmoNum.d = 255 * m_flFadeFactor;
}

void gStdWpnHud::UpdateWpnName(void)
{
	if (!m_sSedWpn.m_bDisplay && m_sPriWpn.m_pszEndoName)
		wcscpy(m_wszDisplayWpnName, m_sPriWpn.m_pszEndoName);
	else if (m_sPriWpn.m_pszEndoName && m_sSedWpn.m_pszEndoName)
		swprintf(m_wszDisplayWpnName, L"%s + %s", m_sPriWpn.m_pszEndoName, m_sSedWpn.m_pszEndoName);
	else
		wcscpy(m_wszDisplayWpnName, L"");
}

void gStdWpnHud::DrawClip(void)
{
	/*if (GET_CURCLIP() < 0)
		return;

	Vector vecSrc	= GetAmmmoNumOrigin() + 3 * HUD_SIZE_NUM_SMALL * m_vecLeanCenter;

	g_cNumberDrawer.Draw3D(GET_CURCLIP(), vecSrc, m_vecLeanCenter, m_vecUp, HUD_SIZE_NUM_LARGE);*/
}

void gStdWpnHud::DrawAmmo(void)
{
	// didnt set the pointer? well, dont draw it.
	if (!m_sPriWpn.m_piBpNum)
		return;

	// if dont have a max value, set to 20.
	if (!m_sPriWpn.m_piBpMax)
		m_sPriWpn.m_piBpMax = &MAX_BACKUP;

	/******************
		main weapon
	******************/

	// ammo name
	swprintf(m_wszAmmoWords, L"%s", m_sPriWpn.m_pszBpName);
	gFontFuncs.DrawSetTextFont(m_hFont);
	gFontFuncs.DrawSetText3DPos(GetAmmmoNameOrigin());
	gFontFuncs.DrawSetText3DDir(m_vecForward, -m_vecLeanCenter, m_vecUp);
	gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetTextColor(255, 255, 255, m_flMiscAlpha);
	gFontFuncs.DrawPrint3DText(m_wszAmmoWords);

	// magazine count.
	float flAmmoPercent = SET_RANGE(float(*m_sPriWpn.m_piBpNum) / float(*m_sPriWpn.m_piBpMax), 1.0f, 0);
	m_clurWeaponAmmoNum.norm = Vector(255, 16, 16) + flAmmoPercent * Vector(-33, 239, 206);

	swprintf(m_wszAmmoWords, L"%d", *m_sPriWpn.m_piBpNum);
	gFontFuncs.DrawSetText3DPos(GetAmmmoNumOrigin());
	gFontFuncs.DrawSetTextColor(m_clurWeaponAmmoNum.norm.x, m_clurWeaponAmmoNum.norm.y, m_clurWeaponAmmoNum.norm.z, m_clurWeaponAmmoNum.d);
	gFontFuncs.DrawPrint3DText(m_wszAmmoWords);

	/******************
		2nd weapon
	******************/

	if (m_sSedWpn.m_pszBpName)
	{
		swprintf(m_wszAmmoWords, L"%s", m_sSedWpn.m_pszBpName);
		gFontFuncs.DrawSetTextFont(m_hFont);
		gFontFuncs.DrawSetText3DPos(GetSecondaryAmmoNameOrigin());
		gFontFuncs.DrawSetText3DDir(m_vecForward, -m_vecLeanCenter, m_vecUp);
		gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
		gFontFuncs.DrawSetTextColor(255, 255, 255, m_flMiscAlpha);
		gFontFuncs.DrawPrint3DText(m_wszAmmoWords);
	}

	if (!m_sSedWpn.m_piBpNum)
		return;

	if (!m_sSedWpn.m_piBpMax)
		m_sSedWpn.m_piBpMax = &MAX_BACKUP;

	flAmmoPercent = SET_RANGE(float(*m_sSedWpn.m_piBpNum) / float(*m_sSedWpn.m_piBpMax), 1.0f, 0);
	m_clurSecondaryAmmoNum.norm = Vector(255, 16, 16) + flAmmoPercent * Vector(-33, 239, 206);

	swprintf(m_wszAmmoWords, L"%d", *m_sSedWpn.m_piBpNum);
	gFontFuncs.DrawSetText3DPos(GetSecondaryAmmoNumOrigin());
	gFontFuncs.DrawSetTextColor(m_clurSecondaryAmmoNum.norm.x, m_clurSecondaryAmmoNum.norm.y, m_clurSecondaryAmmoNum.norm.z, m_clurSecondaryAmmoNum.d);
	gFontFuncs.DrawPrint3DText(m_wszAmmoWords);
}

void gStdWpnHud::DrawFiremode(void)
{
	if (!m_sPriWpn.m_piszFireModeIcons || !m_sPriWpn.m_piFireMode || (*m_sPriWpn.m_piFireMode) <= CSMW_FIREMODE_OFF || (*m_sPriWpn.m_piFireMode) >= CSMW_FIREMODE_COUNT)
		return;

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_sPriWpn.m_piszFireModeIcons[*m_sPriWpn.m_piFireMode]);
	glColor4ub(255, 255, 255, m_flMiscAlpha);

	vecs[0] = GetFiremodeOrigin();
	vecs[1] = vecs[0] - m_vecLeanCenter * HUD_SIZE_FIREMODE_ICON;
	vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_FIREMODE_ICON;
	vecs[3] = vecs[0] - m_vecUp * HUD_SIZE_FIREMODE_ICON;

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();

	if (!m_sSedWpn.m_piszFireModeIcons || !m_sSedWpn.m_piFireMode || (*m_sSedWpn.m_piFireMode) <= CSMW_FIREMODE_OFF || (*m_sSedWpn.m_piFireMode) >= CSMW_FIREMODE_COUNT)
		return;

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_sSedWpn.m_piszFireModeIcons[*m_sSedWpn.m_piFireMode]);
	glColor4ub(255, 255, 255, m_flMiscAlpha);

	vecs[0] = GetSecondaryFiremodeOrigin();
	vecs[1] = vecs[0] - m_vecLeanCenter * HUD_SIZE_FIREMODE_ICON;
	vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_FIREMODE_ICON;
	vecs[3] = vecs[0] - m_vecUp * HUD_SIZE_FIREMODE_ICON;

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();
}

void gStdWpnHud::DrawCurWeapon(void)
{
	if (!m_sPriWpn.m_piWpnDxt || !(*m_sPriWpn.m_piWpnDxt))
		return;

	if (!m_sPriWpn.m_piClip || !m_sPriWpn.m_piClipMax)
		m_sPriWpn.m_piClip = m_sPriWpn.m_piClipMax = &MAX_BACKUP;	// just randomly choose a number..

	// weapon icon
	m_clurWeaponIcon.norm = Vector(255, 16, 16) + SET_RANGE(float(*m_sPriWpn.m_piClip) / float(*m_sPriWpn.m_piClipMax), 1.0f, 0) * Vector(0, 239, 239);

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, *m_sPriWpn.m_piWpnDxt);
	glColor4ub(m_clurWeaponIcon.norm.x, m_clurWeaponIcon.norm.y, m_clurWeaponIcon.norm.z, m_clurWeaponIcon.d);

	vecs[0] = GetWeaponIconOrigin();
	vecs[1] = vecs[0] - m_vecLeanCenter * HUD_SIZE_WPNICON_LEN;
	vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_WPNICON_TALL;
	vecs[3] = vecs[0] - m_vecUp * HUD_SIZE_WPNICON_TALL;

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();

	// weapon name.
	gFontFuncs.DrawSetTextFont(m_hFont);
	gFontFuncs.DrawSetText3DPos(GetWeaponNameOrigin());
	gFontFuncs.DrawSetText3DDir(m_vecForward, -m_vecLeanCenter, m_vecUp);
	gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetTextColor(255, 255, 255, m_flMiscAlpha);
	gFontFuncs.DrawPrint3DTextVertical(m_wszDisplayWpnName);

	if (!m_sSedWpn.m_piWpnDxt || !(*m_sSedWpn.m_piWpnDxt))
		return;

	if (!m_sSedWpn.m_piClip || !m_sSedWpn.m_piClipMax)
		m_sSedWpn.m_piClip = m_sSedWpn.m_piClipMax = &MAX_BACKUP;

	// secondary icon
	m_clurSecondaryIcon.norm = Vector(255, 16, 16) + SET_RANGE(float(*m_sSedWpn.m_piClip) / float(*m_sSedWpn.m_piClipMax), 1.0f, 0) * Vector(0, 239, 239);

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, *m_sSedWpn.m_piWpnDxt);
	glColor4ub(m_clurSecondaryIcon.norm.x, m_clurSecondaryIcon.norm.y, m_clurSecondaryIcon.norm.z, m_clurSecondaryIcon.d);

	vecs[0] = GetSecondaryIconOrigin();
	vecs[1] = vecs[0] - m_vecLeanCenter * HUD_SIZE_WPNICON_LEN;
	vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_WPNICON_TALL;
	vecs[3] = vecs[0] - m_vecUp * HUD_SIZE_WPNICON_TALL;

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();
}

void gStdWpnHud::DrawLaserDot(void)
{
	// no gun, no laser.
	if (!g_pPlayerActivityItem)
		return;

	glPushAttrib(GL_ALL_ATTRIB_BITS);	// Save current depth range value
	glDepthRange(0.3, 0.4);				// Change depth range for laser dot drawing, VMDL draw at 0.1~0.29

	pmtrace_t tr;
	Vector vecEnd = Vector(g_pparams.vieworg) + Vector(g_pparams.forward) * 9999.0f;

	// traceline funcs. NO NEED EV_SetSolidPlayers(), or the Traceline will hit local player entity.
	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	gEngfuncs.pEventAPI->EV_PushPMStates();
	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );	// a point.
	gEngfuncs.pEventAPI->EV_PlayerTrace( g_pPlayerActivityItem->GetMuzzleOrigin(), vecEnd, PM_STUDIO_BOX, -1, &tr );
	gEngfuncs.pEventAPI->EV_PopPMStates();

	// this texture is always facing to player.
	vecs[0]	= tr.endpos + m_iLaserDotHeight * 0.5f * LASER_SCALE * Vector(g_pparams.up) - m_iLaserDotWidth * 0.5f * LASER_SCALE * Vector(g_pparams.right);
	vecs[1]	= tr.endpos + m_iLaserDotHeight * 0.5f * LASER_SCALE * Vector(g_pparams.up) + m_iLaserDotWidth * 0.5f * LASER_SCALE * Vector(g_pparams.right);
	vecs[2]	= tr.endpos - m_iLaserDotHeight * 0.5f * LASER_SCALE * Vector(g_pparams.up) + m_iLaserDotWidth * 0.5f * LASER_SCALE * Vector(g_pparams.right);
	vecs[3]	= tr.endpos - m_iLaserDotHeight * 0.5f * LASER_SCALE * Vector(g_pparams.up) - m_iLaserDotWidth * 0.5f * LASER_SCALE * Vector(g_pparams.right);

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_iIdLaserDot);
	glColor4ub(255, 255, 255, 255);

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();

	glPopAttrib();						// Restore depth range value
}

void gStdWpnHud::DrawLaserDot2D(void)
{
	// no gun, no laser.
	if (!g_pPlayerActivityItem)
		return;

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_iIdLaserDot);
	glColor4ub(255, 255, 255, 255);

	vecs[0] = Vector2D(gHUD::m_sScreenInfo.iWidth * 0.5f - m_iLaserDotWidth * 0.5f * LASER_SCALE, gHUD::m_sScreenInfo.iHeight * 0.5f - m_iLaserDotHeight * 0.5f * LASER_SCALE);
	vecs[1] = Vector2D(gHUD::m_sScreenInfo.iWidth * 0.5f + m_iLaserDotWidth * 0.5f * LASER_SCALE, gHUD::m_sScreenInfo.iHeight * 0.5f - m_iLaserDotHeight * 0.5f * LASER_SCALE);
	vecs[2] = Vector2D(gHUD::m_sScreenInfo.iWidth * 0.5f + m_iLaserDotWidth * 0.5f * LASER_SCALE, gHUD::m_sScreenInfo.iHeight * 0.5f + m_iLaserDotHeight * 0.5f * LASER_SCALE);
	vecs[3] = Vector2D(gHUD::m_sScreenInfo.iWidth * 0.5f - m_iLaserDotWidth * 0.5f * LASER_SCALE, gHUD::m_sScreenInfo.iHeight * 0.5f + m_iLaserDotHeight * 0.5f * LASER_SCALE);

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, 0);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, 0);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, 0);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, 0);
	glEnd();
}

Vector gStdWpnHud::GetWeaponNameOrigin(void)
{
	int iWidth, iHeight;
	gFontFuncs.GetTextSize(m_hFont, m_wszDisplayWpnName, &iWidth, &iHeight);

	return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL - HUD_SIZE_GAP) * m_vecLeanCenter * m_flFadeFactor + (iWidth) * m_vecUp;
}

Vector gStdWpnHud::GetAmmmoNameOrigin(void)
{
	if (m_sSedWpn.m_bDisplay && !m_sSedWpn.m_piWpnDxt)	// for weapon like ARC3
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN - HUD_SIZE_FIREMODE_ICON - HUD_SIZE_GAP) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
	else if (m_sSedWpn.m_bDisplay)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN - HUD_SIZE_FIREMODE_ICON - HUD_SIZE_GAP) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + 2 * HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
	else
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN - HUD_SIZE_FIREMODE_ICON - HUD_SIZE_GAP) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
}

Vector gStdWpnHud::GetAmmmoNumOrigin(void)
{
	int iWidth, iHeight;
	gFontFuncs.GetTextSize(m_hFont, m_wszAmmoWords, &iWidth, &iHeight);

	if (m_sSedWpn.m_bDisplay && !m_sSedWpn.m_piWpnDxt)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
	else if (m_sSedWpn.m_bDisplay)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
	else
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL) * m_vecUp;
}

Vector gStdWpnHud::GetWeaponIconOrigin(void)
{
	if (m_sSedWpn.m_bDisplay && !m_sSedWpn.m_piWpnDxt)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_TALL) * m_vecUp;
	else if (m_sSedWpn.m_bDisplay)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + 2 * HUD_SIZE_WPNICON_TALL) * m_vecUp;
	else
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_WPNICON_TALL) * m_vecUp;
}

Vector gStdWpnHud::GetFiremodeOrigin(void)
{
	if (m_sSedWpn.m_bDisplay && !m_sSedWpn.m_piWpnDxt)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
	if (m_sSedWpn.m_bDisplay)
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL + 2 * HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
	else
		return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_WPNICON_TALL + HUD_SIZE_STRING_TALL) * m_vecUp;
}

Vector gStdWpnHud::GetSecondaryAmmoNameOrigin(void)
{
	return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN - HUD_SIZE_FIREMODE_ICON - HUD_SIZE_GAP) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL) * m_vecUp;
}

Vector gStdWpnHud::GetSecondaryAmmoNumOrigin(void)
{
	int iWidth, iHeight;
	gFontFuncs.GetTextSize(m_hFont, m_wszAmmoWords, &iWidth, &iHeight);

	return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_STRING_TALL * 2) * m_vecUp;
}

Vector gStdWpnHud::GetSecondaryIconOrigin(void)
{
	return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_FIREMODE_ICON + HUD_SIZE_WPNICON_TALL) * m_vecUp;
}

Vector gStdWpnHud::GetSecondaryFiremodeOrigin(void)
{
	return gHUD::TriDimnHud::m_vecScreenCorner[2] + (HUD_SIZE_RUNING_EDGE + HUD_SIZE_STRING_TALL + HUD_SIZE_WPNICON_LEN) * m_vecLeanCenter * m_flFadeFactor + (HUD_SIZE_FIREMODE_ICON) * m_vecUp;
}

void gStdWpnHud::Think3D(void)
{
	gStdWpnHud::CalcVectors();
	gStdWpnHud::CalcEffects();
}

void gStdWpnHud::Draw3D(void)
{
	gStdWpnHud::DrawClip();
	gStdWpnHud::DrawAmmo();
	gStdWpnHud::DrawFiremode();
	gStdWpnHud::DrawCurWeapon();
}

/*
================================
	gStdWpnHud::CBaseMenuWpn

General style to show a weapon in menu.
================================
*/
CBaseMenuWpn::CBaseMenuWpn(void)
{
	m_iIndex = 0;
}

CBaseMenuWpn *CBaseMenuWpn::AddItemByName(const char *classname)
{
	CBaseMenuWpn *pNew = new CBaseMenuWpn;
	pNew->m_iIndex = GetWeaponTypeFromName(classname);
	pNew->m_bCanDelete = true;
	wcscpy(pNew->m_wszString, g_sItemData[pNew->m_iIndex].m_wszEndoName);

	return pNew;
}

CBaseMenuWpn *CBaseMenuWpn::AddItemByIndex(int iType)
{
	CBaseMenuWpn *pNew = new CBaseMenuWpn;
	pNew->m_iIndex = iType;
	pNew->m_bCanDelete = true;
	wcscpy(pNew->m_wszString, g_sItemData[iType].m_wszEndoName);

	return pNew;
}

void CBaseMenuWpn::Select(void)
{
	GiveWeapon(m_iIndex);
}

/*
================================
	gStdWpnHud::CBaseMenuAcc

General style to show an Accessory in the menu.
================================
*/
CBaseMenuAcc::CBaseMenuAcc(void)
{
	m_bitsIndex		= 0;
	m_bitsConflict	= 0;
	m_pBitsCurAcc	= NULL;
}

CBaseMenuAcc *CBaseMenuAcc::AddByIndex(unsigned *pBitsCurAcc, int iType)
{
	CBaseMenuAcc *pNew	= new CBaseMenuAcc;

	pNew->UpdateInfo(pBitsCurAcc, iType);
	pNew->m_bCanDelete = true;	// IMPORTANT!!!

	return pNew;
}

void CBaseMenuAcc::Think(void)
{
	if (!m_pBitsCurAcc)
		return;

	if (!((*m_pBitsCurAcc) & m_bitsIndex))
		m_sColor = UnpackRGB(RGB_WHITE);
	else
		m_sColor = UnpackRGB(RGB_GREENISH);
}

void CBaseMenuAcc::Select(void)
{
	if (!m_pBitsCurAcc)
		return;

	if ((*m_pBitsCurAcc) & m_bitsConflict)
		(*m_pBitsCurAcc) &= ~m_bitsConflict;
	
	if ((*m_pBitsCurAcc) & m_bitsIndex)
	{
		(*m_pBitsCurAcc) &= ~m_bitsIndex;
	}
	else
	{
		(*m_pBitsCurAcc) |= m_bitsIndex;
	}
}

void CBaseMenuAcc::UpdateInfo(unsigned *pBitsCurAcc, int iType)
{
	m_bitsIndex		= iType;
	m_pBitsCurAcc	= pBitsCurAcc;

	char *pToken = "#MW_Acc_Error";
	switch (iType)
	{
	case ACC_LASER:
		pToken = "#MW_Acc_Laser";
		break;
	case ACC_HOLO:
		pToken = "#MW_Acc_Holograph";
		m_bitsConflict = ACC_DOT|ACC_ACOG|ACC_ROUND;
		break;
	case ACC_DOT:
		pToken = "#MW_Acc_Reddot";
		m_bitsConflict = ACC_HOLO|ACC_ACOG|ACC_ROUND;
		break;
	case ACC_ACOG:
		pToken = "#MW_Acc_ACOG";
		m_bitsConflict = ACC_HOLO|ACC_DOT|ACC_ROUND;
		break;
	case ACC_ROUND:
		pToken = "#MW_Acc_Round";
		m_bitsConflict = ACC_HOLO|ACC_DOT|ACC_ACOG;
		break;
	case ACC_SILENCER:
		pToken = "#MW_Acc_Silencer";
		m_bitsConflict = ACC_MUZZLEBREAKER|ACC_FLASHHIDER|ACC_COMPENSATOR;
		break;
	case ACC_MUZZLEBREAKER:
		pToken = "#MW_Acc_MuzzleBreaker";
		m_bitsConflict = ACC_SILENCER|ACC_FLASHHIDER|ACC_COMPENSATOR;
		break;
	case ACC_FLASHHIDER:
		pToken = "#MW_Acc_FlashHider";
		m_bitsConflict = ACC_SILENCER|ACC_MUZZLEBREAKER|ACC_COMPENSATOR;
		break;
	case ACC_COMPENSATOR:
		pToken = "#MW_Acc_Compensator";
		m_bitsConflict = ACC_SILENCER|ACC_MUZZLEBREAKER|ACC_FLASHHIDER;
		break;
	default:
		pToken = "#MW_Acc_Error";
		break;
	}

	wchar_t	*pChars = gpLocalize->Find(pToken);
	if (pChars)
	{
		wcsncpy_s(m_wszString, pChars, _TRUNCATE);
	}
	else
	{
		wchar_t *sz = ANSIToUnicode(pToken);
		wcsncpy_s( m_wszString, sz, _TRUNCATE);
	}
}

/*
===============================
	gStdWpnHud::CBaseCursor

List all avaliable cursor options
===============================
*/

CBaseCursor * gStdWpnHud::CBaseCursor::AddByDistance(int iDistance)
{
	CBaseCursor *pNew = new CBaseCursor;
	if (!pNew)
		return nullptr;

	pNew->m_iDistance = iDistance;
	pNew->m_bCanDelete = true;

	wchar_t	pChars[16];
	UTIL_SearchInLocalize("#MW_Units_Yards", pChars);

	swprintf(pNew->m_wszString, L"%d %s", iDistance, pChars);

	return pNew;
}

void gStdWpnHud::CBaseCursor::Think(void)
{
	if (g_iCursorDistance != m_iDistance)
	{
		m_sColor.r = 255;
		m_sColor.g = 255;
		m_sColor.b = 255;
	}
	else
	{
		m_sColor = UnpackRGB(RGB_GREENISH);
	}
}

void gStdWpnHud::CBaseCursor::Select(void)
{
	g_iCursorDistance = m_iDistance;

	SU_Begin		(GLB_CMD_CURSOR);
	SU_WriteInteger	(g_iCursorDistance);
	SU_End			( );

	CloseMenu();
}
