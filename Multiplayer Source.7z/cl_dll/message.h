#ifndef _MESSAGE_H_
#define _MESSAGE_H_

void InstallMessageHook(void);

int MsgFunc_ResetHUD(const char *pszName, int iSize, void *pbuf );
int MsgFunc_ViewMode( const char *pszName, int iSize, void *pbuf );
int MsgFunc_InitHUD( const char *pszName, int iSize, void *pbuf );
int MsgFunc_GameMode(const char *pszName, int iSize, void *pbuf );
int MsgFunc_Damage(const char *pszName, int iSize, void *pbuf );
int MsgFunc_Concuss( const char *pszName, int iSize, void *pbuf );
int MsgFunc_SetFOV(const char *pszName,  int iSize, void *pbuf);
int MsgFunc_GunShot(const char *pszName,  int iSize, void *pbuf);
int MsgFunc_Sound(const char *pszName,  int iSize, void *pbuf);
int MsgFunc_HudText(const char *pszName,  int iSize, void *pbuf);
int MsgFunc_ExploEfx(const char *pszName,  int iSize, void *pbuf);
int MsgFunc_EntMarker(const char *pszName,  int iSize, void *pbuf);













































#endif