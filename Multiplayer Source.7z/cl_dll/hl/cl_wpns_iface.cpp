/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#include <stdarg.h>

#include "hud.h"
#include "cl_util.h"

#include "eiface.h"
#include "demo_api.h"
#include "pm_defs.h"
#include "event_api.h"
#include "r_efx.h"
#include "view.h"
#include "cl_wpns.h"
#include "GameStudioModelRenderer.h"
#include "hud_wpn.h"
#include "hud_menu.h"
#include "cl_wpn_iface.h"


float g_flApplyVel = 0.0;
int   g_irunninggausspred = 0;
local_state_s	g_sLocalState;
fakeplayer_t	g_sFakePlayer;

/*
======================
Com_Weapon.cpp init

memset(xxx, NULL, sizeof(xxx));
======================
*/
void Com_hl_Weapons_Init(void)
{
	memset(&g_sLocalState,	NULL,	sizeof(g_sLocalState));
	memset(&g_sFakePlayer,	NULL,	sizeof(g_sFakePlayer));

	// WARING: NEVER ZERO HERE!
	g_sFakePlayer.m_flMaxSpeed = 260.0f;

	gEngfuncs.pfnAddCommand("give",				GiveWeapon);
	gEngfuncs.pfnAddCommand("switchswitcher",	SwitchSwitcher);
	gEngfuncs.pfnAddCommand("changemode",		ChangeMode);
	gEngfuncs.pfnAddCommand("drop",				Dropped);
	gEngfuncs.pfnAddCommand("setacc",			SetAccessory);
	gEngfuncs.pfnAddCommand("showallitem",		DrawWeaponMenu);
	gEngfuncs.pfnAddCommand("quickknife",		QuickKnife);
	gEngfuncs.pfnAddCommand("cursor",			AdjustCursor);
	gEngfuncs.pfnAddCommand("destroy",			Destroy);
	// quickthrow moved to input.cpp
}

/*
======================
AlertMessage

Print debug messages to console
======================
*/
void AlertMessage( ALERT_TYPE atype, char *szFmt, ... )
{
	va_list		argptr;
	static char	string[1024];
	
	va_start (argptr, szFmt);
	vsprintf (string, szFmt,argptr);
	va_end (argptr);

	gEngfuncs.Con_Printf( "cl:  " );
	gEngfuncs.Con_Printf( string );
}

/*
=====================
UTIL_ServerCmd
=====================
*/

void UTIL_ServerCmd( char *szFmt, ... )
{
	va_list		argptr;
	static char	string[1024];
	
	va_start (argptr, szFmt);
	vsprintf (string, szFmt,argptr);
	va_end (argptr);

	gEngfuncs.pfnServerCmd( string );
	int i = strlen(string);
}

//Returns if it's multiplayer.
//Mostly used by the client side weapons.
bool bIsMultiplayer ( void )
{
	return gEngfuncs.GetMaxClients() == 1 ? 0 : 1;
}

/*
=====================
GiveWeapon

Give a weapon on clinet.
=====================
*/

CBaseWeapons *GiveWeapon(int iType)
{
	// TODO: inform sv.

	if (iType <= 0 || iType > g_iItemTypes || g_pparams.health <= 0)
		return NULL;

	if (!g_pWeaponChainRoot)
	{
		g_pWeaponChainRoot = CreateWeapon(g_sItemData[iType].m_szClassname);
		g_pWeaponChainRoot->m_iItemType = iType;
		g_pWeaponChainRoot->OnSpawnPost();
		SwitchWeapon(g_pWeaponChainRoot);	// 'cause you dont have any weapon...

		return g_pWeaponChainRoot;
	}

	CBaseWeapons *pChainEnd = g_pWeaponChainRoot;

	while (pChainEnd->m_pNext)
	{
		pChainEnd = pChainEnd->m_pNext;
	}

	pChainEnd->m_pNext = CreateWeapon(g_sItemData[iType].m_szClassname);
	pChainEnd->m_pNext->m_iItemType = iType;
	pChainEnd->m_pNext->OnSpawnPost();

	return pChainEnd->m_pNext;
}

void GiveWeapon(void)
{
	int iType = GetWeaponTypeFromName(gEngfuncs.Cmd_Argv(1));
	GiveWeapon(iType);
}

/*
=====================
SwitchSwitcher
=====================
*/

void SwitchSwitcher(void)
{
	if (g_pPlayerActivityItem)
		g_pPlayerActivityItem->SwitchSwitcher();
}

/*
=====================
ChangeMode

Actrually it's alt fire.
=====================
*/

void ChangeMode(void)
{
	if (g_pPlayerActivityItem)
		g_pPlayerActivityItem->ChangeMode();
}

/*
=====================
Dropped

Dropped a weapon from client. Spawn a CWeaponBox on server.
=====================
*/

void Dropped(void)
{
	if (gEngfuncs.Cmd_Argc() == 1)
	{
		if (g_pPlayerActivityItem)
		{
			g_pPlayerActivityItem->ItemDropped();
		}

		return;
	}

	int iType		= GetWeaponTypeFromName(gEngfuncs.Cmd_Argv(1));
	wpn_c *pItem	= UTIL_UserHasWpn(iType);

	if (pItem)
		pItem->ItemDropped();
}

/*
=====================
SetAccessory

Set the accessories of current weapon.
=====================
*/
void SetAccessory(void)
{
	if (g_pPlayerActivityItem)
		g_pPlayerActivityItem->HUD_AccMenu();
}

/*
=====================
QuickKnife

Melee enemy nearby.
=====================
*/
void QuickKnife(void)
{
	if (g_pPlayerActivityItem)
		g_pPlayerActivityItem->Melee();
}

/*
=====================
DrawWeaponMenu

Show all weapon in .txt file.
=====================
*/
void DrawWeaponMenu(void)
{
	HUD_SwitchMenu(&g_sItemsMenu);
}

/*
=====================
AdjustCursor
=====================
*/
void AdjustCursor(void)
{
	HUD_SwitchMenu(&g_sGunCursor);
}

/*
=====================
Destroy
=====================
*/
void Destroy(void)
{
	if (gEngfuncs.Cmd_Argc() == 1)
	{
		if (g_pPlayerActivityItem)
		{
			g_pPlayerActivityItem->ItemKill();
		}

		return;
	}

	int iType		= GetWeaponTypeFromName(gEngfuncs.Cmd_Argv(1));
	wpn_c *pItem	= UTIL_UserHasWpn(iType);

	if (pItem)
		pItem->ItemKill();
}



/*
=====================
CreateWeapon

Create a weapon by name and return its name.
Note: this function doesn't include setting a m_iItemType.
=====================
*/
CBaseWeapons *CreateWeapon(const char *sz)
{
	// use LINK_CLASS_TO_ITEM here.
	LINK_CLASS_TO_ITEM(wpn_knife,		CKnife);
	LINK_CLASS_TO_ITEM(wpn_arc3,		CARC3);
	LINK_CLASS_TO_ITEM(wpn_g18c,		CGlock18C);
	LINK_CLASS_TO_ITEM(wpn_aa12,		CAA12);
	LINK_CLASS_TO_ITEM(wpn_ar15custom,	CAR15);
	LINK_CLASS_TO_ITEM(wpn_m1014,		CM1014);
	LINK_CLASS_TO_ITEM(wpn_msr,			CMSR);
	LINK_CLASS_TO_ITEM(wpn_hl_gauss,	CGauss);
	LINK_CLASS_TO_ITEM(wpn_acr,			CMasada);
	LINK_CLASS_TO_ITEM(wpn_mk46,		CMK46);
	LINK_CLASS_TO_ITEM(wpn_cm901,		CCM901);
	LINK_CLASS_TO_ITEM(wpn_fn57,		CFN57);
	LINK_CLASS_TO_ITEM(wpn_92f,			C92F);
	LINK_CLASS_TO_ITEM(wpn_93r,			C93R);
	LINK_CLASS_TO_ITEM(wpn_an94,		CAN94);
	LINK_CLASS_TO_ITEM(wpn_rpg7,		CRPG7);
	LINK_CLASS_TO_ITEM(wpn_g36c,		CG36C);
	LINK_CLASS_TO_ITEM(wpn_m16a4,		CM16A4);
	LINK_CLASS_TO_ITEM(wpn_mp5k,		CMP5KPDW);
	LINK_CLASS_TO_ITEM(wpn_scarh,		CSCARH);
	LINK_CLASS_TO_ITEM(wpn_qbz97,		CQBZ97);
	LINK_CLASS_TO_ITEM(wpn_p90,			CP90);
	LINK_CLASS_TO_ITEM(wpn_ump45,		CUMP45);
	LINK_CLASS_TO_ITEM(wpn_xm29,		CXM29);
	LINK_CLASS_TO_ITEM(gr_m67,			CBaseGrenade);

	return new CBaseWeapons;
}


/*
=====================
HUD_WeaponsPostThink

Run Weapon firing code on client
=====================
*/

void HUD_WeaponsPostThink( local_state_s *from, local_state_s *to, usercmd_t *cmd, double time, unsigned int random_seed )
{
	memcpy(to, from, sizeof(to));

	// for safety at view.cpp
	if (g_sFakePlayer.m_flMaxSpeed < 1)
		g_sFakePlayer.m_flMaxSpeed = from->client.maxspeed;

	// Which buttsons chave changed
	int buttonsChanged = (g_sFakePlayer.m_afButtonLast ^ cmd->buttons);	// These buttons have changed this frame

	// Debounced button codes for pressed/released
	// The changed ones still down are "pressed"
	g_sFakePlayer.m_afButtonPressed =  buttonsChanged & cmd->buttons;	
	// The ones not down are "released"
	g_sFakePlayer.m_afButtonReleased = buttonsChanged & (~cmd->buttons);

	if (g_sFakePlayer.m_flResumeZoom && g_sFakePlayer.m_flResumeZoom <= UTIL_WeaponTimeBase())	// FIXME
	{
		gFovManager::Set(g_sFakePlayer.m_flLastZoom);
		g_sFakePlayer.m_flResumeZoom = 0;
	}

	if (g_sFakePlayer.m_flEjectBrass && g_sFakePlayer.m_flEjectBrass <= UTIL_WeaponTimeBase())
	{
		SpawnShell(gEngfuncs.GetLocalPlayer(), MODEL_INDEX(g_sFakePlayer.m_pBrassType->m_szShellModel), g_pViewEnt->attachment[g_sFakePlayer.m_iBrassAttachment], g_sFakePlayer.m_pBrassType->m_iShellSoundType, g_sFakePlayer.m_pBrassType->m_iShellBody);

		g_sFakePlayer.m_pBrassType = NULL;
		g_sFakePlayer.m_flEjectBrass = 0;
		g_sFakePlayer.m_iBrassAttachment = 0;
	}

	// if we dont add this check, the rate of HUD_WeaponsPostThink() being executed will TOTALLY DIFFERENT from g_pparams.frametime
	static double s_flNextFrame = 0;
	if (g_pPlayerActivityItem && s_flNextFrame <= g_flClientTime)
	{
		g_pPlayerActivityItem->ItemPreFrame();
		s_flNextFrame = max(s_flNextFrame + g_flClientFrame, g_flClientTime);
	}

	// LUNA: I don't know why, but enable this code will cause CL no model at all when you're not host.
	/*to->client.viewmodel				= MODEL_INDEX(g_pViewModel->name);*/

	to->client.fov						= gFovManager::m_flFOV;
	to->client.weaponanim				= (g_pPlayerActivityItem ? g_pPlayerActivityItem->m_iDisplayingAnim : 0);
	to->client.maxspeed					= g_sFakePlayer.m_flMaxSpeed;

	memcpy(&g_sLocalState, to, sizeof(g_sLocalState));
}

/*
=====================
HUD_PostRunCmd

Client calls this during prediction, after it has moved the player and updated any info changed into to->
time is the current client clock based on prediction
cmd is the command that caused the movement, etc
runfuncs is 1 if this is the first time we've predicted this command.  If so, sounds and effects should play, otherwise, they should
be ignored
=====================
*/
void _DLLEXPORT HUD_PostRunCmd( struct local_state_s *from, struct local_state_s *to, struct usercmd_s *cmd, int runfuncs, double time, unsigned int random_seed )
{
	if ( cl_lw && cl_lw->value && g_pparams.health > 0 )	// not more weapon function on death.
	{
		HUD_WeaponsPostThink( from, to, cmd, time, random_seed );
	}
	else if (g_pparams.health <= 0)
	{
		g_c2ndVMDL.m_bVisible = false;	// remove 2nd vmdl when dead.
	}

	if ( g_irunninggausspred == 1 )
	{
		Vector forward;
		gEngfuncs.pfnAngleVectors( g_pparams.viewangles, forward, NULL, NULL );
		to->client.velocity = to->client.velocity - forward * g_flApplyVel * 5; 
		g_irunninggausspred = false;
	}
}