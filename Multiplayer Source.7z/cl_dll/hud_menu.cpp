#include "hud.h"
#include "cl_util.h"
#include <string.h>
#include <stdio.h>
#include "cl_entity.h"
#include "view.h"
#include "cl_wpns.h"
#include "hud_menu.h"
#include "hud_wpn.h"

#include <windows.h>
#include <stdio.h>
#include <triangleapi.h>
#include <gl/gl.h>
#include "vector.h"
#include "const.h"
#include <com_model.h>
#include <studio.h>
#include "dxt.h"

#include "DrawFonts.h"

// some defs only used in this cpp.
#define	CL_GLB_TIME			g_flClientTime
#define CL_GLB_FRAME		g_flClientFrame
#define HUD_SCREENCORNER	gHUD::TriDimnHud::m_vecScreenCorner
#define HUD_DIR_UP			gHUD::TriDimnHud::m_vecUp
#define HUD_DIR_RIGHT		gHUD::TriDimnHud::m_vecRight
#define HUD_DIR_FORWARD		gHUD::TriDimnHud::m_vecForward
#define HUD_FONT			gStdWpnHud::m_hFont	// use hud_wpn.cpp 's font is good enough.

// only a menu can display at once.
CBaseMenuTable *g_pCurrentMenu = NULL;

CBaseMenuItem::CBaseMenuItem(void)
{
	m_pNext		= NULL;
	m_pParent	= NULL;
	m_bCanDelete= NULL;

	m_sColor.r	= 255;
	m_sColor.g	= 255;
	m_sColor.b	= 255;

	memset(m_wszString,	NULL,	sizeof(m_wszString));
}

CBaseMenuItem::~CBaseMenuItem(void)
{
	QuitFromMenu();
}

CBaseMenuTable::CBaseMenuTable(void)
{
	m_pFirstChild	= NULL;
	m_pSwitchTo		= NULL;
	m_vecLeanCenter	= Vector();

	memset(m_wszBuffer,	NULL,	sizeof(m_wszBuffer));
	
	m_flMiscAlpha	= NULL;
	m_bShouldDraw	= NULL;

	memset(m_wszTitle,	NULL,	sizeof(m_wszTitle));
	m_iCurrentPage	= 1;	// page 0 makes no sence.
}

CBaseMenuTable::~CBaseMenuTable(void)
{
	RemoveAllItems();

	if (g_pCurrentMenu == this)
		g_pCurrentMenu = m_pSwitchTo;
}

/*
===================================
	CBaseMenuItem::QuitFromMenu

Remove pThis from its parent, and fix chain.
===================================
*/
bool CBaseMenuItem::QuitFromMenu(void)
{
	// if it have no parent, skip chain fix.
	if (!m_pParent || !m_pParent->m_pFirstChild)
		return false;

	// if killing chain root, give chair to his next.
	if (m_pParent->m_pFirstChild == this)
	{
		m_pParent->m_pFirstChild = m_pNext;
		return true;
	}

	// otherwise, which means at least two items in chain, and m_pParent->m_pFirstChild->m_pNext != NULL
	CBaseMenuItem *pl	= m_pParent->m_pFirstChild;
	CBaseMenuItem *p	= m_pParent->m_pFirstChild->m_pNext;

	while (p)
	{
		if ( p == this )
		{
			pl->m_pNext	= m_pNext;
			break;
		}

		pl	= p;
		p	= p->m_pNext;
	}

	// parent database update.
	m_pParent->ChildrenCount();
	m_pParent->PageCount();

	// reset parent.
	m_pParent = NULL;

	return true;
}

/*
=============================
	CBaseMenuTable::Think

Call every frame before drawing.
=============================
*/
void CBaseMenuTable::Think(void)
{
	if (!m_bShouldDraw)
	{
		m_flMiscAlpha = max(m_flMiscAlpha + (0.0f - m_flMiscAlpha) * CL_GLB_FRAME * 8.0f, 0);
	}
	else
	{
		m_flMiscAlpha = min(m_flMiscAlpha + (255.0f - m_flMiscAlpha) * CL_GLB_FRAME * 8.0f, 255.0f);
	}

	CBaseMenuItem *p = m_pFirstChild;
	while (p)
	{
		p->Think();

		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// calc lean center.
	m_vecLeanCenter = (HUD_DIR_FORWARD * 0.5f + HUD_DIR_RIGHT).Normalize();

	// not as cur menu when complete faded out.
	// here is the event which menu is closed.
	if (g_pCurrentMenu == this && m_flMiscAlpha <= 5 && !m_bShouldDraw)
	{
		if (m_pSwitchTo)
			m_pSwitchTo->m_bShouldDraw = true;

		g_pCurrentMenu	= m_pSwitchTo;
		m_pSwitchTo		= NULL;
	}
}

/*
============================
	CBaseMenuTable::Draw

3D Hud.
Call every frame in tri.cpp
============================
*/
void CBaseMenuTable::Draw(void)
{
	if (!m_pFirstChild)
		return;

	Vector vecSrc = GetDrawOrigin();
	wchar_t wszBuffer[64];

	// draw title first.
	if (wcsnlen_s(m_wszTitle, _TRUNCATE) > 0)
	{
		// draw title
		gFontFuncs.DrawSetTextFont(HUD_FONT);
		gFontFuncs.DrawSetText3DPos(vecSrc);
		gFontFuncs.DrawSetText3DDir(HUD_DIR_FORWARD, m_vecLeanCenter, HUD_DIR_UP);
		gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
		gFontFuncs.DrawSetTextColor(255, 255, 255, m_flMiscAlpha);
		gFontFuncs.DrawPrint3DText(m_wszTitle);

		// after drawing, shift the origin.
		vecSrc -= HUD_DIR_UP * (HUD_SIZE_STRING_TALL + HUD_SIZE_GAP);
	}

	// draw page tag.
	if (m_iPageCount > 1)
	{
		swprintf(m_wszBuffer, sizeof(m_wszBuffer), L"(%d/%d)", m_iCurrentPage, m_iPageCount);
		gFontFuncs.DrawSetTextFont(HUD_FONT);
		gFontFuncs.DrawSetText3DPos(vecSrc);
		gFontFuncs.DrawSetText3DDir(HUD_DIR_FORWARD, m_vecLeanCenter, HUD_DIR_UP);
		gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
		gFontFuncs.DrawSetTextColor(255, 255, 255, m_flMiscAlpha);
		gFontFuncs.DrawPrint3DText(m_wszBuffer);

		// after drawing, shift the origin.
		vecSrc -= HUD_DIR_UP * (HUD_SIZE_STRING_TALL + HUD_SIZE_GAP);
	}

	// shift origin for the special gap between title, page tag and items.
	if (m_iPageCount > 1 || wcsnlen_s(m_wszTitle, _TRUNCATE) > 0)
		vecSrc -= HUD_DIR_UP * (HUD_SIZE_STRING_TALL + HUD_SIZE_GAP);

	// the global serial number is meaningless here, 'cause we need to tell player which key to press.
	int iSerialNum = 1;

	CBaseMenuItem *p = GetPageHeader(m_iCurrentPage);
	while (p)
	{
		// draw an item.
		swprintf(m_wszBuffer, sizeof(m_wszBuffer), L"%d. %s", iSerialNum, p->m_wszString);
		gFontFuncs.DrawSetTextFont(HUD_FONT);
		gFontFuncs.DrawSetText3DPos(vecSrc);
		gFontFuncs.DrawSetText3DDir(HUD_DIR_FORWARD, m_vecLeanCenter, HUD_DIR_UP);
		gFontFuncs.DrawSetText3DHeight(p->GetHeight());
		gFontFuncs.DrawSetTextColor(p->m_sColor.r, p->m_sColor.g, p->m_sColor.b, m_flMiscAlpha);
		gFontFuncs.DrawPrint3DText(m_wszBuffer);

		// after drawing, shift the origin.
		vecSrc -= HUD_DIR_UP * (p->GetHeight() + HUD_SIZE_GAP);

		// add the serial number.
		iSerialNum ++;

		// Up to nine items can be displayed on one page.
		if (iSerialNum > 9)
			break;

		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// if it's more than a page, show the key to turn page.
	if (m_iPageCount > 1)
	{
		// leave a blank line between contents and menu options.
		vecSrc -= HUD_DIR_UP * (HUD_SIZE_STRING_TALL + HUD_SIZE_GAP);

		int r = 255, g = 255, b = 255;	// color.

		// words of page up.
		if (m_iCurrentPage == 1)	// first page, no more "last page" exists.
			UnpackRGB(r, g, b, 0x808080);	// GREY for disabled.

		UTIL_SearchInLocalize("#MW_Menu_PageUp", wszBuffer);
		swprintf(m_wszBuffer, sizeof(m_wszBuffer), L"%s. %s", UTIL_KeyNameByCommand("menupageup"), wszBuffer);
		gFontFuncs.DrawSetTextFont(HUD_FONT);
		gFontFuncs.DrawSetText3DPos(vecSrc);
		gFontFuncs.DrawSetText3DDir(HUD_DIR_FORWARD, m_vecLeanCenter, HUD_DIR_UP);
		gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
		gFontFuncs.DrawSetTextColor(r, g, b, m_flMiscAlpha);
		gFontFuncs.DrawPrint3DText(m_wszBuffer);

		// after drawing, shift the origin.
		vecSrc -= HUD_DIR_UP * (HUD_SIZE_STRING_TALL + HUD_SIZE_GAP);

		if (m_iCurrentPage == m_iPageCount)	// last page, no more "next page" exists.
			UnpackRGB(r, g, b, 0x808080);	// GREY for disabled.
		else
			UnpackRGB(r, g, b, 0xFFFFFF);	// WHITE for cancel the value sign just now.

		UTIL_SearchInLocalize("#MW_Menu_PageDown", wszBuffer);
		swprintf(m_wszBuffer, sizeof(m_wszBuffer), L"%s. %s", UTIL_KeyNameByCommand("menupagedown"), wszBuffer);
		gFontFuncs.DrawSetTextFont(HUD_FONT);
		gFontFuncs.DrawSetText3DPos(vecSrc);
		gFontFuncs.DrawSetText3DDir(HUD_DIR_FORWARD, m_vecLeanCenter, HUD_DIR_UP);
		gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
		gFontFuncs.DrawSetTextColor(r, g, b, m_flMiscAlpha);
		gFontFuncs.DrawPrint3DText(m_wszBuffer);

		// after drawing, shift the origin.
		vecSrc -= HUD_DIR_UP * (HUD_SIZE_STRING_TALL + HUD_SIZE_GAP);
	}
}

/*
=====================================
	CBaseMenuTable::GetDrawOrigin

Get a point in 3D space, make every start.
=====================================
*/
Vector CBaseMenuTable::GetDrawOrigin(void)
{
	// no item, no drawing.
	if (m_iChildrenCount <= 0)
		return HUD_SCREENCORNER[0];

	// get total height of this menu
	// part I: get the total string height. in this page only!
	float flHeight = 0;
	int iCount = 0;
	CBaseMenuItem *p = GetPageHeader(m_iCurrentPage);
	while (p)
	{
		flHeight += p->GetHeight();
		iCount ++;

		if ( p->m_pNext && iCount <= 9 )
			p = p->m_pNext;
		else
			break;
	}

	// part II: get the total space height. Up to nine items can be displayed on one page. only 8 gaps will presented.
	// UNDONE: maybe separate the space control into each child??
	flHeight += float(min(m_iChildrenCount - 1, 8)) * GetItemGap();

	// part III: add the title height. consist of a default string height and two gap heights, which will looks like a string between title and contents.
	if (wcsnlen_s(m_wszTitle, _TRUNCATE) > 0)
	{
		// there should be a space between this part and content.
		flHeight += HUD_SIZE_STRING_TALL + GetItemGap();

		// title height.
		int iTitleH, iTitleW;
		gFontFuncs.GetTextSize(HUD_FONT, m_wszTitle, &iTitleW, &iTitleH);
		flHeight += float(iTitleH);
	}

	// part IV:	page tag. Up to nine items can be displayed on one page.
	//			and page turning sign, two lines, one gap.
	if (m_iChildrenCount > 9)
	{
		flHeight += HUD_SIZE_STRING_TALL * 3.0f + GetItemGap() * 3.0f;
	}

	// get the result.
	return (HUD_SCREENCORNER[0] + HUD_SCREENCORNER[3]) / 2.0f + HUD_DIR_UP * flHeight * 0.5f + (HUD_DIR_RIGHT + HUD_DIR_FORWARD).Normalize() * HUD_SIZE_RUNING_EDGE;
}

/*
================================
	CBaseMenuTable::AddChild

Add a child to this parent.
================================
*/
bool CBaseMenuTable::AddChild(CBaseMenuItem *pAdd)
{
	if (pAdd->m_pParent == this)
	{
		CBaseMenuItem *p = m_pFirstChild;
		while (p)
		{
			if (p == pAdd)
				return true;	// it's already in the list.
		}

		// something goes wrong here: it's a child of pThis but not in the chain.
		// Remove m_pParent, and maybe re-add to chain.
		pAdd->m_pParent = NULL;
	}
	else if (pAdd->m_pParent) // you cant have more than one parent!
		return false;

	CBaseMenuItem *p = m_pFirstChild;
	while (p)
	{
		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// p == NULL means this is the first.
	if (!p)
		m_pFirstChild = pAdd;
	else
		p->m_pNext = pAdd;

	// make pThis become parent of pAdd.
	pAdd->m_pParent = this;

	// update database.
	ChildrenCount();
	PageCount();

	return true;
}

/*
================================
	CBaseMenuItem::AddParent

The reversed version of the above function.
================================
*/
bool CBaseMenuItem::AddParent(CBaseMenuTable *p)
{
	if (p)
		return p->AddChild(this);
	else
		return false;
}

/*
=====================================
	CBaseMenuTable::ChildrenCount

Counting for all children.
=====================================
*/
int CBaseMenuTable::ChildrenCount(void)
{
	int iResult = 0;

	CBaseMenuItem *p = m_pFirstChild;
	while (p)
	{
		iResult ++;

		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	m_iChildrenCount = iResult;
	return iResult;
}

/*
======================================
	CBaseMenuTable::RemoveAllItems

Remove all children, free them if it marked as freeable.
======================================
*/
void CBaseMenuTable::RemoveAllItems(void)
{
	if (!m_pFirstChild)
		return;

	while (m_pFirstChild->m_pNext)
	{
		if (m_pFirstChild->m_pNext->m_bCanDelete)	// if it should be free from mem, then do it.
			delete m_pFirstChild->m_pNext;
		else
			m_pFirstChild->m_pNext->QuitFromMenu();	// if it's a static var, only quit it.
	}

	// do the same thing to m_pFirstChild
	if (m_pFirstChild->m_bCanDelete)
		delete m_pFirstChild;
	else
		m_pFirstChild->QuitFromMenu();
}

/*
==============================
	CBaseMenuTable::Select

Trigger when user select an item on menu.
==============================
*/
void CBaseMenuTable::Select(int iId)
{
	if (!m_pFirstChild || m_flMiscAlpha < 230)	// avoid quick bug product by quick-continous hit.
		return;

	// the global serial number is 9(n-1)+x, x is the current serial number.
	iId = 9 * (m_iCurrentPage - 1) + iId;

	int iSerialNum = 1;
	CBaseMenuItem *p = m_pFirstChild;
	while (p)
	{
		// when match the same iId on function and drawing seq, select it.
		// UNDONE: if the serial number is greater then 9, it will never get an change to trigger.
		if (iId == iSerialNum)
		{
			p->Select();
			break;
		}

		// increase the global serial number.
		iSerialNum ++;

		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}
}

/*
================================
	CBaseMenuTable::TurnPage

Turn the menu to a specified page
================================
*/
bool CBaseMenuTable::TurnPage(int iPage)
{
	if (iPage <= 0 || iPage > m_iPageCount)
		return false;

	m_iCurrentPage = iPage;
	return true;
}

/*
=================================
	CBaseMenuTable::PageCount

Update m_iPageCount and return it.
=================================
*/
int CBaseMenuTable::PageCount(void)
{
	int iRemainder = m_iChildrenCount;
	int iQuotient = 0;

	// we need a rounding up division.
	while (iRemainder >= 9)
	{
		iRemainder -= 9;
		iQuotient ++;
	}

	int iResult = iQuotient;
	if (iRemainder > 0)
		iResult ++;

	m_iPageCount = iResult;
	return iResult;
}

/*
=====================================
	CBaseMenuTable::GetPageHeader

Get the first item at of a page.
=====================================
*/
CBaseMenuItem * CBaseMenuTable::GetPageHeader(int iPage)
{
	if (iPage <= 0 || iPage > m_iPageCount)
		iPage = m_iCurrentPage;

	CBaseMenuItem *pResult = m_pFirstChild;

	// the first one at a page is always 9(n-1)+1
	// e.g.: page1 is 1-9, page2 is 10-18, page3 is 19-27, ...
	int iSerialStart = 9 * (iPage - 1) + 1;

	// "for loop" until hit the target.
	for (int i = 1; i < iSerialStart; i ++)
	{
		if (pResult)
			pResult = pResult->m_pNext;
		else
			break;
	}

	return pResult;
}

void HUD_MenuTestInit(void)
{
}

void HUD_MenuDraw(void)
{
	if (g_pCurrentMenu)
		g_pCurrentMenu->Think();

	// because it's totally possible that g_pCurrentMenu is set to NULL after thinking.
	if (g_pCurrentMenu)
		g_pCurrentMenu->Draw();
}

void HUD_SwitchMenu(CBaseMenuTable *pTarget)
{
	// if you want to close all menu??
	if (!pTarget && g_pCurrentMenu)
	{
		g_pCurrentMenu->m_pSwitchTo		= NULL;
		g_pCurrentMenu->m_bShouldDraw	= false;
		return;
	}

	// start fading from invisable
	pTarget->m_flMiscAlpha = 0;
	pTarget->m_bShouldDraw = true;

	if (!g_pCurrentMenu)
	{
		g_pCurrentMenu = pTarget;
		return;
	}

	g_pCurrentMenu->m_pSwitchTo		= pTarget;
	g_pCurrentMenu->m_bShouldDraw	= false;
}