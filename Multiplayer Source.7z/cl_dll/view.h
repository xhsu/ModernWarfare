//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#if !defined ( VIEWH )
#define VIEWH 
#pragma once

#include "ref_params.h"

extern ref_params_t	g_pparams;

extern Vector g_vecPunchAngle;
extern Vector g_vecFixAngleOfs;
extern Vector g_vecGunOfs;
extern Vector g_vecPunchOrigin;

extern bool	v_bGunOfsSmooth;

void V_StartPitchDrift( void );
void V_StopPitchDrift( void );

/*
==========================
	Smooth FOV Manager

Source Engine style zooming.
==========================
*/

namespace gFovManager
{
	extern float	m_flFOV;

	void Think		( float flFrameRate );
	void Reset		( void );
	void Set		( float flTargetFOV );
};

/*
==========================
	Lean  Manager

Idea by Rainbow Six Siege
==========================
*/

namespace gLeanManager
{
	extern float	m_flAngleZ;
	extern Vector	m_vecViewOfs;

	enum	LeanState_e
	{
		LEAN_LEFT	= -1,
		LEAN_NO		= 0,
		LEAN_RIGHT	= 1,
	};

	void	Think				(float flFrameRate);
	void	Reset				(void);
	void	LeanLeft			(void);
	void	LeanRight			(void);
	float	GetTargetAngle		(void);
	Vector	GetTargetViewOfs	(void);
	int		GetLeanState		(void);
	void	UpdateToServer		(void);
};

#endif // !VIEWH