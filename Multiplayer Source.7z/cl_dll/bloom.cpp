#include <sysdef.h>
#include "qgl.h"
#include "CShaders.h"
#include "cl_dll.h"
#include "cdll_int.h"
#include "cl_util.h"
#include "hud.h"
#include "triangleapi.h"

static GLuint	hFrameBufferObject = 0;
static GLuint	hScreenTextureObject = 0;
static GLuint	hRenderBufferObject = 0;
static GLuint	hShaderProgram = 0;
static GLuint	hElementBufferObject = 0;
static GLuint	hVertexArrayObject = 0;
static GLuint	hVertexBufferObject = 0;

static GLint	hEngineCurrentFBO;
static GLint	hEngineCurrentRBO;
static GLint	hEngineCurrentSHP;

static GLuint	hShaderUniformMx4 = 0;
static GLuint	hShaderUniformTex = 0;

static glm::mat4	mx4MVP;

void Bloom_Init(void)
{
	// generate a FBO
	glGetIntegerv(GL_FRAMEBUFFER_BINDING, &hEngineCurrentFBO);
	glGenFramebuffers(1, &hFrameBufferObject);
	glBindFramebuffer(GL_FRAMEBUFFER, hFrameBufferObject);

	// generate a Texture for screen colour.
	glGenTextures(1, &hScreenTextureObject);
	glBindTexture(GL_TEXTURE_2D, hScreenTextureObject);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, gHUD::m_sScreenInfo.iWidth, gHUD::m_sScreenInfo.iHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);  
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	
	// attach texture to FBO.
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, hScreenTextureObject, 0);

	// generate a render buffer object.
	glGetIntegerv(GL_RENDERBUFFER_BINDING, &hEngineCurrentRBO);
	glGenRenderbuffers(1, &hRenderBufferObject);
	glBindRenderbuffer(GL_RENDERBUFFER, hRenderBufferObject);

	// create a storage, GL_DEPTH24_STENCIL8 is an accuracy.
	glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, gHUD::m_sScreenInfo.iWidth, gHUD::m_sScreenInfo.iHeight); 
	glBindRenderbuffer(GL_RENDERBUFFER, hEngineCurrentRBO);

	// attach FBO to RBO.
	glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, hRenderBufferObject);

	// final check
	if(glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
		gEngfuncs.Con_Printf("[OpenGL] Bloom FBO create error!\n");

	// restore.
	glBindFramebuffer(GL_FRAMEBUFFER, hEngineCurrentFBO);

	// get shaders.
	CShaders::Initialize("modernwarfare//gfx//Shaders//bloom.vsh", "modernwarfare//gfx//Shaders//bloom.fsh", hShaderProgram);

	// get uniforms. use program first, or some errors might be occur.
	glUseProgram(hShaderProgram);
	hShaderUniformMx4	= glGetUniformLocation(hShaderProgram, "MVP");
	hShaderUniformTex	= glGetUniformLocation(hShaderProgram, "texture1");
	glUseProgram(0);

	// generate a VAO, don't need to restore it.
	glGenVertexArrays(1, &hVertexArrayObject);

	//-------------------------------------------------- SETUP VERTEX DATA BUFFER --------------------------------------------
	// generate a VBO then bind it to current VAO.
	glGenBuffers(1, &hVertexBufferObject);
	glBindBuffer(GL_ARRAY_BUFFER, hVertexBufferObject);

	float flDatabase[] =
	{
		/* COORD */														/* TEXTURE COORD */
		gHUD::m_sScreenInfo.iWidth,	0,								0,	1,	0,
		gHUD::m_sScreenInfo.iWidth,	gHUD::m_sScreenInfo.iHeight,	0,	1,	1,
		0,							gHUD::m_sScreenInfo.iHeight,	0,	0,	1,
		0,							0,								0,	0,	0,
	};
	
	glBufferData(GL_ARRAY_BUFFER, sizeof(flDatabase), flDatabase, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0); // JUST SETUP

	//------------------------------------------------ SETUP INDEX BUFFER -----------------------------------------------------
	// generate a EBO. don't need to restore it.
	glGenBuffers(1, &hElementBufferObject);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, hElementBufferObject);

	unsigned int indices[] =
	{ // ע��������0��ʼ! 
		0, 1, 3, // ��һ��������
		1, 2, 3  // �ڶ���������
	};

	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	//----------------------------------------------- PARSE VERTEX DATA  AND SAVE TO VAO ------------------------------------------------------
	glBindVertexArray(hVertexArrayObject); // start
	{
		glBindBuffer(GL_ARRAY_BUFFER, hVertexBufferObject); // NOTE: The VAO save the VBO binding ONLY ! no EBO

		// layout (location = 0) in vec3 aPos;
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void *)0);	// saved
		glEnableVertexAttribArray(0);	// saved

		// layout (location = 1) in vec2 aTexCoord;
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void *)(3 * sizeof(float)));	// saved
		glEnableVertexAttribArray(1);	// saved
	}

	// unbind VAO
	glBindVertexArray(0);   //finished

	// I think this can use forever.
	mx4MVP = glm::ortho(0.0f, float(gHUD::m_sScreenInfo.iWidth), float(gHUD::m_sScreenInfo.iHeight), 0.0f) * glm::mat4(1.0f) * glm::mat4(1.0f);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);
}

void Bloom_Pre(void)
{
	glGetIntegerv(GL_FRAMEBUFFER_BINDING, &hEngineCurrentFBO);
	glBindFramebuffer(GL_FRAMEBUFFER, hFrameBufferObject);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Bloom_Post(void)
{
	glBindFramebuffer(GL_FRAMEBUFFER, hEngineCurrentFBO);

	// or we will lose alpha channel.
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glBlendFunc(GL_SRC_COLOR, GL_ONE_MINUS_SRC_COLOR);
	
	// use our shader first.
	glUseProgram(hShaderProgram);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, hScreenTextureObject);

	// sent shader texture info.
	glUniform1i(hShaderUniformTex, 0);

	// sent ortho projection martrix.
	glUniformMatrix4fv(hShaderUniformMx4, 1, GL_FALSE, glm::value_ptr(mx4MVP));

	// draw
	glBindVertexArray(hVertexArrayObject);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, hElementBufferObject);
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	/*
	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, hScreenTextureObject);
	glColor4ub(255, 255, 255, 255);

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(0, 0, 0);
	glTexCoord2f(1, 0);
	glVertex3f(gHUD::m_sScreenInfo.iWidth, 0, 0);
	glTexCoord2f(1, 1);
	glVertex3f(gHUD::m_sScreenInfo.iWidth, gHUD::m_sScreenInfo.iHeight, 0);
	glTexCoord2f(0, 1);
	glVertex3f(0, gHUD::m_sScreenInfo.iHeight, 0);
	glEnd();
	*/

	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);

	glUseProgram(0);
}