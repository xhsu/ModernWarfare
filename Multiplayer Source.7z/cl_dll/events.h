//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#ifndef _EVENTS_H_
#define _EVENTS_H_


qboolean EV_IsPlayer( int idx );
qboolean EV_IsLocal( int idx );
void EV_GetGunPosition( event_args_t *args, float *pos, float *origin );

#endif // EV_HLDMH