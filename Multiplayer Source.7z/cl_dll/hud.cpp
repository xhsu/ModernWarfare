/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/

#include <sysdef.h>

#include "hud.h"
#include "cl_util.h"
#include "parsemsg.h"
#include "cl_entity.h"
#include "view.h"

#include <triangleapi.h>
#include <com_model.h>
#include "dxt.h"
#include "DrawFonts.h"
#include "hud_menu.h"
#include "hud_wpn.h"




namespace gHUD
{
	cvar_t		*m_pCvarZoomSenRatio;
	cvar_t		*m_pCvarDefFOV;
	SCREENINFO	m_sScreenInfo;
	float		m_flMouseSensitivity;
	int			m_iIntermission;

	namespace	BiDimnHud
	{
		unsigned	m_iIdBloodScreen	= 0;

		void		DrawBloodScreen	( void );
	};

	namespace	TriDimnHud
	{
		Vector	m_vecDrawCalcOrigin;
		Vector	m_vecForward;
		Vector	m_vecRight;
		Vector	m_vecUp;
		Vector	m_vecScreenCorner[4];
		Vector	m_vecLeanCenter;
		float	m_fl3DUIDistance;
		float	m_flVerticalFOV;
		float	m_flFrameRate;
		wchar_t	m_wszDisplayWpnName[128 * 2];
		wchar_t m_wszAmmoWords[16];
		float	m_flFadeFactor;
		float	m_flMiscAlpha;

		void	CalcVectors	( void );
		void	DrawArmor	( void );
	};
};

static Vector vecs[4];


cvar_t *cl_lw = NULL;
CHudHintText *g_pHudHintTextHeader = NULL;
CScreenFade g_cScreenFade;

void ShutdownInput (void);


void gHUD::Init(void)
{
	m_pCvarZoomSenRatio	= CVAR_CREATE( "zoom_sensitivity_ratio", "1.2", 0 );
	m_pCvarDefFOV		= CVAR_CREATE( "default_fov", "90", 0 );
	cl_lw				= gEngfuncs.pfnGetCvarPointer( "cl_lw" );

	m_iFOV = 0;
}

void gHUD::VidInit(void)
{
	m_sScreenInfo.iSize = sizeof(m_sScreenInfo);
	gEngfuncs.pfnGetScreenInfo(&m_sScreenInfo);
}

float g_lastFOV = 0.0;

/*
============
COM_FileBase
============
*/
// Extracts the base name of a file (no path, no extension, assumes '/' as path separator)
void COM_FileBase ( const char *in, char *out)
{
	int len, start, end;

	len = strlen( in );
	
	// scan backward for '.'
	end = len - 1;
	while ( end && in[end] != '.' && in[end] != '/' && in[end] != '\\' )
		end--;
	
	if ( in[end] != '.' )		// no '.', copy to end
		end = len-1;
	else 
		end--;					// Found ',', copy to left of '.'


	// Scan backward for '/'
	start = len-1;
	while ( start >= 0 && in[start] != '/' && in[start] != '\\' )
		start--;

	if ( in[start] != '/' && in[start] != '\\' )
		start = 0;
	else 
		start++;

	// Length of new sting
	len = end - start + 1;

	// Copy partial string
	strncpy( out, &in[start], len );
	// Terminate it
	out[len] = 0;
}

/*
=================
HUD_IsGame

=================
*/
int HUD_IsGame( const char *game )
{
	const char *gamedir;
	char gd[ 1024 ];

	gamedir = gEngfuncs.pfnGetGameDirectory();
	if ( gamedir && gamedir[0] )
	{
		COM_FileBase( gamedir, gd );
		if ( !stricmp( gd, game ) )
			return 1;
	}
	return 0;
}

/*
=====================
2DUI

Draw blood screen when health < 100
=====================
*/

void gHUD::BiDimnHud::DrawBloodScreen(void)
{
	if (!m_iIdBloodScreen)
		m_iIdBloodScreen = LoadDDS("modernwarfare//gfx//hp02.dds");

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_iIdBloodScreen);
	glColor4ub(255, 255, 255, 255.0f * (1.0f - float(g_pparams.health) / 100.0f));

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(0, 0, 0);
	glTexCoord2f(1, 0);
	glVertex3f(gHUD::m_sScreenInfo.iWidth, 0, 0);
	glTexCoord2f(1, 1);
	glVertex3f(gHUD::m_sScreenInfo.iWidth, gHUD::m_sScreenInfo.iHeight, 0);
	glTexCoord2f(0, 1);
	glVertex3f(0, gHUD::m_sScreenInfo.iHeight, 0);
	glEnd();
}

/*
=====================
2DUI

Draw the point use to calibrate steel sight.
=====================
*/
#define SIGHT_DOT_SIZE	2
extern cvar_t	*v_pCvarGunOfs[3];
void gHUD::BiDimnHud::DrawCalibrateDot(void)
{
	if (v_pCvarGunOfs[0]->value || v_pCvarGunOfs[1]->value || v_pCvarGunOfs[2]->value)
		gEngfuncs.pfnFillRGBA( gHUD::m_sScreenInfo.iWidth / 2 - (SIGHT_DOT_SIZE / 2), gHUD::m_sScreenInfo.iHeight / 2 - (SIGHT_DOT_SIZE / 2), SIGHT_DOT_SIZE, SIGHT_DOT_SIZE, 255, 255, 255, 255 );
}

/*
=====================
2DUI

Draw the scope effect.
=====================
*/
void gHUD::BiDimnHud::DrawScope(unsigned iIdTexture, bool bCenter, float flWidth, float flHeight)
{
	if (!iIdTexture)
		return;

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, iIdTexture);
	glColor4ub(255, 255, 255, 255.0f);

	if (!bCenter)
	{
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex3f(0, 0, 0);
		glTexCoord2f(1, 0);
		glVertex3f(gHUD::m_sScreenInfo.iWidth, 0, 0);
		glTexCoord2f(1, 1);
		glVertex3f(gHUD::m_sScreenInfo.iWidth, gHUD::m_sScreenInfo.iHeight, 0);
		glTexCoord2f(0, 1);
		glVertex3f(0, gHUD::m_sScreenInfo.iHeight, 0);
		glEnd();
	}
	else
	{
		// we assume iWidth is larger then iHeight.
		float flUpper = max(0, m_sScreenInfo.iHeight * 0.5f - flHeight * 0.5f);
		float flLower = min(m_sScreenInfo.iHeight, m_sScreenInfo.iHeight * 0.5f + flHeight * 0.5f);
		float flResizedWidth = (flHeight > 0) ? (flWidth / flHeight * (flLower - flUpper)) : 1;
		float flRight = m_sScreenInfo.iWidth * 0.5f + flResizedWidth * 0.5f;
		float flLeft = m_sScreenInfo.iWidth * 0.5f - flResizedWidth * 0.5f;

		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex3f(flLeft, flUpper, 0);
		glTexCoord2f(1, 0);
		glVertex3f(flRight, flUpper, 0);
		glTexCoord2f(1, 1);
		glVertex3f(flRight, flLower, 0);
		glTexCoord2f(0, 1);
		glVertex3f(flLeft, flLower, 0);
		glEnd();
	}
}

/*
=====================
3DUI

Basic Drawing Vector Calc
=====================
*/

extern Vector	V_vecCurForward;

void gHUD::TriDimnHud::CalcVectors(void)
{
	// for lag effect, we have to get lag origin first. (using value same as VGunLag)
	m_vecDrawCalcOrigin += (Vector(g_pparams.vieworg) - m_vecDrawCalcOrigin) * g_pparams.frametime * 5 - V_vecCurForward * 3 + m_vecForward * 3;

	// first of all, we need fvckinng vertical fov value
	m_flVerticalFOV = CalcFov(gFovManager::m_flFOV, m_sScreenInfo.iWidth, m_sScreenInfo.iHeight);

	// than, get drawing direction
	gEngfuncs.pfnAngleVectors(g_pparams.viewangles, m_vecForward, m_vecRight, m_vecUp);

	// next, we need a plane we can draw our element on, which keep the same scale as we draw in HUD_Redraw function.
	m_fl3DUIDistance = (0.5 * double(m_sScreenInfo.iWidth)) / tan(gFovManager::m_flFOV * 0.5 * M_PI / 180.0);
	
	// and we can get the four points represent the four corner of our screen
	// vec[left upper corner] = distance * j - distance * tan(theta / 2) * i + distance * tan(phi / 2) * k + playerview_offset + playerorigin
	//Vector vecLagOffset = (LOCAL_VIEW_ORIGIN_LAG - LOCAL_VIEW_ORIGIN).Normalize() * 50;
	m_vecScreenCorner[0] = m_fl3DUIDistance * m_vecForward - m_fl3DUIDistance * tan(gFovManager::m_flFOV * 0.5f * float(M_PI / 180.0)) * m_vecRight + m_fl3DUIDistance * tan(m_flVerticalFOV * 0.5f) * m_vecUp + m_vecDrawCalcOrigin;
	m_vecScreenCorner[1] = m_fl3DUIDistance * m_vecForward + m_fl3DUIDistance * tan(gFovManager::m_flFOV * 0.5f * float(M_PI / 180.0)) * m_vecRight + m_fl3DUIDistance * tan(m_flVerticalFOV * 0.5f) * m_vecUp + m_vecDrawCalcOrigin;
	m_vecScreenCorner[2] = m_fl3DUIDistance * m_vecForward + m_fl3DUIDistance * tan(gFovManager::m_flFOV * 0.5f * float(M_PI / 180.0)) * m_vecRight - m_fl3DUIDistance * tan(m_flVerticalFOV * 0.5f) * m_vecUp + m_vecDrawCalcOrigin;
	m_vecScreenCorner[3] = m_fl3DUIDistance * m_vecForward - m_fl3DUIDistance * tan(gFovManager::m_flFOV * 0.5f * float(M_PI / 180.0)) * m_vecRight - m_fl3DUIDistance * tan(m_flVerticalFOV * 0.5f) * m_vecUp + m_vecDrawCalcOrigin;

	// for most for HUD on right side, we have this.
	m_vecLeanCenter = (m_vecForward * 0.5 - m_vecRight).Normalize();
}

/*
=====================
3DUI

Armor Value Bar
=====================
*/

void gHUD::TriDimnHud::DrawArmor(void)
{
	static unsigned int m_iIdArmorHelmetIcon = LoadDDS("modernwarfare//gfx//StatusBar//HUD_Helmet.dds");

	Vector vecNorm1 = (m_vecForward * 0.5 + m_vecRight).Normalize();
	Vector vecSrc = m_vecScreenCorner[3] + (HUD_SIZE_ARMOR_ICON) * m_vecUp + HUD_SIZE_RUNING_EDGE * vecNorm1;

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_iIdArmorHelmetIcon);
	glColor4ub(255, 255, 255, 255);

	vecs[0] = vecSrc;
	vecs[1] = vecs[0] + vecNorm1 * HUD_SIZE_NUM_LARGE;
	vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_NUM_LARGE;
	vecs[3] = vecs[0] - m_vecUp * HUD_SIZE_NUM_LARGE;

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(1, 1, 1, 1);

	for (int i = 1, j = int(65); i <= 4; i ++)
	{
		if (i == 1)
			vecSrc += vecNorm1 * (HUD_SIZE_NUM_LARGE + HUD_SIZE_GAP) - m_vecUp * ((HUD_SIZE_NUM_LARGE - HUD_SIZE_BAR_WIDTH) / 2);	// outline of block 1
		else
			vecSrc += vecNorm1 * (HUD_SIZE_BAR_LENGTH + HUD_SIZE_GAP);

		vecs[0] = vecSrc;
		vecs[1] = vecs[0] + vecNorm1 * HUD_SIZE_BAR_LENGTH;
		vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_BAR_WIDTH;
		vecs[3] = vecs[0] - m_vecUp * HUD_SIZE_BAR_WIDTH;

		glBegin(GL_LINE_LOOP);
		glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
		glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
		glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
		glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
		glEnd();

		if (j <= 0)
			continue;

		if (j < 25)
		{
			vecs[1] = vecs[0] + vecNorm1 * HUD_SIZE_BAR_LENGTH * (j / 25.0f);	// every section stands for 25% armor.
			vecs[2] = vecs[1] - m_vecUp * HUD_SIZE_BAR_WIDTH;
		}

		glBegin(GL_QUADS);	// fill
		glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
		glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
		glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
		glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
		glEnd();

		j -= 25;
	}

	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
}

/*
=====================
CHudHintText::CHudHintText
=====================
*/
CHudHintText::CHudHintText(void)
{
	m_flAlpha		= 0;	// start from nothing.
	m_sColor		= UnpackRGB(RGB_REDISH);
	m_iPhase		= HHT_FADEIN;
	m_flTimeRemove	= 0;
	m_flFadeFactor	= 0;
	m_pNext			= NULL;

	memset(m_wszText, NULL, sizeof(m_wszText));

	CHudHintText *p = g_pHudHintTextHeader;
	while (p)
	{
		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// p == NULL means this is the first.
	if (!p)
		g_pHudHintTextHeader = this;
	else
		p->m_pNext = this;
}

/*
=====================
CHudHintText::~CHudHintText
=====================
*/
CHudHintText::~CHudHintText(void)
{
	// if killing chain root, give chair to his next.
	if (g_pHudHintTextHeader == this)
	{
		g_pHudHintTextHeader = m_pNext;
		return;
	}

	// otherwise, which means at least two texts in chain, and g_pHudHintTextHeader->m_pNext != NULL
	CHudHintText *pl	= g_pHudHintTextHeader;
	CHudHintText *p		= g_pHudHintTextHeader->m_pNext;

	while (p)
	{
		if ( p == this )
		{
			pl->m_pNext	= m_pNext;
			break;
		}

		pl	= p;
		p	= p->m_pNext;
	}
}

/*
=====================
AddHintText
=====================
*/
CHudHintText *gHUD::AddHintText(const char *sz)
{
	char szWords[512];
	strncpy_s(szWords, sz, sizeof(szWords));

	CHudHintText *pNew = new CHudHintText;

	wchar_t *pwChars = gpLocalize->Find(szWords);
	if (pwChars)
		wcsncpy_s(pNew->m_wszText, pwChars, _TRUNCATE);

	return pNew;
}

CHudHintText *gHUD::AddHintText(const wchar_t *sz)
{
	CHudHintText *pNew = new CHudHintText;
	wcsncpy_s(pNew->m_wszText, sz, _TRUNCATE);

	return pNew;
}

/*
=====================
CHudHintText::Think
=====================
*/
void CHudHintText::Think(void)
{
	color24	sRed	= UnpackRGB(RGB_REDISH);
	color24 sGreen	= UnpackRGB(RGB_GREENISH);

	if ( m_iPhase == HHT_FADEOUT )
		m_flFadeFactor = max(m_flFadeFactor + (0.0f - m_flFadeFactor) * g_flClientFrame * 8, 0);
	else
		m_flFadeFactor = min(m_flFadeFactor + (1.0f - m_flFadeFactor) * g_flClientFrame * 8, 1);

	m_sColor.r	= sRed.r * (1.0f - m_flFadeFactor) + sGreen.r * m_flFadeFactor;
	m_sColor.g	= sRed.g * (1.0f - m_flFadeFactor) + sGreen.g * m_flFadeFactor;
	m_sColor.b	= sRed.b * (1.0f - m_flFadeFactor) + sGreen.b * m_flFadeFactor;
	m_flAlpha	= 255 * m_flFadeFactor;

	if (m_flAlpha > 240 && !m_flTimeRemove)
	{
		m_iPhase		= HHT_STAY;
		m_flTimeRemove	= g_flClientTime + 3.0;
	}
	else if (m_flTimeRemove && m_flTimeRemove < g_flClientTime && m_iPhase != HHT_FADEOUT)
	{
		m_iPhase		= HHT_FADEOUT;
	}
	else if (m_iPhase == HHT_FADEOUT && m_flAlpha < 5)
	{
		delete this;
	}
}

/*
=====================
CHudHintText::Draw
=====================
*/
void CHudHintText::Draw(void)
{
	int iWidth, iHeight;
	gFontFuncs.GetTextSize(gStdWpnHud::m_hFont, m_wszText, &iWidth, &iHeight);

	Vector vecSrc = (gHUD::TriDimnHud::m_vecScreenCorner[2] + gHUD::TriDimnHud::m_vecScreenCorner[3]) / 2.0f;
	vecSrc -= gHUD::TriDimnHud::m_vecRight * iWidth * 0.5f;
	vecSrc += gHUD::TriDimnHud::m_vecUp * (iHeight * 2 + HUD_SIZE_GAP);

	gFontFuncs.DrawSetTextFont(gStdWpnHud::m_hFont);
	gFontFuncs.DrawSetText3DPos(vecSrc);
	gFontFuncs.DrawSetText3DDir(gHUD::TriDimnHud::m_vecForward, gHUD::TriDimnHud::m_vecRight, gHUD::TriDimnHud::m_vecUp);
	gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetTextColor(m_sColor.r, m_sColor.g, m_sColor.b, m_flAlpha);
	gFontFuncs.DrawPrint3DText(m_wszText);
}

/*
=====================
CScreenFade::Draw
=====================
*/
void CScreenFade::Draw(void)
{
	if (m_flAlpha < 3)
		return;

	// LUNA: DONT use gEngfuncs.pfnFillRGBA here!

	glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	glColor4f(m_sColor.r / 255.0, m_sColor.g / 255.0, m_sColor.b / 255.0, m_flAlpha / 255.0);

	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	glVertex2f(0, gHUD::m_sScreenInfo.iHeight);
	glVertex2f(gHUD::m_sScreenInfo.iWidth, gHUD::m_sScreenInfo.iHeight);
	glVertex2f(gHUD::m_sScreenInfo.iWidth, 0);
	glEnd();

	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
}

/*
=====================
CScreenFade::Think
=====================
*/
void CScreenFade::Think(void)
{
	if (memcmp(&m_sColor, &m_sTargetColor, sizeof(color24)))
	{
		m_sColor.r	+= (m_sTargetColor.r - m_sColor.r) * g_flClientFrame * 4;
		m_sColor.g	+= (m_sTargetColor.g - m_sColor.g) * g_flClientFrame * 4;
		m_sColor.b	+= (m_sTargetColor.b - m_sColor.b) * g_flClientFrame * 4;
	}

	if (m_iPhase == SF_FADEIN)
	{
		if (m_flFadeSpeed > 0)
			m_flAlpha = min(m_flAlpha + m_flFadeSpeed * g_flClientFrame, 255);
		else if (m_flFadeSpeed < 0)
			m_flAlpha = min(m_flAlpha + (m_flTargetAlpha - m_flAlpha) * g_flClientFrame * fabs(m_flFadeSpeed), 255);
		else
			m_flAlpha = min(m_flAlpha + (m_flTargetAlpha - m_flAlpha) * g_flClientFrame, 255);

		if (m_flAlpha >= m_flTargetAlpha)
		{
			m_flTimeThink = gEngfuncs.GetClientTime() + m_flStayLength;
			m_iPhase = SF_STAY;
		}
	}
	else if (m_iPhase == SF_STAY)
	{
		if (m_flTimeThink < gEngfuncs.GetClientTime())
			m_iPhase = SF_FADEOUT;
	}
	else if (m_iPhase == SF_FADEOUT)
	{
		if (m_flFadeSpeed > 0)
			m_flAlpha = max(m_flAlpha - m_flFadeSpeed * g_flClientFrame, 0);
		else if (m_flFadeSpeed < 0)
			m_flAlpha = max(m_flAlpha + (0 - m_flAlpha) * g_flClientFrame * m_flFadeSpeed, 0);
		else
			m_flAlpha = max(m_flAlpha + (0 - m_flAlpha) * g_flClientFrame, 0);

		// then ... it's simply done.. nothing to do else.
	}
}