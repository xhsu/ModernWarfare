#ifndef _HUD_CMD_H_
#define _HUD_CMD_H_

namespace gHUD
{
	void	InitCommand	( void );
};













































#endif