/***

Modern Warfare Develop Team
wpn_accessories.cpp

Coder:	Luna the Reborn (Crescent)

Create Date: 2018/11/06

***/

#include <sysdef.h>

#include "hud.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "wpn_accessories.h"

CBaseAccessory * CBaseAccessory::AddByName(const char * sz)
{
	CBaseAccessory *pNew = new CBaseAccessory;

	pNew->m_bCanDelete = true;	// IMPORTANT!!!

	return pNew;
}

CBaseAccessory * CBaseAccessory::AddByIndex(int index)
{
	CBaseAccessory *pNew = new CBaseAccessory;

	pNew->m_bCanDelete = true;	// IMPORTANT!!!

	return pNew;
}
