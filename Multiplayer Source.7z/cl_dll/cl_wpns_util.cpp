/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/

// Com_Weapons.cpp
// Shared weapons common/shared functions
#include <sysdef.h>
#include <stdarg.h>
#include "hud.h"
#include "cl_wpns.h"
#include "cl_util.h"
#include "DDS_Anim.h"
#include "dxt.h"
#include "mh_import.h"

#include "const.h"
#include "entity_state.h"
#include "r_efx.h"
#include "view.h"
#include "event_api.h"
#include "GameStudioModelRenderer.h"

extern "C"
{
#include "pmtrace.h"
#include "pm_materials.h"
#include "pm_defs.h"
}

#include "input.h"
#include "kbutton.h"



/*
====================
COM_Log

Log debug messages to file ( appends )
====================
*/
void COM_Log( char *pszFile, char *fmt, ...)
{
	va_list		argptr;
	char		string[1024];
	FILE *fp;
	char *pfilename;
	
	if ( !pszFile )
	{
		pfilename = "c:\\hllog.txt";
	}
	else
	{
		pfilename = pszFile;
	}

	va_start (argptr,fmt);
	vsprintf (string, fmt,argptr);
	va_end (argptr);

	fp = fopen( pfilename, "a+t");
	if (fp)
	{
		fprintf(fp, "%s", string);
		fclose(fp);
	}
}

// remember the current animation for the view model, in case we get out of sync with
//  server.
static int g_currentanim;

/*
=====================
HUD_SendWeaponAnim

Change weapon model animation
=====================
*/
void HUD_SendWeaponAnim( int iAnim, int iBody )
{
	g_currentanim = iAnim;

	// Tell animation system new info
	gEngfuncs.pfnWeaponAnim( iAnim, g_pPlayerActivityItem ? g_pPlayerActivityItem->m_iDisplayingAnim : 0 );

	// fucking engine.
	g_flViewEntAnimTime = gEngfuncs.GetClientTime();
}

/*
=====================
HUD_GetWeaponAnim

Retrieve current predicted weapon animation
=====================
*/
int HUD_GetWeaponAnim( void )
{
	return g_currentanim;
}

/*
=====================
HUD_PlaySound

Play a sound, if we are seeing this command for the first time
=====================
*/
void HUD_PlaySound( char *sound, float volume )
{
	gEngfuncs.pfnPlaySoundByNameAtLocation( sound, volume, (float *)&g_pparams.vieworg );
}

/*
=====================
HUD_PlaybackEvent

Directly queue up an event on the client
=====================
*/
void HUD_PlaybackEvent( int flags, const edict_t *pInvoker, unsigned short eventindex, float delay,
	float *origin, float *angles, float fparam1, float fparam2, int iparam1, int iparam2, int bparam1, int bparam2 )
{
	vec3_t org;
	vec3_t ang;

	// Weapon prediction events are assumed to occur at the player's origin
	org			= g_pparams.vieworg;
	ang			= g_pparams.viewangles;
	gEngfuncs.pfnPlaybackEvent( flags, pInvoker, eventindex, delay, (float *)&org, (float *)&ang, fparam1, fparam2, iparam1, iparam2, bparam1, bparam2 );
}

/*
=====================
HUD_SetMaxSpeed

=====================
*/

void HUD_SetMaxSpeed( float speed )
{
	g_sFakePlayer.m_flMaxSpeed = speed;
}


/*
=====================
UTIL_WeaponTimeBase
=====================
*/
float UTIL_WeaponTimeBase( void )
{
	return gEngfuncs.GetClientTime();
}

static unsigned int glSeed = 0; 

unsigned int seed_table[ 256 ] =
{
	28985, 27138, 26457, 9451, 17764, 10909, 28790, 8716, 6361, 4853, 17798, 21977, 19643, 20662, 10834, 20103,
	27067, 28634, 18623, 25849, 8576, 26234, 23887, 18228, 32587, 4836, 3306, 1811, 3035, 24559, 18399, 315,
	26766, 907, 24102, 12370, 9674, 2972, 10472, 16492, 22683, 11529, 27968, 30406, 13213, 2319, 23620, 16823,
	10013, 23772, 21567, 1251, 19579, 20313, 18241, 30130, 8402, 20807, 27354, 7169, 21211, 17293, 5410, 19223,
	10255, 22480, 27388, 9946, 15628, 24389, 17308, 2370, 9530, 31683, 25927, 23567, 11694, 26397, 32602, 15031,
	18255, 17582, 1422, 28835, 23607, 12597, 20602, 10138, 5212, 1252, 10074, 23166, 19823, 31667, 5902, 24630,
	18948, 14330, 14950, 8939, 23540, 21311, 22428, 22391, 3583, 29004, 30498, 18714, 4278, 2437, 22430, 3439,
	28313, 23161, 25396, 13471, 19324, 15287, 2563, 18901, 13103, 16867, 9714, 14322, 15197, 26889, 19372, 26241,
	31925, 14640, 11497, 8941, 10056, 6451, 28656, 10737, 13874, 17356, 8281, 25937, 1661, 4850, 7448, 12744,
	21826, 5477, 10167, 16705, 26897, 8839, 30947, 27978, 27283, 24685, 32298, 3525, 12398, 28726, 9475, 10208,
	617, 13467, 22287, 2376, 6097, 26312, 2974, 9114, 21787, 28010, 4725, 15387, 3274, 10762, 31695, 17320,
	18324, 12441, 16801, 27376, 22464, 7500, 5666, 18144, 15314, 31914, 31627, 6495, 5226, 31203, 2331, 4668,
	12650, 18275, 351, 7268, 31319, 30119, 7600, 2905, 13826, 11343, 13053, 15583, 30055, 31093, 5067, 761,
	9685, 11070, 21369, 27155, 3663, 26542, 20169, 12161, 15411, 30401, 7580, 31784, 8985, 29367, 20989, 14203,
	29694, 21167, 10337, 1706, 28578, 887, 3373, 19477, 14382, 675, 7033, 15111, 26138, 12252, 30996, 21409,
	25678, 18555, 13256, 23316, 22407, 16727, 991, 9236, 5373, 29402, 6117, 15241, 27715, 19291, 19888, 19847
};

unsigned int U_Random( void ) 
{ 
	glSeed *= 69069; 
	glSeed += seed_table[ glSeed & 0xff ];
 
	return ( ++glSeed & 0x0fffffff ); 
} 

void U_Srand( unsigned int seed )
{
	glSeed = seed_table[ seed & 0xff ];
}

/*
=====================
UTIL_SharedRandomLong
=====================
*/
int UTIL_SharedRandomLong( unsigned int seed, int low, int high )
{
	unsigned int range;

	U_Srand( (int)seed + low + high );

	range = high - low + 1;
	if ( !(range - 1) )
	{
		return low;
	}
	else
	{
		int offset;
		int rnum;

		rnum = U_Random();

		offset = rnum % range;

		return (low + offset);
	}
}

/*
=====================
UTIL_SharedRandomFloat
=====================
*/
float UTIL_SharedRandomFloat( unsigned int seed, float low, float high )
{
	//
	unsigned int range;

	U_Srand( (int)seed + *(int *)&low + *(int *)&high );

	U_Random();
	U_Random();

	range = high - low;
	if ( !range )
	{
		return low;
	}
	else
	{
		int tensixrand;
		float offset;

		tensixrand = U_Random() & 65535;

		offset = (float)tensixrand / 65536.0;

		return (low + offset * range );
	}
}

/*
=====================
UTIL_UserHasWpn
=====================
*/

CBaseWeapons *UTIL_UserHasWpn(int iWeaponType, CBaseWeapons *pExclusive)
{
	if (iWeaponType <= 0 || iWeaponType > g_iItemTypes)
		return NULL;

	CBaseWeapons *p = g_pWeaponChainRoot;

	while (p)
	{
		if (p->m_iItemType != iWeaponType || (pExclusive && p == pExclusive) )
		{
			p = p->m_pNext;
			continue;
		}

		return p;
	}

	return NULL;
}

/*
=====================
SwitchWeapon
=====================
*/

void SwitchWeapon(CBaseWeapons *pTarget)
{
	if (!pTarget || pTarget == g_pPlayerActivityItem)
		return;

	// dont switch to alt weapon.
	if (g_pPlayerActivityItem && pTarget == g_pPlayerActivityItem->m_pAltWeapon)
		return;

	if (g_pPlayerActivityItem)
		g_pPlayerActivityItem->m_pSwitchTo = pTarget;
	else
	{
		g_pPlayerActivityItem = pTarget;
		g_pPlayerActivityItem->ItemDeploy();
		return;
	}

	if (!g_pPlayerActivityItem->CanItemHolster())
		return;

	g_pPlayerActivityItem->ItemHolster();
	g_pPlayerLastItem = g_pPlayerActivityItem;

	g_pPlayerActivityItem = pTarget;
	g_pPlayerActivityItem->ItemDeploy();
	g_pPlayerActivityItem->m_pSwitchTo = NULL;
}

/*
=====================
UTIL_SortItemsBySlot

Overriding all m_pChain.
Return a chain root which rearrange by slot
=====================
*/

CBaseWeapons *UTIL_SortItemsBySlot(void)
{
	if (!g_pWeaponChainRoot)
		return NULL;

	// we need to clear all m_pChain, avoid some dead gun stuck in m_pChain and accessed by some functions.
	CBaseWeapons *p = g_pWeaponChainRoot;
	while (p)
	{
		p->m_pChain = NULL;
		p = p->m_pNext;
	}

	CBaseWeapons *pRoot = NULL;
	CBaseWeapons *pEnd	= NULL;

	for (int iSlot = 1; iSlot <= 10; iSlot ++)
	{
		p = g_pWeaponChainRoot;

		while (p)
		{
			if (p->m_sItemData.m_iSlot == iSlot)
			{
				if (p->IsInferior())	// inferior weapon cant get in the loop.
				{
					p = p->m_pNext;
					continue;
				}

				if (!pRoot)
					pRoot = p;
				else if (!pEnd)
					pRoot->m_pChain = pEnd = p;
				else
				{
					pEnd->m_pChain = p;
					pEnd = p;
				}
			}

			p = p->m_pNext;
		}
	}

	return pRoot;
}

/*
=====================
UTIL_SlotBestWpn
=====================
*/

wpn_c *UTIL_SlotBestWpn(int iSlot)
{
	if (!g_pPlayerActivityItem || g_pPlayerActivityItem->m_sItemData.m_iSlot != iSlot)
	{
		if (!g_pWeaponChainRoot)
			return NULL;

		wpn_c *p = g_pWeaponChainRoot;

		while (p)
		{
			if (p->m_sItemData.m_iSlot == iSlot)
				return p;

			p = p->m_pNext;
		}

		// we must return here, otherwise it will run those code for g_pPlayerActivityItem existed.
		return NULL;
	}

	// it is impossible you have a curweapon and there is no root.
	wpn_c *p = g_pPlayerActivityItem->m_pNext;

	while (p)
	{
		if (p->m_sItemData.m_iSlot == iSlot && !p->IsInferior())	// remember, InferiorWeapon can't be selected.
			return p;

		p = p->m_pNext;
	}

	// if goes here, it means that you're using the last weapon in this slot.
	// we should move back to root and run again.
	p = g_pWeaponChainRoot;

	while (p)
	{
		if (p->m_sItemData.m_iSlot == iSlot && !p->IsInferior())
			return p;

		p = p->m_pNext;
	}

	// there is nothing more in this slot.
	return NULL;
}

/*
=====================
UTIL_GetLastWpn
=====================
*/

wpn_c *UTIL_GetLastWpn(void)
{
	if (!g_pWeaponChainRoot)
		return NULL;

	if (!g_pPlayerActivityItem)
		return g_pWeaponChainRoot;

	wpn_c *p = UTIL_SortItemsBySlot();
	while (p)
	{
		if ( p->m_pChain == g_pPlayerActivityItem )
			break;
		else if ( p->m_pChain )
			p = p->m_pChain;
		else	// WTF? g_pPlayerActivityItem is not in the chain???
			return NULL;
	}

	return p;
}

/*
=====================
UTIL_GetNextWpn
=====================
*/

wpn_c *UTIL_GetNextWpn(void)
{
	if (!g_pWeaponChainRoot)
		return NULL;

	if (!g_pPlayerActivityItem)
		return g_pWeaponChainRoot;

	UTIL_SortItemsBySlot();

	return g_pPlayerActivityItem->m_pChain;
}


/*
=====================
UTIL_ReleaseRun
=====================
*/

extern kbutton_t	in_duck;
extern kbutton_t	in_run;

void UTIL_ReleaseRun(void)
{
	memset(&in_run, NULL, sizeof(in_run));
	g_bHoldRun = false;
}

/*
=====================
UTIL_ReleaseDuck
=====================
*/
void UTIL_ReleaseDuck(void)
{
	memset(&in_duck, NULL, sizeof(in_duck));
	g_bHoldDuck = false;
}

static gDxtAnimManager::animdata_t *s_smoke1 = NULL;
static gDxtAnimManager::animdata_t *s_smoke2 = NULL;
static decaltexture_t s_sgshot32[5];
static decaltexture_t s_sgshot64[5];
static decaltexture_t s_sgshot96[5];
static decaltexture_t s_sgshot128[5];
static int s_idsgshot32[5];
static int s_idsgshot64[5];
static int s_idsgshot96[5];
static int s_idsgshot128[5];

void UTIL_EfxVidInit(void)
{
	s_smoke1 = gDxtAnimManager::LoadAnim("modernwarfare//gfx//GunSmoke//gunsmoke1", "gunsmoke_1", 15);
	s_smoke2 = gDxtAnimManager::LoadAnim("modernwarfare//gfx//GunSmoke//gunsmoke2", "gunsmoke_2", 15);

	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[128];
	for (int i = 1; i <= g_iAmmoTypes; i ++)
	{
		if (strlen(g_sAmmoData[i].m_szHole) < 1)
			continue;

		// first, clear the current vector.
		g_sAmmoData[i].m_vHoleDecalId.clear();

		// print out the location of file.
		sprintf_s(szPath, _TRUNCATE, "modernwarfare//gfx//BulletHole//%s//*.*", g_sAmmoData[i].m_szHole);

		// scan & load all texture inside the folder.
		if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
		{
			do
			{
				// exclude all subdir.
				if (!(sInfo.attrib & _A_SUBDIR) && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
				{
					sprintf(szPath, "modernwarfare//gfx//BulletHole//%s//%s", g_sAmmoData[i].m_szHole, sInfo.name);
					if (_access(szPath, 4) != -1)
					{
						int iWidth, iHeight;
						unsigned idTexture = LoadDDS(szPath, &iWidth, &iHeight);

						g_sAmmoData[i].m_vHoleDecalId.push_back(gMHSharedFuncs.pfnAllocateDecal(idTexture, iWidth, iHeight));
					}
				}
			}
			while (_findnext(hFile, &sInfo) == 0);

			_findclose(hFile);
		}

		// I dont think we need to expand it anymore.
		g_sAmmoData[i].m_vHoleDecalId.shrink_to_fit();
	}

	for (int i = 0; i < 5; i ++)
	{
		sprintf_s(szPath, _TRUNCATE, "modernwarfare//gfx//BulletHole//sgshot32//sgshot32-%d.dds", i + 1);
		s_sgshot32[i].width	= s_sgshot32[i].height = 32;
		s_sgshot32[i].gl_texturenum = LoadDDS(szPath);
		s_idsgshot32[i] = gMHSharedFuncs.pfnRegisterDecal(&s_sgshot32[i]);

		sprintf_s(szPath, _TRUNCATE, "modernwarfare//gfx//BulletHole//sgshot64//sgshot64-%d.dds", i + 1);
		s_sgshot64[i].width	= s_sgshot64[i].height = 64;
		s_sgshot64[i].gl_texturenum = LoadDDS(szPath);
		s_idsgshot64[i] = gMHSharedFuncs.pfnRegisterDecal(&s_sgshot64[i]);

		sprintf_s(szPath, _TRUNCATE, "modernwarfare//gfx//BulletHole//sgshot96//sgshot96-%d.dds", i + 1);
		s_sgshot96[i].width	= s_sgshot96[i].height = 96;
		s_sgshot96[i].gl_texturenum = LoadDDS(szPath);
		s_idsgshot96[i] = gMHSharedFuncs.pfnRegisterDecal(&s_sgshot96[i]);

		sprintf_s(szPath, _TRUNCATE, "modernwarfare//gfx//BulletHole//sgshot128//sgshot128-%d.dds", i + 1);
		s_sgshot128[i].width	= s_sgshot128[i].height = 128;
		s_sgshot128[i].gl_texturenum = LoadDDS(szPath);
		s_idsgshot128[i] = gMHSharedFuncs.pfnRegisterDecal(&s_sgshot128[i]);
	}
}

/*
=====================
SpawnShell
=====================
*/
void SpawnShell(cl_entity_t *pPlayer, int iModelIndex, Vector vecOrigin, int iSoundType, int iBody)
{
	Vector vecForward, vecRight, vecUp;
	if (pPlayer == gEngfuncs.GetLocalPlayer())
		gEngfuncs.pfnAngleVectors(g_pparams.viewangles, vecForward, vecRight, vecUp);
	else
		gEngfuncs.pfnAngleVectors(pPlayer->angles, vecForward, vecRight, vecUp);

	Vector vecVelocity = Vector(pPlayer->curstate.velocity) + vecRight * RANDOM_FLOAT(100.0f, 150.0f) + vecUp * RANDOM_FLOAT(50.0f, 70.0f) + vecForward * 25.0f;

	TEMPENTITY *pTempEnt = gEngfuncs.pEfxAPI->R_TempModel(vecOrigin, vecVelocity, pPlayer->angles, 8, iModelIndex, iSoundType);	//gEngfuncs.pEventAPI->EV_FindModelIndex
	if (pTempEnt)
		pTempEnt->entity.curstate.body = iBody;
}

/*
=====================
DrawLight
=====================
*/
void DrawLight(Vector vecOrigin, float flRadius)
{
	// FIXME: make dim light to weapon code.

	dlight_t *dl = gEngfuncs.pEfxAPI->CL_AllocDlight(0);
	vecOrigin.CopyToArray(dl->origin);
	dl->radius = RANDOM_FLOAT(flRadius * 0.75f, flRadius * 1.25f);
	dl->die = gEngfuncs.GetClientTime() + 0.05f;
	dl->dark = true;
	dl->color.r = 255;
	dl->color.g = 150;
	dl->color.b = 15;
}

/*
=====================
DrawGunSmoke
=====================
*/
void CBaseWeapons::DrawGunSmoke(void)
{
	using namespace gDxtAnimManager;

	float flRandomSize	= RANDOM_FLOAT(0.8f, 1.25f);

	CBaseDDSAnim *p		= Add(RANDOM_LONG(0, 1) ? s_smoke1 : s_smoke2);

	p->SetLastingTime(RANDOM_FLOAT(0.8f, 1.0f));
	p->SetRGBA(190, 190, 190, RANDOM_FLOAT(60, 75));
	p->SetSize(24 * flRandomSize, 18 * flRandomSize);

	if (IsInferior())
		p->SetAttach(&g_c2ndVMDL.m_vecAttachments[GetMuzzleEnum()]);
	else
		p->SetAttach(gEngfuncs.GetViewModel(), GetMuzzleEnum());

	p->m_bitsFlags		|= FTENT_FADEOUT;
	p->m_vecOffset		= Vector(RANDOM_FLOAT(-2, 2), RANDOM_FLOAT(-2, 2), RANDOM_FLOAT(-2, 2));
}

/*
=====================
DrawGunShot
=====================
*/
int g_iGunShotDecal[5] = { 0, 0, 0, 0, 0 };

void DrawGunShot(Vector vecSrc, Vector vecEnd, int iAmmoIndex)
{
	pmtrace_t tr;
	UTIL_TraceLine(vecSrc, vecEnd, PM_STUDIO_BOX, -1, &tr, gEngfuncs.GetLocalPlayer()->index, 2);

	if (!g_iGunShotDecal[0])
	{
		g_iGunShotDecal[0] = gEngfuncs.pEfxAPI->Draw_DecalIndexFromName("{shot1");
		g_iGunShotDecal[1] = gEngfuncs.pEfxAPI->Draw_DecalIndexFromName("{shot2");
		g_iGunShotDecal[2] = gEngfuncs.pEfxAPI->Draw_DecalIndexFromName("{shot3");
		g_iGunShotDecal[3] = gEngfuncs.pEfxAPI->Draw_DecalIndexFromName("{shot4");
		g_iGunShotDecal[4] = gEngfuncs.pEfxAPI->Draw_DecalIndexFromName("{shot5");
	}

	if (!strcmp(g_sAmmoData[iAmmoIndex].m_szAmmoName, "buckshot"))
	{
		int *pIndexSet = s_idsgshot128;
		float flDistance = (vecSrc - tr.endpos).Length();

		if (flDistance <= 32)
			pIndexSet = s_idsgshot32;
		else if (flDistance <= 64)
			pIndexSet = s_idsgshot64;
		else if (flDistance <= 96)
			pIndexSet = s_idsgshot96;

		gMHSharedFuncs.pfnDrawCustomDecal(pIndexSet[RANDOM_LONG(0, 4)], gEngfuncs.pEventAPI->EV_IndexFromTrace(&tr), NULL, tr.endpos, FDECAL_NONE, 1.0f);
	}
	else if (iAmmoIndex <= 0 || iAmmoIndex > g_iAmmoTypes || !strnlen_s(g_sAmmoData[iAmmoIndex].m_szHole, _TRUNCATE))
	{
		int iDecalIndex = g_iGunShotDecal[RANDOM_LONG(0, 4)];
		gEngfuncs.pEfxAPI->R_DecalShoot(gEngfuncs.pEfxAPI->Draw_DecalIndex(iDecalIndex), gEngfuncs.pEventAPI->EV_IndexFromTrace(&tr), NULL, tr.endpos, 0);
	}
	else
	{
		const std::vector<int> *pvDecalIndex = &g_sAmmoData[iAmmoIndex].m_vHoleDecalId;	// UNDONE: when weapon changed it's mode.. We should use pWeapon->data here

		if (!pvDecalIndex->empty())
		{
			gMHSharedFuncs.pfnDrawCustomDecal((*pvDecalIndex)[RANDOM_LONG(0, pvDecalIndex->size() - 1)], gEngfuncs.pEventAPI->EV_IndexFromTrace(&tr), NULL, tr.endpos, FDECAL_NONE, 1.0f);
		}
	}

	gEngfuncs.pEfxAPI->R_StreakSplash(tr.endpos, tr.plane.normal, 5, 22, 25, -65, 65);
	gEngfuncs.pEfxAPI->R_BulletImpactParticles(tr.endpos);

	// decide counts and model
	int iCount, iModel;
	char chTextureType = UTIL_GetTextureType(&tr, vecSrc, vecEnd);
	switch (chTextureType)
	{
	default:
	case CHAR_TEX_CONCRETE:
	case CHAR_TEX_SLOSH:
		iCount = RANDOM_LONG(6, 8);
		iModel = MODEL_INDEX("models/gibs/gibs3.mdl");
		break;

		// those shouldn't have efx.
	case CHAR_TEX_METAL:
	case CHAR_TEX_VENT:
	case CHAR_TEX_GRATE:
	case CHAR_TEX_FLESH:
		iCount = 0;
		iModel = 0;
		break;

	case CHAR_TEX_TILE:
		iCount = RANDOM_LONG(8, 12);
		iModel = MODEL_INDEX("models/gibs/gibs2.mdl");
		break;

	case CHAR_TEX_WOOD:
		iCount = RANDOM_LONG(4, 8);
		iModel = MODEL_INDEX("models/gibs/gibs.mdl");
		break;

	case CHAR_TEX_COMPUTER:
	case CHAR_TEX_GLASS:
		iCount = RANDOM_LONG(4, 6);
		iModel = MODEL_INDEX("models/gibs/gibs4.mdl");
		break;
	}

	// decide angles, and dir vecs.
	Vector vAngles = VectorAngles(tr.plane.normal);
	Vector vForward, vRight, vUp;
	gEngfuncs.pfnAngleVectors(vAngles, vForward, vRight, vUp);

	for (int i = 0; i < iCount; i++)
	{
		Vector vecVelocity = vForward * RANDOM_FLOAT(75, 100) + vRight * RANDOM_FLOAT(-15, 15) + vUp * RANDOM_FLOAT(-15, 15);
		Vector vecSize(RANDOM_FLOAT(0.8, 1.2), RANDOM_FLOAT(0.8, 1.2), RANDOM_FLOAT(0.8, 1.2));

		gEngfuncs.pEfxAPI->R_BreakModel(tr.endpos + vecSize * RANDOM_FLOAT(-8, 8), vecSize, vecVelocity, 0, RANDOM_LONG(3, 5), RANDOM_LONG(1, 2), iModel, 0);
	}

	// ballistic sound efx.
	EV_HLDM_PlayTextureSound(&tr, vecSrc, vecEnd);

	using namespace gDxtAnimManager;

	float flRandomSize	= RANDOM_FLOAT(6, 9);

	CBaseDDSAnim *p		= Add(s_smoke1);	// smoke1 is more like wall smoke effect, so just keep smoke1.

	p->SetLastingTime(RANDOM_FLOAT(0.8f, 1.0f));
	p->SetRGBA(190, 190, 190, RANDOM_FLOAT(60, 75));
	p->SetSize(24 * flRandomSize, 18 * flRandomSize);

	p->m_bitsFlags		= FTENT_FADEOUT;
	p->m_vecOrigin		= Vector(tr.endpos) + Vector(tr.plane.normal) * RANDOM_LONG(5, 8);
	p->m_vecVelocity	= Vector(tr.plane.normal) * RANDOM_LONG(60, 90);
	p->m_vecAcceleration= Vector(tr.plane.normal) * -RANDOM_LONG(40, 60);
}

/*
=====================
EV_HLDM_PlayTextureSound
=====================
*/
float UTIL_PlayTextureSound( Vector vecOrigin, char chTextureType )
{
	float fvol;
	float fvolbar;
	char *rgsz[4];
	int cnt;
	float fattn = ATTN_NORM;
	
	switch (chTextureType)
	{
	default:
	case CHAR_TEX_CONCRETE: fvol = 0.9;	fvolbar = 0.6;
		rgsz[0] = "player/pl_step1.wav";
		rgsz[1] = "player/pl_step2.wav";
		cnt = 2;
		break;
	case CHAR_TEX_METAL: fvol = 0.9; fvolbar = 0.3;
		rgsz[0] = "player/pl_metal1.wav";
		rgsz[1] = "player/pl_metal2.wav";
		cnt = 2;
		break;
	case CHAR_TEX_DIRT:	fvol = 0.9; fvolbar = 0.1;
		rgsz[0] = "player/pl_dirt1.wav";
		rgsz[1] = "player/pl_dirt2.wav";
		rgsz[2] = "player/pl_dirt3.wav";
		cnt = 3;
		break;
	case CHAR_TEX_VENT:	fvol = 0.5; fvolbar = 0.3;
		rgsz[0] = "player/pl_duct1.wav";
		rgsz[1] = "player/pl_duct1.wav";
		cnt = 2;
		break;
	case CHAR_TEX_GRATE: fvol = 0.9; fvolbar = 0.5;
		rgsz[0] = "player/pl_grate1.wav";
		rgsz[1] = "player/pl_grate4.wav";
		cnt = 2;
		break;
	case CHAR_TEX_TILE:	fvol = 0.8; fvolbar = 0.2;
		rgsz[0] = "player/pl_tile1.wav";
		rgsz[1] = "player/pl_tile3.wav";
		rgsz[2] = "player/pl_tile2.wav";
		rgsz[3] = "player/pl_tile4.wav";
		cnt = 4;
		break;
	case CHAR_TEX_SLOSH: fvol = 0.9; fvolbar = 0.0;
		rgsz[0] = "player/pl_slosh1.wav";
		rgsz[1] = "player/pl_slosh3.wav";
		rgsz[2] = "player/pl_slosh2.wav";
		rgsz[3] = "player/pl_slosh4.wav";
		cnt = 4;
		break;
	case CHAR_TEX_WOOD: fvol = 0.9; fvolbar = 0.2;
		rgsz[0] = "debris/wood1.wav";
		rgsz[1] = "debris/wood2.wav";
		rgsz[2] = "debris/wood3.wav";
		cnt = 3;
		break;
	case CHAR_TEX_GLASS:
	case CHAR_TEX_COMPUTER:
		fvol = 0.8; fvolbar = 0.2;
		rgsz[0] = "debris/glass1.wav";
		rgsz[1] = "debris/glass2.wav";
		rgsz[2] = "debris/glass3.wav";
		cnt = 3;
		break;
	case CHAR_TEX_FLESH:
		fvol = 1.0;	fvolbar = 0.2;
		rgsz[0] = "weapons/bullet_hit1.wav";
		rgsz[1] = "weapons/bullet_hit2.wav";
		fattn = 1.0;
		cnt = 2;
		break;
	}

	// play material hit sound
	gEngfuncs.pEventAPI->EV_PlaySound( 0, vecOrigin, CHAN_STATIC, rgsz[gEngfuncs.pfnRandomLong(0,cnt-1)], fvol, fattn, 0, 96 + gEngfuncs.pfnRandomLong(0,0xf) );
	return fvolbar;
}

float EV_HLDM_PlayTextureSound( pmtrace_t *ptr, Vector vecSrc, Vector vecEnd )
{
	// hit the world, try to play sound based on texture material type
	char chTextureType = UTIL_GetTextureType(ptr, vecSrc, vecEnd);

	if (chTextureType == CHAR_TEX_COMPUTER)
	{
		// play random spark if computer

		if ( ptr->fraction != 1.0 && RANDOM_LONG(0,1))
		{
			gEngfuncs.pEfxAPI->R_SparkEffect(ptr->endpos,RANDOM_LONG(8, 12), -120, 120);

			float flVolume = RANDOM_FLOAT ( 0.7 , 1.0 );//random volume range
			switch ( RANDOM_LONG(0,1) )
			{
				case 0: gEngfuncs.pEventAPI->EV_PlaySound( 0, ptr->endpos, CHAN_STATIC, "buttons/spark5.wav", flVolume, ATTN_NORM, 0, 100); break;
				case 1: gEngfuncs.pEventAPI->EV_PlaySound( 0, ptr->endpos, CHAN_STATIC, "buttons/spark6.wav", flVolume, ATTN_NORM, 0, 100); break;
			}
		}
	}
	
	return UTIL_PlayTextureSound(ptr->endpos, chTextureType);
}

/*
=====================
ExplosionEffect
=====================
*/

void ExplosionEffect(Vector vecOrigin, char chTextureType, bool bBreakModel)
{
	gEngfuncs.pEfxAPI->R_TempSprite( Vector(vecOrigin.Make2D(), vecOrigin.z + 200.0f), g_pparams.forward, 2, MODEL_INDEX("sprites/rockeexplode.spr"), kRenderTransAdd, kRenderFxNone, 100.0f/255.0f, 0, FTENT_SPRANIMATE );

	gEngfuncs.pEfxAPI->R_TempSprite( Vector(vecOrigin.Make2D(), vecOrigin.z + 70.0f), g_pparams.forward, 3, MODEL_INDEX("sprites/zerogxplode-big1.spr"), kRenderTransAdd, kRenderFxNone, 1, 0, FTENT_SPRANIMATE );

	dlight_t *dl = gEngfuncs.pEfxAPI->CL_AllocDlight( 0 );
	dl->origin = vecOrigin;
	dl->radius	= 500;
	dl->color.r	= 255;
	dl->color.g	= 0;
	dl->color.b	= 0;
	dl->die		= gEngfuncs.GetClientTime() + 0.2f;
	dl->decay	= 0.01f;
	
	int truecontents;
	if (gEngfuncs.PM_PointContents(vecOrigin, &truecontents) == CONTENTS_WATER)
		return;

	vecOrigin.z += 40.0f;
	
	Vector vecOrigin2[8], vecOrigin3[21];
	vecOrigin3[0] = get_spherical_coord(vecOrigin, 100.0, 20.0, 0.0);
	vecOrigin3[1] = get_spherical_coord(vecOrigin, 0.0, 100.0, 0.0);
	vecOrigin3[2] = get_spherical_coord(vecOrigin, 100.0, 100.0, 0.0);
	vecOrigin3[3] = get_spherical_coord(vecOrigin, 70.0, 120.0, 0.0);
	vecOrigin3[4] = get_spherical_coord(vecOrigin, 120.0, 20.0, 0.0);
	vecOrigin3[5] = get_spherical_coord(vecOrigin, 120.0, 65.0, 0.0);
	vecOrigin3[6] = get_spherical_coord(vecOrigin, 120.0, 110.0, 0.0);
	vecOrigin3[7] = get_spherical_coord(vecOrigin, 120.0, 155.0, 0.0);
	vecOrigin3[8] = get_spherical_coord(vecOrigin, 120.0, 200.0, 0.0);
	vecOrigin3[9] = get_spherical_coord(vecOrigin, 120.0, 245.0, 0.0);
	vecOrigin3[10] = get_spherical_coord(vecOrigin, 120.0, 290.0, 20.0);
	vecOrigin3[11] = get_spherical_coord(vecOrigin, 120.0, 335.0, 20.0);
	vecOrigin3[12] = get_spherical_coord(vecOrigin, 120.0, 40.0, 20.0);
	vecOrigin3[13] = get_spherical_coord(vecOrigin, 40.0, 120.0, 20.0);
	vecOrigin3[14] = get_spherical_coord(vecOrigin, 40.0, 110.0, 20.0);
	vecOrigin3[15] = get_spherical_coord(vecOrigin, 60.0, 110.0, 20.0);
	vecOrigin3[16] = get_spherical_coord(vecOrigin, 110.0, 40.0, 20.0);
	vecOrigin3[17] = get_spherical_coord(vecOrigin, 120.0, 30.0, 20.0);
	vecOrigin3[18] = get_spherical_coord(vecOrigin, 30.0, 130.0, 20.0);
	vecOrigin3[19] = get_spherical_coord(vecOrigin, 30.0, 125.0, 20.0);
	vecOrigin3[20] = get_spherical_coord(vecOrigin, 30.0, 120.0, 20.0);

	char *pszModel = "models/concrete_gibs.mdl";	// HL
	switch (chTextureType)
	{
		default:
		case CHAR_TEX_CONCRETE:
			pszModel = "models/concrete_gibs.mdl";	// HL
			break;

		case CHAR_TEX_METAL:
		case CHAR_TEX_VENT:
			pszModel = "models/gibs/gibs_stairsmetal.mdl";	// CZDS
			break;

		case CHAR_TEX_GRATE:
			pszModel = "models/mechgibs.mdl";	// HL
			break;
			
		case CHAR_TEX_TILE:
			pszModel = "models/gibs/gibs_brickred.mdl";	// CZDS
			break;

		case CHAR_TEX_DIRT:
		case CHAR_TEX_SLOSH:
			pszModel = "models/gibs/gibs_wallbrown.mdl";	// CZDS
			break;

		case CHAR_TEX_WOOD:
			pszModel = "models/gibs/gibs_woodplank.mdl";	// CZDS
			break;

		case CHAR_TEX_COMPUTER:
			pszModel = "models/computergibs.mdl";	// HL
			break;

		case CHAR_TEX_GLASS:
			pszModel = "models/gibs/gibs4.mdl";	// DS
			break;

		case CHAR_TEX_FLESH:
			pszModel = "models/fleshgibs.mdl";	// HL
			break;
	}
	
	for (int i = 0; i < 21; i++)
	{
		if (i < 8 && bBreakModel)
		{
			Vector vecDir(RANDOM_FLOAT(-500.0, 500.0), RANDOM_FLOAT(-500.0, 500.0), RANDOM_FLOAT(-300.0, 300.0));
			gEngfuncs.pEfxAPI->R_BreakModel( vecOrigin, Vector(1), vecDir, 100, RANDOM_FLOAT(4, 8), RANDOM_LONG(1, 4), MODEL_INDEX(pszModel), 0x40 );
		}

		gEngfuncs.pEfxAPI->R_TempSprite( vecOrigin3[i], g_pparams.forward, 1, MODEL_INDEX("sprites/rockeexfire.spr"), kRenderTransAdd, kRenderFxNone, 1, 0, FTENT_SPRANIMATE );
	}
	
	vecOrigin.z += 120.0f;

	vecOrigin2[0] = get_spherical_coord(vecOrigin, 0.0, 0.0, 185.0);
	vecOrigin2[1] = get_spherical_coord(vecOrigin, 0.0, 80.0, 130.0);
	vecOrigin2[2] = get_spherical_coord(vecOrigin, 41.0, 43.0, 110.0);
	vecOrigin2[3] = get_spherical_coord(vecOrigin, 90.0, 90.0, 90.0);
	vecOrigin2[4] = get_spherical_coord(vecOrigin, 80.0, 25.0, 185.0);
	vecOrigin2[5] = get_spherical_coord(vecOrigin, 101.0, 100.0, 162.0);
	vecOrigin2[6] = get_spherical_coord(vecOrigin, 68.0, 35.0, 189.0);
	vecOrigin2[7] = get_spherical_coord(vecOrigin, 0.0, 95.0, 155.0);
	
	using namespace gDxtAnimManager;

	for (int i = 0; i < 8; i++)
	{
		//gEngfuncs.pEfxAPI->R_TempSprite( vecOrigin2[i], g_pparams.forward, 5, MODEL_INDEX("sprites/gas_smoke1.spr"), kRenderTransAdd, kRenderFxNone, 50.0f/255.0f, 0, FTENT_SPRANIMATE );
		
		float flRandomSize	= RANDOM_FLOAT(26, 29);

		CBaseDDSAnim *p		= Add(s_smoke1);	// smoke1 is more like wall smoke effect, so just keep smoke1.

		p->SetLastingTime(RANDOM_FLOAT(0.8f, 1.0f));
		p->SetRGBA(190, 190, 190, RANDOM_FLOAT(240, 255));
		p->SetSize(24 * flRandomSize, 18 * flRandomSize);
		p->SetLastingTime(RANDOM_FLOAT(10, 20), 30);

		p->m_bitsFlags		= FTENT_FADEOUT;
		p->m_vecOrigin		= vecOrigin2[i];
	}
}