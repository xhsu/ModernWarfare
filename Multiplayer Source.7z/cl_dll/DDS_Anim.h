#pragma once

#ifndef _DDS_ANIM_H_
#define _DDS_ANIM_H_

#include "vector.h"
#include "const.h"
#include "cl_entity.h"
#include <r_efx.h>

namespace gDxtAnimManager
{
	typedef struct animdata_s
	{
		char			m_szPath[256];
		char			m_szName[64];
		unsigned short	m_iMaxFrame;
		unsigned int	m_iTextureIndexs[64];
	}
	animdata_t;

	void		Initialization	( void );
	animdata_t	*LoadAnim		( const char *path,	const char *name,	int maxframe	);
};

class CBaseDDSAnim
{
public:
	CBaseDDSAnim			( void );
	virtual	~CBaseDDSAnim	( void );

public:
	virtual void SetTextureGroup	( const char *path,	const char *name,	int maxframe	);
	virtual void SetLastingTime		( double looptime,	int fps = NULL	);
	virtual void SetRGBA			( unsigned long RGB,	int a = 255	);
	virtual void Frame				( void );
	virtual void Draw				( void );

public:
	inline	void SetTextureGroup	( gDxtAnimManager::animdata_t *p	)
	{
		m_sAnimData = *p;
	}

	inline	void SetRGBA			( int r = 255,		int g = 255,	int b = 255,		int a = 255	)
	{
		m_sColor.r		= r;
		m_sColor.g		= g;
		m_sColor.b		= b;
		m_sColor.a		= a;
	}

	inline	void SetSize			( float w,			float h		)
	{
		m_flWidth	= w;
		m_flHeight	= h;
	}

	inline	void SetAttach			( cl_entity_t *ent = NULL,	int attachment = 0	)
	{
		if (ent)
		{
			m_pEntity	=	ent;
			m_bitsFlags	|=	FTENT_PLYRATTACHMENT;
		}
		else
		{
			m_pEntity	=	NULL;
			m_bitsFlags	&=	~FTENT_PLYRATTACHMENT;
		}

		m_pvecAttachOri	=	NULL;
		m_iAttachment	=	attachment;
	}
	inline	void SetAttach			( Vector *p	)
	{
		m_pvecAttachOri	=	p;
	}

public:
	gDxtAnimManager::animdata_t		m_sAnimData;

public:
	double			m_flTimeLoop;
	PackedColorVec	m_sColor;
	short			m_iFPS;
	short			m_iCurrentFrame;
	double			m_flPlayedRatio;
	double			m_flTimeStart;
	int				m_bitsFlags;
	cl_entity_t		*m_pEntity;
	short			m_iAttachment;
	Vector			m_vecOrigin;
	Vector			m_vecOffset;
	Vector			m_vecVelocity;
	Vector			m_vecAcceleration;
	float			m_flWidth;
	float			m_flHeight;
	Vector			*m_pvecAttachOri;

public:
	CBaseDDSAnim	*m_pNext;
};

namespace gDxtAnimManager
{
	CBaseDDSAnim	*Add		( animdata_t	*d	);
	void			Add			( CBaseDDSAnim	*pt	);
	void			UpdateAll	( void				);
	void			DrawAll		( void				);
};











































#endif