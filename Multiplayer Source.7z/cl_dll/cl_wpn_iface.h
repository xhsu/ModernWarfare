#pragma once

#ifndef _CL_WPN_IFACE_H_
#define _CL_WPN_IFACE_H_


void	Com_hl_Weapons_Init(void);

void	GiveWeapon(void);	// cmd func, dont call.
void	SwitchSwitcher(void);	// cmd func, dont call.
void	ChangeMode(void);	// cmd func, dont call.
void	Dropped(void);	// cmd func, dont call.
void	SetAccessory( void );	// cmd func, dont call.
void	DrawWeaponMenu( void );	// cmd func, dont call.
void	QuickKnife( void );	// cmd func, dont call.
void	AdjustCursor( void );	// cmd func, dont call.
void	Destroy( void );	// cmd func, dont call.

extern "C"
{
	void _DLLEXPORT HUD_PostRunCmd( struct local_state_s *from, struct local_state_s *to, struct usercmd_s *cmd, int runfuncs, double time, unsigned int random_seed );
}














































#endif // !_CL_WPN_IFACE_H_

