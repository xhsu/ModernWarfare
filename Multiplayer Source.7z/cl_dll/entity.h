#pragma once

#ifndef _ENTITY_H_
#define _ENTITY_H_

typedef enum enttype_e
{
	TYPE_NONE = 0,
	TYPE_LIVED_NPC,

	TYPE_COUNTS
} enttype_t;

extern int g_aiEntType[32767];
















































#endif
