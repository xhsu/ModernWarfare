//#define GL_LOADTEXTURE_SIG "\xA1\xC8\x20\xEC\x01\x8B\x4C\x24\x20\x8B\x54\x24\x1C\x50\x8B\x44"

//extern int (*g_pfnGL_LoadTexture)(char *identifier, int textureType, int width, int height, BYTE *data, int mipmap, int iType, BYTE *pPal);

//void Models_Texture_InstallHook(void);
void Dxt_Initialization(void);
//void LoadTextureConfig(void);

unsigned int LoadDDS(const char *szFile, int *iWidth = NULL, int *iHeight = NULL);
/*
struct	sTextureReplaceDatabase
{
	int		m_iType;
	char	m_szTarget[512];
	char	m_szReplace[512];
};

extern int g_iTexRep;
extern sTextureReplaceDatabase	g_sTexRepDB[512];

namespace gViewModelHandsTexture
{
	void	Initialization	( void );
	void	Think			( void );
	void	InferiorThink	( void );
};*/