#pragma once
#ifndef _BLOOM_H_
#define _BLOOM_H_

void Bloom_Init(void);
void Bloom_Pre(void);
void Bloom_Post(void);
















































#endif