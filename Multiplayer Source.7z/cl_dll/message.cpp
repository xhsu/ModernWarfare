/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//
//  hud_msg.cpp
//

#include "hud.h"
#include "cl_util.h"
#include "parsemsg.h"
#include "r_efx.h"
#include "message.h"
#include "event_api.h"
#include "entity.h"

#define MAX_CLIENTS 32

extern cvar_t *cl_lw;
extern float g_lastFOV;
extern cvar_t *sensitivity;

namespace gHUD
{
	int m_Teamplay = 0;
};

void InstallMessageHook(void)
{
	gEngfuncs.pfnHookUserMsg("ResetHUD",	MsgFunc_ResetHUD);
	gEngfuncs.pfnHookUserMsg("InitHUD",		MsgFunc_InitHUD);
	gEngfuncs.pfnHookUserMsg("GameMode",	MsgFunc_GameMode);
	gEngfuncs.pfnHookUserMsg("Damage",		MsgFunc_Damage);
	//gEngfuncs.pfnHookUserMsg("SetFOV",		MsgFunc_SetFOV);
	gEngfuncs.pfnHookUserMsg("GunShot",		MsgFunc_GunShot);
	gEngfuncs.pfnHookUserMsg("Sound",		MsgFunc_Sound);
	gEngfuncs.pfnHookUserMsg("HudText",		MsgFunc_HudText);
	gEngfuncs.pfnHookUserMsg("ExploEfx",	MsgFunc_ExploEfx);
	gEngfuncs.pfnHookUserMsg("EntMarker",	MsgFunc_EntMarker);
}

int MsgFunc_ResetHUD(const char *pszName, int iSize, void *pbuf )
{
	ASSERT( iSize == 0 );

	// reset sensitivity
	gHUD::m_flMouseSensitivity = 0;

	// reset concussion effect
	gHUD::m_iConcussionEffect = 0;

	return 1;
}

void CAM_ToFirstPerson(void);

int MsgFunc_ViewMode( const char *pszName, int iSize, void *pbuf )
{
	CAM_ToFirstPerson();

	return TRUE;
}

int MsgFunc_InitHUD( const char *pszName, int iSize, void *pbuf )
{
	return TRUE;
}


int MsgFunc_GameMode(const char *pszName, int iSize, void *pbuf )
{
	BEGIN_READ( pbuf, iSize );
	gHUD::m_Teamplay = READ_BYTE();

	return 1;
}


int MsgFunc_Damage(const char *pszName, int iSize, void *pbuf )
{
	int		armor, blood;
	Vector	from;
	int		i;
	float	count;
	
	BEGIN_READ( pbuf, iSize );
	armor = READ_BYTE();
	blood = READ_BYTE();

	for (i=0 ; i<3 ; i++)
		from[i] = READ_COORD();

	count = (blood * 0.5) + (armor * 0.5);

	if (count < 10)
		count = 10;

	// TODO: kick viewangles,  show damage visually

	return 1;
}

int MsgFunc_Concuss( const char *pszName, int iSize, void *pbuf )
{
	BEGIN_READ( pbuf, iSize );

	gHUD::m_iConcussionEffect = READ_BYTE();

	// TODO: recover concuss effects.

	return 1;
}

int MsgFunc_SetFOV(const char *pszName,  int iSize, void *pbuf)
{
	BEGIN_READ( pbuf, iSize );

	int newfov = READ_BYTE();
	int def_fov = gHUD::m_pCvarDefFOV->value;

	//Weapon prediction already takes care of changing the fog. ( g_lastFOV ).
	if ( cl_lw && cl_lw->value )
		return 1;

	g_lastFOV = newfov;

	if ( newfov == 0 )
	{
		gHUD::m_iFOV = def_fov;
	}
	else
	{
		gHUD::m_iFOV = newfov;
	}

	// the clients fov is actually set in the client data update section of the hud

	// Set a new sensitivity
	if ( gHUD::m_iFOV == def_fov )
	{  
		// reset to saved sensitivity
		gHUD::m_flMouseSensitivity = 0;
	}
	else
	{  
		// set a new sensitivity that is proportional to the change from the FOV default
		gHUD::m_flMouseSensitivity = sensitivity->value * ((float)newfov / (float)def_fov) * gHUD::m_pCvarZoomSenRatio->value;
	}

	return 1;
}

#include "pmtrace.h"
#include "pm_defs.h"
#include "cl_wpns.h"

int MsgFunc_GunShot(const char *pszName,  int iSize, void *pbuf)
{
	BEGIN_READ( pbuf, iSize );

	Vector vecEnd;
	vecEnd.x	= READ_COORD();
	vecEnd.y	= READ_COORD();
	vecEnd.z	= READ_COORD();

	Vector vecSrc;
	vecSrc.x	= READ_COORD();
	vecSrc.y	= READ_COORD();
	vecSrc.z	= READ_COORD();

	int iAmmoIndex = -1;
	if (iSize > 4*sizeof(short))
		iAmmoIndex = READ_BYTE();

	DrawGunShot(vecSrc, vecEnd, iAmmoIndex);

	return TRUE;
}

int MsgFunc_Sound(const char *pszName,  int iSize, void *pbuf)
{
	BEGIN_READ( pbuf, iSize );

	int index = READ_SHORT();

	char szSound[128];
	strcpy(szSound, READ_STRING());

	gEngfuncs.pEventAPI->EV_PlaySound(index, INDEXENT(index)->origin, CHAN_ITEM, szSound, VOL_NORM, ATTN_NORM, NULL, PITCH_NORM + RANDOM_LONG(-3, 3));

	return TRUE;
}

int MsgFunc_HudText(const char *pszName,  int iSize, void *pbuf)
{
	BEGIN_READ( pbuf, iSize );

	char szWords[512];
	strncpy_s(szWords, READ_STRING(), _TRUNCATE);

	gHUD::AddHintText(szWords);

	return TRUE;
}

int MsgFunc_ExploEfx(const char *pszName,  int iSize, void *pbuf)
{
	BEGIN_READ( pbuf, iSize );

	Vector vecSrc;
	vecSrc.x	= READ_COORD();
	vecSrc.y	= READ_COORD();
	vecSrc.z	= READ_COORD();

	int iItemType = READ_BYTE();

	char chTextureType = (char)READ_CHAR();

	bool bBreakModel = !!READ_BYTE();

	ExplosionEffect(vecSrc, chTextureType, bBreakModel);

	return TRUE;
}

int MsgFunc_EntMarker(const char *pszName,  int iSize, void *pbuf)
{
	BEGIN_READ( pbuf, iSize );

	int index = READ_SHORT();
	int type = READ_BYTE();

	g_aiEntType[index] = type;

	return TRUE;
}