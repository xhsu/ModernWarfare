//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#include <assert.h>
#include "hud.h"
#include "cl_util.h"
#include "const.h"
#include "com_model.h"
#include "studio.h"
#include "entity_state.h"
#include "cl_entity.h"
#include "dlight.h"
#include "triangleapi.h"
#include "cl_wpns.h"

#include <windows.h>
#include <stdio.h>
#include <triangleapi.h>
#include <gl/gl.h>
#include <string.h>
#include <memory.h>
#include <math.h>

#include "studio_util.h"
#include "r_studioint.h"

#include "StudioModelRenderer.h"
#include "GameStudioModelRenderer.h"
#include "bloom.h"

//
// Override the StudioModelRender virtual member functions here to implement custom bone
// setup, blending, etc.
//

// Global engine <-> studio model rendering code interface
extern engine_studio_api_t IEngineStudio;

// enging will help you to glEnable and glDisable when needed.
cvar_t *g_pCvarReverseVMDL = NULL;

// view model sub model controller
int	*g_pViewModelSubModel = NULL;
cl_entity_t *g_pViewEnt = NULL;
model_t	*g_pViewModel = NULL;

// view model anim controller
float g_flViewEntAnimTime = 0;

// expand the attachment slot.
Vector g_vecViewModelAttmt[MAX_VMDL_ATTACHMENT];


// The renderer object, created on the stack.
CGameStudioModelRenderer g_StudioRenderer;

/*
====================
CGameStudioModelRenderer

VidInit
====================
*/
void R_VidInit(void)
{
	g_pCvarReverseVMDL = gEngfuncs.pfnRegisterVariable("cl_righthand", "0", FCVAR_CLIENTDLL);
}

/*
====================
CGameStudioModelRenderer

====================
*/
CGameStudioModelRenderer::CGameStudioModelRenderer( void )
{
}

/*
====================
CGameStudioModelRenderer::StudioSetupBones

I Need to use CS VMDL, so I need to reverse model.
====================
*/
void CGameStudioModelRenderer::StudioSetupBones ( void )
{
	int					i;
	double				f;

	mstudiobone_t		*pbones;
	mstudioseqdesc_t	*pseqdesc;
	mstudioanim_t		*panim;

	static float		pos[MAXSTUDIOBONES][3];
	static vec4_t		q[MAXSTUDIOBONES];
	float				bonematrix[3][4];

	static float		pos2[MAXSTUDIOBONES][3];
	static vec4_t		q2[MAXSTUDIOBONES];
	static float		pos3[MAXSTUDIOBONES][3];
	static vec4_t		q3[MAXSTUDIOBONES];
	static float		pos4[MAXSTUDIOBONES][3];
	static vec4_t		q4[MAXSTUDIOBONES];

	if (m_pCurrentEntity->curstate.sequence >=  m_pStudioHeader->numseq) 
	{
		m_pCurrentEntity->curstate.sequence = 0;
	}

	pseqdesc = (mstudioseqdesc_t *)((byte *)m_pStudioHeader + m_pStudioHeader->seqindex) + m_pCurrentEntity->curstate.sequence;

	f = StudioEstimateFrame( pseqdesc );

	if (m_pCurrentEntity->latched.prevframe > f)
	{
		//Con_DPrintf("%f %f\n", m_pCurrentEntity->prevframe, f );
	}

	panim = StudioGetAnim( m_pRenderModel, pseqdesc );
	StudioCalcRotations( pos, q, pseqdesc, panim, f );

	if (pseqdesc->numblends > 1)
	{
		float				s;
		float				dadt;

		panim += m_pStudioHeader->numbones;
		StudioCalcRotations( pos2, q2, pseqdesc, panim, f );

		dadt = StudioEstimateInterpolant();
		s = (m_pCurrentEntity->curstate.blending[0] * dadt + m_pCurrentEntity->latched.prevblending[0] * (1.0 - dadt)) / 255.0;

		StudioSlerpBones( q, pos, q2, pos2, s );

		if (pseqdesc->numblends == 4)
		{
			panim += m_pStudioHeader->numbones;
			StudioCalcRotations( pos3, q3, pseqdesc, panim, f );

			panim += m_pStudioHeader->numbones;
			StudioCalcRotations( pos4, q4, pseqdesc, panim, f );

			s = (m_pCurrentEntity->curstate.blending[0] * dadt + m_pCurrentEntity->latched.prevblending[0] * (1.0 - dadt)) / 255.0;
			StudioSlerpBones( q3, pos3, q4, pos4, s );

			s = (m_pCurrentEntity->curstate.blending[1] * dadt + m_pCurrentEntity->latched.prevblending[1] * (1.0 - dadt)) / 255.0;
			StudioSlerpBones( q, pos, q3, pos3, s );
		}
	}
	
	if (m_fDoInterp &&
		m_pCurrentEntity->latched.sequencetime &&
		( m_pCurrentEntity->latched.sequencetime + 0.2 > m_clTime ) && 
		( m_pCurrentEntity->latched.prevsequence < m_pStudioHeader->numseq ))
	{
		// blend from last sequence
		static float		pos1b[MAXSTUDIOBONES][3];
		static vec4_t		q1b[MAXSTUDIOBONES];
		float				s;

		pseqdesc = (mstudioseqdesc_t *)((byte *)m_pStudioHeader + m_pStudioHeader->seqindex) + m_pCurrentEntity->latched.prevsequence;
		panim = StudioGetAnim( m_pRenderModel, pseqdesc );
		// clip prevframe
		StudioCalcRotations( pos1b, q1b, pseqdesc, panim, m_pCurrentEntity->latched.prevframe );

		if (pseqdesc->numblends > 1)
		{
			panim += m_pStudioHeader->numbones;
			StudioCalcRotations( pos2, q2, pseqdesc, panim, m_pCurrentEntity->latched.prevframe );

			s = (m_pCurrentEntity->latched.prevseqblending[0]) / 255.0;
			StudioSlerpBones( q1b, pos1b, q2, pos2, s );

			if (pseqdesc->numblends == 4)
			{
				panim += m_pStudioHeader->numbones;
				StudioCalcRotations( pos3, q3, pseqdesc, panim, m_pCurrentEntity->latched.prevframe );

				panim += m_pStudioHeader->numbones;
				StudioCalcRotations( pos4, q4, pseqdesc, panim, m_pCurrentEntity->latched.prevframe );

				s = (m_pCurrentEntity->latched.prevseqblending[0]) / 255.0;
				StudioSlerpBones( q3, pos3, q4, pos4, s );

				s = (m_pCurrentEntity->latched.prevseqblending[1]) / 255.0;
				StudioSlerpBones( q1b, pos1b, q3, pos3, s );
			}
		}

		s = 1.0 - (m_clTime - m_pCurrentEntity->latched.sequencetime) / 0.2;
		StudioSlerpBones( q, pos, q1b, pos1b, s );
	}
	else
	{
		//Con_DPrintf("prevframe = %4.2f\n", f);
		m_pCurrentEntity->latched.prevframe = f;
	}

	pbones = (mstudiobone_t *)((byte *)m_pStudioHeader + m_pStudioHeader->boneindex);

	// calc gait animation
	if (m_pPlayerInfo && m_pPlayerInfo->gaitsequence != 0)
	{
		if (m_pPlayerInfo->gaitsequence >= m_pStudioHeader->numseq) 
		{
			m_pPlayerInfo->gaitsequence = 0;
		}

		pseqdesc = (mstudioseqdesc_t *)((byte *)m_pStudioHeader + m_pStudioHeader->seqindex) + m_pPlayerInfo->gaitsequence;

		panim = StudioGetAnim( m_pRenderModel, pseqdesc );
		StudioCalcRotations( pos2, q2, pseqdesc, panim, m_pPlayerInfo->gaitframe );

		for (i = 0; i < m_pStudioHeader->numbones; i++)
		{
			if (strcmp( pbones[i].name, "Bip01 Spine") == 0)
				break;
			memcpy( pos[i], pos2[i], sizeof( pos[i] ));
			memcpy( q[i], q2[i], sizeof( q[i] ));
		}
	}


	for (i = 0; i < m_pStudioHeader->numbones; i++) 
	{
		QuaternionMatrix( q[i], bonematrix );

		bonematrix[0][3] = pos[i][0];
		bonematrix[1][3] = pos[i][1];
		bonematrix[2][3] = pos[i][2];

		if (pbones[i].parent == -1) 
		{
			// reverse model, like CS.
			if ( (m_pCurrentEntity == g_pViewEnt && !g_c2ndVMDL.GetDrawing() && g_pPlayerActivityItem && g_pPlayerActivityItem->m_sItemData.m_bReverseVMDL) ||
				(m_pCurrentEntity == g_pViewEnt && g_c2ndVMDL.GetDrawing() && g_c2ndVMDL.m_bReflect) )
			{
				bonematrix[1][0] = -bonematrix[1][0];
				bonematrix[1][1] = -bonematrix[1][1];
				bonematrix[1][2] = -bonematrix[1][2];
				bonematrix[1][3] = -bonematrix[1][3];
			}

			if ( IEngineStudio.IsHardware() )
			{
				ConcatTransforms ((*m_protationmatrix), bonematrix, (*m_pbonetransform)[i]);

				// MatrixCopy should be faster...
				//ConcatTransforms ((*m_protationmatrix), bonematrix, (*m_plighttransform)[i]);
				MatrixCopy( (*m_pbonetransform)[i], (*m_plighttransform)[i] );
			}
			else
			{
				ConcatTransforms ((*m_paliastransform), bonematrix, (*m_pbonetransform)[i]);
				ConcatTransforms ((*m_protationmatrix), bonematrix, (*m_plighttransform)[i]);
			}

			// Apply client-side effects to the transformation matrix
			StudioFxTransform( m_pCurrentEntity, (*m_pbonetransform)[i] );
		} 
		else 
		{
			ConcatTransforms ((*m_pbonetransform)[pbones[i].parent], bonematrix, (*m_pbonetransform)[i]);
			ConcatTransforms ((*m_plighttransform)[pbones[i].parent], bonematrix, (*m_plighttransform)[i]);
		}
	}
}

/*
====================
StudioCalcAttachments

====================
*/
void CGameStudioModelRenderer::StudioCalcAttachments( void )
{
	int i;
	mstudioattachment_t *pattachment;

	if ( m_pStudioHeader->numattachments > MAX_VMDL_ATTACHMENT )
	{
		gEngfuncs.Con_DPrintf( "Too many attachments on %s\n", m_pCurrentEntity->model->name );
		exit( -1 );
	}

	// calculate attachment points
	pattachment = (mstudioattachment_t *)((byte *)m_pStudioHeader + m_pStudioHeader->attachmentindex);
	for (i = 0; i < m_pStudioHeader->numattachments; i++)
	{
		if (!g_c2ndVMDL.GetDrawing())
		{
			if (i < 4)
			{
				VectorTransform( pattachment[i].org, (*m_plighttransform)[pattachment[i].bone],  m_pCurrentEntity->attachment[i] );
				VectorCopy( m_pCurrentEntity->attachment[i], g_vecViewModelAttmt[i] );
			}
			else
				VectorTransform( pattachment[i].org, (*m_plighttransform)[pattachment[i].bone],  g_vecViewModelAttmt[i] );
		}
		else
		{
			VectorTransform( pattachment[i].org, (*m_plighttransform)[pattachment[i].bone],  g_c2ndVMDL.m_vecAttachments[i] );
		}
	}
}

/*
====================
R_StudioDrawPlayer

====================
*/
int R_StudioDrawPlayer( int flags, entity_state_t *pplayer )
{
	return g_StudioRenderer.StudioDrawPlayer( flags, pplayer );
}

/*
====================
R_StudioDrawModel

====================
*/
int R_StudioDrawModel( int flags )
{
	if (IEngineStudio.GetCurrentEntity() == g_pViewEnt)
	{
		// UNDONE & FIXME: a failure bloom renderer.
		//Bloom_Pre();

		// 2nd model draw first.
		g_c2ndVMDL.Display(flags);

		if (!g_pViewModel)
		{
			g_pViewModel = IEngineStudio.Mod_ForName("models/weapons/v_nothing.mdl", 1);
		}

		g_pViewEnt->model = g_pViewModel;

		if (g_pPlayerActivityItem && g_pPlayerActivityItem->m_sItemData.m_bReverseVMDL)
			g_pCvarReverseVMDL->value = 1;
		else
			g_pCvarReverseVMDL->value = 0;

		// LUNA: fucking engine.
		g_pViewEnt->curstate.animtime = g_flViewEntAnimTime;

		// then draw.
		g_StudioRenderer.StudioDrawModel( flags );

		//Bloom_Post();
		return 1;
	}

	return g_StudioRenderer.StudioDrawModel( flags );
}

/*
====================
R_StudioInit

====================
*/
void R_StudioInit( void )
{
	g_StudioRenderer.Init();
	g_c2ndVMDL.Initialization();

	g_pViewEnt				= gEngfuncs.GetViewModel();
	g_pViewModelSubModel	= &g_pViewEnt->curstate.body;
}

// The simple drawing interface we'll pass back to the engine
r_studio_interface_t studio =
{
	STUDIO_INTERFACE_VERSION,
	R_StudioDrawModel,
	R_StudioDrawPlayer,
};

/*
====================
HUD_GetStudioModelInterface

Export this function for the engine to use the studio renderer class to render objects.
====================
*/
#define DLLEXPORT __declspec( dllexport )
extern "C" int DLLEXPORT HUD_GetStudioModelInterface( int version, struct r_studio_interface_s **ppinterface, struct engine_studio_api_s *pstudio )
{
	if ( version != STUDIO_INTERFACE_VERSION )
		return 0;

	// Point the engine to our callbacks
	*ppinterface = &studio;

	// Copy in engine helper functions
	memcpy( &IEngineStudio, pstudio, sizeof( IEngineStudio ) );

	// Initialize local variables, etc.
	R_StudioInit();

	// Success
	return 1;
}

/*
====================
CSecondaryViewModelManager

Allow you to show two vmdl on screen at once
====================
*/

CSecondaryViewModelManager g_c2ndVMDL;

void CSecondaryViewModelManager::Initialization(void)
{
	m_bIsDrawing	= NULL;
	m_pModel		= NULL;
	m_iSequence		= NULL;
	m_flAnimtime	= NULL;
	m_flFramerate	= NULL;
	m_flFrame		= NULL;
	m_bReflect		= NULL;
	m_piBody		= NULL;
	m_bVisible		= NULL;
	m_vecOfs		= Vector();
	m_vecRawOrg		= Vector();

	memset(m_iController, NULL, sizeof(m_iController));
	memset(m_vecAttachments, NULL, sizeof(m_vecAttachments));

	//memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
}

void CSecondaryViewModelManager::SetModel(const char *sz)
{
	m_pModel = IEngineStudio.Mod_ForName(sz, TRUE);
}

void CSecondaryViewModelManager::Display(int flags)
{
	static cl_entity_t save;
	static Vector vecTemp;

	if (!m_pModel || !m_bVisible)
		return;

	save = *g_pViewEnt;

	//prevent from bothering by others.
	m_bIsDrawing = true;

	g_pViewEnt->model				= m_pModel;
	g_pViewEnt->curstate.sequence	= m_iSequence;
	g_pViewEnt->curstate.animtime	= m_flAnimtime;
	g_pViewEnt->curstate.framerate	= m_flFramerate;
	g_pViewEnt->curstate.frame		= m_flFrame;
	g_pViewEnt->curstate.body		= (m_piBody ? (*m_piBody) : 0);

	//vecTemp = (m_vecOfs.y * gHUD::TriDimnHud::m_vecForward - m_vecOfs.x * gHUD::TriDimnHud::m_vecRight + m_vecOfs.z * gHUD::TriDimnHud::m_vecUp);
	//VectorAdd(g_pViewEnt->origin, vecTemp, g_pViewEnt->origin);

	if (IS_DUALING)
	{
		// here are our real calcu.
		vecTemp = m_vecOfs.y * gHUD::TriDimnHud::m_vecForward + m_vecOfs.x * gHUD::TriDimnHud::m_vecRight + m_vecOfs.z * gHUD::TriDimnHud::m_vecUp;
		g_pViewEnt->origin = m_vecRawOrg + vecTemp;
	}

	// applying origin
	VectorCopy(g_pViewEnt->origin, g_pViewEnt->curstate.origin);

	// reflecting model
	g_pCvarReverseVMDL->value = m_bReflect;

	// UNDONE
	// for inferior weapon hand texture.
	//gViewModelHandsTexture::InferiorThink();

	// draw
	g_StudioRenderer.StudioDrawModel( flags );

	// restore
	*g_pViewEnt	= save;

	m_bIsDrawing = false;
}

void CSecondaryViewModelManager::SetAnim(int iSeq)
{
	m_iSequence		= iSeq;
	m_flAnimtime	= gEngfuncs.GetClientTime();
	m_flFramerate	= 1;
	m_flFrame		= 0;
}
/*
void CSecondaryViewModelManager::PushAnim(void)
{
	m_sAnimStack.m_flAnimtime	= m_flAnimtime;
	m_sAnimStack.m_flFrame		= m_flFrame;
	m_sAnimStack.m_flFramerate	= m_flFramerate;
	m_sAnimStack.m_iSequence	= m_iSequence;
}

void CSecondaryViewModelManager::PopAnim(void)
{
	m_flAnimtime	= m_sAnimStack.m_flAnimtime;
	m_flFrame		= m_sAnimStack.m_flFrame;
	m_flFramerate	= m_sAnimStack.m_flFramerate;
	m_iSequence		= m_sAnimStack.m_iSequence;
}*/