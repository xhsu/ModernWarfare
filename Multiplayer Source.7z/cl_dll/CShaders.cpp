#include <sysdef.h>
#include "glext.h"
#include <iostream>
#include "CShaders.h"
#include "qgl.h"


char *FS_LoadFile( const char *filename )
{
	FILE	*file;
	int		size;
	char	*buffer;

	if ( !( file = fopen( filename, "rb" ) ) )
	{
		return 0;
	}

	fseek( file, 0, SEEK_END );
	size = ftell( file );
	fseek( file, 0, SEEK_SET );

	if ( size == 0 )
	{
		fclose( file );
		return 0;
	}

	buffer = (char *)malloc( size + 1 );	// more one for '\0'

	if ( !buffer )
	{
		fclose( file );
		return 0;
	}

	if ( fread( buffer, size, 1, file ) != 1 )
	{
		fclose( file );
		free( buffer );
		return 0;
	}

	// make sure string NULL terminated
	buffer[size] = 0;

	fclose( file );

	return buffer;
}

void CShaders::Initialize(const GLchar * vsh, const GLchar * fsh, GLuint & iId)
{
	// vertex shader
	unsigned int vertexShader;
	vertexShader = glCreateShader(GL_VERTEX_SHADER);

	GLcharARB *src = FS_LoadFile(vsh);
	glShaderSource(vertexShader, 1, &src, NULL);
	glCompileShader(vertexShader);

	int  success;
	char infoLog[512];
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);

	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}
	
	free(src);

	// fragment shader
	unsigned int fragmentShader;
	src = FS_LoadFile(fsh);
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &src, NULL);
	glCompileShader(fragmentShader);

	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	free(src);

	// shader program
	iId = glCreateProgram();

	glAttachShader(iId, vertexShader);
	glAttachShader(iId, fragmentShader);
	glLinkProgram(iId);

	glGetProgramiv(iId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(iId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	glDeleteShader(vertexShader);	// FIXME
	glDeleteShader(fragmentShader);
}

void CShaders::Initialize(const GLchar * vsh, const GLchar * fsh)
{
	Initialize(vsh, fsh, m_iId);
}

void CShaders::Use(void) const
{
	glUseProgram(m_iId);
}
