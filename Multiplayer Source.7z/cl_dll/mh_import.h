#pragma once
#ifndef _MH_IMPORT_H_
#define _MH_IMPORT_H_

#include "../mh_dll/cl_api.h"
extern mw_mh_apis_t gMHSharedFuncs;















































#endif