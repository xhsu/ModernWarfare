/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//
//  cdll_int.c
//
// this implementation handles the linking of the engine to the DLL
//

#include <sysdef.h>

#include "hud.h"
#include "hud_menu.h"
#include "hud_wpn.h"
#include "hud_cmd.h"

#include "cl_util.h"
#include "cl_entity.h"
#include "netadr.h"
#include "cl_wpns.h"
#include "cl_wpn_iface.h"
#include "message.h"
#include "entity.h"

#include "dxt.h"
#include "GameStudioModelRenderer.h"
#include "DDS_Anim.h"
#include "qgl.h"
#include "bloom.h"

extern "C"
{
#include "pm_shared.h"
#include "pm_defs.h"
}

#include "IClientVGUI.h"
#include "mh_import.h"

#define DLLEXPORT __declspec( dllexport )


cl_enginefunc_t gEngfuncs;
mw_mh_apis_t gMHSharedFuncs;

void InitInput (void);
void EV_HookEvents( void );
void IN_Commands( void );

extern "C" 
{
int		DLLEXPORT Initialize( cl_enginefunc_t *pEnginefuncs, int iVersion );
int		DLLEXPORT HUD_VidInit( void );
void	DLLEXPORT HUD_Init( void );
int		DLLEXPORT HUD_Redraw( float flTime, int intermission );
int		DLLEXPORT HUD_UpdateClientData( client_data_t *cdata, float flTime );
void	DLLEXPORT HUD_Reset ( void );
void	DLLEXPORT HUD_PlayerMove( struct playermove_s *ppmove, int server );
void	DLLEXPORT HUD_PlayerMoveInit( struct playermove_s *ppmove );
char	DLLEXPORT HUD_PlayerMoveTexture( char *name );
int		DLLEXPORT HUD_ConnectionlessPacket( const struct netadr_s *net_from, const char *args, char *response_buffer, int *response_buffer_size );
int		DLLEXPORT HUD_GetHullBounds( int hullnumber, float *mins, float *maxs );
void	DLLEXPORT HUD_Frame( double time );
void	DLLEXPORT HUD_VoiceStatus(int entindex, qboolean bTalking);
void	DLLEXPORT HUD_DirectorMessage( int iSize, void *pbuf );
void	DLLEXPORT MH_Initialize ( void );
}

/*
========================== 
    Initialize

Called when the DLL is first loaded.
==========================
*/
int DLLEXPORT Initialize( cl_enginefunc_t *pEnginefuncs, int iVersion )
{
	gEngfuncs = *pEnginefuncs;

	if (iVersion != CLDLL_INTERFACE_VERSION)
		return 0;

	memcpy(&gEngfuncs, pEnginefuncs, sizeof(cl_enginefunc_t));

	EV_HookEvents();

	Dxt_Initialization();

	MH_Initialize();

	return 1;
}

/*
================================
HUD_GetHullBounds

  Engine calls this to enumerate player collision hulls, for prediction.  Return 0 if the hullnumber doesn't exist.
================================
*/
int DLLEXPORT HUD_GetHullBounds( int hullnumber, float *mins, float *maxs )
{
	int iret = 0;

	switch ( hullnumber )
	{
	case 0:				// Normal player
		mins = Vector(-16, -16, -36);
		maxs = Vector(16, 16, 36);
		iret = 1;
		break;
	case 1:				// Crouched player
		mins = Vector(-16, -16, -18 );
		maxs = Vector(16, 16, 18 );
		iret = 1;
		break;
	case 2:				// Point based hull
		mins = Vector( 0, 0, 0 );
		maxs = Vector( 0, 0, 0 );
		iret = 1;
		break;
	}

	g_pMaxs[hullnumber]	= maxs;
	g_pMins[hullnumber] = mins;

	return iret;
}

/*
================================
HUD_ConnectionlessPacket

 Return 1 if the packet is valid.  Set response_buffer_size if you want to send a response packet.  Incoming, it holds the max
  size of the response_buffer, so you must zero it out if you choose not to respond.
================================
*/
int	DLLEXPORT HUD_ConnectionlessPacket( const struct netadr_s *net_from, const char *args, char *response_buffer, int *response_buffer_size )
{
	// Parse stuff from args
	int max_buffer_size = *response_buffer_size;

	// Zero it out since we aren't going to respond.
	// If we wanted to response, we'd write data into response_buffer
	*response_buffer_size = 0;

	// Since we don't listen for anything here, just respond that it's a bogus message
	// If we didn't reject the message, we'd return 1 for success instead.
	return 0;
}

void DLLEXPORT HUD_PlayerMoveInit( struct playermove_s *ppmove )
{
	PM_Init( ppmove );

	// for CL side ducking judge.
	g_pPMUseHull = &(ppmove->usehull);
}

char DLLEXPORT HUD_PlayerMoveTexture( char *name )
{
	return PM_FindTextureType( name );
}

void DLLEXPORT HUD_PlayerMove( struct playermove_s *ppmove, int server )
{
	PM_Move( ppmove, server );
}


/*
==========================
	HUD_VidInit

Called when the game initializes
and whenever the vid_mode is changed
so the HUD can reinitialize itself.

LUNA: SPRITE
==========================
*/

int DLLEXPORT HUD_VidInit( void )
{
	gHUD::VidInit();
	gDxtAnimManager::Initialization();
	UTIL_RemoveAllItems();
	gStdWpnHud::VidInit();
	UTIL_EfxVidInit();
	memset(g_aiEntType, NULL, sizeof(g_aiEntType));
	Bloom_Init();
	return 1;
}

/*
==========================
	HUD_Init

Called whenever the client connects
to a server.  Reinitializes all 
the hud variables.

LUNA:	This is called every time the DLL is loaded.
		msghook, cmdhook, cvarreg, sprlist clear.
==========================
*/

void DLLEXPORT HUD_Init( void )
{
	InitInput();
	gHUD::Init();
	gHUD::InitCommand();
	HUD_MenuTestInit();
	Com_hl_Weapons_Init();
	R_VidInit();
	InstallMessageHook();
	qgl_LoadFunctions();

	// Load Weapons Here.
	InitializeWpnDB();
	LoadDirectory();
	gStdWpnHud::Initialize();
}


/*
==========================
	HUD_Redraw

called every screen frame to
redraw the HUD.
===========================
*/

int DLLEXPORT HUD_Redraw( float time, int intermission )
{
	gHUD::m_iIntermission = intermission;

	// bloody screen efx.
	gHUD::BiDimnHud::DrawBloodScreen();

	// screen fade.
	g_cScreenFade.Think();
	g_cScreenFade.Draw();

	if (g_pPlayerActivityItem)
	{
		g_pPlayerActivityItem->HUD_Think2D();
		g_pPlayerActivityItem->HUD_Draw2D();
	}

	return 1;
}


/*
==========================
	HUD_UpdateClientData

called every time shared client
dll/engine data gets changed,
and gives the cdll a chance
to modify the data.

returns 1 if anything has been changed, 0 otherwise.
==========================
*/

int DLLEXPORT HUD_UpdateClientData(client_data_t *pcldata, float flTime )
{
	IN_Commands();

	return gHUD::UpdateClientData(pcldata, flTime );
}

/*
==========================
	HUD_Reset

Called at start and end of demos to restore to "non"HUD state.
==========================
*/

void DLLEXPORT HUD_Reset( void )
{
	gHUD::VidInit();
}

/*
==========================
HUD_Frame

Called by engine every frame that client .dll is loaded
==========================
*/

void DLLEXPORT HUD_Frame( double time )
{
	g_flClientTime += time;
	g_flClientFrame = time;

	// dds anims: drawing in TRI.cpp
	gDxtAnimManager::UpdateAll();
}


/*
==========================
HUD_VoiceStatus

Called when a player starts or stops talking.
==========================
*/

void DLLEXPORT HUD_VoiceStatus(int entindex, qboolean bTalking)
{
}

/*
==========================
HUD_DirectorEvent

Called when a director event message was received
==========================
*/

void DLLEXPORT HUD_DirectorMessage( int iSize, void *pbuf )
{
}

/*
==========================
MH_Initialize

Copy functions from Metahook.
==========================
*/
void DLLEXPORT MH_Initialize(void)
{
	HMODULE hMetahookDLL = LoadLibrary("mw_metahook.dll");

	if (!hMetahookDLL)
		return;

	MH_GetAPIFunc pfn = (MH_GetAPIFunc)GetProcAddress(hMetahookDLL, "CL_GetAPI");

	if (pfn)
		pfn(&gMHSharedFuncs);

	if (gMHSharedFuncs.version != MW_MH_API_CURRENT_VERSION)	// you cant play this game without Metahook.dll, or wrong version.
		exit(0);
}


