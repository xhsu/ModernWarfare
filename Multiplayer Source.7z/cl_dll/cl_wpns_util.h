//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

// com_weapons.h
// Shared weapons common function prototypes
#if !defined( COM_WEAPONSH )
#define COM_WEAPONSH
#ifdef _WIN32
#pragma once
#endif

#include "hud_iface.h"
#include "pmtrace.h"

class CBaseWeapons;
typedef CBaseWeapons wpn_c;

// use in CreateWeapon() only.
#define LINK_CLASS_TO_ITEM(name,whichclass)	if (!strcmp(sz, #name))	\
												return new whichclass


void	COM_Log( char *pszFile, char *fmt, ...);
int		CL_IsDead( void );
void	UTIL_ServerCmd( char *szFmt, ... );

float	UTIL_SharedRandomFloat( unsigned int seed, float low, float high );
int		UTIL_SharedRandomLong( unsigned int seed, int low, int high );
float	UTIL_WeaponTimeBase( void );

int		HUD_GetWeaponAnim( void );
void	HUD_SendWeaponAnim( int iAnim, int iBody = 0 );
void	HUD_PlaySound( char *sound, float volume );
void	HUD_SetMaxSpeed( float speed );
wpn_c	*UTIL_UserHasWpn( int iWeaponType, CBaseWeapons *pExclusive = NULL );
void	SwitchWeapon( CBaseWeapons *pTarget );
wpn_c	*GiveWeapon(int iType);
wpn_c	*UTIL_SortItemsBySlot(void);
wpn_c	*UTIL_SlotBestWpn(int iSlot);
wpn_c	*UTIL_GetLastWpn(void);
wpn_c	*UTIL_GetNextWpn(void);
void	UTIL_ReleaseRun( void );
void	UTIL_ReleaseDuck( void );
void	SpawnShell(cl_entity_t *pPlayer, int iModelIndex, Vector vecOrigin, int iSoundType, int iBody);
void	DrawLight(Vector vecOrigin, float flRadius);
void	DrawGunShot(Vector vecSrc, Vector vecEnd, int iAmmoIndex = -1);
void	DrawGunShot(pmtrace_t *tr, int iAmmoIndex = -1);
float	UTIL_PlayTextureSound( Vector vecOrigin, char chTextureType );
float	EV_HLDM_PlayTextureSound( pmtrace_t *ptr, Vector vecSrc, Vector vecEnd );


extern cvar_t *cl_lw;

extern struct local_state_s g_sLocalState;

#define IS_RUNNING	(m_ulStatus & WPN_FLAG_RUN)
#define IS_AIMING	(m_ulStatus & WPN_FLAG_AIM)
#define IS_DUALING	(g_pPlayerActivityItem && g_pPlayerActivityItem->m_pAltWeapon)

#define BP_MAGAZINE	g_cMagManager.m_iMagAmount[m_sItemData.m_pMagDB->m_iType]
#define	AMMUNITION	g_cMagManager.m_iAmmoAmount[m_sItemData.m_pAmmoDB->m_iType]

typedef struct sAmmo ammo_t;

typedef struct fakeplayer_s
{
	float	m_flMaxSpeed;
	float	m_flResumeZoom;
	float	m_flLastZoom;
	float	m_flEjectBrass;
	ammo_t	*m_pBrassType;
	int		m_iBrassAttachment;
	int		m_afButtonLast;
	int		m_afButtonPressed;
	int		m_afButtonReleased;

} fakeplayer_t;

extern fakeplayer_t g_sFakePlayer;

#endif