#ifndef _HUD_MENU_H_
#define _HUD_MENU_H_

class CBaseMenuItem;
class CBaseMenuTable;

class CBaseMenuTable
{
public:
	void *operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void *ptr)
	{
		free(ptr);
	}
	CBaseMenuTable(void);
	virtual ~CBaseMenuTable(void);

	CBaseMenuItem	*m_pFirstChild;
	CBaseMenuTable	*m_pSwitchTo;

public:
	wchar_t			m_wszBuffer[512];
	float			m_flMiscAlpha;
	bool			m_bShouldDraw;
	Vector			m_vecLeanCenter;
	wchar_t			m_wszTitle[64];
	int				m_iCurrentPage;
	int				m_iPageCount;
	int				m_iChildrenCount;

public:
	virtual void	Think			( void );
	virtual	void	Draw			( void );
	virtual Vector	GetDrawOrigin	( void );
	virtual bool	AddChild		( CBaseMenuItem *p );
	virtual int		ChildrenCount	( void );
	virtual	float	GetItemGap		( void )	{ return HUD_SIZE_GAP;	}
	virtual void	RemoveAllItems	( void );
	virtual void	Select			( int iId );
	virtual	bool	TurnPage		( int iPage );
	virtual	int		PageCount		( void );

	CBaseMenuItem	*GetPageHeader	( int iPage = -1 );

	inline	bool	PageUp			( void )	{ return TurnPage(m_iCurrentPage - 1);	}
	inline	bool	PageDown		( void )	{ return TurnPage(m_iCurrentPage + 1);	}
};

class CBaseMenuItem
{
public:
	void *operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void *ptr)
	{
		free(ptr);
	}
	CBaseMenuItem(void);
	virtual ~CBaseMenuItem(void);

	CBaseMenuItem	*m_pNext;
	CBaseMenuTable	*m_pParent;

public:
	wchar_t			m_wszString[512];
	color24			m_sColor;
	bool			m_bCanDelete;	// use to mark whether it's create by new/malloc or a global var.

public:
	virtual	float	GetHeight		( void )	{ return HUD_SIZE_STRING_TALL;	}
	virtual void	Think			( void )	{	}
	virtual bool	QuitFromMenu	( void );
	virtual void	Select			( void )	{ CloseMenu();	}
	virtual bool	AddParent		( CBaseMenuTable *p );
	inline	void	CloseMenu		( void )	{ if (m_pParent) m_pParent->m_bShouldDraw = false;	}
};

extern CBaseMenuTable *g_pCurrentMenu;

void HUD_MenuTestInit(void);
void HUD_MenuDraw(void);
void HUD_SwitchMenu(CBaseMenuTable *pTarget);













































#endif