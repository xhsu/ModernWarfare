#include "hud.h"
#include "hud_menu.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "keydefs.h"
#include "mh_import.h"

namespace gHUD
{
	void	InitCommand	( void );

	void	Slot1		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(1); else SwitchWeapon(UTIL_SlotBestWpn(1));	}
	void	Slot2		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(2); else SwitchWeapon(UTIL_SlotBestWpn(2));	}
	void	Slot3		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(3); else SwitchWeapon(UTIL_SlotBestWpn(3));	}
	void	Slot4		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(4); else SwitchWeapon(UTIL_SlotBestWpn(4));	}
	void	Slot5		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(5); else SwitchWeapon(UTIL_SlotBestWpn(5));	}
	void	Slot6		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(6); else SwitchWeapon(UTIL_SlotBestWpn(6));	}
	void	Slot7		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(7); else SwitchWeapon(UTIL_SlotBestWpn(7));	}
	void	Slot8		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(8); else SwitchWeapon(UTIL_SlotBestWpn(8));	}
	void	Slot9		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->Select(9); else SwitchWeapon(UTIL_SlotBestWpn(9));	}
	void	Slot0		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->m_bShouldDraw = false; else SwitchWeapon(UTIL_SlotBestWpn(10));	}
	void	WheelUp		( void );
	void	WheelDown	( void );
	void	PageUp		( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->PageUp();		}
	void	PageDown	( void )	{ if (g_pCurrentMenu) g_pCurrentMenu->PageDown();	}
};

void testfunc(void)
{
	/*Vector vec(0, 5, 5);
	Vector save(vec);

	Vector i(1, 0, 0);
	Vector j(0, 1, 0);
	Vector k(0, 0, 1);
	AngleVectors(vec.VectorAngles(), i, j, k);

	float fl = Math::DegreeToRadian(30);
	float ang = RANDOM_FLOAT(0, M_PI);
	float sine = sin(fl);
	float cosine = cos(fl);
	float tangent = tan(fl);

	float lenK = tangent * vec.Length();
	vec += j * tangent * vec.Length() * cos(ang) + k * tangent * vec.Length() * sin(ang);
	//vec = vec.SetLength(save.Length());

	double rstl = Math::RadianToDegree(vec ^ save);*/

	const char *keyname = gMHSharedFuncs.Key_NameForBinding(gEngfuncs.Cmd_Argv(1));
	gEngfuncs.Con_Printf("Key Name = %s\n", keyname);
}

void gHUD::InitCommand(void)
{
	gEngfuncs.pfnAddCommand("slot1", gHUD::Slot1);
	gEngfuncs.pfnAddCommand("slot2", gHUD::Slot2);
	gEngfuncs.pfnAddCommand("slot3", gHUD::Slot3);
	gEngfuncs.pfnAddCommand("slot4", gHUD::Slot4);
	gEngfuncs.pfnAddCommand("slot5", gHUD::Slot5);
	gEngfuncs.pfnAddCommand("slot6", gHUD::Slot6);
	gEngfuncs.pfnAddCommand("slot7", gHUD::Slot7);
	gEngfuncs.pfnAddCommand("slot8", gHUD::Slot8);
	gEngfuncs.pfnAddCommand("slot9", gHUD::Slot9);
	gEngfuncs.pfnAddCommand("slot0", gHUD::Slot0);

	gEngfuncs.pfnAddCommand("invprev", gHUD::WheelUp);
	gEngfuncs.pfnAddCommand("invnext", gHUD::WheelDown);

	gEngfuncs.pfnAddCommand("menupageup",	gHUD::PageUp);
	gEngfuncs.pfnAddCommand("menupagedown",	gHUD::PageDown);

	gEngfuncs.pfnAddCommand("test", testfunc);
}

void gHUD::WheelUp(void)
{
	if (g_pPlayerActivityItem)
	{
		if (g_pPlayerActivityItem->MouseWheel(true))
			SwitchWeapon(UTIL_GetLastWpn());
	}
	else
		SwitchWeapon(UTIL_GetLastWpn());
}

void gHUD::WheelDown(void)
{
	if (g_pPlayerActivityItem)
	{
		if (g_pPlayerActivityItem->MouseWheel(false))
			SwitchWeapon(UTIL_GetNextWpn());
	}
	else
		SwitchWeapon(UTIL_GetNextWpn());
}