#ifndef _WPN_ACC_H_
#pragma once

#include "hud_wpn.h"

class CBaseAccessory : public gStdWpnHud::CBaseMenuAcc	// yes, it's derivated from CBaseMenuAcc..
{
public:

	static CBaseAccessory *AddByName(const char *sz = "");
	static CBaseAccessory *AddByIndex(int index);
};
















































#endif