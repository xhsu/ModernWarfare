//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#if !defined( GAMESTUDIOMODELRENDERER_H )
#define GAMESTUDIOMODELRENDERER_H
#if defined( _WIN32 )
#pragma once
#endif

#include "vector.h"
#include "const.h"
#include "com_model.h"
#include "studio.h"
#include "studio_util.h"
#include "r_studioint.h"
#include "StudioModelRenderer.h"

// Global engine <-> studio model rendering code interface
extern engine_studio_api_t IEngineStudio;
extern cvar_t *g_pCvarReverseVMDL;

/*
====================
CGameStudioModelRenderer

VidInit
====================
*/
void R_VidInit(void);

/*
====================
CGameStudioModelRenderer

====================
*/
class CGameStudioModelRenderer : public CStudioModelRenderer
{
public:
	CGameStudioModelRenderer( void );

	// Find final attachment points
	// Luna: I want to expand attachment slots.
	virtual void StudioCalcAttachments ( void );

	// Set up model bone positions
	// Luna: I use it to make CS VMDL compatible
	virtual void StudioSetupBones ( void );	
};

/*
====================
CSecondaryViewModelManager

Allow you to show two vmdl on screen at once
====================
*/

#define MAX_VMDL_ATTACHMENT	12

extern int			*g_pViewModelSubModel;
extern cl_entity_t	*g_pViewEnt;
extern model_t		*g_pViewModel;
extern Vector		g_vecViewModelAttmt[MAX_VMDL_ATTACHMENT];
extern float		g_flViewEntAnimTime;

class CSecondaryViewModelManager
{
public:
	void *operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void *ptr)
	{
		free(ptr);
	}

private:
	bool		m_bIsDrawing;

public:
	model_t		*m_pModel;
	int			m_iSequence;
	float		m_flAnimtime;
	float		m_flFramerate;
	float		m_flFrame;
	bool		m_bReflect;
	int			*m_piBody;
	bool		m_bVisible;
	Vector		m_vecOfs;
	int			m_iController[4];
	Vector		m_vecAttachments[MAX_VMDL_ATTACHMENT];
	Vector		m_vecRawOrg;
	//entanim_t	m_sAnimStack;

public:
	void	Initialization	( void				);	// this is a reset.
	void	SetModel		( const char *sz	);
	void	Display			( int flags			);
	void	SetAnim			( int iSeq			);
	bool	GetDrawing		( void				)	{ return m_bIsDrawing;	}
	/*void	PushAnim		( void				);
	void	PopAnim			( void				);*/
};

extern CSecondaryViewModelManager g_c2ndVMDL;

#endif // GAMESTUDIOMODELRENDERER_H