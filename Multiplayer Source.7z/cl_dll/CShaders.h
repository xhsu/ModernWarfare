#pragma once
#ifndef _CSHADER_H_
#define _CSHADER_H_

#include "glext.h"


class CShaders
{
public:
	static void	Initialize	( const GLchar *vsh, const GLchar *fsh, unsigned &iId );

public:
	unsigned	m_iId;

public:
	void	Initialize	( const GLchar *vsh, const GLchar *fsh );
	void	Use			( void )	const;
};

char *FS_LoadFile( const char *filename );












































#endif