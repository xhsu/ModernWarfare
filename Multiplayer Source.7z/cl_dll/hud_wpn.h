#ifndef	_HUD_WPN_H_
#define _HUD_WPN_H_

#include "hud_menu.h"

typedef struct wpnfxdb_s
{
	const unsigned	*m_piWpnDxt;
	const int		*m_piClip;
	const int		*m_piClipMax;
	const unsigned	*m_piBpNum;
	const int		*m_piBpMax;
	const int		*m_piFireMode;
	const unsigned	*m_piszFireModeIcons;
	const unsigned	*m_pbitsFlags;
	const wchar_t	*m_pszEndoName;
	const wchar_t	*m_pszBpName;

	bool		m_bDisplay;

} wpnfxdb_t;

namespace gStdWpnHud
{
	extern const int	MAX_BACKUP;
	extern const float	LASER_SCALE;

	extern int	m_hFont;

	extern wpnfxdb_s	m_sPriWpn;
	extern wpnfxdb_s	m_sSedWpn;

	void	Initialize		( void );
	void	VidInit			( void );
	void	UpdateWpnName	( void );
	void	Think3D			( void );
	void	Draw3D			( void );
	void	DrawLaserDot	( void );
	void	DrawLaserDot2D	( void );

	class CBaseMenuWpn : public CBaseMenuItem
	{
	public:
		int		m_iIndex;

		CBaseMenuWpn(void);

		static CBaseMenuWpn *AddItemByName(const char *classname);
		static CBaseMenuWpn *AddItemByIndex(int iType);

		virtual void Select(void);
	};

	class CBaseMenuAcc : public CBaseMenuItem
	{
	public:
		int			m_bitsIndex;
		int			m_bitsConflict;
		unsigned	*m_pBitsCurAcc;

		CBaseMenuAcc(void);

		static CBaseMenuAcc *AddByIndex(unsigned *pBitsCurAcc, int iType);

		virtual void Think		( void );
		virtual void Select		( void );
		virtual void UpdateInfo	( unsigned *pBitsCurAcc, int iType );
	};

	class CBaseCursor : public CBaseMenuItem
	{
	public:
		int		m_iDistance;

		static	CBaseCursor *AddByDistance(int iDistance);

		virtual	void	Think	( void );
		virtual void	Select	( void );
	};
};

extern CBaseMenuTable g_sItemsMenu;
extern CBaseMenuTable g_sGunCursor;












































#endif