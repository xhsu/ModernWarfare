
#include <windows.h>
#include <stdio.h>
#include <triangleapi.h>
#include <gl/gl.h>
#include "vector.h"
#include "const.h"
#include <com_model.h>
#include <studio.h>
#include "dxt.h"
#include "glext.h"
#include "newkeyvalues.h"

#pragma comment(lib, "opengl32.lib")

PFNGLCOMPRESSEDTEXIMAGE2DARBPROC glCompressedTexImage2DARB = NULL;


#pragma region DDS

#define DDPF_ALPHAPIXELS	0x000001
#define DDPF_ALPHA			0x000002
#define DDPF_FOURCC			0x000004
#define DDPF_RGB			0x000040
#define DDPF_YUV			0x000200
#define DDPF_LUMINANCE		0x020000

#define D3DFMT_DXT1		(('D'<<0)|('X'<<8)|('T'<<16)|('1'<<24))
#define D3DFMT_DXT3		(('D'<<0)|('X'<<8)|('T'<<16)|('3'<<24))
#define D3DFMT_DXT5		(('D'<<0)|('X'<<8)|('T'<<16)|('5'<<24))

typedef struct
{
	DWORD	dwSize;
	DWORD	dwFlags;
	DWORD	dwFourCC;
	DWORD	dwRGBBitCount;
	DWORD	dwRBitMask;
	DWORD	dwGBitMask;
	DWORD	dwBBitMask;
	DWORD	dwABitMask;
} DDS_PIXELFORMAT;

#define DDSD_CAPS			0x000001
#define DDSD_HEIGHT			0x000002
#define DDSD_WIDTH			0x000004
#define DDSD_PITCH			0x000008
#define DDSD_PIXELFORMAT	0x001000
#define DDSD_MIPMAPCOUNT	0x020000
#define DDSD_LINEARSIZE		0x080000
#define DDSD_DEPTH			0x800000

typedef struct
{
    DWORD			dwSize;
    DWORD			dwFlags;
    DWORD			dwHeight;
    DWORD			dwWidth;
    DWORD			dwPitchOrLinearSize;
    DWORD			dwDepth;
    DWORD			dwMipMapCount;
    DWORD			dwReserved1[11];
    DDS_PIXELFORMAT	ddspf;
    DWORD			dwCaps;
    DWORD			dwCaps2;
    DWORD			dwCaps3;
    DWORD			dwCaps4;
    DWORD			dwReserved2;
} DDS_HEADER;

typedef struct
{
    DWORD		dwMagic;
    DDS_HEADER	Header;
} DDS_FILEHEADER;

// For a compressed texture, the size of each mipmap level image is typically one-fourth the size of the previous, with a minimum of 8 (DXT1) or 16 (DXT2-5) bytes (for 
// square textures). Use the following formula to calculate the size of each level for a non-square texture:
#define SIZE_OF_DXT1(width, height)		( max(1, ( (width + 3) >> 2 ) ) * max(1, ( (height + 3) >> 2 ) ) * 8 )
#define SIZE_OF_DXT2(width, height)		( max(1, ( (width + 3) >> 2 ) ) * max(1, ( (height + 3) >> 2 ) ) * 16 )

#pragma endregion

int (*g_pfnGL_LoadTexture)(char *identifier, int textureType, int width, int height, BYTE *data, int mipmap, int iType, BYTE *pPal) = NULL;
GLuint gl_load_dds(GLvoid *pBuffer, int *iWidth = NULL, int *iHeight = NULL);

#define GLT_DECALS		1
#define GLT_SPRITES		2
#define GLT_STUDIO		3
#define GLT_WORLD		4
/*
int g_iTexRep = 0;
sTextureReplaceDatabase	g_sTexRepDB[512];

int GL_LoadTexture(char *identifier, int textureType, int width, int height, BYTE *data, int mipmap, int iType, BYTE *pPal)
{
	for (int i = 0; i < g_iTexRep; i ++)
	{
		if (textureType != g_sTexRepDB[i].m_iType)
			continue;

		if (strcmp(identifier, g_sTexRepDB[i].m_szTarget))
			continue;

		if (!strlen(g_sTexRepDB[i].m_szReplace))
			continue;

		if (strstr(g_sTexRepDB[i].m_szReplace, ".dds"))
			return LoadDDS(g_sTexRepDB[i].m_szReplace);
		else if (strstr(g_sTexRepDB[i].m_szReplace, ".tga"))
			return LoadTGA(g_sTexRepDB[i].m_szReplace);
	}

	if (width * height > 287264)	// biggest known loadable: 764*376
	{
		static BYTE buffer[2048 * 2048 * 3];

		for (DWORD i = 0; i < DWORD(width * height); ++i)
		{
			buffer[(i * 3) + 0] = pPal[(data[i] * 3) + 0];
			buffer[(i * 3) + 1] = pPal[(data[i] * 3) + 1];
			buffer[(i * 3) + 2] = pPal[(data[i] * 3) + 2];
		}

		int id = g_pSurface->CreateNewTextureID();

		glBindTexture(GL_TEXTURE_2D, id);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, buffer);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

		return id;
	}

	return g_pfnGL_LoadTexture(identifier, textureType, width, height, data, mipmap, iType, pPal);
}

void Models_Texture_InstallHook(void)
{
	g_pfnGL_LoadTexture = (int (*)(char *, int, int, int, BYTE *, int, int, BYTE *))g_pMetaHookAPI->SearchPattern((void *)g_dwEngineBase, g_dwEngineSize, GL_LOADTEXTURE_SIG, sizeof(GL_LOADTEXTURE_SIG) - 1);

	if (g_pfnGL_LoadTexture)
	{
		g_pMetaHookAPI->InlineHook(g_pfnGL_LoadTexture, GL_LoadTexture, (void *&)g_pfnGL_LoadTexture);
	}
}
*/
void Dxt_Initialization(void)
{
	// GL_ARB_texture_compression
	// GL_EXT_texture_compression_s3tc
	glCompressedTexImage2DARB = (PFNGLCOMPRESSEDTEXIMAGE2DARBPROC)wglGetProcAddress("glCompressedTexImage2DARB");

	/*memset(g_sTexRepDB, NULL, sizeof(g_sTexRepDB));

	LoadTextureConfig();*/
}

unsigned int LoadDDS(const char *szFile, int *iWidth, int *iHeight)
{
	FILE	*fp;
	int		size;
	void	*data;

	fp = fopen(szFile, "rb");
	if (!fp)
		return 0;

	fseek(fp, 0, SEEK_END);
	size = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	data = malloc(size);
	if (!data)
	{
		fclose(fp);
		return 0;
	}

	if (fread(data, size, 1, fp) != 1)
	{
		free(data);
		fclose(fp);
		return 0;
	}

	fclose(fp);

	// Load DDS to GL texture
	unsigned int iResult = gl_load_dds(data, iWidth, iHeight);

	free(data);

	return iResult;
}

GLuint gl_load_dds(GLvoid *pBuffer, int *iWidth, int *iHeight)
{
	DDS_FILEHEADER	*header;
	DWORD			compressFormat;
	GLvoid			*data;
	GLsizei			imageSize;

	header = (DDS_FILEHEADER *)pBuffer;

	if (header->dwMagic != 0x20534444)
	{
		printf("bad dds file\n");
		return 0;
	}

	if (header->Header.dwSize != 124)
	{
		printf("bad header size\n");
		return 0;
	}

	if (!(header->Header.dwFlags & DDSD_LINEARSIZE))
	{
		printf("bad file type\n");
		return 0;
	}

	if (!(header->Header.ddspf.dwFlags & DDPF_FOURCC))
	{
		printf("bad pixel format\n");
		return 0;
	}

	compressFormat = header->Header.ddspf.dwFourCC;

	if (compressFormat != D3DFMT_DXT1 &&
		compressFormat != D3DFMT_DXT3 &&
		compressFormat != D3DFMT_DXT5)
	{
		printf("bad compress format\n");
		return 0;
	}

	data = (GLvoid *)(header + 1);    // header data skipped

	//int iTextureID = g_pSurface->CreateNewTextureID();
	unsigned int iTextureID;
	glGenTextures(1, &iTextureID);
	glBindTexture(GL_TEXTURE_2D, iTextureID);

	switch (compressFormat)
	{
	case D3DFMT_DXT1:
		imageSize = SIZE_OF_DXT1(header->Header.dwWidth, header->Header.dwHeight);
		glCompressedTexImage2DARB(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGB_S3TC_DXT1_EXT, header->Header.dwWidth, header->Header.dwHeight, 0, imageSize, data);
		break;
	case D3DFMT_DXT3:
		imageSize = SIZE_OF_DXT2(header->Header.dwWidth, header->Header.dwHeight);
		glCompressedTexImage2DARB(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGBA_S3TC_DXT3_EXT, header->Header.dwWidth, header->Header.dwHeight, 0, imageSize, data);
		break;
	case D3DFMT_DXT5:
		imageSize = SIZE_OF_DXT2(header->Header.dwWidth, header->Header.dwHeight);
		glCompressedTexImage2DARB(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGBA_S3TC_DXT5_EXT, header->Header.dwWidth, header->Header.dwHeight, 0, imageSize, data);
		break;
	}

	// LUNA: return the height and width data.
	if (iWidth)
		*iWidth = header->Header.dwWidth;
	if (iHeight)
		*iHeight = header->Header.dwHeight;

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, NULL);	// reset current texture
	return iTextureID;
}

#define	LTC_CURRENT	g_sTexRepDB[g_iTexRep]
/*
void LoadTextureConfig(void)
{
	NewKeyValues *pFile = new NewKeyValues("Data");
	pFile->LoadFromFile("cstrike//gfx//Texture//config.txt");

	if (!pFile)
		return;

	NewKeyValues *pValue = pFile->GetFirstValue();

	while (pFile)
	{
		while (pValue)
		{
			if (strstr(pFile->GetName(), ".mdl"))
				LTC_CURRENT.m_iType = GLT_STUDIO;
			else if (strstr(pFile->GetName(), ".spr"))
				LTC_CURRENT.m_iType = GLT_SPRITES;
			else if (!strcmp(pFile->GetName(), "decals.wad"))
				LTC_CURRENT.m_iType = GLT_DECALS;
			else if (strstr(pFile->GetName(), ".wad"))
				LTC_CURRENT.m_iType = GLT_WORLD;

			if (LTC_CURRENT.m_iType == GLT_STUDIO || LTC_CURRENT.m_iType == GLT_SPRITES)
			{
				strcpy(LTC_CURRENT.m_szTarget, pFile->GetName());
				strcat(LTC_CURRENT.m_szTarget, pValue->GetName());

				char szPath[128];
				strcpy(szPath, pFile->GetName());

				char szLast[128];
				char *pChar = strtok(szPath, "/");
				while (pChar)
				{
					strcpy(szLast, pChar);
					pChar = strtok(NULL, "/");
				}

				// we need a pure file name to determind path.
				if (strstr(pValue->GetString(), ".tga"))
					sprintf(LTC_CURRENT.m_szReplace, "gfx/Texture/%s/%s", szLast, pValue->GetString());
				else if (strstr(pValue->GetString(), ".dds"))
					sprintf(LTC_CURRENT.m_szReplace, "cstrike//gfx//Texture//%s//%s", szLast, pValue->GetString());
			}
			else if (LTC_CURRENT.m_iType == GLT_WORLD)
			{
				strcpy(LTC_CURRENT.m_szTarget, pValue->GetName());
				sprintf(LTC_CURRENT.m_szReplace, "cstrike//gfx//Texture//%s//%s", pFile->GetName(), pValue->GetString());
			}
			else if (LTC_CURRENT.m_iType == GLT_DECALS)
			{
				sprintf(LTC_CURRENT.m_szTarget, "}%s", pValue->GetName());
				sprintf(LTC_CURRENT.m_szReplace, "cstrike//gfx//Texture//%s//%s", pFile->GetName(), pValue->GetString());
			}

			g_iTexRep ++;
			pValue = pValue->GetNextValue();
		}

		pFile = pFile->GetNextKey();

		if (pFile)
			pValue = pFile->GetFirstValue();
	}
}

namespace gViewModelHandsTexture
{
	bool	m_bAvailable		= false;
	model_t	*m_pLastViewModel	= NULL;
	uint	m_iCTHandTexture	= NULL;
	uint	m_iTRHandTexture	= NULL;

	void	Initialization	( void )
	{
		if (m_bAvailable)
			return;

		m_iCTHandTexture		= LoadDDS("cstrike//gfx//Texture//Hands//v_hands_CT.dds");
		m_iTRHandTexture		= LoadDDS("cstrike//gfx//Texture//Hands//v_hands_TR.dds");

		m_bAvailable			= !!(m_iCTHandTexture && m_iTRHandTexture);
	}

	void	Think	( void )
	{
		if (!m_bAvailable || !g_pViewEntity || !g_pViewEntity->model || g_pViewEntity->model == m_pLastViewModel)
			return;

		studiohdr_t *pStudio = (studiohdr_t *)IEngineStudio.Mod_Extradata(g_pViewEntity->model);
		mstudiotexture_t *pTexture = (mstudiotexture_t *)(((byte *)pStudio) + pStudio->textureindex);

		for (int i = 0; i < pStudio->numtextures; i++)
		{
			if(strstr(pTexture->name, "hands"))
			{
				pTexture->index = ((g_sClientInfo[gEngfuncs.GetLocalPlayer()->index].m_iTeamID == 2) ? m_iCTHandTexture : m_iTRHandTexture);
				break;
			}

			pTexture ++;
		}

		m_pLastViewModel	= g_pViewEntity->model;
	}

	model_t	*m_pLastInfViewModel	= NULL;

	void	InferiorThink	( void )
	{
		if (!m_bAvailable || !g_pViewEntity || !g_pViewEntity->model || g_pViewEntity->model == m_pLastInfViewModel)
			return;

		studiohdr_t *pStudio = (studiohdr_t *)IEngineStudio.Mod_Extradata(g_pViewEntity->model);
		mstudiotexture_t *pTexture = (mstudiotexture_t *)(((byte *)pStudio) + pStudio->textureindex);

		for (int i = 0; i < pStudio->numtextures; i++)
		{
			if(strstr(pTexture->name, "hands"))
			{
				pTexture->index = ((g_sClientInfo[gEngfuncs.GetLocalPlayer()->index].m_iTeamID == 2) ? m_iCTHandTexture : m_iTRHandTexture);
				break;
			}

			pTexture ++;
		}

		m_pLastInfViewModel	= g_pViewEntity->model;
	}
};*/