#ifndef _INPUT_H_
#define _INPUT_H_

int CL_GetButtonBits( int bResetState = FALSE );
void CL_ResetButtonBits( int bits );

extern bool g_bHoldRun;
extern bool g_bHoldDuck;

#endif