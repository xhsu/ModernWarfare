//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

// view/refresh setup functions

#include <sysdef.h>

#include "hud.h"
#include "cl_util.h"
#include "cvardef.h"
#include "usercmd.h"
#include "const.h"

#include "entity_state.h"
#include "cl_entity.h"
#include "ref_params.h"
#include "in_defs.h" // PITCH YAW ROLL
#include "pm_movevars.h"
#include "pm_shared.h"
#include "pm_defs.h"
#include "event_api.h"
#include "pmtrace.h"
#include "screenfade.h"
#include "shake.h"
#include "hltv.h"
#include "view.h"
#include "cl_wpns.h"
#include "GameStudioModelRenderer.h"
#include "wpn_cmd_shared.h"

// Spectator Mode
extern "C" 
{
	float	vecNewViewAngles[3];
	int		iHasNewViewAngles;
	float	vecNewViewOrigin[3];
	int		iHasNewViewOrigin;
	int		iIsSpectator;
}

#ifndef M_PI
#define M_PI		3.14159265358979323846	// matches value in gcc v2 math.h
#endif

extern "C" 
{
	int		CL_IsThirdPerson( void );
	void	CL_CameraOffset( float *ofs );

	void	DLLEXPORT V_CalcRefdef( struct ref_params_s *pparams );

	void	PM_ParticleLine( float *start, float *end, int pcolor, float life, float vert);
	int		PM_GetVisEntInfo( int ent );
	int		PM_GetPhysEntInfo( int ent );
	void	InterpolateAngles(  float * start, float * end, float * output, float frac );
	void	NormalizeAngles( float * angles );
	float	Distance(const float * v1, const float * v2);
	float	AngleBetweenVectors(  const float * v1,  const float * v2 );

	float	vJumpOrigin[3];
	float	vJumpAngles[3];
}

void V_DropPunchAngle ( float frametime, float *vecPunchAngle );
void VectorAngles( const float *forward, float *angles );

#include "r_studioint.h"
#include "com_model.h"

extern engine_studio_api_t IEngineStudio;

/*
The view is allowed to move slightly from it's true position for bobbing,
but if it exceeds 8 pixels linear distance (spherical, not box), the list of
entities sent from the server may not include everything in the pvs, especially
when crossing a water boudnary.
*/

int g_iUser1	= 0;
int g_iUser2	= 0;
int g_iUser3	= 0;

extern cvar_t	*cl_forwardspeed;
extern cvar_t	*chase_active;
extern cvar_t	*cl_vsmoothing;

#define	CAM_MODE_RELAX		1
#define CAM_MODE_FOCUS		2

vec3_t			v_origin, v_angles, v_cl_angles, v_sim_org, v_lastAngles;
float			v_frametime, v_lastDistance;	
float			v_cameraRelaxAngle	= 5.0f;
float			v_cameraFocusAngle	= 35.0f;
int				v_cameraMode = CAM_MODE_FOCUS;
float			v_idlescale = 0;
qboolean		v_resetCamera = 1;
ref_params_t	g_pparams;
ref_params_t	*g_pRefParams = NULL;
bool			v_bGunOfsSmooth = true;
bool			v_bGunOfsWasReset = false;
Vector			v_vecLastVmdlOrg = Vector();

Vector g_vecPunchAngle	= Vector();
Vector g_vecFixAngleOfs	= Vector();
Vector g_vecGunOfs		= Vector();
Vector g_vecPunchOrigin	= Vector();

cvar_t	*v_centermove;
cvar_t	*v_centerspeed;

cvar_t	*cl_waterdist;
cvar_t	*cl_chasedist;

cvar_t	*v_pCvarGunOfs[3];

/* 
============================================================================== 
						VIEW MODEL EFFECT CALC
============================================================================== 
*/

/*
==============
V_CalcBob

bob is presented when walking
==============
*/

#define V_BOB_SPEED				50
#define V_BOB_VERTICAL_SCALE	0.005f
#define V_BOB_HORIZONTAL_SCALE	0.005f
#define V_BOB_COEFFICIENT		2
#define V_BOB_CYCLE				2.5f
#define V_SHAKE_PITCH_SCALE		0.002f
#define V_SHAKE_YAW_SCALE		0.002f
#define V_SHAKE_ROLL_SCALE		0.002f

Vector V_CalcBob ( struct ref_params_s *pparams )
{
	static float	m_flBobTime		= 0;
	static Vector	m_vecBobOffset	= Vector();
	static float	m_flAngleBobTime	= 0;
	static Vector	m_vecAngleBobOffset	= Vector();

	gEngfuncs.pfnAngleVectors(pparams->viewangles, pparams->forward, pparams->right, pparams->up);

	Vector	vecTarget	= Vector();
	float	flSpeed		= g_sLocalState.client.velocity.Length2D();
	float	flCycle		= V_BOB_CYCLE * (165.0f / max(flSpeed, 1));	// calibrate number.

	m_flBobTime += pparams->frametime;
	m_flAngleBobTime += pparams->frametime;

	if (flSpeed > V_BOB_SPEED && !UTIL_IsPlayerRunning())
	{
		if (m_flBobTime > flCycle)
			m_flBobTime = 0;
		else if (m_flBobTime > flCycle * 0.75f)
			vecTarget = -(V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) - (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
		else if (m_flBobTime > flCycle * 0.5f)
			vecTarget = -(V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) + (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
		else if (m_flBobTime > flCycle * 0.25f)
			vecTarget = (V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) - (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
		else if (m_flBobTime > 0)
			vecTarget = (V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) + (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
	}
	else if (UTIL_IsPlayerRunning())	// running anim by coding.
	{
		flCycle *= 1.4;	// looks more soft.

		if ( g_pPlayerActivityItem->m_iDisplayingAnim == g_pPlayerActivityItem->m_sAnims[WPN_COMMON_ANIM_RUN_LOOP].m_i )
		{
			// angular rotation,
			if (m_flAngleBobTime > flCycle)
				m_flAngleBobTime = 0;
			else if (m_flAngleBobTime > flCycle * 0.75f)
				vecTarget = Vector(-V_SHAKE_PITCH_SCALE, -V_SHAKE_YAW_SCALE, -V_SHAKE_ROLL_SCALE) * flSpeed;
			else if (m_flAngleBobTime > flCycle * 0.5f)
				vecTarget = Vector(V_SHAKE_PITCH_SCALE, -V_SHAKE_YAW_SCALE, V_SHAKE_ROLL_SCALE) * flSpeed;
			else if (m_flAngleBobTime > flCycle * 0.25f)
				vecTarget = Vector(-V_SHAKE_PITCH_SCALE, V_SHAKE_YAW_SCALE, V_SHAKE_ROLL_SCALE) * flSpeed;
			else if (m_flAngleBobTime > 0)
				vecTarget = Vector(V_SHAKE_PITCH_SCALE, V_SHAKE_YAW_SCALE, -V_SHAKE_ROLL_SCALE) * flSpeed;

			m_vecAngleBobOffset += (vecTarget - m_vecAngleBobOffset) * pparams->frametime * V_BOB_COEFFICIENT;

			// screen shake.
			VectorAdd(pparams->viewangles, m_vecAngleBobOffset, pparams->viewangles);
			RationalizationAngle(pparams->viewangles);

			// linear movement.
			// LD->LU->RD->RU
			if (m_flBobTime > flCycle)
				m_flBobTime = 0;
			else if (m_flBobTime > flCycle * 0.75f)
				vecTarget = (V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) + (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
			else if (m_flBobTime > flCycle * 0.5f)
				vecTarget = (V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) - (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
			else if (m_flBobTime > flCycle * 0.25f)
				vecTarget = -(V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) + (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);
			else if (m_flBobTime > 0)
				vecTarget = -(V_BOB_HORIZONTAL_SCALE * flSpeed) * Vector(pparams->right) - (V_BOB_VERTICAL_SCALE * flSpeed) * Vector(pparams->up);

			// enlarge it, it's running.
			vecTarget *= 5;

			// when you're running, you will need to move your gun to your hip.
			vecTarget -= Vector(pparams->up) * 5;
		}
		else if ( g_pPlayerActivityItem->m_iDisplayingAnim == g_pPlayerActivityItem->m_sAnims[WPN_COMMON_ANIM_RUN_START].m_i )
		{
			// reset all value to start from balance.
			m_flBobTime			= 0;
			m_flAngleBobTime	= 0;
			m_vecAngleBobOffset	= Vector();

			vecTarget = Vector(pparams->up) * -5;
		}
		else
		{
			m_flAngleBobTime	= 0;
			vecTarget			= Vector();

			m_vecAngleBobOffset += (vecTarget - m_vecAngleBobOffset) * pparams->frametime * V_BOB_COEFFICIENT;
		}

		// angular rotation apply to VMDL.
		if (g_pPlayerActivityItem->m_sItemData.m_bUseCodeRun)
		{
			g_pViewEnt->angles += m_vecAngleBobOffset;
			g_pViewEnt->curstate.angles += m_vecAngleBobOffset;
			RationalizationAngle(g_pViewEnt->angles);
			RationalizationAngle(g_pViewEnt->curstate.angles);
		}
	}

	m_vecBobOffset += (vecTarget - m_vecBobOffset) * pparams->frametime * V_BOB_COEFFICIENT;

	if (UTIL_IsPlayerAiming())
		return m_vecBobOffset * 0.4f;

	if (UTIL_IsPlayerRunning() && !g_pPlayerActivityItem->m_sItemData.m_bUseCodeRun)
		return Vector();

	return m_vecBobOffset;
}

/*
==============
V_CalcGunLagOfs

lag is presented when turing your sight.
==============
*/

Vector	V_vecCurForward		= Vector();
Vector	V_vecLagGunOffset	= Vector();

Vector V_CalcGunLagOfs ( struct ref_params_s *pparams )
{
	float	flSpeed			= 5;
	Vector	vecTargetDir	= pparams->forward;
	float	flFinalFactor	= 1.0f;

	// first we need to determind whether it's moving too fast in horizontal direction.
	Vector2D	vec1	= vecTargetDir.Make2D().Normalize();
	Vector2D	vec2	= Vector2D(pparams->forward).Normalize();

	// dot product is small then 0 means in opposite direction
	if (DotProduct(vec1, vec2) < 0)
		vecTargetDir = (V_vecCurForward + Vector(pparams->forward)).Normalize();

	// when sighting, make the ofs eventually not exist.
	if (UTIL_IsPlayerAiming())
		flFinalFactor *= pparams->frametime;
	else
		flFinalFactor += (1.0f - flFinalFactor) * pparams->frametime * flSpeed;

	V_vecCurForward		+=	(vecTargetDir - V_vecCurForward) * pparams->frametime * flSpeed;
	V_vecCurForward		=	V_vecCurForward.Normalize();
	V_vecLagGunOffset	=	-V_vecCurForward * flSpeed * 0.6f + Vector(pparams->forward) * flSpeed * 0.6f;

	return (V_vecLagGunOffset * flFinalFactor);
}

/*
==============
V_GetGunAimOffset

Aiming Effect.
==============
*/

#define USING_FULL_CALIBRATE_MODE
#define V_AIMING_SPEED			0.4f
#define V_AIMING_COEFFICIENT	6

Vector V_GetGunAimOffset(void)
{
	static Vector	m_vecAimOffsetEnd	= Vector();
	static Vector	m_vecAimOffsetVel	= Vector();
	static Vector	m_vecResult			= Vector();

	if (v_pCvarGunOfs[0]->value || v_pCvarGunOfs[1]->value || v_pCvarGunOfs[2]->value)
	{

#ifndef USING_FULL_CALIBRATE_MODE

		m_vecAimOffsetEnd = Vector();

		if (m_pCvarGunOffset[0]->value)
			m_vecAimOffsetEnd += m_pCvarGunOffset[0]->value * Vector(g_pRefParams->right);
		else
			m_vecAimOffsetEnd += g_vecGunOfs.x * Vector(g_pRefParams->right);
		
		if (m_pCvarGunOffset[1]->value)
			m_vecAimOffsetEnd += m_pCvarGunOffset[1]->value * Vector(g_pRefParams->forward);
		else
			m_vecAimOffsetEnd += g_vecGunOfs.y * Vector(g_pRefParams->forward);

		if (m_pCvarGunOffset[2]->value)
			m_vecAimOffsetEnd -= (m_pCvarGunOffset[2]->value * Vector(g_pRefParams->up);
		else
			m_vecAimOffsetEnd -= g_vecGunOfs.z * Vector(g_pRefParams->up);
#else
		m_vecAimOffsetEnd = v_pCvarGunOfs[1]->value * Vector(g_pRefParams->forward) + v_pCvarGunOfs[0]->value * Vector(g_pRefParams->right) - v_pCvarGunOfs[2]->value * Vector(g_pRefParams->up);
#endif

	}
	else	// y*i + x*j - z*k, since z axis is inverse in HLMV
		m_vecAimOffsetEnd = g_vecGunOfs.y * Vector(g_pRefParams->forward) + g_vecGunOfs.x * Vector(g_pRefParams->right) - g_vecGunOfs.z * Vector(g_pRefParams->up);

	// calc
	if (UTIL_IsPlayerAiming() && v_bGunOfsSmooth)
	{
		Vector vecOfs = m_vecAimOffsetEnd - m_vecResult;
		m_vecResult += vecOfs * g_pRefParams->frametime * V_AIMING_COEFFICIENT;

		if (vecOfs.Length() < 0.01f)
			v_bGunOfsSmooth = false;

		/*
		// use vieworg since we need to overcome Bob and Lag.
		m_vecAimOffsetVel	= (m_vecAimOffsetEnd - m_vecResult).SetLength((m_vecAimOffsetEnd / V_AIMING_SPEED).Length());
		m_vecResult			+= m_vecAimOffsetVel * g_pRefParams->frametime;

		if ((m_vecResult - m_vecAimOffsetEnd).Length() < 0.1)
		{
			m_vecAimOffsetVel	= Vector();
			m_vecResult			= m_vecAimOffsetEnd;
		}*/
	}
	else if (UTIL_IsPlayerAiming())
	{
		m_vecResult = m_vecAimOffsetEnd;
	}
	else	// it's aim down.
	{
		m_vecResult -= m_vecResult * g_pRefParams->frametime * V_AIMING_COEFFICIENT;
	}

	return m_vecResult;
}

/*
==============
V_CalcViewModelAngle

lean effect at vmdl.
==============
*/
static float	m_flVAngleZ	= 0;
static float	m_flTargetZ	= 0;
void V_CalcViewModelAngle( struct ref_params_s *pparams )
{
	// calc effect first.
	// drop ROLL when aiming.
	m_flTargetZ	= (UTIL_IsPlayerAiming() ? pparams->viewangles[ROLL] : pparams->viewangles[ROLL] * 0.66666f);
	m_flVAngleZ	+= (m_flTargetZ - m_flVAngleZ) * pparams->frametime * 10;

	m_flVAngleZ = max(min(m_flVAngleZ, 180), -180);
	m_flTargetZ = max(min(m_flTargetZ, 180), -180);

	// Give gun our viewangles
	Vector(-pparams->viewangles[PITCH], pparams->viewangles[YAW], m_flVAngleZ).CopyToArray(g_pViewEnt->angles);
	VectorCopy( g_pViewEnt->angles, g_pViewEnt->curstate.angles );
	VectorCopy( g_pViewEnt->angles, g_pViewEnt->latched.prevangles );
}

/*
==============
V_CalcPunchOrigin

Something like PunchAngle
==============
*/
Vector V_CalcPunchOrigin(struct ref_params_s *pparams)
{
	gEngfuncs.pfnAngleVectors(Vector(pparams->viewangles[0], pparams->viewangles[1], 0), pparams->forward, pparams->right, pparams->up);

	Vector vecResult = (Vector(pparams->forward) * g_vecPunchOrigin.x + Vector(pparams->right) * g_vecPunchOrigin.y + Vector(pparams->up) * g_vecPunchOrigin.z);

	V_DropPunchAngle(pparams->frametime, g_vecPunchOrigin);

	return vecResult;
}

Vector V_CalcDualOfs(struct ref_params_s *pparams)
{
	if (g_pPlayerActivityItem && g_pPlayerActivityItem->IsDoubleHolding())
		return (g_pPlayerActivityItem->m_sItemData.m_vecSHOFS.y * Vector(pparams->forward) - g_pPlayerActivityItem->m_sItemData.m_vecSHOFS.x * Vector(pparams->right) + g_pPlayerActivityItem->m_sItemData.m_vecSHOFS.z * Vector(pparams->up));
	else
		return Vector();
}

/* 
============================================================================== 
						LUNA: I DONT KNOW WHAT ARE THESE FUCKERS
============================================================================== 
*/

typedef struct pitchdrift_s
{
	float		pitchvel;
	int			nodrift;
	float		driftmove;
	double		laststop;
} pitchdrift_t;

static pitchdrift_t pd;

void V_StartPitchDrift( void )
{
	if ( pd.laststop == gEngfuncs.GetClientTime() )
	{
		return;		// something else is keeping it from drifting
	}

	if ( pd.nodrift || !pd.pitchvel )
	{
		pd.pitchvel = v_centerspeed->value;
		pd.nodrift = 0;
		pd.driftmove = 0;
	}
}

void V_StopPitchDrift ( void )
{
	pd.laststop = gEngfuncs.GetClientTime();
	pd.nodrift = 1;
	pd.pitchvel = 0;
}

/*
===============
V_DriftPitch

Moves the client pitch angle towards idealpitch sent by the server.

If the user is adjusting pitch manually, either with lookup/lookdown,
mlook and mouse, or klook and keyboard, pitch drifting is constantly stopped.
===============
*/
void V_DriftPitch ( struct ref_params_s *pparams )
{
	float		delta, move;

	if ( gEngfuncs.IsNoClipping() || !pparams->onground || pparams->demoplayback || pparams->spectator )
	{
		pd.driftmove = 0;
		pd.pitchvel = 0;
		return;
	}

	// don't count small mouse motion
	if (pd.nodrift)
	{
		if ( fabs( pparams->cmd->forwardmove ) < cl_forwardspeed->value )
			pd.driftmove = 0;
		else
			pd.driftmove += pparams->frametime;
	
		if ( pd.driftmove > v_centermove->value)
		{
			V_StartPitchDrift ();
		}
		return;
	}
	
	delta = pparams->idealpitch - pparams->cl_viewangles[PITCH];

	if (!delta)
	{
		pd.pitchvel = 0;
		return;
	}

	move = pparams->frametime * pd.pitchvel;
	pd.pitchvel += pparams->frametime * v_centerspeed->value;
	
	if (delta > 0)
	{
		if (move > delta)
		{
			pd.pitchvel = 0;
			move = delta;
		}
		pparams->cl_viewangles[PITCH] += move;
	}
	else if (delta < 0)
	{
		if (move > -delta)
		{
			pd.pitchvel = 0;
			move = -delta;
		}
		pparams->cl_viewangles[PITCH] -= move;
	}
}

/* 
============================================================================== 
						VIEW RENDERING 
============================================================================== 
*/ 

/*
==============
V_CalcViewRoll

Roll is induced by movement and damage
==============
*/
void V_CalcViewRoll ( struct ref_params_s *pparams )
{
	if (!g_pViewEnt)
		return;

	// calc lean.
	gLeanManager::Think(pparams->frametime);

	// add results up.
	pparams->viewangles[ROLL] += 2.0f * (DotProduct(pparams->simvel, pparams->right) / g_sFakePlayer.m_flMaxSpeed);
	pparams->viewangles[ROLL] += gLeanManager::m_flAngleZ;

	if ( pparams->health <= 0 && ( pparams->viewheight[2] != 0 ) )
	{
		// only roll the view if the player is dead and the viewheight[2] is nonzero 
		// this is so deadcam in multiplayer will work.
		pparams->viewangles[ROLL] = 80;	// dead view angle
		return;
	}
}


/*
==================
V_CalcIntermissionRefdef

==================
*/
void V_CalcIntermissionRefdef ( struct ref_params_s *pparams )
{
	cl_entity_t	*ent, *view;
	float		old;

	// ent is the player model ( visible when out of body )
	ent = gEngfuncs.GetLocalPlayer();
	
	// view is the weapon model (only visible from inside body )
	view = gEngfuncs.GetViewModel();

	VectorCopy ( pparams->simorg, pparams->vieworg );
	VectorCopy ( pparams->cl_viewangles, pparams->viewangles );

	view->model = NULL;

	// allways idle in intermission
	old = v_idlescale;
	v_idlescale = 1;

	if ( gEngfuncs.IsSpectateOnly() )
	{
		// in HLTV we must go to 'intermission' position by ourself
		// VectorCopy( gHUD.m_Spectator.m_cameraOrigin, pparams->vieworg );
		// VectorCopy( gHUD.m_Spectator.m_cameraAngles, pparams->viewangles );
	}

	v_idlescale = old;

	v_cl_angles = pparams->cl_viewangles;
	v_origin = pparams->vieworg;
	v_angles = pparams->viewangles;
}

#define ORIGIN_BACKUP 64
#define ORIGIN_MASK ( ORIGIN_BACKUP - 1 )

typedef struct 
{
	float Origins[ ORIGIN_BACKUP ][3];
	float OriginTime[ ORIGIN_BACKUP ];

	float Angles[ ORIGIN_BACKUP ][3];
	float AngleTime[ ORIGIN_BACKUP ];

	int CurrentOrigin;
	int CurrentAngle;
} viewinterp_t;

/*
==================
V_CalcRefdef

==================
*/
void V_CalcNormalRefdef ( struct ref_params_s *pparams )
{
	cl_entity_t		*ent, *view;
	int				i;
	float			waterOffset;
	static viewinterp_t		ViewInterp;

	static float oldz = 0;
	static float lasttime;

	vec3_t camAngles, camForward, camRight, camUp;
	cl_entity_t *pwater;

	V_DriftPitch ( pparams );

	if ( gEngfuncs.IsSpectateOnly() )
	{
		ent = gEngfuncs.GetEntityByIndex( g_iUser2 );
	}
	else
	{
		// ent is the player model ( visible when out of body )
		ent = gEngfuncs.GetLocalPlayer();
	}
	
	// view is the weapon model (only visible from inside body )
	view = gEngfuncs.GetViewModel();

	// integral local angle adjust, recoil system.
	VectorAdd(pparams->cl_viewangles, g_vecFixAngleOfs, pparams->cl_viewangles);
	g_vecFixAngleOfs = Vector();

	// refresh position
	VectorCopy ( pparams->simorg, pparams->vieworg );
	VectorAdd( pparams->vieworg, pparams->viewheight, pparams->vieworg );

	// lean effects on player
	VectorAdd(pparams->vieworg, gLeanManager::m_vecViewOfs, pparams->vieworg);

	// copy result.
	VectorCopy ( pparams->cl_viewangles, pparams->viewangles );

	// shake player
	gEngfuncs.V_CalcShake();
	gEngfuncs.V_ApplyShake( pparams->vieworg, pparams->viewangles, 1.0 );

	// never let view origin sit exactly on a node line, because a water plane can
	// dissapear when viewed with the eye exactly on it.
	// FIXME, we send origin at 1/128 now, change this?
	// the server protocol only specifies to 1/16 pixel, so add 1/32 in each axis
	
	pparams->vieworg[0] += 1.0/32;
	pparams->vieworg[1] += 1.0/32;
	pparams->vieworg[2] += 1.0/32;

	// Check for problems around water, move the viewer artificially if necessary 
	// -- this prevents drawing errors in GL due to waves

	waterOffset = 0;
	if ( pparams->waterlevel >= 2 )
	{
		int		i, contents, waterDist, waterEntity;
		vec3_t	point;
		waterDist = cl_waterdist->value;

		if ( pparams->hardware )
		{
			waterEntity = gEngfuncs.PM_WaterEntity( pparams->simorg );
			if ( waterEntity >= 0 && waterEntity < pparams->max_entities )
			{
				pwater = gEngfuncs.GetEntityByIndex( waterEntity );
				if ( pwater && ( pwater->model != NULL ) )
				{
					waterDist += ( pwater->curstate.scale * 16 );	// Add in wave height
				}
			}
		}
		else
		{
			waterEntity = 0;	// Don't need this in software
		}
		
		VectorCopy( pparams->vieworg, point );

		// Eyes are above water, make sure we're above the waves
		if ( pparams->waterlevel == 2 )	
		{
			point[2] -= waterDist;
			for ( i = 0; i < waterDist; i++ )
			{
				contents = gEngfuncs.PM_PointContents( point, NULL );
				if ( contents > CONTENTS_WATER )
					break;
				point[2] += 1;
			}
			waterOffset = (point[2] + waterDist) - pparams->vieworg[2];
		}
		else
		{
			// eyes are under water.  Make sure we're far enough under
			point[2] += waterDist;

			for ( i = 0; i < waterDist; i++ )
			{
				contents = gEngfuncs.PM_PointContents( point, NULL );
				if ( contents <= CONTENTS_WATER )
					break;
				point[2] -= 1;
			}
			waterOffset = (point[2] - waterDist) - pparams->vieworg[2];
		}
	}

	pparams->vieworg[2] += waterOffset;
	
	V_CalcViewRoll ( pparams );

	// fractors
	gEngfuncs.pfnAngleVectors(pparams->cl_viewangles, pparams->forward, pparams->right, pparams->up );
	
	// Treating cam_ofs[2] as the distance
	if( CL_IsThirdPerson() )
	{
		Vector ofs = Vector();

		CL_CameraOffset( ofs );

		VectorCopy( ofs, camAngles );
		camAngles[ ROLL ]	= 0;

		gEngfuncs.pfnAngleVectors( camAngles, camForward, camRight, camUp );

		for ( i = 0; i < 3; i++ )
		{
			pparams->vieworg[ i ] += -ofs[2] * camForward[ i ];
		}
	}
	
	// Give gun our viewangles
	V_CalcViewModelAngle(pparams);

	// Use predicted origin as view origin.
	// Luna: WHY????
	/*VectorCopy ( pparams->simorg, view->origin );
	view->origin[2] += ( waterOffset );
	VectorAdd( view->origin, pparams->viewheight, view->origin );*/
	
	// use view origin as current view model origin.
	VectorCopy(pparams->vieworg, view->origin);

	// Let the viewmodel shake at about 10% of the amplitude
	gEngfuncs.V_ApplyShake( view->origin, view->angles, 0.9 );

	// fudge position around to keep amount of weapon visible
	// roughly equal with different FOV
	if (pparams->viewsize == 110)
	{
		view->origin[2] += 1;
	}
	else if (pparams->viewsize == 100)
	{
		view->origin[2] += 2;
	}
	else if (pparams->viewsize == 90)
	{
		view->origin[2] += 1;
	}
	else if (pparams->viewsize == 80)
	{
		view->origin[2] += 0.5;
	}

	// Add in the punchangle, if any
	VectorAdd ( pparams->viewangles, pparams->punchangle, pparams->viewangles );

	// Include client side punch, too
	VectorAdd ( pparams->viewangles, (float *)&g_vecPunchAngle, pparams->viewangles);

	V_DropPunchAngle ( pparams->frametime, (float *)&g_vecPunchAngle );

	// add the punchorigin on.
	VectorAdd(pparams->vieworg, V_CalcPunchOrigin(pparams),	pparams->vieworg);

	// smooth out stair step ups
	if ( !pparams->smoothing && pparams->onground && pparams->simorg[2] - oldz > 0)
	{
		float steptime;
		
		steptime = pparams->time - lasttime;
		if (steptime < 0)
			steptime = 0;

		oldz += steptime * 150;
		if (oldz > pparams->simorg[2])
			oldz = pparams->simorg[2];
		if (pparams->simorg[2] - oldz > 18)
			oldz = pparams->simorg[2]- 18;
		pparams->vieworg[2] += oldz - pparams->simorg[2];
		view->origin[2] += oldz - pparams->simorg[2];
	}
	else
	{
		oldz = pparams->simorg[2];
	}

	{
		static float lastorg[3];
		vec3_t delta;

		VectorSubtract( pparams->simorg, lastorg, delta );

		if ( Length( delta ) != 0.0 )
		{
			VectorCopy( pparams->simorg, ViewInterp.Origins[ ViewInterp.CurrentOrigin & ORIGIN_MASK ] );
			ViewInterp.OriginTime[ ViewInterp.CurrentOrigin & ORIGIN_MASK ] = pparams->time;
			ViewInterp.CurrentOrigin++;

			VectorCopy( pparams->simorg, lastorg );
		}
	}

	// Smooth out whole view in multiplayer when on trains, lifts
	if ( cl_vsmoothing && cl_vsmoothing->value &&
		( pparams->smoothing && ( pparams->maxclients > 1 ) ) )
	{
		int foundidx;
		int i;
		float t;

		if ( cl_vsmoothing->value < 0.0 )
		{
			gEngfuncs.Cvar_SetValue( "cl_vsmoothing", 0.0 );
		}

		t = pparams->time - cl_vsmoothing->value;

		for ( i = 1; i < ORIGIN_MASK; i++ )
		{
			foundidx = ViewInterp.CurrentOrigin - 1 - i;
			if ( ViewInterp.OriginTime[ foundidx & ORIGIN_MASK ] <= t )
				break;
		}

		if ( i < ORIGIN_MASK &&  ViewInterp.OriginTime[ foundidx & ORIGIN_MASK ] != 0.0 )
		{
			// Interpolate
			vec3_t delta;
			double frac;
			double dt;
			vec3_t neworg;

			dt = ViewInterp.OriginTime[ (foundidx + 1) & ORIGIN_MASK ] - ViewInterp.OriginTime[ foundidx & ORIGIN_MASK ];
			if ( dt > 0.0 )
			{
				frac = ( t - ViewInterp.OriginTime[ foundidx & ORIGIN_MASK] ) / dt;
				frac = min( 1.0, frac );
				VectorSubtract( ViewInterp.Origins[ ( foundidx + 1 ) & ORIGIN_MASK ], ViewInterp.Origins[ foundidx & ORIGIN_MASK ], delta );
				VectorMA( ViewInterp.Origins[ foundidx & ORIGIN_MASK ], frac, delta, neworg );

				// Dont interpolate large changes
				if ( Length( delta ) < 64 )
				{
					VectorSubtract( neworg, pparams->simorg, delta );

					VectorAdd( pparams->simorg, delta, pparams->simorg );
					VectorAdd( pparams->vieworg, delta, pparams->vieworg );
					VectorAdd( view->origin, delta, view->origin );

				}
			}
		}
	}

	// Store off v_angles before munging for third person
	v_angles = pparams->viewangles;
	v_lastAngles = pparams->viewangles;

	if ( CL_IsThirdPerson() )
	{
		VectorCopy( camAngles, pparams->viewangles);
		float pitch = camAngles[ 0 ];

		// Normalize angles
		if ( pitch > 180 ) 
			pitch -= 360.0;
		else if ( pitch < -180 )
			pitch += 360;

		// Player pitch is inverted
		pitch /= -3.0;

		// Slam local player's pitch value
		ent->angles[ 0 ] = pitch;
		ent->curstate.angles[ 0 ] = pitch;
		ent->prevstate.angles[ 0 ] = pitch;
		ent->latched.prevangles[ 0 ] = pitch;
	}

	// override all previous settings if the viewent isn't the client
	if ( pparams->viewentity > pparams->maxclients )
	{
		cl_entity_t *viewentity;
		viewentity = gEngfuncs.GetEntityByIndex( pparams->viewentity );
		if ( viewentity )
		{
			VectorCopy( viewentity->origin, pparams->vieworg );
			VectorCopy( viewentity->angles, pparams->viewangles );

			// Store off overridden viewangles
			v_angles = pparams->viewangles;
		}
	}
	else	// or these code will make vmdl move to some entity...
	{
		// Luna: MW's post gun position calcs
		VectorAdd(view->origin, V_CalcBob(pparams),			view->origin);
		VectorAdd(view->origin, V_CalcGunLagOfs(pparams),	view->origin);
		VectorAdd(view->origin, V_GetGunAimOffset(),		view->origin);

		// need to save first.
		g_c2ndVMDL.m_vecRawOrg = view->origin;

		VectorAdd(view->origin, V_CalcDualOfs(pparams),		view->origin);

		v_vecLastVmdlOrg = view->origin;
	}

	lasttime	= pparams->time;
	v_origin	= pparams->vieworg;
}

void V_SmoothInterpolateAngles( float * startAngle, float * endAngle, float * finalAngle, float degreesPerSec )
{
	float absd,frac,d,threshhold;
	
	NormalizeAngles( startAngle );
	NormalizeAngles( endAngle );

	for ( int i = 0 ; i < 3 ; i++ )
	{
		d = endAngle[i] - startAngle[i];

		if ( d > 180.0f )
		{
			d -= 360.0f;
		}
		else if ( d < -180.0f )
		{	
			d += 360.0f;
		}

		absd = fabs(d);

		if ( absd > 0.01f )
		{
			frac = degreesPerSec * v_frametime;

			threshhold= degreesPerSec / 4;

			if ( absd < threshhold )
			{
				float h = absd / threshhold;
				h *= h;
				frac*= h;  // slow down last degrees
			}

			if ( frac >  absd )
			{
				finalAngle[i] = endAngle[i];
			}
			else
			{
				if ( d>0)
					finalAngle[i] = startAngle[i] + frac;
				else
					finalAngle[i] = startAngle[i] - frac;
			}
		}
		else
		{
			finalAngle[i] = endAngle[i];
		}

	}

	NormalizeAngles( finalAngle );
}

// Get the origin of the Observer based around the target's position and angles
void V_GetChaseOrigin( float * angles, float * origin, float distance, float * returnvec )
{
	vec3_t	vecEnd;
	vec3_t	forward;
	vec3_t	vecStart;
	pmtrace_t * trace;
	int maxLoops = 8;

	int ignoreent = -1;	// first, ignore no entity
	
	cl_entity_t	 *	ent = NULL;
	
	// Trace back from the target using the player's view angles
	gEngfuncs.pfnAngleVectors(angles, forward, NULL, NULL);
	
	VectorScale(forward,-1,forward);

	VectorCopy( origin, vecStart );

	VectorMA(vecStart, distance , forward, vecEnd);

	while ( maxLoops > 0)
	{
		trace = gEngfuncs.PM_TraceLine( vecStart, vecEnd, PM_TRACELINE_PHYSENTSONLY, 2, ignoreent );

		// WARNING! trace->ent is is the number in physent list not the normal entity number

		if ( trace->ent <= 0)
			break;	// we hit the world or nothing, stop trace

		ent = gEngfuncs.GetEntityByIndex( PM_GetPhysEntInfo( trace->ent ) );

		if ( ent == NULL )
			break;

		// hit non-player solid BSP , stop here
		if ( ent->curstate.solid == SOLID_BSP && !ent->player ) 
			break;

		// if close enought to end pos, stop, otherwise continue trace
		if( Distance(trace->endpos, vecEnd ) < 1.0f )
		{
			break;
		}
		else
		{
			ignoreent = trace->ent;	// ignore last hit entity
			VectorCopy( trace->endpos, vecStart);
		}

		maxLoops--;
	}  

/*	if ( ent )
	{
		gEngfuncs.Con_Printf("Trace loops %i , entity %i, model %s, solid %i\n",(8-maxLoops),ent->curstate.number, ent->model->name , ent->curstate.solid ); 
	} */

	VectorMA( trace->endpos, 4, trace->plane.normal, returnvec );

	v_lastDistance = Distance(trace->endpos, origin);	// real distance without offset
}

/*void V_GetDeathCam(cl_entity_t * ent1, cl_entity_t * ent2, float * angle, float * origin)
{
	float newAngle[3]; float newOrigin[3]; 

	float distance = 168.0f;

	v_lastDistance+= v_frametime * 96.0f;	// move unit per seconds back

	if ( v_resetCamera )
		v_lastDistance = 64.0f;

	if ( distance > v_lastDistance )
		distance = v_lastDistance;

	VectorCopy(ent1->origin, newOrigin);

	if ( ent1->player )
		newOrigin[2]+= 17; // head level of living player

	// get new angle towards second target
	if ( ent2 )
	{
		VectorSubtract( ent2->origin, ent1->origin, newAngle );
		VectorAngles( newAngle, newAngle );
		newAngle[0] = -newAngle[0];
	}
	else
	{
		// if no second target is given, look down to dead player
		newAngle[0] = 90.0f;
		newAngle[1] = 0.0f;
		newAngle[2] = 0;
	}

	// and smooth view
	V_SmoothInterpolateAngles( v_lastAngles, newAngle, angle, 120.0f );
			
	V_GetChaseOrigin( angle, newOrigin, distance, origin );

	VectorCopy(angle, v_lastAngles);
}*/

void V_GetSingleTargetCam(cl_entity_t * ent1, float * angle, float * origin)
{
	float newAngle[3]; float newOrigin[3]; 

	// see is target is a dead player
	qboolean deadPlayer = ent1->player && (ent1->curstate.solid == SOLID_NOT);

	float distance = 112.0f + ( 16.0f * 1.0f ); // get close if dramatic;
	
	// go away in final scenes or if player just died
	if ( deadPlayer )
		distance*=1.5f;	

	// let v_lastDistance float smoothly away
	v_lastDistance+= v_frametime * 32.0f;	// move unit per seconds back

	if ( distance > v_lastDistance )
		distance = v_lastDistance;
	
	VectorCopy(ent1->origin, newOrigin);

	if ( ent1->player )
	{
		if ( deadPlayer )  
			newOrigin[2]+= 2;	//laying on ground
		else
			newOrigin[2]+= 17; // head level of living player
			
	}
	else
		newOrigin[2]+= 8;	// object, tricky, must be above bomb in CS

	// we have no second target, choose view direction based on
	// show front of primary target
	VectorCopy(ent1->angles, newAngle);


	newAngle[0] += 12.5f; // lower angle if dramatic
	newAngle[1] -= 22.5f;

	V_SmoothInterpolateAngles( v_lastAngles, newAngle, angle, 120.0f );

	// HACK, if player is dead don't clip against his dead body, can't check this
	V_GetChaseOrigin( angle, newOrigin, distance, origin );
}

float MaxAngleBetweenAngles(  float * a1, float * a2 )
{
	float d, maxd = 0.0f;

	NormalizeAngles( a1 );
	NormalizeAngles( a2 );

	for ( int i = 0 ; i < 3 ; i++ )
	{
		d = a2[i] - a1[i];
		if ( d > 180 )
		{
			d -= 360;
		}
		else if ( d < -180 )
		{	
			d += 360;
		}

		d = fabs(d);

		if ( d > maxd )
			maxd=d;
	}

	return maxd;
}

void V_GetDoubleTargetsCam(cl_entity_t	 * ent1, cl_entity_t * ent2,float * angle, float * origin)
{
	float newAngle[3]; float newOrigin[3]; float tempVec[3];

	float distance = 112.0f + ( 16.0f * 1.0f ); // get close if dramatic;
	
	// go away in final scenes or if player just died
	
	// let v_lastDistance float smoothly away
	v_lastDistance+= v_frametime * 32.0f;	// move unit per seconds back

	if ( distance > v_lastDistance )
		distance = v_lastDistance;

	VectorCopy(ent1->origin, newOrigin);

	if ( ent1->player )
		newOrigin[2]+= 17; // head level of living player
	else
		newOrigin[2]+= 8;	// object, tricky, must be above bomb in CS

	// get new angle towards second target
	VectorSubtract( ent2->origin, ent1->origin, newAngle );

	VectorAngles( newAngle, newAngle );
	newAngle[0] = -newAngle[0];

	// set angle diffrent in Dramtaic scenes
	newAngle[0] += 12.5f; // lower angle if dramatic
	newAngle[1] -= 22.5f;

	float d = MaxAngleBetweenAngles( v_lastAngles, newAngle );

	if ( ( d < v_cameraFocusAngle) && ( v_cameraMode == CAM_MODE_RELAX ) )
	{
		// difference is to small and we are in relax camera mode, keep viewangles
		VectorCopy(v_lastAngles, newAngle );
	}
	else if ( (d < v_cameraRelaxAngle) && (v_cameraMode == CAM_MODE_FOCUS) )
	{
		// we catched up with our target, relax again
		v_cameraMode = CAM_MODE_RELAX;
	}
	else
	{
		// target move too far away, focus camera again
		v_cameraMode = CAM_MODE_FOCUS;
	}

	// and smooth view, if not a scene cut
	if ( v_resetCamera || (v_cameraMode == CAM_MODE_RELAX) )
	{
		VectorCopy( newAngle, angle );
	}
	else
	{
		V_SmoothInterpolateAngles( v_lastAngles, newAngle, angle, 180.0f );
	}

	V_GetChaseOrigin( newAngle, newOrigin, distance, origin );

	// move position up, if very close at target
	if ( v_lastDistance < 64.0f )
		origin[2]+= 16.0f*( 1.0f - (v_lastDistance / 64.0f ) );

	// calculate angle to second target
	VectorSubtract( ent2->origin, origin, tempVec );
	VectorAngles( tempVec, tempVec );
	tempVec[0] = -tempVec[0];

	/* take middle between two viewangles
	InterpolateAngles( newAngle, tempVec, newAngle, 0.5f); */
	
	

}

void V_GetDirectedChasePosition(cl_entity_t	 * ent1, cl_entity_t * ent2,float * angle, float * origin)
{

	if ( v_resetCamera )
	{
		v_lastDistance = 4096.0f;
		// v_cameraMode = CAM_MODE_FOCUS;
	}

	if ( ( ent2 == (cl_entity_t*)0xFFFFFFFF ) || ( ent1->player && (ent1->curstate.solid == SOLID_NOT) ) )
	{
		// we have no second target or player just died
		V_GetSingleTargetCam(ent1, angle, origin);
	}
	else if ( ent2 )
	{
		// keep both target in view
		V_GetDoubleTargetsCam( ent1, ent2, angle, origin );
	}
	else
	{
		// second target disappeard somehow (dead)

		// keep last good viewangle
		float newOrigin[3];

		float dfactor	= 1.0f;

		float distance	= 112.0f + ( 16.0f * dfactor ); // get close if dramatic;

	
		// let v_lastDistance float smoothly away
		v_lastDistance+= v_frametime * 32.0f;	// move unit per seconds back

		if ( distance > v_lastDistance )
			distance = v_lastDistance;
		
		VectorCopy(ent1->origin, newOrigin);

		if ( ent1->player )
			newOrigin[2]+= 17; // head level of living player
		else
			newOrigin[2]+= 8;	// object, tricky, must be above bomb in CS

		V_GetChaseOrigin( angle, newOrigin, distance, origin );
	}

	VectorCopy(angle, v_lastAngles);
}

void V_GetChasePos(int target, float * cl_angles, float * origin, float * angles)
{
	cl_entity_t	 *	ent = NULL;
	
	if ( target ) 
	{
		ent = gEngfuncs.GetEntityByIndex( target );
	};
	
	if (!ent)
	{
		// just copy a save in-map position
		VectorCopy ( vJumpAngles, angles );
		VectorCopy ( vJumpOrigin, origin );
		return;
	}
	
	
	
	/*if ( gHUD.m_Spectator.m_autoDirector->value )
	{*/
		if ( g_iUser3 )
			V_GetDirectedChasePosition( ent, gEngfuncs.GetEntityByIndex( g_iUser3 ),
				angles, origin );
		else
			V_GetDirectedChasePosition( ent, ( cl_entity_t*)0xFFFFFFFF,
				angles, origin );
	/*}
	else
	{
		if ( cl_angles == NULL )	// no mouse angles given, use entity angles ( locked mode )
		{
			VectorCopy ( ent->angles, angles);
			angles[0]*=-1;
		}
		else
			VectorCopy ( cl_angles, angles);


		VectorCopy ( ent->origin, origin);
		
		origin[2]+= 28; // DEFAULT_VIEWHEIGHT - some offset

		V_GetChaseOrigin( angles, origin, cl_chasedist->value, origin );
	}*/

	v_resetCamera = false;	
}

void V_ResetChaseCam()
{
	v_resetCamera = true;
}


void V_GetInEyePos(int target, float * origin, float * angles )
{
	if ( !target)
	{
		// just copy a save in-map position
		VectorCopy ( vJumpAngles, angles );
		VectorCopy ( vJumpOrigin, origin );
		return;
	};


	cl_entity_t	 * ent = gEngfuncs.GetEntityByIndex( target );

	if ( !ent )
		return;

	VectorCopy ( ent->origin, origin );
	VectorCopy ( ent->angles, angles );

	angles[PITCH]*=-3.0f;	// see CL_ProcessEntityUpdate()

	if ( ent->curstate.solid == SOLID_NOT )
	{
		angles[ROLL] = 80;	// dead view angle
		origin[2]+= -8 ; // PM_DEAD_VIEWHEIGHT
	}
	else if (ent->curstate.usehull == 1 )
		origin[2]+= 12; // VEC_DUCK_VIEW;
	else
		// exacty eye position can't be caluculated since it depends on
		// client values like cl_bobcycle, this offset matches the default values
		origin[2]+= 28; // DEFAULT_VIEWHEIGHT
}

/*void V_GetMapFreePosition( float * cl_angles, float * origin, float * angles )
{
	vec3_t forward;
	vec3_t zScaledTarget;

	VectorCopy(cl_angles, angles);

	// modify angles since we don't wanna see map's bottom
	angles[0] = 51.25f + 38.75f*(angles[0]/90.0f);

	zScaledTarget[0] = gHUD.m_Spectator.m_mapOrigin[0];
	zScaledTarget[1] = gHUD.m_Spectator.m_mapOrigin[1];
	zScaledTarget[2] = gHUD.m_Spectator.m_mapOrigin[2] * (( 90.0f - angles[0] ) / 90.0f );
	

	AngleVectors(angles, forward, NULL, NULL);

	VectorNormalize(forward);

	VectorMA(zScaledTarget, -( 4096.0f / gHUD.m_Spectator.m_mapZoom ), forward , origin);
}*/

/*void V_GetMapChasePosition(int target, float * cl_angles, float * origin, float * angles)
{
	vec3_t forward;

	if ( target )
	{
		cl_entity_t	 *	ent = gEngfuncs.GetEntityByIndex( target );

		if ( gHUD.m_Spectator.m_autoDirector->value )
		{
			// this is done to get the angles made by director mode
			V_GetChasePos(target, cl_angles, origin, angles);
			VectorCopy(ent->origin, origin);
			
			// keep fix chase angle horizontal
			angles[0] = 45.0f;
		}
		else
		{
			VectorCopy(cl_angles, angles);
			VectorCopy(ent->origin, origin);

			// modify angles since we don't wanna see map's bottom
			angles[0] = 51.25f + 38.75f*(angles[0]/90.0f);
		}
	}
	else
	{
		// keep out roaming position, but modify angles
		VectorCopy(cl_angles, angles);
		angles[0] = 51.25f + 38.75f*(angles[0]/90.0f);
	}

	origin[2] *= (( 90.0f - angles[0] ) / 90.0f );
	angles[2] = 0.0f;	// don't roll angle (if chased player is dead)

	AngleVectors(angles, forward, NULL, NULL);

	VectorNormalize(forward);

	VectorMA(origin, -1536, forward, origin); 
}*/

int V_FindViewModelByWeaponModel(int weaponindex)
{

	static char * modelmap[][2] =	{
		{ "models/p_crossbow.mdl",		"models/v_crossbow.mdl"		},
		{ "models/p_crowbar.mdl",		"models/v_crowbar.mdl"		},
		{ "models/p_egon.mdl",			"models/v_egon.mdl"			},
		{ "models/p_gauss.mdl",			"models/v_gauss.mdl"		},
		{ "models/p_9mmhandgun.mdl",	"models/v_9mmhandgun.mdl"	},
		{ "models/p_grenade.mdl",		"models/v_grenade.mdl"		},
		{ "models/p_hgun.mdl",			"models/v_hgun.mdl"			},
		{ "models/p_9mmAR.mdl",			"models/v_9mmAR.mdl"		},
		{ "models/p_357.mdl",			"models/v_357.mdl"			},
		{ "models/p_rpg.mdl",			"models/v_rpg.mdl"			},
		{ "models/p_shotgun.mdl",		"models/v_shotgun.mdl"		},
		{ "models/p_squeak.mdl",		"models/v_squeak.mdl"		},
		{ "models/p_tripmine.mdl",		"models/v_tripmine.mdl"		},
		{ "models/p_satchel_radio.mdl",	"models/v_satchel_radio.mdl"},
		{ "models/p_satchel.mdl",		"models/v_satchel.mdl"		},
		{ NULL, NULL } };

	struct model_s * weaponModel = IEngineStudio.GetModelByIndex( weaponindex );

	if ( weaponModel )
	{
		int len = strlen( weaponModel->name );
		int i = 0;

		while ( modelmap[i] != NULL )
		{
			if ( !strnicmp( weaponModel->name, modelmap[i][0], len ) )
			{
				return gEngfuncs.pEventAPI->EV_FindModelIndex( modelmap[i][1] );
			}
			i++;
		}

		return 0;
	}
	else
		return 0;

}


/*
==================
V_CalcSpectatorRefdef

==================
*/
void V_CalcSpectatorRefdef ( struct ref_params_s * pparams )
{
	static vec3_t			velocity ( 0.0f, 0.0f, 0.0f);

	static int lastWeaponModelIndex = 0;
	static int lastViewModelIndex = 0;
		
	cl_entity_t	 * ent = gEngfuncs.GetEntityByIndex( g_iUser2 );
	
	pparams->onlyClientDraw = false;

	// refresh position
	VectorCopy ( pparams->simorg, v_sim_org );

	// get old values
	VectorCopy ( pparams->cl_viewangles, v_cl_angles );
	VectorCopy ( pparams->viewangles, v_angles );
	VectorCopy ( pparams->vieworg, v_origin );

	if ( g_iUser1 == OBS_IN_EYE && ent )
	{
		// calculate player velocity
		float timeDiff = ent->curstate.msg_time - ent->prevstate.msg_time;

		if ( timeDiff > 0 )
		{
			vec3_t distance;
			VectorSubtract(ent->prevstate.origin, ent->curstate.origin, distance);
			VectorScale(distance, 1/timeDiff, distance );

			velocity[0] = velocity[0]*0.9f + distance[0]*0.1f;
			velocity[1] = velocity[1]*0.9f + distance[1]*0.1f;
			velocity[2] = velocity[2]*0.9f + distance[2]*0.1f;
			
			VectorCopy(velocity, pparams->simvel);
		}

		// predict missing client data and set weapon model ( in HLTV mode or inset in eye mode )
		if ( gEngfuncs.IsSpectateOnly() )
		{
			V_GetInEyePos( g_iUser2, pparams->simorg, pparams->cl_viewangles );

			pparams->health = 1;

			cl_entity_t	 * gunModel = gEngfuncs.GetViewModel();

			if ( lastWeaponModelIndex != ent->curstate.weaponmodel )
			{
				// weapon model changed

				lastWeaponModelIndex = ent->curstate.weaponmodel;
				lastViewModelIndex = V_FindViewModelByWeaponModel( lastWeaponModelIndex );
				if ( lastViewModelIndex )
				{
					gEngfuncs.pfnWeaponAnim(0,0);	// reset weapon animation
				}
				else
				{
					// model not found
					gunModel->model = NULL;	// disable weapon model
					lastWeaponModelIndex = lastViewModelIndex = 0;
				}
			}

			if ( lastViewModelIndex )
			{
				gunModel->model = IEngineStudio.GetModelByIndex( lastViewModelIndex );
				gunModel->curstate.modelindex = lastViewModelIndex;
				gunModel->curstate.frame = 0;
				gunModel->curstate.colormap = 0; 
				gunModel->index = g_iUser2;
			}
			else
			{
				gunModel->model = NULL;	// disable weaopn model
			}
		}
		else
		{
			// only get viewangles from entity
			VectorCopy ( ent->angles, pparams->cl_viewangles );
			pparams->cl_viewangles[PITCH]*=-3.0f;	// see CL_ProcessEntityUpdate()
		}
	}

	v_frametime = pparams->frametime;

	if ( pparams->nextView == 0 )
	{
		// first renderer cycle, full screen

		switch ( g_iUser1 )
		{
			case OBS_CHASE_LOCKED:	V_GetChasePos( g_iUser2, NULL, v_origin, v_angles );
									break;

			case OBS_CHASE_FREE:	V_GetChasePos( g_iUser2, v_cl_angles, v_origin, v_angles );
									break;

			case OBS_ROAMING	:	VectorCopy (v_cl_angles, v_angles);
									VectorCopy (v_sim_org, v_origin);
									break;

			case OBS_IN_EYE		:   V_CalcNormalRefdef ( pparams );
									break;
				
			case OBS_MAP_FREE  :	pparams->onlyClientDraw = true;
									//V_GetMapFreePosition( v_cl_angles, v_origin, v_angles );
									break;

			case OBS_MAP_CHASE  :	pparams->onlyClientDraw = true;
									//V_GetMapChasePosition( g_iUser2, v_cl_angles, v_origin, v_angles );
									break;
		}

		/*if ( gHUD.m_Spectator.m_pip->value )
			pparams->nextView = 1;	// force a second renderer view

		gHUD.m_Spectator.m_iDrawCycle = 0;*/

	}
	/*else
	{
		// second renderer cycle, inset window

		// set inset parameters
		pparams->viewport[0] = XRES(gHUD.m_Spectator.m_OverviewData.insetWindowX);	// change viewport to inset window
		pparams->viewport[1] = YRES(gHUD.m_Spectator.m_OverviewData.insetWindowY);
		pparams->viewport[2] = XRES(gHUD.m_Spectator.m_OverviewData.insetWindowWidth);
		pparams->viewport[3] = YRES(gHUD.m_Spectator.m_OverviewData.insetWindowHeight);
		pparams->nextView	 = 0;	// on further view

		// override some settings in certain modes
		switch ( (int)gHUD.m_Spectator.m_pip->value )
		{
			case INSET_CHASE_FREE : V_GetChasePos( g_iUser2, v_cl_angles, v_origin, v_angles );
									break;	

			case INSET_IN_EYE	 :	V_CalcNormalRefdef ( pparams );
									break;

			case INSET_MAP_FREE  :	pparams->onlyClientDraw = true;
									V_GetMapFreePosition( v_cl_angles, v_origin, v_angles );
									break;

			case INSET_MAP_CHASE  :	pparams->onlyClientDraw = true;

									if ( g_iUser1 == OBS_ROAMING )
										V_GetMapChasePosition( 0, v_cl_angles, v_origin, v_angles );
									else
										V_GetMapChasePosition( g_iUser2, v_cl_angles, v_origin, v_angles );

									break;
		}

		gHUD.m_Spectator.m_iDrawCycle = 1;
	}*/

	// write back new values into pparams
	VectorCopy ( v_cl_angles, pparams->cl_viewangles );
	VectorCopy ( v_angles, pparams->viewangles )
	VectorCopy ( v_origin, pparams->vieworg );

}



void DLLEXPORT V_CalcRefdef( struct ref_params_s *pparams )
{
	// copy for 3DUI first.
	gHUD::TriDimnHud::m_flFrameRate = pparams->frametime;
	g_pRefParams = pparams;

	// intermission / finale rendering
	if ( pparams->intermission )
	{	
		V_CalcIntermissionRefdef ( pparams );	
	}
	else if ( pparams->spectator || g_iUser1 )	// g_iUser true if in spectator mode
	{
		V_CalcSpectatorRefdef ( pparams );	
	}
	else if ( !pparams->paused )
	{
		V_CalcNormalRefdef ( pparams );
	}

	memcpy(&g_pparams, pparams, sizeof(g_pparams));

/*
// Example of how to overlay the whole screen with red at 50 % alpha
#define SF_TEST
#if defined SF_TEST
	{
		screenfade_t sf;
		gEngfuncs.pfnGetScreenFade( &sf );

		sf.fader = 255;
		sf.fadeg = 0;
		sf.fadeb = 0;
		sf.fadealpha = 128;
		sf.fadeFlags = FFADE_STAYOUT | FFADE_OUT;

		gEngfuncs.pfnSetScreenFade( &sf );
	}
#endif
*/
}

/*
=============
V_DropPunchAngle

=============
*/
void V_DropPunchAngle ( float frametime, float *vecPunchAngle )
{
	float	len;
	
	len = VectorNormalize ( vecPunchAngle );
	len -= (10.0 + len * 0.5) * frametime;
	len = max( len, 0.0 );
	VectorScale ( vecPunchAngle, len, vecPunchAngle );
}

/*
=============
V_PunchAxis

Client side punch effect
=============
*/
void V_PunchAxis( int axis, float punch )
{
	g_vecPunchAngle[ axis ] = punch;
}

/*
=============
V_Init
=============
*/
void V_Init (void)
{
	gEngfuncs.pfnAddCommand ("centerview", V_StartPitchDrift );
	gEngfuncs.pfnAddCommand ("leanleft", gLeanManager::LeanLeft);
	gEngfuncs.pfnAddCommand ("+leanleft", gLeanManager::LeanLeft);
	gEngfuncs.pfnAddCommand ("-leanleft", gLeanManager::Reset);
	gEngfuncs.pfnAddCommand ("leanright", gLeanManager::LeanRight);
	gEngfuncs.pfnAddCommand ("+leanright", gLeanManager::LeanRight);
	gEngfuncs.pfnAddCommand ("-leanright", gLeanManager::Reset);

	v_centermove		= gEngfuncs.pfnRegisterVariable( "v_centermove", "0.15", 0 );
	v_centerspeed		= gEngfuncs.pfnRegisterVariable( "v_centerspeed","500", 0 );

	cl_waterdist		= gEngfuncs.pfnRegisterVariable( "cl_waterdist","4", 0 );
	cl_chasedist		= gEngfuncs.pfnRegisterVariable( "cl_chasedist","112", 0 );

	v_pCvarGunOfs[0] = gEngfuncs.pfnRegisterVariable("cl_gunoffsetX", "0", 0);
	v_pCvarGunOfs[1] = gEngfuncs.pfnRegisterVariable("cl_gunoffsetY", "0", 0);
	v_pCvarGunOfs[2] = gEngfuncs.pfnRegisterVariable("cl_gunoffsetZ", "0", 0);
}


/*
==========================
	Smooth FOV Manager

Source Engine style zooming.
==========================
*/

#include "hud.h"

extern cvar_t	*sensitivity;

namespace gFovManager
{
	float	m_flTargetFOV	= 90;
	float	m_flFOV			= 90;

	// this is the replace of gHUD::Think()
	void Think(float flFrameRate)
	{
		m_flFOV			+=	(m_flTargetFOV - m_flFOV) * flFrameRate * 10;

		// avoid some strange situation.
		if ( m_flFOV <= 0 || m_flFOV > 179 )
			m_flFOV = gHUD::m_pCvarDefFOV->value;

		// set a new sensitivity that is proportional to the change from the FOV default
		gHUD::m_flMouseSensitivity = sensitivity->value * (m_flFOV / gHUD::m_pCvarDefFOV->value) * gHUD::m_pCvarZoomSenRatio->value;
	}

	void Reset(void)
	{
		Set(gHUD::m_pCvarDefFOV->value);
	}

	void Set(float flTargetFOV)
	{
		m_flTargetFOV	= flTargetFOV;
	}
};

/*
==========================
	Lean  Manager

Idea by Rainbow Six Siege
==========================
*/

namespace gLeanManager
{
	int		m_iLeanState	= 0;
	float	m_flAngleZ		= 0;
	Vector	m_vecViewOfs	= Vector();

	const Vector	m_vecLeanOfs	= Vector(10, 0, 0);
	const float		m_flLeanAngle	= 20;
};

void gLeanManager::Think(float flFrameRate)
{
	m_flAngleZ		+=	(GetTargetAngle() - m_flAngleZ) * flFrameRate * 10;
	m_vecViewOfs	+=	(GetTargetViewOfs() - m_vecViewOfs) * flFrameRate * 10;
}

void gLeanManager::Reset(void)
{
	m_iLeanState = LEAN_NO;

	UpdateToServer();
}

void gLeanManager::LeanLeft(void)
{
	if (m_iLeanState == LEAN_LEFT)
		Reset();
	else
		m_iLeanState = LEAN_LEFT;

	UpdateToServer();
}

void gLeanManager::LeanRight(void)
{
	if (m_iLeanState == LEAN_RIGHT)
		Reset();
	else
		m_iLeanState = LEAN_RIGHT;

	UpdateToServer();
}

float gLeanManager::GetTargetAngle(void)
{
	switch (m_iLeanState)
	{
		case LEAN_LEFT:
			return -m_flLeanAngle;
		case LEAN_RIGHT:
			return m_flLeanAngle;
		default:
			return 0.0f;
	}
}

Vector gLeanManager::GetTargetViewOfs(void)
{
	gEngfuncs.pfnAngleVectors(Vector(g_pRefParams->viewangles[0], g_pRefParams->viewangles[1], 0), g_pRefParams->forward, g_pRefParams->right, g_pRefParams->up);

	switch (m_iLeanState)
	{
		case LEAN_LEFT:
			return (-Vector(g_pRefParams->right) * m_vecLeanOfs.x - Vector(g_pRefParams->forward) * m_vecLeanOfs.y - Vector(g_pRefParams->up) * m_vecLeanOfs.z);
		case LEAN_RIGHT:
			return (Vector(g_pRefParams->right) * m_vecLeanOfs.x + Vector(g_pRefParams->forward) * m_vecLeanOfs.y + Vector(g_pRefParams->up) * m_vecLeanOfs.z);
		default:
			return Vector();
	}
}

int gLeanManager::GetLeanState(void)
{
	return m_iLeanState;
}

void gLeanManager::UpdateToServer(void)
{
	SU_Begin		(GLB_CMD_LEAN);
	SU_WriteInteger	(GetLeanState());
	SU_End			(	);
}
