//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

// Triangle rendering, if any

#include "hud.h"
#include "hud_menu.h"
#include "cl_util.h"

// Triangle rendering apis are in gEngfuncs.pTriAPI

#include "const.h"
#include "entity_state.h"
#include "cl_entity.h"
#include "cl_wpns.h"
#include "DDS_Anim.h"
#include "view.h"

#include <windows.h>
#include <stdio.h>
#include <triangleapi.h>
#include <gl/gl.h>
#include <glext.h>

#define DLLEXPORT __declspec( dllexport )

extern "C"
{
	void DLLEXPORT HUD_DrawNormalTriangles( void );
	void DLLEXPORT HUD_DrawTransparentTriangles( void );
};

bool	g_bDraw3DGUI	= true;	// e.g. open game menu.

#if FALSE
/*
=================
Draw_Triangles

Example routine.  Draws a sprite offset from the player origin.
=================
*/
void Draw_Triangles( void )
{
	cl_entity_t *player;
	vec3_t org;

	// Load it up with some bogus data
	player = gEngfuncs.GetLocalPlayer();
	if ( !player )
		return;

	org = player->origin;

	org.x += 50;
	org.y += 50;

	if (gHUD.m_hsprCursor == 0)
	{
		char sz[256];
		sprintf( sz, "sprites/cursor.spr" );
		gHUD.m_hsprCursor = SPR_Load( sz );
	}

	if ( !gEngfuncs.pTriAPI->SpriteTexture( (struct model_s *)gEngfuncs.GetSpritePointer( gHUD.m_hsprCursor ), 0 ))
	{
		return;
	}
	
	// Create a triangle, sigh
	gEngfuncs.pTriAPI->RenderMode( kRenderNormal );
	gEngfuncs.pTriAPI->CullFace( TRI_NONE );
	gEngfuncs.pTriAPI->Begin( TRI_QUADS );
	// Overload p->color with index into tracer palette, p->packedColor with brightness
	gEngfuncs.pTriAPI->Color4f( 1.0, 1.0, 1.0, 1.0 );
	// UNDONE: This gouraud shading causes tracers to disappear on some cards (permedia2)
	gEngfuncs.pTriAPI->Brightness( 1 );
	gEngfuncs.pTriAPI->TexCoord2f( 0, 0 );
	gEngfuncs.pTriAPI->Vertex3f( org.x, org.y, org.z );

	gEngfuncs.pTriAPI->Brightness( 1 );
	gEngfuncs.pTriAPI->TexCoord2f( 0, 1 );
	gEngfuncs.pTriAPI->Vertex3f( org.x, org.y + 50, org.z );

	gEngfuncs.pTriAPI->Brightness( 1 );
	gEngfuncs.pTriAPI->TexCoord2f( 1, 1 );
	gEngfuncs.pTriAPI->Vertex3f( org.x + 50, org.y + 50, org.z );

	gEngfuncs.pTriAPI->Brightness( 1 );
	gEngfuncs.pTriAPI->TexCoord2f( 1, 0 );
	gEngfuncs.pTriAPI->Vertex3f( org.x + 50, org.y, org.z );

	gEngfuncs.pTriAPI->End();
	gEngfuncs.pTriAPI->RenderMode( kRenderNormal );
}

#endif

/*
=================
HUD_DrawNormalTriangles

Non-transparent triangles-- add them here
=================
*/
void DLLEXPORT HUD_DrawNormalTriangles( void )
{
}

/*
=================
HUD_DrawTransparentTriangles

Render any triangles with transparent rendermode needs here
=================
*/
void DLLEXPORT HUD_DrawTransparentTriangles( void )
{
	// DDS anim part.
	// update move to HUD_Frame()
	gDxtAnimManager::DrawAll();

	if (g_bDraw3DGUI && g_pparams.viewentity <= g_pparams.maxclients)	// dont't draw 3DUI when using a camera or something like that.
	{
		glPushAttrib(GL_ALL_ATTRIB_BITS);				// Save current depth range value
		glDepthRange(0.0001, 0.0002);					// Change depth range for 3D HUD drawing

		// glb hud
		gHUD::TriDimnHud::CalcVectors();
		gHUD::TriDimnHud::DrawArmor();

		// menu
		HUD_MenuDraw();

		// actived item.
		if (g_pPlayerActivityItem)
		{
			g_pPlayerActivityItem->HUD_Think3D();
			g_pPlayerActivityItem->HUD_Draw3D();
		}

		// hint text.
		if (g_pHudHintTextHeader)
			g_pHudHintTextHeader->Think();

		if (g_pHudHintTextHeader)
			g_pHudHintTextHeader->Draw();

		glPopAttrib();									// Restore depth range value
	}

	// after back to normal world
	if (g_pPlayerActivityItem)
		g_pPlayerActivityItem->DrawWorldCustomObjects();
}