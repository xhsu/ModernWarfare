#include <io.h>
#include <windows.h>
#include <stdio.h>
#include <triangleapi.h>
#include <gl/gl.h>
#include "cl_util.h"
#include "dxt.h"
#include "DDS_Anim.h"
#include "GameStudioModelRenderer.h"
#include "view.h"

using namespace gDxtAnimManager;

CBaseDDSAnim::CBaseDDSAnim(void)
{
	memset(&m_sAnimData,	NULL,	sizeof(m_sAnimData));
	memset(&m_sColor,		255,	sizeof(m_sColor));

	m_flTimeLoop		= 1;
	m_iFPS				= 1;
	m_iCurrentFrame		= 1;
	m_flPlayedRatio		= 0;
	m_flTimeStart		= 0;
	m_bitsFlags			= FTENT_NONE;
	m_pEntity			= NULL;
	m_iAttachment		= 0;
	m_vecOrigin			= Vector();
	m_vecOffset			= Vector();
	m_vecVelocity		= Vector();
	m_vecAcceleration	= Vector();
	m_flWidth			= 1;
	m_flHeight			= 1;
	m_pvecAttachOri		= NULL;
	m_pNext				= NULL;
}

CBaseDDSAnim::~CBaseDDSAnim(void)
{
}

void CBaseDDSAnim::SetTextureGroup( const char *path,	const char *name,	int maxframe	)
{
	m_sAnimData = *LoadAnim(path, name, maxframe);
}

void CBaseDDSAnim::SetLastingTime(double looptime, int fps)
{
	if (fps)
	{
		m_iFPS			= fps;
		m_flTimeLoop	= double(m_sAnimData.m_iMaxFrame) / double(m_iFPS);
	}
	else if (looptime)
	{
		m_flTimeLoop	= looptime;
		m_iFPS			= short(double(m_sAnimData.m_iMaxFrame) / looptime);
	}
}

void CBaseDDSAnim::SetRGBA(unsigned long RGB, int a)
{
	color24 sRGB	= UnpackRGB(RGB);

	m_sColor.r		= sRGB.r;
	m_sColor.g		= sRGB.g;
	m_sColor.b		= sRGB.b;
	m_sColor.a		= a;
}

void CBaseDDSAnim::Frame(void)
{
	if (m_bitsFlags & FTENT_NOMODEL)
		return;

	if (m_flTimeStart <= 0)
		m_flTimeStart = g_flClientTime;

	m_flPlayedRatio	= (g_flClientTime - m_flTimeStart) / m_flTimeLoop;
	m_iCurrentFrame	= short(1.0 + m_flPlayedRatio * double(m_sAnimData.m_iMaxFrame - 1));

	if (m_iCurrentFrame > m_sAnimData.m_iMaxFrame && m_bitsFlags & FTENT_SPRCYCLE)
	{
		m_iCurrentFrame	= 1;
		m_flTimeStart	= 0;
	}
	else if (m_iCurrentFrame > m_sAnimData.m_iMaxFrame)
	{
		m_iCurrentFrame	= m_sAnimData.m_iMaxFrame;
	}

	if (!(m_bitsFlags & FTENT_PLYRATTACHMENT))
	{
		m_vecVelocity	+= m_vecAcceleration * g_flClientFrame;
		m_vecOrigin		+= m_vecVelocity * g_flClientFrame;
	}
}

void CBaseDDSAnim::Draw(void)
{
	if (m_bitsFlags & FTENT_NOMODEL)
		return;

	if (m_bitsFlags & FTENT_PLYRATTACHMENT)
	{
		if (m_iAttachment <= 3)
			m_vecOrigin = m_pEntity->attachment[m_iAttachment];
		else if (m_pEntity == g_pViewEnt && m_iAttachment < MAX_VMDL_ATTACHMENT)
			m_vecOrigin = g_vecViewModelAttmt[m_iAttachment];
		else
			m_vecOrigin = m_pEntity->origin;

		m_vecOrigin += m_vecOffset;
	}
	else if (m_pvecAttachOri)
	{
		m_vecOrigin	=	*m_pvecAttachOri;
		m_vecOrigin	+=	m_vecOffset;
	}

	gEngfuncs.pTriAPI->RenderMode(kRenderTransTexture);
	glBindTexture(GL_TEXTURE_2D, m_sAnimData.m_iTextureIndexs[m_iCurrentFrame]);
	glColor4ub(m_sColor.r, m_sColor.g, m_sColor.b, (m_bitsFlags & FTENT_FADEOUT) ? max(m_sColor.a * (1.0 - m_flPlayedRatio), 0) : m_sColor.a);

	Vector vecs[4];
	vecs[0] = m_vecOrigin - Vector(g_pparams.right) * m_flWidth * 0.5f + Vector(g_pparams.up) * m_flHeight * 0.5f;
	vecs[1] = vecs[0] + Vector(g_pparams.right) * m_flWidth;
	vecs[2] = vecs[1] - Vector(g_pparams.up) * m_flHeight;
	vecs[3] = vecs[0] - Vector(g_pparams.up) * m_flHeight;

	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glTexCoord2f(1, 0);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glTexCoord2f(1, 1);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glTexCoord2f(0, 1);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();
}

static animdata_t		m_sDataBase[64];
static unsigned short	m_iAnimTypes;
static CBaseDDSAnim		m_sAnimRoot;
static CBaseDDSAnim		*m_pAnimRoot	= &m_sAnimRoot;

namespace gDxtAnimManager
{
	void		Initialization ( void )
	{
		m_iAnimTypes				= 0;
		m_sAnimRoot.m_bitsFlags		= FTENT_NOMODEL|FTENT_PERSIST;

		memset(m_sDataBase, NULL, sizeof(m_sDataBase));
	}

	animdata_t	*LoadAnim ( const char *path,	const char *name,	int maxframe )
	{
		for (int i = 0; i < m_iAnimTypes; i ++)
		{
			if (maxframe != m_sDataBase[i].m_iMaxFrame || strcmp(m_sDataBase[i].m_szPath, path) || strcmp(m_sDataBase[i].m_szName, name))
				continue;

			return &m_sDataBase[i];
		}

		strcpy(m_sDataBase[m_iAnimTypes].m_szName, name);
		strcpy(m_sDataBase[m_iAnimTypes].m_szPath, path);
		m_sDataBase[m_iAnimTypes].m_iMaxFrame = (unsigned short)maxframe;

		char szFullPath[256 + 64];
		for (int i = 1; i <= maxframe; i ++)
		{
			sprintf(szFullPath, "%s//%s_%d.dds", path, name, i);
			m_sDataBase[m_iAnimTypes].m_iTextureIndexs[i] = LoadDDS(szFullPath);
		}

		return &m_sDataBase[m_iAnimTypes ++];
	}

	CBaseDDSAnim	*Add ( animdata_t	*d	)
	{
		CBaseDDSAnim **p = &m_pAnimRoot;
		while (*p)
		{
			p = &((*p)->m_pNext);
		}

		*p					= new CBaseDDSAnim;
		(**p).m_sAnimData	= *d;

		return *p;
	}

	void			Add ( CBaseDDSAnim	*pt	)
	{
		CBaseDDSAnim **p = &m_pAnimRoot;
		while (*p)
		{
			p = &((*p)->m_pNext);
		}

		*p					= pt;
	}

	void			UpdateAll ( void )
	{
		CBaseDDSAnim *p = m_pAnimRoot;
		CBaseDDSAnim *l = p;

		while (p)
		{
			p->Frame();

			if (p != m_pAnimRoot && p->m_flPlayedRatio > 1 && !(p->m_bitsFlags & (FTENT_SPRANIMATELOOP|FTENT_SPRCYCLE|FTENT_PERSIST)) )
			{
				l->m_pNext = p->m_pNext;
				delete p;
				p = l->m_pNext;

				continue;
			}

			l = p;
			p = p->m_pNext;
		}
	}

	void			DrawAll ( void )
	{
		CBaseDDSAnim *p = m_pAnimRoot;

		while (p)
		{
			p->Draw();

			p = p->m_pNext;
		}
	}
};