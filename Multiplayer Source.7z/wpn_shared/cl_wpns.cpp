/***

Modern Warfare Develop Team
cl_wpns.cpp

Coder:	Luna the Reborn

Create Date: 2017/11

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "GameStudioModelRenderer.h"
#include "view.h"
#include "input.h"
#include "event_api.h"
#include "entity_state.h"
#include "wpn_cmd_shared.h"
#include "pm_defs.h"
#include "r_efx.h"
#include "DrawFonts.h"

// root
CBaseWeapons	*g_pWeaponChainRoot = NULL;

// cur weapon and last weapon
CBaseWeapons	*g_pPlayerActivityItem = NULL;
CBaseWeapons	*g_pPlayerLastItem = NULL;

// their priority chioce of some action.
CBaseMelee		*g_pPlayerFavMelee = NULL;
CBaseGrenade	*g_pPlayerPriGr = NULL;
CBaseGrenade	*g_pPlayerSedGr = NULL;

// mag manager
CMagazineManager g_cMagManager;

/*
===================================
Constructor & Destructor

Chains are here.
===================================
*/

CBaseItems::CBaseItems(void)
{
	m_iItemType			= 0;
	m_pOriginalDB		= &g_sItemData[0];
	m_sItemData			= g_sItemData[0];
	m_flNextPriAttack	= 0;
	m_flNextSedAttack	= 0;
	m_flNextIdle		= 0;
	m_ulStatus			= 0;
	m_flNextFrame		= 0;
	m_flNextThink		= 0;
	m_iClip				= 0;
	m_iChamberClip		= 0;

	m_pfnThink			= NULL;
	m_pfnItemAddToPlayer= NULL;
	m_pfnItemPreFrame	= NULL;
	m_pfnItemDeploy		= NULL;
	m_pfnItemPostFrame	= NULL;
	m_pfnPrimaryAttack	= NULL;
	m_pfnSecondaryAttack= NULL;
	m_pfnWeaponIdle		= NULL;
	m_pfnWeaponReload	= NULL;
	m_pfnItemHolster	= NULL;
	m_pfnItemDropped	= NULL;
	m_pfnItemKill		= NULL;
}

CBaseWeapons::CBaseWeapons(void)
{
	m_pPlayer		= gEngfuncs.GetLocalPlayer();

	memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
	m_sAnimStack.m_iSequence = -1;	// mark as should not be Pop().

	CBaseWeapons *p = g_pWeaponChainRoot;
	while (p)
	{
		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// p == NULL means this is the first.
	if (!p)
		g_pWeaponChainRoot = this;
	else
		p->m_pNext = this;

	// function setting
	SetAddFunc(&CBaseWeapons::Def_ItemAddToPlayer);
	SetFunc(m_pfnItemPreFrame,		&CBaseWeapons::Def_ItemPreFrame);
	SetFunc(m_pfnItemDeploy,		&CBaseWeapons::Def_ItemDeploy);
	SetFunc(m_pfnItemPostFrame,		&CBaseWeapons::Def_ItemPostFrame);
	SetFunc(m_pfnPrimaryAttack,		&CBaseWeapons::Def_PrimaryAttack);
	SetFunc(m_pfnSecondaryAttack,	&CBaseWeapons::Def_SteelSight);
	SetFunc(m_pfnWeaponIdle,		&CBaseWeapons::Def_WeaponIdle);
	SetFunc(m_pfnRunStart,			&CBaseWeapons::Def_RunStart);
	SetFunc(m_pfnRunStop,			&CBaseWeapons::Def_RunStop);
	SetFunc(m_pfnWeaponReload,		&CBaseWeapons::Def_WeaponReload);
	SetFunc(m_pfnItemHolster,		&CBaseWeapons::Def_ItemHolster);
	SetFunc(m_pfnItemDropped,		&CBaseWeapons::Def_ItemDropped);
	SetFunc(m_pfnItemKill,			&CBaseWeapons::Def_ItemKill);
}

CBaseWeapons::~CBaseWeapons(void)
{
	// remove subs item.
	if (m_pSubsItem)
		m_pSubsItem->ItemKill();

	// free alt item.
	if (m_pAltWeapon)
	{
		// reset 2nd vmdl.
		g_c2ndVMDL.Initialization();

		m_pAltWeapon->UninstallAltWeapon();	// uninstall it first.
		UninstallAltWeapon();
	}

	if (g_pPlayerActivityItem == this)	// handle switch weapon in ItemDropped.
	{
		g_pPlayerActivityItem = NULL;
		g_pViewModel = NULL;
	}

	if (g_pPlayerLastItem == this)
		g_pPlayerLastItem = NULL;

	// if killing chain root, give chair to his next.
	if (g_pWeaponChainRoot == this)
	{
		g_pWeaponChainRoot = m_pNext;
		return;
	}

	// otherwise, which means at least two weapons in chain, and g_pWeaponChainRoot->m_pNext != NULL
	CBaseWeapons *pl	= g_pWeaponChainRoot;
	CBaseWeapons *p		= g_pWeaponChainRoot->m_pNext;

	while (p)
	{
		if ( p == this )
		{
			pl->m_pNext	= m_pNext;
			break;
		}

		pl	= p;
		p	= p->m_pNext;
	}
}

void UTIL_RemoveAllItems(void)
{
	if (!g_pWeaponChainRoot)
	{
		goto LAB_RAI_RESETVALUE;
	}

	while (g_pWeaponChainRoot->m_pNext)
	{
		g_pWeaponChainRoot->m_pNext->ItemKill();
	}

	g_pWeaponChainRoot->ItemKill();

LAB_RAI_RESETVALUE:
	g_pViewModel			= NULL;
	g_pWeaponChainRoot		= NULL;
	g_pPlayerActivityItem	= NULL;
	g_pPlayerLastItem		= NULL;
	
	// remove 2nd vmdl.
	g_c2ndVMDL.Initialization();
}

CMagazineManager::CMagazineManager(void)
{
	memset(m_iAmmoAmount,	NULL,	sizeof(m_iAmmoAmount));
	memset(m_iMagAmount,	NULL,	sizeof(m_iMagAmount));
}

/*
===================================

Part of New Functions

===================================
*/
void CBaseWeapons::AimUp(void)
{
	if (IS_AIMING)
		return;

	if (IS_RUNNING)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_AIM;
		return;
	}

	m_ulStatus |= WPN_FLAG_AIM;
	m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	if (WPNANIM(AIM_UP).m_i > 0)
		WeaponAnim(&WPNANIM(AIM_UP), 2);

	gFovManager::Set(GetAimFOV());

	// tell servers current FOV, avoid bugs.
	SU_Begin		(WPN_CMD_FOV);
	SU_WriteInteger	(GetAimFOV());
	SU_End			();

	g_vecGunOfs = GetAimOffset();
	v_bGunOfsSmooth = true;

	SPK_SOUND("weapons/steelsight_in.wav");
}

void CBaseWeapons::AimDown(void)
{
	if (!(m_ulStatus & WPN_FLAG_AIM))
		return;

	m_ulStatus &= ~WPN_FLAG_AIM;

	if (WPNANIM(AIM_DOWN).m_i > 0)
		WeaponAnim(&WPNANIM(AIM_DOWN), 2);

	gFovManager::Reset();

	// tell servers current FOV, avoid bugs.
	SU_Begin		(WPN_CMD_FOV);
	SU_WriteInteger	(90);
	SU_End			();

	g_vecGunOfs = Vector();
	v_bGunOfsSmooth = true;

	SPK_SOUND("weapons/steelsight_out.wav");
}

void CBaseWeapons::Def_RunStart(void)
{
	// you can't run without pressing forwarding button.
	if (!(CL_GetButtonBits() & IN_FORWARD))
		return;

	// You can't ducking & running
	if (UTIL_IsPlayerDucking())
	{
		// if user want to switch to duck, then do it.
		if (IS_RUNNING)
		{
			RunStop();
			return;
		}

		if (g_bHoldDuck)
		{
			UTIL_ReleaseDuck();
			m_ulStatus |= WPN_FLAG_SHOULD_RUN;
			m_ulStatus |= WPN_FLAG_TRY_UNTIL_DONE;
		}

		return;
	}

	// aim down...first.
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();	// instead of just AimDown() since there maybe other scope type..

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			m_ulStatus |= WPN_FLAG_SHOULD_RUN;
			return;
		}
	}

	if (m_ulStatus & WPN_FLAG_RUN)
		return;

	// allow running interrupt subitem reload.
	if (m_pSubsItem && m_pSubsItem->m_bInReload)
		m_pSubsItem->Pause();

	if (m_flNextFrame > 0 && !m_bInReload)
		return;

	if (g_sLocalState.client.velocity.Length2D() < 50)
		return;

	if (m_bInReload)
		PauseReload();	// not in Melee();

	m_ulStatus |= WPN_FLAG_RUN;
	m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	WeaponAnim(&WPNANIM(RUN_START), 2);

	ResetPlayerSpeed();
	gLeanManager::Reset();
}

void CBaseWeapons::Def_RunStop(void)
{
	if (!(m_ulStatus & WPN_FLAG_RUN))
		return;

	m_ulStatus &= ~WPN_FLAG_RUN;
	
	if (m_flNextFrame > 0 && m_iDisplayingAnim == WPNANIM_NUM(RUN_START))
	{
		// m_flNextFrame means how much time left, save it first, or it will be overrided by WeaponAnim()
		float flRunStartUnplayedRatio = m_flNextFrame / WPNANIM_DUR(RUN_START);

		// get the time we need to wait.
		float flRunStopTimeLeft = WPNANIM_DUR(RUN_STOP) * flRunStartUnplayedRatio;

		// normally play RUN_STOP
		WeaponAnim(&WPNANIM(RUN_STOP), 2);

		// change this var, if RUN_STOP is made by a inversion of RUN_START, this will work pretty well.
		g_flViewEntAnimTime = gEngfuncs.GetClientTime() - flRunStopTimeLeft;

		// type 2 anim CD.
		m_flNextFrame = m_flNextPriAttack = m_flNextSedAttack = m_flNextIdle = flRunStopTimeLeft;
	}
	else
		// if RUN_START is normally played and finished, go normal.
		WeaponAnim(&WPNANIM(RUN_STOP), 2);



	// speed needs to decrease, of couse.
	ResetPlayerSpeed();

	// if this is a HOLD RUN, stop it.
	if (g_bHoldRun)
		UTIL_ReleaseRun();
}

void CBaseWeapons::Jump(void)
{
	if (WPNANIM_NUM(JUMP) && m_iDisplayingAnim != WPNANIM_NUM(JUMP) && !(m_ulStatus & (WPN_FLAG_AIM|WPN_FLAG_RUN)) && !m_bInReload && (!m_pSubsItem || (m_pSubsItem && !m_pSubsItem->m_bInReload)) )
		WeaponAnim(&WPNANIM(JUMP), 2);

	gLeanManager::Reset();
}

void CBaseWeapons::SwitchSwitcher(void)
{
	if (m_pOriginalDB->m_bSingleShoot)
		return;
	
	if (m_sItemData.m_bSingleShoot)
	{
		m_iFireMode = CSMW_FIREMODE_MULTIPLE;
		m_sItemData.m_bSingleShoot = false;
		//UTIL_ShowTextMsg(m_pEntity->v.owner, HUD_PRINTCENTER, "#Switch_To_FullAuto");
		SPK_SOUND("weapons/Switcher1.wav");

		if (WPNANIM_NUM(SELECTOR_A))
			WeaponAnim(&WPNANIM(SELECTOR_A), 2);
	}
	else
	{
		m_iFireMode = CSMW_FIREMODE_SINGLE;
		m_sItemData.m_bSingleShoot = true;
		//UTIL_ShowTextMsg(m_pEntity->v.owner, HUD_PRINTCENTER, "#Switch_To_SemiAuto");
		SPK_SOUND("weapons/Switcher2.wav");

		if (WPNANIM_NUM(SELECTOR_B))
			WeaponAnim(&WPNANIM(SELECTOR_B), 2);
	}
}

void CBaseWeapons::Melee(void)
{
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();
		m_ulStatus |= WPN_FLAG_SHOULD_MELEE;

		if (WPNANIM_NUM(AIM_DOWN) > 0)
			return;
	}
	
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_MELEE;
		return;
	}

	m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	CBaseWeapons *p = g_pWeaponChainRoot;
	while (p)
	{
		// UNDONE: we should make a system to let player choose their melee wpn.
		if (p->GetWeaponClass() == WPN_CLASS_MELEE)
		{
			p->m_ulStatus |= WPN_FLAG_QUICKUSING;
			m_ulStatus |= WPN_FLAG_SKIPHOLSTER;
			SwitchWeapon(p);
			break;
		}

		p = p->m_pNext;
	}
}

void CBaseWeapons::QuickThrow(short iQuickSlot)
{
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();
		m_ulStatus |= WPN_FLAG_SHOULD_QT;
		m_iSavedQuickSlot = iQuickSlot;		// an extra data need to be saved, comparing to SHOULD_MELEE.

		if (WPNANIM_NUM(AIM_DOWN) > 0)
			return;
	}
	
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_QT;
		m_iSavedQuickSlot = iQuickSlot;
		return;
	}

	m_ulStatus &= ~WPN_FLAG_SHOULD_QT;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	CBaseWeapons *p = g_pWeaponChainRoot;
	while (p)
	{
		// UNDONE: we should make a system to let player choose their melee wpn.
		if (p->GetWeaponClass() == WPN_CLASS_HGRENADE)
		{
			// you can repeatly pressing G or Q !!!
			if (((CBaseGrenade *)p)->IsQuickThrow())
			{
				p = p->m_pNext;
				continue;
			}

			// FIXME: so why we need a freaking m_bIsQuickThrow that messes things up?
			p->m_ulStatus |= WPN_FLAG_QUICKUSING;
			
			// assign QT slot. FIXME
			((CBaseGrenade *)p)->m_bitsQTSlot = IN_QUICKTHROW1|IN_QUICKTHROW2;

			// skip holster anim for current weapon.
			m_ulStatus |= WPN_FLAG_SKIPHOLSTER;
			SwitchWeapon(p);
			break;
		}

		p = p->m_pNext;
	}

	// UNDONE: we should make a system to let player choose their quick throw item.
	if (iQuickSlot == 1)
	{
	}
	else if (iQuickSlot == 2)
	{
	}
}

bool CBaseWeapons::InstallAltWeapon( CBaseWeapons *pAnother, bool bBecomeMaster )
{
	if (!pAnother)
		return false;

	m_bAltWeapon	= !bBecomeMaster;
	m_pAltWeapon	= pAnother;

	if (bBecomeMaster)
	{
		SetFunc(m_pfnRunStart,		&CBaseWeapons::Spr_RunStart);
		SetFunc(m_pfnRunStop,		&CBaseWeapons::Spr_RunStop);
		SetFunc(m_pfnItemPreFrame,	&CBaseWeapons::Spr_ItemPreFrame);
		SetFunc(m_pfnItemDeploy,	&CBaseWeapons::Spr_ItemDeploy);
		SetFunc(m_pfnItemPostFrame,	&CBaseWeapons::Spr_ItemPostFrame);
		SetFunc(m_pfnItemHolster,	&CBaseWeapons::Spr_ItemHolster);
	}
	else
	{
		SetFunc(m_pfnRunStart,		&CBaseWeapons::Ifr_RunStart);
		SetFunc(m_pfnRunStop,		&CBaseWeapons::Ifr_RunStop);
		SetFunc(m_pfnItemPreFrame,	&CBaseWeapons::Ifr_ItemPreFrame);
		SetFunc(m_pfnItemDeploy,	&CBaseWeapons::Ifr_ItemDeploy);
		SetFunc(m_pfnItemPostFrame,	&CBaseWeapons::Ifr_ItemPostFrame);
		SetFunc(m_pfnItemHolster,	&CBaseWeapons::Ifr_ItemHolster);
	}

	// common funcs.
	SetFunc(m_pfnWeaponReload,		&CBaseWeapons::SH_WeaponReload);

	return true;
}

void CBaseWeapons::UninstallAltWeapon(void)
{
	m_bAltWeapon	= false;
	m_pAltWeapon	= NULL;

	// set function back to default.
	// if using custom weapon, careful to set.
	SetFunc(m_pfnRunStart,		&CBaseWeapons::Def_RunStart);
	SetFunc(m_pfnRunStop,		&CBaseWeapons::Def_RunStop);
	SetFunc(m_pfnItemPreFrame,	&CBaseWeapons::Def_ItemPreFrame);
	SetFunc(m_pfnItemDeploy,	&CBaseWeapons::Def_ItemDeploy);
	SetFunc(m_pfnItemPostFrame,	&CBaseWeapons::Def_ItemPostFrame);
	SetFunc(m_pfnWeaponReload,	&CBaseWeapons::Def_WeaponReload);
	SetFunc(m_pfnItemHolster,	&CBaseWeapons::Def_ItemHolster);

	// then reset anims.
	SH_ResetAnims();
}

void CBaseWeapons::ScopeIn(void)
{
	if (IS_AIMING)
		return;

	if (IS_RUNNING)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_AIM;
		return;
	}

	m_ulStatus |= WPN_FLAG_AIM;
	m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	if (WPNANIM(AIM_UP).m_i > 0)
		WeaponAnim(&WPNANIM(AIM_UP), 2);

	g_vecGunOfs = GetAimOffset();
	v_bGunOfsSmooth = true;

	m_flNextThink = UTIL_WeaponTimeBase() + max(0.12f, WPNANIM_DUR(AIM_UP));
	SetFunc(m_pfnThink, &CBaseWeapons::ScopeThink);

	SPK_SOUND("weapons/steelsight_in.wav");
}

void CBaseWeapons::ScopeOut(void)
{
	if (!(m_ulStatus & WPN_FLAG_AIM))
		return;

	m_ulStatus &= ~WPN_FLAG_AIM;

	if (WPNANIM(AIM_DOWN).m_i > 0)
		WeaponAnim(&WPNANIM(AIM_DOWN), 2);

	gFovManager::Reset();

	// tell servers current FOV, avoid bugs.
	SU_Begin		(WPN_CMD_FOV);
	SU_WriteInteger	(90);
	SU_End			();

	g_vecGunOfs = Vector();
	v_bGunOfsSmooth = true;
	m_bInScope = false;
	m_iLastZoomFOV = gFovManager::m_flFOV;

	g_pViewModel = IEngineStudio.Mod_ForName(m_sItemData.m_szViewModel, 1);

	SPK_SOUND("weapons/steelsight_out.wav");
}

void CBaseWeapons::ScopeThink(void)
{
	g_cScreenFade.SetAlpha(255, 255);
	g_cScreenFade.SetCurrentColor(0, 0, 0);
	g_cScreenFade.SetTargetColor(0, 0, 0);
	g_cScreenFade.SetFadeSpeed(512);
	g_cScreenFade.Start(CScreenFade::SF_STAY);

	float flFOV = GetAimFOV();
	if (m_iLastZoomFOV > 0)
		flFOV = m_iLastZoomFOV;
	else
		m_iLastZoomFOV = flFOV;

	gFovManager::Set(flFOV);

	// tell servers current FOV, avoid bugs.
	SU_Begin		(WPN_CMD_FOV);
	SU_WriteInteger	(flFOV);
	SU_End			();

	m_bInScope = true;
	g_pViewModel = NULL;

	SetFunc(m_pfnThink, NULL);
}

bool CBaseWeapons::MouseWheel(bool bUp)
{
	if (m_bInScope)
	{
		m_iLastZoomFOV += bUp ? -1 : 1;	// FOV small means zoom larger..

		if (m_iLastZoomFOV < m_sItemData.m_iZoomRange[1])
			m_iLastZoomFOV = m_sItemData.m_iZoomRange[1];
		else if (m_iLastZoomFOV > m_sItemData.m_iZoomRange[0])
			m_iLastZoomFOV = m_sItemData.m_iZoomRange[0];

		gFovManager::Set(m_iLastZoomFOV);

		return MOUSEWHEEL_HANDLED;
	}

	return MOUSEWHEEL_CONTINUE;
}

/*
===================================

Part of Override Functions

===================================
*/
bool CBaseWeapons::CanItemHolster(void)
{
	if (m_ulStatus & WPN_FLAG_SKIPHOLSTER)
	{
		m_ulStatus &= ~WPN_FLAG_SKIPHOLSTER;
		m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;
		return true;
	}
	
	if (m_ulStatus & WPN_FLAG_HOLSTERING && !(m_ulStatus & WPN_FLAG_CAN_HOLSTER))
		return false;

	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();	// cambo anims.

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;
			return false;
		}
	}
	
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;
		return false;
	}

	if (!(m_ulStatus & WPN_FLAG_CAN_HOLSTER))
	{
		m_ulStatus &= ~WPN_FLAG_SHOULD_HOLSTER;
		m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;
		m_ulStatus |= WPN_FLAG_HOLSTERING;
		WeaponAnim(&WPNANIM(HOLSTER), 2);

		if (IsSuperior())
			m_pAltWeapon->Ifr_PlayHolsterAnim();

		return false;
	}

	return true;
}

bool CBaseWeapons::CanItemDropped(void)
{
	if (m_ulStatus & WPN_FLAG_HOLSTERING && !(m_ulStatus & WPN_FLAG_CAN_HOLSTER))
		return false;

	return true;
}

float CBaseWeapons::GetWalkSpeed(void)
{
	float flResult = m_sItemData.m_sWalkSpeed.m_flWalkSpeed;

	if (m_ulStatus & WPN_FLAG_RUN)
		flResult += m_sItemData.m_sWalkSpeed.m_flRunOfs;
	else if (m_ulStatus & WPN_FLAG_AIM)
		flResult += m_sItemData.m_sWalkSpeed.m_flAimOfs;

	return flResult;
}

void CBaseWeapons::OnSpawnPost(void)
{
	m_sItemData		= g_sItemData[m_iItemType];
	m_pOriginalDB	= &g_sItemData[m_iItemType];
	m_iClip			= (m_sItemData.m_pMagDB ? m_sItemData.m_pMagDB->m_iClip : -1);
	m_iChamberClip	= m_sItemData.m_iChamberClip;
	m_iFireMode		= (m_sItemData.m_bSingleShoot ? CSMW_FIREMODE_SINGLE : CSMW_FIREMODE_MULTIPLE);

	// initialize model anims.
	AnimationSet(g_sItemData[m_iItemType].m_sDefaultAnims);

	// FIXME: test only
	for (int i = 0; i < 20; i ++)
		GiveAmmo();

	if (!ItemAddToPlayer())
	{
		ItemKill();
		return;
	}

	// we only need it once.
	HUD_GenerateAccMenu();
}

void CBaseWeapons::PlayShootingAnim(void)
{
	animdb_t *pSelected = nullptr;

	// using random aiming-shooting anim will make player more immersive.
	if (IS_AIMING)
		pSelected = &m_sAnims[RANDOM_LONG(WPN_COMMON_ANIM_AIM_SHOOT, WPN_COMMON_ANIM_AIM_SHOOT_3)];
	else
		pSelected = &WPNANIM(SHOOT);	// default one.

	WeaponAnim(pSelected);
}

void CBaseWeapons::PauseReload(void)
{
	if (m_bInReload)
	{
		m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
		m_ulStatus |= WPN_FLAG_CONTINUE_ANIM;
		PushAnim();	// restore later when reloading.
	}

	m_bInReload = false;
}

int CBaseWeapons::GetAimFOV(void)
{
	if (m_bitsAccessories & ACC_HOLO)
		return m_sItemData.m_sHolo.m_flFOV;
	else if (m_bitsAccessories & ACC_DOT)
		return m_sItemData.m_sRedDot.m_flFOV;
	else if (m_bitsAccessories & ACC_ACOG)
		return m_sItemData.m_sACOG.m_flFOV;
	else if (m_bitsAccessories & ACC_ROUND)
		return m_sItemData.m_sRound.m_flFOV;
	else
		return m_sItemData.m_sSteelSt.m_flFOV;
}

Vector CBaseWeapons::GetAimOffset(void)
{
	if (m_bitsAccessories & ACC_HOLO)
		return m_sItemData.m_sHolo.m_vecOfs;
	else if (m_bitsAccessories & ACC_DOT)
		return m_sItemData.m_sRedDot.m_vecOfs;
	else if (m_bitsAccessories & ACC_ACOG)
		return m_sItemData.m_sACOG.m_vecOfs;
	else if (m_bitsAccessories & ACC_ROUND)
		return m_sItemData.m_sRound.m_vecOfs;
	else
		return m_sItemData.m_sSteelSt.m_vecOfs;
}

bool CBaseWeapons::CheckAttachment(int iAttachment)
{
	// we should grant attachments to weapon which has corresponding database.

	bool bResult = false;

	if (m_sItemData.m_sACOG.m_flFOV >= 10 && iAttachment & ACC_ACOG)
		bResult = true;

	if (m_sItemData.m_sHolo.m_flFOV >= 10 && iAttachment & ACC_HOLO)
		bResult = true;

	if (m_sItemData.m_sRound.m_flFOV >= 10 && iAttachment & ACC_ROUND)
		bResult = true;

	if (m_sItemData.m_sRedDot.m_flFOV >= 10 && iAttachment & ACC_DOT)
		bResult = true;

	return bResult;
}

bool CBaseWeapons::CanWeaponFire(void)
{
	if (IS_RUNNING || m_bInReload || m_flNextPriAttack > 0 || m_flNextFrame > 0 || m_bBlocked)
		return false;

	if (m_sItemData.m_bSingleShoot && !m_bTriggerRel)
		return false;

	if (IsWeaponEmpty())
	{
		gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, m_sItemData.m_szDryFireSound, 0.8, ATTN_NORM, 0, PITCH_NORM);
		m_flNextPriAttack = 0.8;		// play efx not so quick.

		return false;
	}

	return true;
}

bool CBaseWeapons::CheckBlocked(void)
{
	pmtrace_t tr;
	Vector vecMuzzle = GetMuzzleOrigin();
	Vector vecLastMuzzle = Vector(g_pparams.vieworg) + Vector(g_pparams.forward) * m_vecBlockOffset.x + Vector(g_pparams.right) * m_vecBlockOffset.y + Vector(g_pparams.up) * m_vecBlockOffset.z;

	if (m_vecBlockOffset.Length() < 0.1f)
		vecLastMuzzle = vecMuzzle;	// first use, avoid bug.

	//UTIL_TraceLine(g_pparams.vieworg, vecMuzzle, PM_STUDIO_BOX, -1, &tr, m_pPlayer->index, 2);

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
	gEngfuncs.pEventAPI->EV_PlayerTrace( g_pparams.vieworg, vecLastMuzzle, PM_STUDIO_BOX, -1, &tr );

	bool save = m_bBlocked;
	m_bBlocked = !!(tr.fraction < 1);

	if (!save && m_bBlocked)	// a new blocked situation.
	{
		vecMuzzle -= Vector(g_pparams.vieworg);	// become a offset first.
		m_vecBlockOffset.x	= DotProduct(vecMuzzle, g_pparams.forward);
		m_vecBlockOffset.y	= DotProduct(vecMuzzle, g_pparams.right);
		m_vecBlockOffset.z	= DotProduct(vecMuzzle, g_pparams.up);
	}

	return m_bBlocked;
}

/*
===================================

Part of Util Functions

===================================
*/
void CBaseWeapons::SetShell(float flTime)
{
	if (flTime <= 0.0f)	// spawn a shell instantly.
	{
		SpawnShell(m_pPlayer,
				   gEngfuncs.pEventAPI->EV_FindModelIndex(m_sItemData.m_pAmmoDB->m_szShellModel),
				   GetShellOrigin(),
				   m_bUsingSubs ? m_pSubsItem->m_sItemData.m_pAmmoDB->m_iShellSoundType : m_sItemData.m_pAmmoDB->m_iShellSoundType,
				   m_bUsingSubs ? m_pSubsItem->m_sItemData.m_pAmmoDB->m_iShellBody : m_sItemData.m_pAmmoDB->m_iShellBody);

		return;
	}

	g_sFakePlayer.m_flEjectBrass = UTIL_WeaponTimeBase() + flTime;
	g_sFakePlayer.m_pBrassType = m_bUsingSubs ? (ammo_t *)m_pSubsItem->m_sItemData.m_pAmmoDB : (ammo_t *)m_sItemData.m_pAmmoDB;
	g_sFakePlayer.m_iBrassAttachment = GetShellEnum();
}

void CBaseWeapons::OnNewRound(bool bActiveItem)
{
	m_ulStatus |= WPN_FLAG_FIRSTUSE;

	if (m_ulStatus & WPN_FLAG_AIM)
		SecondaryAttack();
	else if (m_ulStatus & WPN_FLAG_RUN)
		RunStop();

	if (m_pSubsItem)
		m_pSubsItem->OnNewRound(bActiveItem);

	m_bInReload		= false;
	m_iChamberClip	= m_sItemData.m_iChamberClip;

	if (m_sItemData.m_pMagDB)
		m_iClip = m_sItemData.m_pMagDB->m_iClip;

	for (int i = 0; i < 3; i ++)
		GiveAmmo();

	if (bActiveItem)
		ItemDeploy();
}

void CBaseItems::KickBack(recdb_t *pRecoil)
{
	// CSMW version need this, since it's using R6S style recoil.
	// no z axis is because we have lean system.
	// UNDONE: I guess it is work okey with DUAL WEAPONS ???
	g_vecFixAngleOfs.x = 0;
	g_vecFixAngleOfs.y = 0;

	// determind database.
	if (!pRecoil)
	{
		if (!(g_sLocalState.client.flags & FL_ONGROUND))
			pRecoil = &(m_sItemData.m_srJumping);
		else if (m_pPlayer->curstate.velocity.Length2D() > 0)
			pRecoil = &(m_sItemData.m_srMoving);
		else if (!(g_sLocalState.client.flags & FL_DUCKING))
			pRecoil = &(m_sItemData.m_srDucking);
		else
			pRecoil = &(m_sItemData.m_srOtherwise);
	}

	float flFront, flSide;
	if (m_iShotsFired == 1)
	{
		flFront	= pRecoil->up_base;
		flSide	= pRecoil->lateral_base;
	}
	else
	{
		flFront	= (m_iShotsFired - 1) * pRecoil->up_modifier + pRecoil->up_base;
		flSide	= (m_iShotsFired - 1) * pRecoil->lateral_modifier + pRecoil->lateral_base;
	}

	g_vecFixAngleOfs.x -= flFront;

	if (g_vecFixAngleOfs.x < -pRecoil->up_max)
		g_vecFixAngleOfs.x = -pRecoil->up_max;

	if (m_bDirection)
	{
		g_vecFixAngleOfs.y += flSide;

		if (g_vecFixAngleOfs.y > pRecoil->lateral_max)
			g_vecFixAngleOfs.y = pRecoil->lateral_max;
	}
	else
	{
		g_vecFixAngleOfs.y -= flSide;

		if (g_vecFixAngleOfs.y < -pRecoil->lateral_max)
			g_vecFixAngleOfs.y = -pRecoil->lateral_max;
	}

	if (!RANDOM_LONG(0, pRecoil->direction_change))
		m_bDirection = !m_bDirection;

	g_vecPunchAngle		= g_vecFixAngleOfs * 0.65f;
	g_vecFixAngleOfs	*= 0.5f;
}

bool CBaseItems::AnimationSet(const animdb_t sSet[WPN_STANDARD_ANIM_COUNTS])
{
	//memcpy(m_sAnims, sizeof(m_sAnims), sSet, sizeof(sSet));
	memcpy(m_sAnims, sSet, sizeof(m_sAnims));
	return true;
}

void CBaseWeapons::UpdateItemStatus(void)
{
	// keeping update sub model status.
	m_iSubModelStatus = GetViewModelSubModelStatus();

	if (m_pSubsItem)
		m_pSubsItem->UpdateItemStatus();
}

bool CBaseWeapons::GiveAmmo(void)
{
	// not each time this gun have a subitem.
	bool result1 = true, result2 = false;

	if (m_pSubsItem)
		result2 = m_pSubsItem->GiveAmmo();

	// TODO: wait for maxium system.
	if (m_sItemData.m_pMagDB)
	{
		g_cMagManager.m_iMagAmount[m_sItemData.m_pMagDB->m_iType] ++;
	}
	else if (m_sItemData.m_pAmmoDB)	// since there is a knife...
	{
		g_cMagManager.m_iAmmoAmount[m_sItemData.m_pAmmoDB->m_iType] += m_sItemData.m_iChamberClip;
	}
	else
		result1 = false;

	return (result1 && result2);
}

void CBaseWeapons::WeaponAnim(animdb_t *p, int iCDType)
{
	if (!p)
		return;

	if (!IsInferior())
	{
		HUD_SendWeaponAnim(p->m_i, m_iSubModelStatus);
		m_iDisplayingAnim = p->m_i;
	}
	else
	{
		g_c2ndVMDL.SetAnim(p->m_i);
		m_iDisplayingAnim = p->m_i;
	}

	switch (iCDType)
	{
		case 0:
			m_flNextIdle = p->m_fd;
			break;

		case 1:	// anim will continue, but you can do whatever you like
			m_flNextFrame = p->m_fe;
			m_flNextIdle = p->m_fd;
			break;

		case 2:	// frame will go on, but you can't attack until it's fully done.
			m_flNextFrame = p->m_fe;
			m_flNextPriAttack = m_flNextSedAttack = m_flNextIdle = p->m_fd;
			break;
	}
}

void CBaseWeapons::PushAnim(void)
{
	if (IsInferior())
	{
		m_sAnimStack.m_flAnimtime	= gEngfuncs.GetClientTime() - g_c2ndVMDL.m_flAnimtime;
		m_sAnimStack.m_flFrame		= g_c2ndVMDL.m_flFrame;
		m_sAnimStack.m_flFramerate	= g_c2ndVMDL.m_flFramerate;
		m_sAnimStack.m_iSequence	= g_c2ndVMDL.m_iSequence;
	}
	else
	{
		m_sAnimStack.m_flAnimtime	= gEngfuncs.GetClientTime() - g_flViewEntAnimTime;
		m_sAnimStack.m_flFrame		= g_pViewEnt->curstate.frame;
		m_sAnimStack.m_flFramerate	= g_pViewEnt->curstate.framerate;
		m_sAnimStack.m_iSequence	= g_pViewEnt->curstate.sequence;
	}

	m_sAnimStack.m_flNextPriAttack	= m_flNextPriAttack;
	m_sAnimStack.m_flNextSedAttack	= m_flNextSedAttack;
	m_sAnimStack.m_flNextIdle		= m_flNextIdle;
	m_sAnimStack.m_flNextFrame		= m_flNextFrame;
	m_sAnimStack.m_flEjectBrass		= g_sFakePlayer.m_flEjectBrass;
	g_sFakePlayer.m_flEjectBrass	= 0;
}

void CBaseWeapons::PopAnim(void)
{
	if (m_sAnimStack.m_iSequence < 0)
		return;

	if (IsInferior())
	{
		g_c2ndVMDL.m_flAnimtime		= gEngfuncs.GetClientTime() - m_sAnimStack.m_flAnimtime;
		g_c2ndVMDL.m_flFrame		= m_sAnimStack.m_flFrame;
		g_c2ndVMDL.m_flFramerate	= m_sAnimStack.m_flFramerate;
		g_c2ndVMDL.m_iSequence		= m_sAnimStack.m_iSequence;
	}
	else
	{
		g_flViewEntAnimTime				= gEngfuncs.GetClientTime() - m_sAnimStack.m_flAnimtime;
		g_pViewEnt->curstate.frame		= m_sAnimStack.m_flFrame;	// LUNA: seems change this var doesn't effect anything at all.
		g_pViewEnt->curstate.framerate	= m_sAnimStack.m_flFramerate;
		g_pViewEnt->curstate.sequence	= m_sAnimStack.m_iSequence;
	}

	m_flNextPriAttack	= m_sAnimStack.m_flNextPriAttack;
	m_flNextSedAttack	= m_sAnimStack.m_flNextSedAttack;
	m_flNextIdle		= m_sAnimStack.m_flNextIdle;
	m_flNextFrame		= m_sAnimStack.m_flNextFrame;

	// additional.
	m_iDisplayingAnim				= m_sAnimStack.m_iSequence;
	g_sFakePlayer.m_flEjectBrass	= m_sAnimStack.m_flEjectBrass;

	memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
	m_sAnimStack.m_iSequence = -1;	// mark as should not be Pop().
}

Vector CBaseWeapons::GetMuzzleOrigin(void)
{
	if (m_bInScope)
		return Vector(g_pparams.vieworg) + Vector(g_pparams.forward) * 20.0f - Vector(g_pparams.up) * 5.0f;
	else if (!IsInferior())
	{
		int iEnum = GetMuzzleEnum();

		if (iEnum < 4)
			return g_pViewEnt->attachment[iEnum];
		else
			return g_vecViewModelAttmt[iEnum];
	}
	else
		return g_c2ndVMDL.m_vecAttachments[GetMuzzleEnum()];
}

Vector CBaseWeapons::GetShellOrigin(void)
{
	if (!IsInferior())
	{
		int iEnum = GetShellEnum();

		if (iEnum < 4)
			return g_pViewEnt->attachment[iEnum];
		else
			return g_vecViewModelAttmt[iEnum];
	}
	else
		return g_c2ndVMDL.m_vecAttachments[GetShellEnum()];
}

void CBaseWeapons::BindDataToHud(void)
{
	// clear it first, avoid some break down.
	// only do so if you are SUPERIOR.
	if (IsSuperior() || !IsDoubleHolding())
	{
		memset(&gStdWpnHud::m_sPriWpn, NULL, sizeof(gStdWpnHud::m_sPriWpn));
		memset(&gStdWpnHud::m_sSedWpn, NULL, sizeof(gStdWpnHud::m_sSedWpn));
	}

	// determind which DB.
	wpnfxdb_t *pHud = &gStdWpnHud::m_sPriWpn;
	if (IsInferior())
		pHud = &gStdWpnHud::m_sSedWpn;

	// link def hud database.
	pHud->m_bDisplay			= true;
	pHud->m_pbitsFlags			= &m_ulStatus;
	pHud->m_piBpNum				= &(m_sItemData.m_pMagDB ? g_cMagManager.m_iMagAmount[m_sItemData.m_pMagDB->m_iType] : g_cMagManager.m_iAmmoAmount[m_sItemData.m_pAmmoDB->m_iType]);
	pHud->m_piBpMax				= NULL;
	pHud->m_piClip				= m_sItemData.m_pMagDB ? &m_iClip : &m_iChamberClip;
	pHud->m_piClipMax			= m_sItemData.m_pMagDB ? &m_sItemData.m_pMagDB->m_iClip : &m_sItemData.m_iChamberClip;
	pHud->m_piFireMode			= &m_iFireMode;
	pHud->m_piszFireModeIcons	= m_sItemData.m_pAmmoDB->m_iIdAmmoIcons;
	pHud->m_piWpnDxt			= &m_sItemData.m_iIdWeaponIcon;
	pHud->m_pszBpName			= m_sItemData.m_pAmmoDB->m_wszEndoName;
	pHud->m_pszEndoName			= m_sItemData.m_wszEndoName;

	// update def hud database.
	gStdWpnHud::UpdateWpnName();
}

/*
===================================

Part of Basic Logic Functions

===================================
*/
bool CBaseWeapons::Def_ItemAddToPlayer(void)
{
	// TODO: Slot judgement

	if (CanDoubleHold())	// avoid undoublable weapon mass up.
	{
		wpn_c *pWeapon = g_pWeaponChainRoot;

		while (pWeapon)
		{
			// find a weapon can be dualing, and has no partner
			if (pWeapon == this || !pWeapon->CanDoubleHold() || pWeapon->IsDoubleHolding())
				pWeapon = pWeapon->m_pNext;
			else
				break;
		}

		if (UTIL_UserHasWpn(m_iItemType, this))
		{
			if (!pWeapon)
				return false;
			else
				SH_MakeAlts(pWeapon, this);
		}
		else if (pWeapon)	// has no same kind of weapon, and got a partner.
		{
			SH_MakeAlts(pWeapon, this);
		}

		// otherwise, add to player normally.
	}
	else if (UTIL_UserHasWpn(m_iItemType, this))
		return false;

	SPK_SOUND("items/gunpickup2.wav");

	m_ulStatus |= WPN_FLAG_FIRSTUSE;

	// tell server we have it.
	SU_Begin		(WPN_CMD_ADD);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	return true;
}

void CBaseWeapons::Def_ItemPreFrame(void)
{
	// think first.
	if (m_flNextThink && m_flNextThink <= UTIL_WeaponTimeBase())
		Think();

	// we need an extra m_flAltFrameTime
	m_flNextFrame		= max(m_flNextFrame - g_pparams.frametime, 0.0f);

	//it seems that these value won't sub itself this time...
	m_flNextPriAttack	= max(m_flNextPriAttack - g_pparams.frametime, 0.0f);
	m_flNextSedAttack	= max(m_flNextSedAttack - g_pparams.frametime, 0.0f);
	m_flNextIdle		= max(m_flNextIdle - g_pparams.frametime, 0.0f);

	//if frame times up, call ItemPostFrame...
	if ( m_flNextFrame <= 0.0f &&
		(!m_pSubsItem || (m_pSubsItem && !m_pSubsItem->IsTakeOver())) )
		ItemPostFrame();

	// prevent things going south...
	if (m_ulStatus & WPN_FLAG_MARK_FOR_DEL)
		return;

	if (GetWalkSpeed() > 0.0f)
		HUD_SetMaxSpeed(GetWalkSpeed());

	// run think, you cant ducking & running.
	if (CL_GetButtonBits() & IN_RUN)
		RunStart();
	else
		RunStop();

	// update vmdl sub model
	UpdateItemStatus();
	*g_pViewModelSubModel = m_iSubModelStatus;

	if (m_pSubsItem)
	{
		m_bUsingSubs = true;
		m_pSubsItem->ItemPreFrame();
		m_bUsingSubs = false;
	}
}

void CBaseWeapons::Def_ItemDeploy(void)
{
	// TODO: Send data back to every client. Use to draw player 3rd model.
	SU_Begin		(WPN_CMD_DEPLOY);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	// make item ready to use
	m_iShotsFired = 0;
	
	// set player effect
	g_pViewModel = IEngineStudio.Mod_ForName(m_sItemData.m_szViewModel, 1);
	WeaponAnim((m_ulStatus & WPN_FLAG_FIRSTUSE) ? &WPNANIM(DRAW_FIRST) : &WPNANIM(DRAW), 2);
	ResetPlayerSpeed();

	// remove flags
	m_ulStatus &= ~WPN_FLAG_FIRSTUSE;
	m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;
	m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;
	m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;
	m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;
	m_ulStatus &= ~WPN_FLAG_SHOULD_HOLSTER;

	// Update gStdWpnHud.
	BindDataToHud();

	if (m_pSubsItem)
		m_pSubsItem->ItemDeploy();
}

void CBaseWeapons::Def_ItemPostFrame(void)
{
	if (m_ulStatus & WPN_FLAG_HOLSTERING)
	{
		m_ulStatus |= WPN_FLAG_CAN_HOLSTER;
		SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_HOLSTER)
	{
		if (!m_pSwitchTo)
			SwitchWeapon(UTIL_SortItemsBySlot());
		else if (CanItemHolster())
			SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_USE_SUB && !(m_ulStatus & WPN_FLAG_RUN))
	{
		// not support WPN_FLAG_TRY_UNTIL_DONE, since no function to cancel the flag.
		m_ulStatus &= ~WPN_FLAG_SHOULD_USE_SUB;

		if (m_pSubsItem)
		{
			m_bUsingSubs = true;
			m_pSubsItem->Use();
			m_bUsingSubs = false;
		}
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RELOAD && !(m_ulStatus & WPN_FLAG_RUN))	// I have no other way to achieve it...
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;

		WeaponReload();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_MELEE)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;

		Melee();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_QT)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_QT;

		QuickThrow(m_iSavedQuickSlot);
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RUN)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;

		RunStart();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_AIM)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;

		AimUp();
		return;
	}

	if (m_flNextBlockCheck < UTIL_WeaponTimeBase())
	{
		CheckBlocked();
		m_flNextBlockCheck = UTIL_WeaponTimeBase() + 0.08;

		if ( m_bBlocked && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_UP)
			&& ( !WPNANIM_NUM(BLOCK_IDLE) || (WPNANIM_NUM(BLOCK_IDLE) && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_IDLE)) )	/* only check BLOCK_IDLE when there is one. */
			&& ( !IS_RUNNING && !IS_AIMING )	/* if playing RUN_IDLE or AIM_IDLE, don't bother. */
			)
		{
			WeaponAnim(&WPNANIM(BLOCK_UP), 2);
		}
		else if (!m_bBlocked && m_iDisplayingAnim == WPNANIM_NUM(BLOCK_UP))
		{
			WeaponAnim(&WPNANIM(BLOCK_DOWN), 2);
		}
	}

	if (m_bInReload && m_sItemData.m_pMagDB)
	{
		// there is an anim that rechamber the first bullet into chamber...
		if (m_iClip <= 0 && m_iChamberClip <= 0)
		{
			m_iClip			= m_sItemData.m_pMagDB->m_iClip - m_sItemData.m_iChamberClip;
			m_iChamberClip	= m_sItemData.m_iChamberClip;
		}
		else
			m_iClip	= m_sItemData.m_pMagDB->m_iClip;

		BP_MAGAZINE		= max(BP_MAGAZINE - 1, 0);
		m_bInReload		= false;
		m_flLastReload	= -1;
	}
	else if (m_bInReload)	// which means chamber-mag weapons.
	{
		// we need to avoid the 29->30 rounds' bug.
		m_iChamberClip = 0;

		// here from HLSDK
		int j = min(m_sItemData.m_iChamberClip - m_iChamberClip, int(AMMUNITION) );
		
		m_iChamberClip += j;
		AMMUNITION -= j;
		m_bInReload = false;
		m_flLastReload	= -1;

		// no more bounce ammo, since this time it's all in chamber.
	}

	int bitsButton = CL_GetButtonBits();
	if (!(bitsButton & IN_ATTACK) && m_iShotsFired > 0 && UTIL_WeaponTimeBase() > m_flDecreaseShotsFired)
	{
		m_bTriggerRel = true;
		m_iShotsFired --;
		m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + (m_bDelayFire ? 0.4f : 0.0225f);

		if (m_bDelayFire)
			m_bDelayFire = false;
	}
	else if (!(bitsButton & IN_ATTACK) )
		m_bTriggerRel = true;

	if (!(bitsButton & IN_ATTACK2) )
		m_bAimCoolDown = true;
	
	if (bitsButton & IN_ATTACK && CanWeaponFire())
		PrimaryAttack();
	else if (bitsButton & IN_ATTACK && IS_RUNNING)	// required by avJager.
		RunStop();
	if (m_bAimCoolDown && bitsButton & IN_ATTACK2 && m_flNextSedAttack <= 0.0f)
		SecondaryAttack();
	else if (bitsButton & IN_RELOAD)
		WeaponReload();
	else if (m_flNextIdle <= 0.0f)
		WeaponIdle();
}

void CBaseWeapons::Def_PrimaryAttack(void)
{
	PlayShootingAnim();

	/*MAKE_VECTORS(pPlayer->v.v_angle + pPlayer->v.punchangle);
	Vector vecSrc = pPlayer->v.origin + pPlayer->v.view_ofs;

	// lean effects here
	if (g_iPlayerLean[ENTINDEX(pPlayer)] == 1)
		vecSrc += gpGlobals->v_right * g_sRules.m_vecLeanOfs.x + gpGlobals->v_forward * g_sRules.m_vecLeanOfs.y + gpGlobals->v_up * g_sRules.m_vecLeanOfs.z;
	else if (g_iPlayerLean[ENTINDEX(pPlayer)] == -1)
		vecSrc -= gpGlobals->v_right * g_sRules.m_vecLeanOfs.x + gpGlobals->v_forward * g_sRules.m_vecLeanOfs.y + gpGlobals->v_up * g_sRules.m_vecLeanOfs.z;

	// like original CS, we will calc all effects at clinet.
	Vector vecSpread = Vector();
	if (!m_sItemData.m_bMultiFired)
		vecSpread = FireBullets3(vecSrc, gpGlobals->v_forward, m_sItemData.m_flSpreadX, m_sItemData.m_flMaxReachedDistance, m_sItemData.m_iMaxThrough, m_sItemData.m_iAmmoType, m_sItemData.m_iBaseDamage, m_sItemData.m_flRangeModifier, &pPlayer->v, m_sItemData.m_bSingleShoot, 0);
	else
		FireBullets(m_sItemData.m_iMultiFiredBullets, vecSrc, gpGlobals->v_forward, Vector(m_sItemData.m_flSpreadX, m_sItemData.m_flSpreadY, 0.0f), m_sItemData.m_flMaxReachedDistance, m_sItemData.m_iAmmoType, 0, m_sItemData.m_iBaseDamage, &pPlayer->v);
*/
	KickBack();
/*
	// after deal with aim mode, we can send recoil message to clinet.
	if (MF_IsPlayerBot(ENTINDEX(pPlayer)))
		pPlayer->v.v_angle += pPlayer->v.vuser1;
	else
	{
		MESSAGE_BEGIN(MSG_ONE, g_msgSetAngles, NULL, m_pEntity->v.owner);
		WRITE_LONG(m_pEntity->v.owner->v.vuser1.x * 100000000);
		WRITE_LONG(m_pEntity->v.owner->v.vuser1.y * 100000000);
		WRITE_LONG(m_pEntity->v.owner->v.vuser1.z * 100000000);
		MESSAGE_END();
	}*/

	// mag ammo first, then chamber clip.
	if (m_iClip > 0)
		m_iClip --;
	else
		m_iChamberClip --;

	// refill chamber, if not normal gun(e.g. KSG12), set your self.
	if (m_iChamberClip < m_sItemData.m_iChamberClip && m_iClip > 0)
	{
		int j = min(m_sItemData.m_iChamberClip - m_iChamberClip, m_iClip);
		
		m_iChamberClip	+= j;
		m_iClip			-= j;
	}
	
	m_flNextPriAttack = m_sItemData.m_flNextPriAttack;
	m_iShotsFired ++;
	m_bTriggerRel = false;
	m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + 0.4f;
	m_bDelayFire = true;

	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(GetMuzzleOrigin());
	SU_WriteVector	(g_pparams.viewangles);
	SU_WriteFloat	(DotProduct(Vector(g_pparams.vieworg) - GetMuzzleOrigin(), g_pparams.up));	// aiming baseline

	// mark silencer shoot for server.
	if (m_bitsAccessories & ACC_SILENCER)
		SU_WriteInteger(TRUE);	// ARGV: 9

	SU_End			();

	// local efx.
	if (!(GetWeaponClass() & WPN_CLASS_RECHAMBER))
		SetShell();

	DrawLight(GetMuzzleOrigin(), m_sItemData.m_iGunFlash * (m_bitsAccessories & ACC_SILENCER ? 0.5f : 1.0f));
	DrawGunSmoke();

	// if a weapon assigned an angle and a range: consider it's a shotgun.
	if (m_sItemData.m_pAmmoDB && m_sItemData.m_iEffectiveAngle > 0 && m_sItemData.m_iEffectiveRange > 0)
	{
		Vector vecForward, vecRight, vecUp, vecDir, vecEnd;
		gEngfuncs.pfnAngleVectors(g_pparams.viewangles, vecForward, vecRight, vecUp);

		Vector vecSpread(abs(sin(Math::DegreeToRadian(m_sItemData.m_iEffectiveAngle) / 2.0f)));

		int iCount = RANDOM_LONG(12, 20);
		pmtrace_t tr;

		gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
		gEngfuncs.pEventAPI->EV_PushPMStates();
		gEngfuncs.pEventAPI->EV_SetSolidPlayers ( m_pPlayer->index - 1 );
		gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
		
		for (int i = 1; i <= iCount; i ++)
		{
			float x, y, z;
			do
			{
				x = RANDOM_FLOAT(-0.5, 0.5) + RANDOM_FLOAT(-0.5, 0.5);
				y = RANDOM_FLOAT(-0.5, 0.5) + RANDOM_FLOAT(-0.5, 0.5);
				z = x * x + y * y;

			} while (z > 1);

			vecDir = vecForward + x * vecSpread.x * vecRight + y * vecSpread.y * vecUp;
			vecEnd = GetMuzzleOrigin() + vecDir.Normalize() * m_sItemData.m_iEffectiveRange;

			gEngfuncs.pEventAPI->EV_PlayerTrace( GetMuzzleOrigin(), vecEnd, PM_STUDIO_BOX, -1, &tr );
			gEngfuncs.pEfxAPI->R_TracerEffect(GetMuzzleOrigin(), tr.endpos);
		}

		gEngfuncs.pEventAPI->EV_PopPMStates();

		// only draw bullet efx for last time.
		vecEnd = GetMuzzleOrigin() + vecForward * m_sItemData.m_iEffectiveRange;	// draw at center.
		DrawGunShot(GetMuzzleOrigin(), vecEnd, m_sItemData.m_pAmmoDB->m_iType);
	}

	// UNDONE: 3rd personal gunfire efx.
}

void CBaseWeapons::Def_SteelSight(void)
{
	if (IS_AIMING)
		AimDown();
	else
		AimUp();

	// special cool down
	m_bAimCoolDown = false;
	m_flNextSedAttack = m_sItemData.m_flNextSedAttack;
}

void CBaseWeapons::Def_Scope(void)
{
	if (IS_AIMING)
		ScopeOut();
	else
		ScopeIn();

	// special cool down
	m_bAimCoolDown = false;
	m_flNextSedAttack = m_sItemData.m_flNextSedAttack;
}

void CBaseWeapons::Def_WeaponIdle(void)
{
	//m_sItemData.m_sAnims[WPN_COMMON_ANIM_RUN_LOOP]
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		// fix when player hit a wall of even release W button, but still playing RUN anim...
		if (g_sLocalState.client.velocity.Length2D() < GetWalkSpeed() * 0.85f)
			RunStop();
		else if (m_iDisplayingAnim != WPNANIM_NUM(RUN_LOOP))
			WeaponAnim(&WPNANIM(RUN_LOOP), -1);
	}
	/*else if (m_iClip <= 0 && m_iClip != -1 && AMMUNITION)
		WeaponReload();*/
	else if (IS_AIMING)
	{
		if (m_iDisplayingAnim != WPNANIM_NUM(AIM_IDLE))
			WeaponAnim(&WPNANIM(AIM_IDLE), -1);
	}
	/*else if (m_pEntity->v.owner->v.velocity.Length2D() > GetWalkSpeed() * 0.5f)
	{
		if (m_iDisplayingAnim != m_sCSMWItemData.m_sWalk.m_i)
			SendWeaponAnim(m_pEntity->v.owner, m_sCSMWItemData.m_sWalk.m_i);
	}*/
	else if (m_bBlocked)	// if it's exist, it can't be normal idle anim.
	{
		if (WPNANIM_NUM(BLOCK_IDLE) && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_IDLE))
			WeaponAnim(&WPNANIM(BLOCK_IDLE), -1);
	}
	else if (m_iDisplayingAnim != WPNANIM_NUM(IDLE))
		WeaponAnim(&WPNANIM(IDLE), -1);
	
	if (m_pSubsItem)
		m_pSubsItem->WeaponIdle();
}

void CBaseWeapons::Def_WeaponReload(void)
{
	if ( (m_sItemData.m_pMagDB && (m_iClip >= m_sItemData.m_pMagDB->m_iClip || m_sItemData.m_pMagDB->m_iClip < 0 || BP_MAGAZINE <= 0) )			/* condiction for the mag function presented. */
		 || (!m_sItemData.m_pMagDB && (m_iChamberClip >= m_sItemData.m_iChamberClip || m_sItemData.m_iChamberClip < 0 || AMMUNITION <= 0)) )	/* condiction for non-mag weapon. */
	{
		return;
	}

	// if aim down anim presented, you cant skip it or play it at the same time.
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			// come back later plz.
			m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
			return;
		}
	}

	// running is defnately a fully anim.
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
		return;
	}

	m_iShotsFired	= 0;
	m_bInReload		= true;
	m_flLastReload	= gEngfuncs.GetClientTime();

	WeaponAnim((m_iChamberClip <= 0) ? &WPNANIM(RELOAD_EMPTY) : &WPNANIM(RELOAD), 2);

	// it should be came from something interrupt reloading??
	if (m_ulStatus & WPN_FLAG_CONTINUE_ANIM)
	{
		PopAnim();
		m_ulStatus &= ~WPN_FLAG_CONTINUE_ANIM;
	}

	m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	SU_Begin		(WPN_CMD_RELOAD);
	SU_WriteInteger	(m_iItemType);
	SU_End			();
}

void CBaseWeapons::Def_ItemHolster(void)
{
	// TODO: sv: weaponmodel = 0
	SU_Begin		(WPN_CMD_HOLSTER);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	g_pViewModel = NULL;
	gFovManager::Reset();

	m_bInReload			= false;
	m_iDisplayingAnim	= -1;
	m_pSwitchTo			= NULL;
	m_bInScope			= false;

	// remove the effect of SetSehll();
	g_sFakePlayer.m_flEjectBrass		= 0;
	g_sFakePlayer.m_pBrassType			= NULL;
	g_sFakePlayer.m_iBrassAttachment	= 0;

	// avoid some bug..
	m_ulStatus &= ~WPN_FLAG_CONTINUE_ANIM;
	memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
	m_sAnimStack.m_iSequence = -1;

	// close menu.
	if (g_pCurrentMenu == &m_sAccMenu)
		m_sAccMenu.m_bShouldDraw = false;
	
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;
			return;
		}
	}

	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;

		return;
	}

	m_ulStatus &= ~WPN_FLAG_HOLSTERING;
	m_ulStatus &= ~WPN_FLAG_CAN_HOLSTER;
	m_ulStatus &= ~WPN_FLAG_SHOULD_HOLSTER;

	if (m_pSubsItem)
		m_pSubsItem->ItemHolster();
}

void CBaseWeapons::Def_ItemDropped(void)
{
	SU_Begin		(WPN_CMD_DROP);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	bool bSwitch = false;

	if (g_pPlayerActivityItem == this)
		bSwitch = true;

	if (m_pSubsItem)
		m_pSubsItem->ItemDropped();

	delete this;

	// move to the best weapon currently (slot1 > slot2 > slot3 > ...)
	if (bSwitch)
		SwitchWeapon(UTIL_SortItemsBySlot());
}

void CBaseWeapons::Def_ItemKill(void)
{
	SU_Begin		(WPN_CMD_KILL);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	m_ulStatus	|= WPN_FLAG_MARK_FOR_DEL;	// prevent further damage.

	// killed for subitem put in DECONSTRUCT function.

	delete this;
}

/*
===================================

Part of Default Single-Handed Weapons' Function

===================================
*/
void CBaseWeapons::SH_MakeAlts(wpn_c * pSuperior, wpn_c * pInferior)
{
	// function reset.
	pSuperior->InstallAltWeapon(pInferior, true);
	pInferior->InstallAltWeapon(pSuperior, false);

	pSuperior->SH_ResetAnims();
	pInferior->SH_ResetAnims();

	// redeploy to avoid strange things.
	if (pSuperior == g_pPlayerActivityItem)
		pSuperior->ItemDeploy();
}

void CBaseWeapons::SH_ResetAnims(void)
{
	AnimationSet(IsDoubleHolding() ? m_sItemData.m_sSingleHandAnims : m_sItemData.m_sDefaultAnims);
}

void CBaseWeapons::SH_WeaponReload(void)
{
	float flThisRatio = 0;
	if (m_sItemData.m_pMagDB)
		flThisRatio = float(m_iClip + m_iChamberClip) / float(m_sItemData.m_pMagDB->m_iClip + m_sItemData.m_iChamberClip);
	else
		flThisRatio = float(m_iChamberClip) / float(m_sItemData.m_iChamberClip);

	float flPartnerRatio = 0;
	if (m_pAltWeapon->m_sItemData.m_pMagDB)
		flPartnerRatio = float(m_pAltWeapon->m_iClip + m_pAltWeapon->m_iChamberClip) / float(m_pAltWeapon->m_sItemData.m_pMagDB->m_iClip + m_pAltWeapon->m_sItemData.m_iChamberClip);
	else
		flPartnerRatio = float(m_pAltWeapon->m_iChamberClip) / float(m_pAltWeapon->m_sItemData.m_iChamberClip);

	if (flThisRatio > flPartnerRatio)
	{
		if (m_pAltWeapon->m_bInReload && (gEngfuncs.GetClientTime() - m_pAltWeapon->m_flLastReload) > 0.25f)	// have a cool down of 0.25 second.
			goto LAB_SH_GO_RELOAD;
		else
			return;
	}

LAB_SH_GO_RELOAD:
	Def_WeaponReload();
}

void CBaseWeapons::Spr_RunStart(void)
{
	Def_RunStart();

	if (IS_RUNNING)
		m_pAltWeapon->RunStart();
}

void CBaseWeapons::Spr_RunStop(void)
{
	Def_RunStop();

	m_pAltWeapon->RunStop();
}

void CBaseWeapons::Spr_ItemPreFrame(void)
{
	Def_ItemPreFrame();

	m_pAltWeapon->ItemPreFrame();
}

void CBaseWeapons::Spr_ItemDeploy(void)
{
	Def_ItemDeploy();

	m_pAltWeapon->ItemDeploy();
}

void CBaseWeapons::Spr_ItemPostFrame(void)
{
	if (m_ulStatus & WPN_FLAG_HOLSTERING)
	{
		m_ulStatus |= WPN_FLAG_CAN_HOLSTER;
		SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_HOLSTER)
	{
		if (!m_pSwitchTo)
			SwitchWeapon(UTIL_SortItemsBySlot());
		else if (CanItemHolster())
			SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_USE_SUB && !(m_ulStatus & WPN_FLAG_RUN))
	{
		// not support WPN_FLAG_TRY_UNTIL_DONE, since no function to cancel the flag.
		m_ulStatus &= ~WPN_FLAG_SHOULD_USE_SUB;

		if (m_pSubsItem)
		{
			m_bUsingSubs = true;
			m_pSubsItem->Use();
			m_bUsingSubs = false;
		}
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RELOAD && !(m_ulStatus & WPN_FLAG_RUN))	// I have no other way to achieve it...
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;

		WeaponReload();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_MELEE)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;

		Melee();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_QT)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_QT;

		QuickThrow(m_iSavedQuickSlot);
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RUN)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;

		RunStart();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_AIM)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;

		AimUp();
		return;
	}

	if (m_flNextBlockCheck < UTIL_WeaponTimeBase())
	{
		CheckBlocked();
		m_flNextBlockCheck = UTIL_WeaponTimeBase() + 0.08;

		if ( m_bBlocked && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_UP)
			&& ( !WPNANIM_NUM(BLOCK_IDLE) || (WPNANIM_NUM(BLOCK_IDLE) && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_IDLE)) )	/* only check BLOCK_IDLE when there is one. */
			&& ( !IS_RUNNING && !IS_AIMING )	/* if playing RUN_IDLE or AIM_IDLE, don't bother. */
			)
		{
			WeaponAnim(&WPNANIM(BLOCK_UP), 2);
		}
		else if (!m_bBlocked && m_iDisplayingAnim == WPNANIM_NUM(BLOCK_UP))
		{
			WeaponAnim(&WPNANIM(BLOCK_DOWN), 2);
		}
	}

	if (m_bInReload && m_sItemData.m_pMagDB)
	{
		// there is an anim that rechamber the first bullet into chamber...
		if (m_iClip <= 0 && m_iChamberClip <= 0)
		{
			m_iClip			= m_sItemData.m_pMagDB->m_iClip - m_sItemData.m_iChamberClip;
			m_iChamberClip	= m_sItemData.m_iChamberClip;
		}
		else
			m_iClip	= m_sItemData.m_pMagDB->m_iClip;

		BP_MAGAZINE	= max(BP_MAGAZINE - 1, 0);
		m_bInReload	= false;
	}
	else if (m_bInReload)	// which means chamber-mag weapons.
	{
		// we need to avoid the 29->30 rounds' bug.
		m_iChamberClip = 0;

		// here from HLSDK
		int j = min(m_sItemData.m_iChamberClip - m_iChamberClip, int(AMMUNITION) );
		
		m_iChamberClip += j;
		AMMUNITION -= j;
		m_bInReload = false;

		// no more bounce ammo, since this time it's all in chamber.
	}

	int bitsButton = CL_GetButtonBits();
	if (!(bitsButton & IN_ATTACK2) && m_iShotsFired > 0 && UTIL_WeaponTimeBase() > m_flDecreaseShotsFired)
	{
		m_bTriggerRel = true;
		m_iShotsFired --;
		m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + (m_bDelayFire ? 0.4f : 0.0225f);

		if (m_bDelayFire)
			m_bDelayFire = false;
	}
	else if (!(bitsButton & IN_ATTACK2) )
		m_bTriggerRel = true;
	
	if (bitsButton & IN_ATTACK2 && CanWeaponFire())
		PrimaryAttack();

	// IN_ATTACK occupy by INFERIOR.

	else if (bitsButton & IN_RELOAD)
		WeaponReload();
	else if (m_flNextIdle <= 0.0f)
		WeaponIdle();
}

void CBaseWeapons::Spr_ItemHolster(void)
{
	Def_ItemHolster();

	m_pAltWeapon->ItemHolster();
}

void CBaseWeapons::Ifr_RunStart(void)
{
	if (IS_RUNNING)
		return;

	if (m_bInReload)
		PauseReload();	// PUT IT BEFORE ANY WeaponAnim()!!!!

	// running judgement is already done in Spr_RunStop(), we dont need to do that again.
	// just simply play the anims
	WeaponAnim(&WPNANIM(RUN_START), 2);

	m_ulStatus |= WPN_FLAG_RUN;
	m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;
}

void CBaseWeapons::Ifr_RunStop(void)
{
	// this is means this is a called require to stop running.
	if (m_pAltWeapon->m_ulStatus & WPN_FLAG_RUN)
	{
		m_pAltWeapon->RunStop();
		return;
	}

	if (!(m_ulStatus & WPN_FLAG_RUN))
		return;

	m_ulStatus &= ~WPN_FLAG_RUN;

	// same reason as Ifr_RunStart()
	// code copied from Def_RunStart()
	// since it's inferior weapon, we should use something else instead of m_iDisplayingAnim
	if (m_flNextFrame > 0 && m_iDisplayingAnim == WPNANIM_NUM(RUN_START))
	{
		// m_flNextFrame means how much time left, save it first, or it will be overrided by WeaponAnim()
		float flRunStartUnplayedRatio = m_flNextFrame / WPNANIM_DUR(RUN_START);

		// get the time we need to wait.
		float flRunStopTimeLeft = WPNANIM_DUR(RUN_STOP) * flRunStartUnplayedRatio;

		// normally play RUN_STOP
		WeaponAnim(&WPNANIM(RUN_STOP), 2);

		// in inferior weapon, use this var instead. if RUN_STOP is made by a inversion of RUN_START, this will work pretty well.
		g_c2ndVMDL.m_flAnimtime = gEngfuncs.GetClientTime() - flRunStopTimeLeft;

		// type 2 anim CD.
		m_flNextFrame = m_flNextPriAttack = m_flNextSedAttack = m_flNextIdle = flRunStopTimeLeft;
	}
	else
		// if RUN_START is normally played and finished, go normal.
		WeaponAnim(&WPNANIM(RUN_STOP), 2);
}

void CBaseWeapons::Ifr_PlayHolsterAnim(void)
{
	// inferior weapon cant refuse holstering.
	WeaponAnim(&WPNANIM(HOLSTER), 2);

	// make sure inferior weapon awaits.
	// if we don't elongate the time, WeaponIdle() will automatically play idle anim again, fuck.
	m_flNextFrame = max(WPNANIM_DUR(HOLSTER), m_pAltWeapon->m_sAnims[WPN_COMMON_ANIM_HOLSTER].m_fd);
}

void CBaseWeapons::Ifr_ItemPreFrame(void)
{
	// think first.
	if (m_flNextThink && m_flNextThink <= UTIL_WeaponTimeBase())
		Think();

	// we need an extra m_flAltFrameTime
	m_flNextFrame		= max(m_flNextFrame - g_pparams.frametime, 0.0f);

	//it seems that these value won't sub itself this time...
	m_flNextPriAttack	= max(m_flNextPriAttack - g_pparams.frametime, 0.0f);
	m_flNextSedAttack	= max(m_flNextSedAttack - g_pparams.frametime, 0.0f);
	m_flNextIdle		= max(m_flNextIdle - g_pparams.frametime, 0.0f);

	//if frame times up, call ItemPostFrame...
	if (m_flNextFrame <= 0.0f)
		ItemPostFrame();

	// walk speed controled by SUPERIOR.

	// run controlled by SUPERIOR.

	// update vmdl sub model. since there is a pointer in g_c2ndVMDL, dont need to assign the value.
	UpdateItemStatus();
}

void CBaseWeapons::Ifr_ItemDeploy(void)
{
	// no more up-stream.

	// make item ready to use
	m_iShotsFired = 0;
	
	// set 2nd vmdl (inferior)
	g_c2ndVMDL.m_bVisible	= true;
	g_c2ndVMDL.m_bReflect	= !m_sItemData.m_bReverseVMDL;
	g_c2ndVMDL.m_piBody		= &m_iSubModelStatus;
	g_c2ndVMDL.m_vecOfs		= m_sItemData.m_vecSHOFS;
	g_c2ndVMDL.SetModel(m_sItemData.m_szViewModel);

	// play anim.
	WeaponAnim((m_ulStatus & WPN_FLAG_FIRSTUSE) ? &WPNANIM(DRAW_FIRST) : &WPNANIM(DRAW), 2);

	// remove flags
	m_ulStatus &= ~WPN_FLAG_FIRSTUSE;
	m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;
	m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;
	m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;
	m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;
	m_ulStatus &= ~WPN_FLAG_SHOULD_HOLSTER;

	// Update gStdWpnHud.
	BindDataToHud();
}

void CBaseWeapons::Ifr_ItemPostFrame(void)
{
	if (m_ulStatus & WPN_FLAG_SHOULD_RELOAD && !(m_ulStatus & WPN_FLAG_RUN))	// I have no other way to achieve it...
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;

		WeaponReload();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_MELEE)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;

		Melee();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_QT)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_QT;

		QuickThrow(m_iSavedQuickSlot);
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RUN)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;

		RunStart();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_AIM)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;

		AimUp();
		return;
	}

	if (m_flNextBlockCheck < UTIL_WeaponTimeBase())
	{
		CheckBlocked();
		m_flNextBlockCheck = UTIL_WeaponTimeBase() + 0.08;

		if ( m_bBlocked && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_UP)
			&& ( !WPNANIM_NUM(BLOCK_IDLE) || (WPNANIM_NUM(BLOCK_IDLE) && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_IDLE)) )	/* only check BLOCK_IDLE when there is one. */
			&& ( !IS_RUNNING && !IS_AIMING )	/* if playing RUN_IDLE or AIM_IDLE, don't bother. */
			)
		{
			WeaponAnim(&WPNANIM(BLOCK_UP), 2);
		}
		else if (!m_bBlocked && m_iDisplayingAnim == WPNANIM_NUM(BLOCK_UP))
		{
			WeaponAnim(&WPNANIM(BLOCK_DOWN), 2);
		}
	}

	if (m_bInReload && m_sItemData.m_pMagDB)
	{
		// there is an anim that rechamber the first bullet into chamber...
		if (m_iClip <= 0 && m_iChamberClip <= 0)
		{
			m_iClip			= m_sItemData.m_pMagDB->m_iClip - m_sItemData.m_iChamberClip;
			m_iChamberClip	= m_sItemData.m_iChamberClip;
		}
		else
			m_iClip	= m_sItemData.m_pMagDB->m_iClip;

		BP_MAGAZINE	= max(BP_MAGAZINE - 1, 0);
		m_bInReload	= false;
	}
	else if (m_bInReload)	// which means chamber-mag weapons.
	{
		// we need to avoid the 29->30 rounds' bug.
		m_iChamberClip = 0;

		// here from HLSDK
		int j = min(m_sItemData.m_iChamberClip - m_iChamberClip, int(AMMUNITION) );
		
		m_iChamberClip += j;
		AMMUNITION -= j;
		m_bInReload = false;

		// no more bounce ammo, since this time it's all in chamber.
	}

	int bitsButton = CL_GetButtonBits();
	if (!(bitsButton & IN_ATTACK) && m_iShotsFired > 0 && UTIL_WeaponTimeBase() > m_flDecreaseShotsFired)
	{
		m_bTriggerRel = true;
		m_iShotsFired --;
		m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + (m_bDelayFire ? 0.4f : 0.0225f);

		if (m_bDelayFire)
			m_bDelayFire = false;
	}
	else if (!(bitsButton & IN_ATTACK) )
		m_bTriggerRel = true;

	
	if (bitsButton & IN_ATTACK && CanWeaponFire())
		PrimaryAttack();

	// IN_ATTACK2 occupy by SUPERIOR.

	else if (bitsButton & IN_RELOAD)
		WeaponReload();
	else if (m_flNextIdle <= 0.0f)
		WeaponIdle();
}

void CBaseWeapons::Ifr_ItemHolster(void)
{
	// current weapon control not in INFERIOR.

	// this is a reset of 2nd vmdl.
	g_c2ndVMDL.Initialization();

	m_bInReload			= false;
	m_iDisplayingAnim	= -1;
	m_pSwitchTo			= NULL;
	m_bInScope			= false;

	// reset 2nd wpnhud.
	memset(&gStdWpnHud::m_sSedWpn, NULL, sizeof(gStdWpnHud::m_sSedWpn));

	// avoid some bug..
	m_ulStatus &= ~WPN_FLAG_CONTINUE_ANIM;
	memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
	m_sAnimStack.m_iSequence = -1;

	// close menu.
	if (g_pCurrentMenu == &m_sAccMenu)
		m_sAccMenu.m_bShouldDraw = false;
	
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;
			return;
		}
	}

	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;

		return;
	}

	m_ulStatus &= ~WPN_FLAG_HOLSTERING;
	m_ulStatus &= ~WPN_FLAG_CAN_HOLSTER;
	m_ulStatus &= ~WPN_FLAG_SHOULD_HOLSTER;

	if (m_pSubsItem)
		m_pSubsItem->ItemHolster();
}

/*
===================================

Miscellaneous/Hud

===================================
*/
void CBaseWeapons::HUD_AccMenu(void)
{
	HUD_SwitchMenu(&m_sAccMenu);
}

void CBaseWeapons::HUD_Draw2D(void)
{
	gHUD::BiDimnHud::DrawCalibrateDot();

	if (m_bInScope)
	{
		// draw the crosshair texture
		gHUD::BiDimnHud::DrawScope(m_sItemData.m_iIdScope, true, m_sItemData.m_iScopeCrosshairSize[0], m_sItemData.m_iScopeCrosshairSize[1]);

		// draw the black out side.
		gHUD::BiDimnHud::DrawScope(m_sItemData.m_iIdScopeShadow);
	}

	//if (m_bitsAccessories & ACC_LASER && m_iDisplayingAnim == WPNANIM_NUM(IDLE))
		//gStdWpnHud::DrawLaserDot2D();
}

void CBaseWeapons::HUD_Draw3D(void)
{
	if (!m_bInScope)
		gStdWpnHud::Draw3D();
}

void CBaseWeapons::HUD_Think2D(void)
{
}

void CBaseWeapons::HUD_Think3D(void)
{
	if (!m_bInScope)
		gStdWpnHud::Think3D();
}

void CBaseWeapons::HUD_GenerateAccMenu(void)
{
	m_sAccMenu.RemoveAllItems();

	for (int i = 0; i < ACC_COUNT; i ++)
	{
		if (!CheckAttachment((1<<i)) )
			continue;

		gStdWpnHud::CBaseMenuAcc::AddByIndex(&m_bitsAccessories, (1<<i))->AddParent(&m_sAccMenu);
	}
}

void CBaseWeapons::DrawWorldCustomObjects(void)
{
	if (m_bitsAccessories & ACC_LASER &&
		(m_iDisplayingAnim == WPNANIM_NUM(IDLE) || m_iDisplayingAnim == WPNANIM_NUM(SHOOT) || m_iDisplayingAnim == WPNANIM_NUM(AIM_SHOOT)) )
		gStdWpnHud::DrawLaserDot();
}

/*
===================================
CBaseSubItems

Items whose can attach to a weapon shall be classify in here.
===================================
*/

CBaseSubItems::CBaseSubItems(void)
{
	m_pPlayer = gEngfuncs.GetLocalPlayer();

	m_sAnimStack.m_iSequence = -1;	// mark as should not be Pop().

	SetFunc(m_pfnItemPreFrame,	&CBaseSubItems::Sub_PreFrame);
	SetFunc(m_pfnItemDeploy,	&CBaseSubItems::Sub_Deploy);
	SetFunc(m_pfnItemHolster,	&CBaseSubItems::Sub_Holster);
	SetFunc(m_pfnItemKill,		&CBaseSubItems::Sub_Destroy);
}

CBaseSubItems::~CBaseSubItems(void)
{
	if (m_pMaster)
		m_pMaster->m_pSubsItem = NULL;
}

bool CBaseSubItems::ItemAttachToWeapon(CBaseWeapons * p)
{
	if (!p || p->m_pSubsItem != this/* || m_pMaster != p*/)
		return false;

	p->m_pSubsItem	= this;
	m_pMaster		= p;

	return true;
}

void CBaseSubItems::Sub_PreFrame(void)
{
	// think first.
	if (m_flNextThink && m_flNextThink <= UTIL_WeaponTimeBase())
		Think();

	// we need an extra m_flAltFrameTime
	m_flNextFrame		= max(m_flNextFrame - g_pparams.frametime, 0.0f);

	//it seems that these value won't sub itself this time...
	m_flNextPriAttack	= max(m_flNextPriAttack - g_pparams.frametime, 0.0f);
	m_flNextSedAttack	= max(m_flNextSedAttack - g_pparams.frametime, 0.0f);
	m_flNextIdle		= max(m_flNextIdle - g_pparams.frametime, 0.0f);

	//if frame times up, call ItemPostFrame...
	if (m_flNextFrame <= 0.0f)
		ItemPostFrame();
}

void CBaseSubItems::Sub_Deploy(void)
{
	// replace the original msg sent in AMX version.
	BindDataToHud();

	// reset some values.
	m_iShotsFired = 0;
}

void CBaseSubItems::Sub_Holster(void)
{
	memset(&gStdWpnHud::m_sSedWpn, NULL, sizeof(gStdWpnHud::m_sSedWpn));

	m_bInReload = false;

	memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
	m_sAnimStack.m_iSequence = -1;
}

void CBaseSubItems::Sub_Destroy(void)
{
	Sub_Holster();
	delete this;
}

bool CBaseSubItems::CanWeaponFire(void)
{
	if (m_pMaster->m_ulStatus & WPN_FLAG_RUN || m_bInReload || m_pMaster->m_bBlocked)
		return false;

	if (IsWeaponEmpty())
	{
		gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, m_sItemData.m_szDryFireSound, 0.8, ATTN_NORM, 0, PITCH_NORM);
		m_flNextPriAttack = 0.8;		// play efx not so quick.

		return false;
	}

	return true;
}

void CBaseSubItems::OnNewRound(bool bActiveItem)
{
	m_bInReload		= false;
	m_iChamberClip	= m_sItemData.m_iChamberClip;

	if (m_sItemData.m_pMagDB)
		m_iClip = m_sItemData.m_pMagDB->m_iClip;

	// ammo was given by the m_pMaster
}

void CBaseSubItems::BindDataToHud(void)
{
	// clear it first, avoid some break down.
	memset(&gStdWpnHud::m_sSedWpn, NULL, sizeof(gStdWpnHud::m_sSedWpn));

	// link def hud database.
	gStdWpnHud::m_sSedWpn.m_bDisplay			= true;
	gStdWpnHud::m_sSedWpn.m_pbitsFlags			= &m_ulStatus;
	gStdWpnHud::m_sSedWpn.m_piBpNum				= &(m_sItemData.m_pMagDB ? g_cMagManager.m_iMagAmount[m_sItemData.m_pMagDB->m_iType] : g_cMagManager.m_iAmmoAmount[m_sItemData.m_pAmmoDB->m_iType]);
	gStdWpnHud::m_sSedWpn.m_piBpMax				= NULL;
	gStdWpnHud::m_sSedWpn.m_piClip				= m_sItemData.m_pMagDB ? &m_iClip : &m_iChamberClip;
	gStdWpnHud::m_sSedWpn.m_piClipMax			= m_sItemData.m_pMagDB ? &m_sItemData.m_pMagDB->m_iClip : &m_sItemData.m_iChamberClip;
	gStdWpnHud::m_sSedWpn.m_piFireMode			= &m_iFireMode;
	gStdWpnHud::m_sSedWpn.m_piszFireModeIcons	= m_sItemData.m_pAmmoDB->m_iIdAmmoIcons;
	gStdWpnHud::m_sSedWpn.m_piWpnDxt			= &m_sItemData.m_iIdWeaponIcon;
	gStdWpnHud::m_sSedWpn.m_pszBpName			= m_sItemData.m_pAmmoDB->m_wszEndoName;
	gStdWpnHud::m_sSedWpn.m_pszEndoName			= m_sItemData.m_wszEndoName;

	// update def hud database.
	gStdWpnHud::UpdateWpnName();
}

bool CBaseSubItems::GiveAmmo(void)
{
	// TODO: wait for maxium system.
	if (m_sItemData.m_pMagDB)
	{
		g_cMagManager.m_iMagAmount[m_sItemData.m_pMagDB->m_iType] ++;
	}
	else if (m_sItemData.m_pAmmoDB)	// since there is a knife...
	{
		g_cMagManager.m_iAmmoAmount[m_sItemData.m_pAmmoDB->m_iType] += m_sItemData.m_iChamberClip;
	}
	else
		return false;

	return true;
}

void CBaseSubItems::WeaponAnim(animdb_t * pAnim, int iCDType, bool bSyncMaster)
{
	if (!pAnim)
		return;

	HUD_SendWeaponAnim(pAnim->m_i, m_pMaster->m_iSubModelStatus);

	switch (iCDType)
	{
		case 1:	// anim will continue, but you can do whatever you like
			m_flNextFrame = pAnim->m_fe;
			m_flNextIdle = pAnim->m_fd;
			break;

		case 2:	// frame will go on, but you can't attack until it's fully done.
			m_flNextFrame = pAnim->m_fe;
			m_flNextPriAttack = m_flNextSedAttack = m_flNextIdle = pAnim->m_fd;
			break;

		default:
			m_flNextIdle = pAnim->m_fd;
			break;
	}

	if (!bSyncMaster)
		return;

	// or maybe some discontinous will happen.
	m_pMaster->m_iDisplayingAnim = pAnim->m_i;

	switch (iCDType)
	{
		case 1:	// anim will continue, but you can do whatever you like
			m_pMaster->m_flNextFrame = pAnim->m_fe;
			m_pMaster->m_flNextIdle = pAnim->m_fd;
			break;

		case 2:	// frame will go on, but you can't attack until it's fully done.
			m_pMaster->m_flNextFrame = pAnim->m_fe;
			m_pMaster->m_flNextPriAttack = m_pMaster->m_flNextSedAttack = m_pMaster->m_flNextIdle = pAnim->m_fd;
			break;

		default:
			m_pMaster->m_flNextIdle = pAnim->m_fd;
			break;
	}
}

void CBaseSubItems::PushAnim(bool bSyncMaster)
{
	m_sAnimStack.m_flAnimtime	= gEngfuncs.GetClientTime() - g_flViewEntAnimTime;
	m_sAnimStack.m_flFrame		= g_pViewEnt->curstate.frame;
	m_sAnimStack.m_flFramerate	= g_pViewEnt->curstate.framerate;
	m_sAnimStack.m_iSequence	= g_pViewEnt->curstate.sequence;

	m_sAnimStack.m_flNextPriAttack	= m_flNextPriAttack;
	m_sAnimStack.m_flNextSedAttack	= m_flNextSedAttack;
	m_sAnimStack.m_flNextIdle		= m_flNextIdle;
	m_sAnimStack.m_flNextFrame		= m_flNextFrame;

	if (bSyncMaster && m_pMaster)	// we only need to save it's timedata.
		m_pMaster->PushAnim();
}

bool CBaseSubItems::PopAnim(bool bSyncMaster)
{
	if (m_sAnimStack.m_iSequence < 0)
		return false;

	if (bSyncMaster && m_pMaster)	// pop then override its data.
		m_pMaster->PopAnim();

	g_flViewEntAnimTime				= gEngfuncs.GetClientTime() - m_sAnimStack.m_flAnimtime;
	g_pViewEnt->curstate.frame		= m_sAnimStack.m_flFrame;
	g_pViewEnt->curstate.framerate	= m_sAnimStack.m_flFramerate;
	g_pViewEnt->curstate.sequence	= m_sAnimStack.m_iSequence;

	m_flNextPriAttack	= m_sAnimStack.m_flNextPriAttack;
	m_flNextSedAttack	= m_sAnimStack.m_flNextSedAttack;
	m_flNextIdle		= m_sAnimStack.m_flNextIdle;
	m_flNextFrame		= m_sAnimStack.m_flNextFrame;

	// additional.
	m_pMaster->m_iDisplayingAnim	= m_sAnimStack.m_iSequence;
	gEngfuncs.pfnWeaponAnim( m_sAnimStack.m_iSequence, 0 );	// somehow we need this or it will be automaticly set back. WHY MAIN WPN DONT NEED IT ?!

	memset(&m_sAnimStack, NULL, sizeof(m_sAnimStack));
	m_sAnimStack.m_iSequence = -1;	// mark as should not be Pop().

	return true;
}

void CBaseSubItems::Pause(void)
{
	PushAnim();
	m_bInReload = false;

	if (m_pMaster)
	{
		m_pMaster->m_ulStatus		|= WPN_FLAG_SHOULD_USE_SUB;
		m_pMaster->m_flNextFrame	= 0;
	}

	SetFunc(m_pfnUse,	&CBaseSubItems::Restore);
}

void CBaseSubItems::Restore(void)
{
	if (m_bInReload)
		return;

	PopAnim();
	m_bInReload = true;
}

/*
===================================
CBaseMelee

Weapon that can attack people nearby shall be classified in here.
===================================
*/

void CBaseMelee::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	SetFunc(m_pfnItemPreFrame,	&CBaseMelee::Mel_ItemPreFrame);
	SetFunc(m_pfnItemPostFrame,	&CBaseMelee::Mel_ItemPostFrame);
}

void CBaseMelee::BindDataToHud(void)
{
	// clear it first, avoid some break down.
	memset(&gStdWpnHud::m_sPriWpn, NULL, sizeof(gStdWpnHud::m_sPriWpn));

	// link def hud database.
	gStdWpnHud::m_sPriWpn.m_bDisplay			= true;
	gStdWpnHud::m_sPriWpn.m_pbitsFlags			= &m_ulStatus;
	gStdWpnHud::m_sPriWpn.m_piWpnDxt			= &m_sItemData.m_iIdWeaponIcon;
	gStdWpnHud::m_sPriWpn.m_pszBpName			= m_sItemData.m_pAmmoDB->m_wszEndoName;
	gStdWpnHud::m_sPriWpn.m_pszEndoName			= m_sItemData.m_wszEndoName;

	// update def hud database.
	gStdWpnHud::UpdateWpnName();
}

void CBaseMelee::Mel_ItemPreFrame(void)
{
	if (m_ulStatus & WPN_FLAG_QUICKUSING)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_QUICKUSING;

		QuickMelee();
		return;
	}

	CBaseWeapons::Def_ItemPreFrame();
}

void CBaseMelee::Mel_ItemPostFrame(void)
{
	if (m_ulStatus & WPN_FLAG_HOLSTERING)
	{
		m_ulStatus |= WPN_FLAG_CAN_HOLSTER;
		SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_HOLSTER)
	{
		if (!m_pSwitchTo)
			SwitchWeapon(UTIL_SortItemsBySlot());
		else if (CanItemHolster())
			SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RUN)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;

		RunStart();
		return;
	}

	int bitsButton = CL_GetButtonBits(FALSE);
	
	if (bitsButton & IN_ATTACK && m_flNextPriAttack <= 0.0f)
		PrimaryAttack();
	else if (bitsButton & IN_ATTACK2 && m_flNextSedAttack <= 0.0f)
		SecondaryAttack();
	else if (m_flNextIdle <= 0.0f)
		WeaponIdle();
}

/*
===================================
CBasePistol

Weapon that have a slide shall be classified in here.
===================================
*/

bool CBasePistol::IsNonslidemoveAnim(int iAnim)
{
	if ( iAnim == WPNANIM_NUM(IDLE) || iAnim == WPNANIM_NUM(DRAW) || iAnim == WPNANIM_NUM(HOLSTER)	// basical
		|| iAnim == WPNANIM_NUM(AIM_DOWN) || iAnim == WPNANIM_NUM(AIM_IDLE) || iAnim == WPNANIM_NUM(AIM_UP)	// aim
		|| iAnim == WPNANIM_NUM(RUN_LOOP) || iAnim == WPNANIM_NUM(RUN_START) || iAnim == WPNANIM_NUM(RUN_STOP) || iAnim == WPNANIM_NUM(JUMP)	// movement
		|| iAnim == WPNANIM_NUM(BLOCK_UP) || iAnim == WPNANIM_NUM(BLOCK_IDLE) || iAnim == WPNANIM_NUM(BLOCK_DOWN) )	// block
		return true;

	return false;
}

void CBasePistol::PlayShootingAnim(void)
{
	animdb_t *pSelected = nullptr;

	if (!m_iClip && m_iChamberClip)	// last shot.
	{
		if (IS_AIMING)
			pSelected = &WPNANIM(AIM_SHOOT_LAST);
		else
			pSelected = &WPNANIM(SHOOT_LAST);
	}
	else
	{
		// using random aiming-shooting anim will make player more immersive.
		if (IS_AIMING)
			pSelected = &m_sAnims[RANDOM_LONG(WPN_COMMON_ANIM_AIM_SHOOT, WPN_COMMON_ANIM_AIM_SHOOT_3)];
		else
			pSelected = &WPNANIM(SHOOT);	// default one.
	}

	WeaponAnim(pSelected);
}

/*
===================================
CBaseTubularWeapon

Weapon that using a tubular magazine shall be classified here.
===================================
*/

float CBaseTubularWeapon::LoadForAmmoAddLoop(NewKeyValues *pRoot, float flDef)
{
	NewKeyValues *pBlock = pRoot->FindKey("customdata");
	NewKeyValues *p = NULL;

	if (pBlock)
	{
		if ( (p = pBlock->FindKey("flTimeAmmoAddLoop")) )
			return p->GetFloat();
	}

	return flDef;
}

void CBaseTubularWeapon::RunStart(void)
{
	if (m_bInReload)
	{
		m_bSetForceStopReload = true;
		return;
	}

	CBaseWeapons::RunStart();
}

void CBaseTubularWeapon::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	SetFunc(m_pfnWeaponReload,	&CBaseTubularWeapon::Tbl_WeaponReload);
	SetFunc(m_pfnItemHolster,	&CBaseTubularWeapon::Tbl_ItemHolster);
}

void CBaseTubularWeapon::Tbl_ItemPostFrame(void)
{
	if (m_bInReload && !(m_ulStatus & WPN_FLAG_HOLSTERING))
	{
		if (m_flNextInsertAnim <= gEngfuncs.GetClientTime() && m_iChamberClip < m_sItemData.m_iChamberClip)
		{
			HUD_SendWeaponAnim(WPNANIM_NUM(INSERT));
			
			SU_Begin		( WPN_CMD_RELOAD );
			SU_WriteInteger	( m_iItemType );
			SU_End			( );

			m_flNextInsertAnim = gEngfuncs.GetClientTime() + WPNANIM_DUR(INSERT);
		}

		if (AMMUNITION > 0 && m_flNextAddAmmo <= gEngfuncs.GetClientTime() && m_iChamberClip < m_sItemData.m_iChamberClip)
		{
			m_iChamberClip ++;
			AMMUNITION --;

			m_flNextAddAmmo = gEngfuncs.GetClientTime() + WPNANIM_DUR(INSERT);
		}

		if ( ( (m_iChamberClip >= m_sItemData.m_iChamberClip || AMMUNITION <= 0) && m_flNextInsertAnim <= gEngfuncs.GetClientTime())
			|| m_bSetForceStopReload || CL_GetButtonBits() & (IN_ATTACK|IN_RUN) )
		{
			WeaponAnim(m_bStartedFromEmpty ? &WPNANIM(AFTER_RELOAD_EMPTY) : &WPNANIM(AFTER_RELOAD), 2);

			m_bInReload				= false;
			m_bStartedFromEmpty		= false;
			m_bSetForceStopReload	= false;

			SetFunc(m_pfnItemPostFrame,	&CBaseWeapons::Def_ItemPostFrame);
			SetFunc(m_pfnWeaponIdle,	&CBaseWeapons::Def_WeaponIdle);
		}
	}
	else
		Def_ItemPostFrame();	// for emergency.
}

void CBaseTubularWeapon::Tbl_WeaponReload(void)
{
	if (m_iChamberClip >= m_sItemData.m_iChamberClip || m_sItemData.m_iChamberClip < 0 || AMMUNITION <= 0)
		return;

	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
			return;
		}
	}

	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
		return;
	}

	m_iShotsFired		= 0;
	m_bInReload			= true;
	m_bStartedFromEmpty = !!(m_iChamberClip <= 0);
	m_flNextFrame		= WPNANIM_DUR(START_RELOAD);
	m_flNextInsertAnim	= gEngfuncs.GetClientTime() + WPNANIM_DUR(START_RELOAD);
	m_flNextAddAmmo		= gEngfuncs.GetClientTime() + (*m_pflAddAmmoLoop) + WPNANIM_DUR(START_RELOAD);

	WeaponAnim(&WPNANIM(START_RELOAD), 2);

	SetFunc(m_pfnItemPostFrame,	&CBaseTubularWeapon::Tbl_ItemPostFrame);
	SetFunc(m_pfnWeaponIdle,	&CBaseTubularWeapon::DoNothing);

	m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;
}

void CBaseTubularWeapon::Tbl_ItemHolster(void)
{
	if (m_bInReload)
	{
		m_ulStatus |= WPN_FLAG_FIRSTUSE;
		m_bInReload = false;
	}

	m_bStartedFromEmpty		= false;
	m_bSetForceStopReload	= false;

	SetFunc(m_pfnItemPostFrame,	&CBaseWeapons::Def_ItemPostFrame);
	SetFunc(m_pfnWeaponIdle,	&CBaseWeapons::Def_WeaponIdle);

	Def_ItemHolster();
}

/*
===================================
CBaseHighTecWeapon

Weapon that have a fire control system, and a grenade launcher.
===================================
*/

void CBaseHighTecWeapon::FCS_SwitchGrenadeMode(void)
{
	// looping in these three various types.
	switch (m_iGrenadeType)
	{
		case GR_DELAY:
			m_iGrenadeType = GR_TOUCH_DELAY;
			break;

		case GR_TOUCH_DELAY:
			m_iGrenadeType = GR_TOUCH;
			break;

		default:
			m_iGrenadeType = GR_DELAY;
			break;
	}
}

void CBaseHighTecWeapon::FCS_Initialize(void)
{
	// const strings init.
	// LUNA: the string ptr is NOT constant?!
	s_wszFCSwords[SIGHT_BLOCK]		= gpLocalize->Find(s_szFCSwords[SIGHT_BLOCK]);
	s_wszFCSwords[SIGHT_DANGER]		= gpLocalize->Find(s_szFCSwords[SIGHT_DANGER]);
	s_wszFCSwords[SIGHT_OK]			= gpLocalize->Find(s_szFCSwords[SIGHT_OK]);
	s_wszGrenadeMode[GR_TOUCH]		= gpLocalize->Find(s_szGrenadeMode[GR_TOUCH]);
	s_wszGrenadeMode[GR_TOUCH_DELAY]= gpLocalize->Find(s_szGrenadeMode[GR_TOUCH_DELAY]);
	s_wszGrenadeMode[GR_DELAY]		= gpLocalize->Find(s_szGrenadeMode[GR_DELAY]);
	s_wszFCSadjust					= gpLocalize->Find(s_szFCSadjust);

	// at least 0.10s detonate time
	m_flGrenadeDelay = 0.1f;
}

void CBaseHighTecWeapon::FCS_DrawText(void)
{
	wchar_t buffer[64];
	swprintf_s(buffer, _TRUNCATE, L"[%s] %s", UTIL_KeyNameByCommand("switchswitcher"), s_wszGrenadeMode[m_iGrenadeType]);

	int iWidth, iHeight;
	gFontFuncs.GetTextSize(gStdWpnHud::m_hFont, buffer, &iWidth, &iHeight);

	int x = gHUD::m_sScreenInfo.iWidth - (iWidth + HUD_SIZE_GAP);
	int y = gHUD::m_sScreenInfo.iHeight - (iHeight + HUD_SIZE_GAP);

	gFontFuncs.DrawSetTextFont(gStdWpnHud::m_hFont);
	gFontFuncs.DrawSetTextPos(x, y);
	gFontFuncs.DrawSetTextColor(255, 255, 255, 255);
	gFontFuncs.DrawPrintText(buffer);

	if (m_iGrenadeType == GR_TOUCH)
		return;	// if it's standard grenade, we dont need to print the delay time.

	const wchar_t *pwsz = gpLocalize->Find("#MW_Units_Seconds");
	swprintf_s(buffer, _TRUNCATE, L"[%s/%s] %s: %.2f %s", UTIL_KeyNameByCommand("invprev"), UTIL_KeyNameByCommand("invnext"), s_wszFCSadjust, m_flGrenadeDelay, pwsz);
	gFontFuncs.GetTextSize(gStdWpnHud::m_hFont, buffer, &iWidth, &iHeight);

	x = gHUD::m_sScreenInfo.iWidth - (iWidth + HUD_SIZE_GAP);
	y -= iHeight + HUD_SIZE_GAP;	// Y value must calc base on the old Y coord.

	gFontFuncs.DrawSetTextFont(gStdWpnHud::m_hFont);
	gFontFuncs.DrawSetTextPos(x, y);
	gFontFuncs.DrawSetTextColor(255, 255, 255, 255);
	gFontFuncs.DrawPrintText(buffer);
}

void CBaseHighTecWeapon::FCS_Prediction(void)
{
	Vector vecSrc = GetMuzzleOrigin();	// all classes using this function shall modify either GetMuzzleOrigin() or GetMuzzleEnum().
	Vector vecVel = Vector(g_pparams.forward) * m_pGrenadeAmmoDB->m_flInitVel;
	float flAcceleration = 800.0f;	// UNDONE: sv_gravity value could be changed.
	float dt = 0.05f;
	pmtrace_t tr;
	Vector vecEnd = vecSrc + vecVel * dt;
	float flSummationTime = 0;

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	gEngfuncs.pEventAPI->EV_PushPMStates();
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( m_pPlayer->index - 1 );	// for this clinet
	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );	// a point.

	do
	{
		gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecEnd, PM_STUDIO_BOX, -1, &tr );

		vecVel.z -= flAcceleration * dt;
		vecSrc = tr.endpos;
		vecEnd = vecSrc + vecVel * dt;

		if (m_iGrenadeType == GR_DELAY)	// if using Airbrust Round, predict the airbrust location.
		{
			flSummationTime += dt;

			if (flSummationTime >= m_flGrenadeDelay)
				break;
		}
	}
	while (tr.fraction == 1.0f);

	m_vecGrPredictHit = tr.endpos;

	gEngfuncs.pEventAPI->EV_PlayerTrace( g_pparams.vieworg, m_vecGrPredictHit, PM_STUDIO_BOX, -1, &tr );

	m_iFCSstatus	= (tr.fraction != 1.0) ? SIGHT_BLOCK : SIGHT_OK;
	m_sFCScolor		= UnpackRGB((tr.fraction != 1.0) ? RGB_YELLOWISH : RGB_GREENISH);

	if ((Vector(g_pparams.vieworg) - m_vecGrPredictHit).Length() <= m_pGrenadeAmmoDB->m_flRadius)
	{
		m_iFCSstatus	= SIGHT_DANGER;
		m_sFCScolor		= UnpackRGB(RGB_REDISH);
	}

	gEngfuncs.pEventAPI->EV_PopPMStates();
}

void CBaseHighTecWeapon::FCS_ShowResult(void)
{
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	glColor4f(m_sFCScolor.r / 255.0f, m_sFCScolor.g / 255.0f, m_sFCScolor.b / 255.0f, 1);

	Vector vecs[4];
	vecs[0] = m_vecGrPredictHit - Vector(g_pparams.right) * HUD_SIZE_STRING_TALL * 0.5f + Vector(g_pparams.up) * HUD_SIZE_STRING_TALL * 0.5f;
	vecs[1] = vecs[0] + Vector(g_pparams.right) * HUD_SIZE_STRING_TALL;
	vecs[2] = vecs[1] - Vector(g_pparams.up) * HUD_SIZE_STRING_TALL;
	vecs[3] = vecs[0] - Vector(g_pparams.up) * HUD_SIZE_STRING_TALL;

	glBegin(GL_QUADS);
	glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
	glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
	glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
	glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
	glEnd();

	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);

	gFontFuncs.DrawSetTextFont(gStdWpnHud::m_hFont);
	gFontFuncs.DrawSetText3DPos(vecs[1] + Vector(g_pparams.right) * HUD_SIZE_GAP + Vector(g_pparams.up) * HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetText3DDir(g_pparams.forward, g_pparams.right, g_pparams.up);
	gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetTextColor(m_sFCScolor.r, m_sFCScolor.g, m_sFCScolor.b, 255);
	gFontFuncs.DrawPrint3DText(s_wszFCSwords[m_iFCSstatus]);

	wchar_t wszExtra[32];
	
	// first, about the distance.
	float flDistance = (m_vecGrPredictHit - Vector(g_pparams.vieworg)).Length() / 36;	// inches to yards
	const wchar_t *pwsz = gpLocalize->Find("#MW_Units_Yards");

	if (!pwsz)
		return;

	swprintf_s(wszExtra, _TRUNCATE, L"%.1f %s", flDistance, pwsz);

	gFontFuncs.DrawSetTextFont(gStdWpnHud::m_hFont);
	gFontFuncs.DrawSetText3DPos(vecs[1] + Vector(g_pparams.right) * HUD_SIZE_GAP);
	gFontFuncs.DrawSetText3DDir(g_pparams.forward, g_pparams.right, g_pparams.up);
	gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetTextColor(m_sFCScolor.r, m_sFCScolor.g, m_sFCScolor.b, 255);
	gFontFuncs.DrawPrint3DText(wszExtra);

	// then, about the approximately time
	float flAprxTime = flDistance / (Vector2D(g_pparams.forward[0] * m_pGrenadeAmmoDB->m_flInitVel, g_pparams.forward[1] * m_pGrenadeAmmoDB->m_flInitVel).Length() / 36);	// inches to yards
	pwsz = gpLocalize->Find("#MW_Units_Seconds");

	if (!pwsz)
		return;

	swprintf_s(wszExtra, _TRUNCATE, L"%.2f %s", flAprxTime, pwsz);

	gFontFuncs.DrawSetTextFont(gStdWpnHud::m_hFont);
	gFontFuncs.DrawSetText3DPos(vecs[2] + Vector(g_pparams.right) * HUD_SIZE_GAP);
	gFontFuncs.DrawSetText3DDir(g_pparams.forward, g_pparams.right, g_pparams.up);
	gFontFuncs.DrawSetText3DHeight(HUD_SIZE_STRING_TALL);
	gFontFuncs.DrawSetTextColor(m_sFCScolor.r, m_sFCScolor.g, m_sFCScolor.b, 255);
	gFontFuncs.DrawPrint3DText(wszExtra);
}

bool CBaseHighTecWeapon::HTW_MouseWheel(bool bUp)
{
	if (bUp)
		m_flGrenadeDelay += 0.05f;
	else
		m_flGrenadeDelay -= 0.05f;

	if (m_flGrenadeDelay > 5.0f)
		m_flGrenadeDelay = 5.0f;
	else if (m_flGrenadeDelay < 0.1f)
		m_flGrenadeDelay = 0.1f;

	return false;
}

void CBaseHighTecWeapon::HTW_ItemHolster(void)
{
	// when we leave, we should close 2nd wpn panel.
	memset(&gStdWpnHud::m_sSedWpn, NULL, sizeof(gStdWpnHud::m_sSedWpn));
}

/*
===================================
CBaseGrenade

Obviously, this is the father of all grenades.
===================================
*/

void CBaseGrenade::PullPin(void)
{
	// of course, we need to play animation.
	WeaponAnim(&WPNANIM(PULLPIN), 1);

	// set the stage flage. Since the stages cannot logically co-existance...
	m_iGrenadeStage = STAGE_PULLPIN;
}

void CBaseGrenade::Charging(void)
{
	WeaponAnim(&WPNANIM(CHARGING), 1);

	m_iGrenadeStage = STAGE_CHARGING;
}

void CBaseGrenade::Throw(void)
{
	WeaponAnim(&WPNANIM(THROW), 2);	// the WeaponAnim() type parameter is a little bit different here.

	// initiates grenade entity spawning.
	SetFunc(m_pfnThink,	&CBaseGrenade::GrSpawn);
	m_flNextThink = m_flTimeGrSpawn;

	m_iGrenadeStage = STAGE_THROW;
}

void CBaseGrenade::GrSpawn(void)
{
	// this is a Think() altering function, so DO remember to reset m_flNextThink value to zero.
	SetFunc(m_pfnThink,	NULL);
	m_flNextThink = 0;

	SU_Begin		(HGR_CMD_SPAWN);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(GetMuzzleOrigin());
	SU_WriteVector	(g_pparams.viewangles);

	// get cooked time here instead Throw() since the fuse is still burning while we attempt to throw this grenade.
	// then calculate the total fuse time to server.
	SU_WriteFloat	(max(0.0f, m_sItemData.m_pAmmoDB->m_flFuseTime - GetCookedTime()));

	// send the force value, with which we can use grenade handy.
	SU_WriteFloat	(m_flForce);

	SU_End			();

	// special process for QT mode.
	if (IsQuickThrow())
	{
		AMMUNITION --;

		// should not kill item here. it would cause some trouble.
	}
}

void CBaseGrenade::Revoke(void)
{
	WeaponAnim(&WPNANIM(REVOKE), 1);

	m_iGrenadeStage = STAGE_REVOKE;

	// we need this flag to makes sure we can totally withdraw from uprising.
	m_bInWithdrawal	= true;
}

void CBaseGrenade::PlugPin(void)
{
	WeaponAnim(&WPNANIM(PLUGPIN), 1);

	m_iGrenadeStage = STAGE_PLUGPIN;

	// we need this flag to makes sure we can totally withdraw from uprising.
	// especially, from the middle.m
	m_bInWithdrawal	= true;
}

void CBaseGrenade::QuickThrow(void)
{
	// start with this. this value WILL alters all m_pfns.
	m_bIsQuickThrow = true;

	// play quickpull anim.
	WeaponAnim(&WPNANIM(QUICKPULLPIN), 1);

	// block original ItemPostFrame()
	// since it is forced to assign on class CBaseGrenade, you may need to override this function if you want to customize QTs.
	SetFunc(m_pfnItemPostFrame,	&CBaseGrenade::QT_WaitForRel);
}

void CBaseGrenade::QT_WaitForRel(void)
{
	// if the quick use button is already released, we can just execute it.
	if (!(CL_GetButtonBits() & m_bitsQTSlot))
	{
		// play throw anim.
		WeaponAnim(&WPNANIM(QUICKTHROW), 1);

		// we need to manually set this. FUCK.
		m_flNextFrame	= WPNANIM_DUR(QUICKTHROW);

		// assign a grenade spawn time.
		m_flNextThink	= m_flTimeQTGrSpawn;
		SetFunc(m_pfnThink,	&CBaseGrenade::GrSpawn);

		// the next ItemPostFrame() should restore everything back to normal.
		SetFunc(m_pfnItemPostFrame,	&CBaseGrenade::QT_BackToNorm);

		// the removal of ammo is moved to GrSpawn().
	}

	// in QT mode, the cooking process is forced to start.
	// it means that we still pressing correspounding button(s).
	else if (m_flStartCooking <= 0)
	{
		m_flStartCooking	= UTIL_WeaponTimeBase();
	}

	// then copy some code from Gr_ItemPostFrame().
	// overcooked: BOOOOOOOOOM!!!
	if (GetCookedTime() >= m_flTimeExplosion)
	{
		AMMUNITION --;

		// spawn a grenade downword to explo yourself.
		SU_Begin		(HGR_CMD_SPAWN);
		SU_WriteInteger	(m_iItemType);
		SU_WriteVector	(GetMuzzleOrigin());
		SU_WriteVector	(g_pparams.viewangles);
		SU_WriteFloat	(0.001f);	// means, explo, RIGHT FUCING NOW
		SU_WriteFloat	(1.0f);		// no extra force given, so just drop down.
		SU_End			();

		// then we can just call QT_BackToNorm() to clean up the mess.
		QT_BackToNorm();

		return;
	}
}

void CBaseGrenade::QT_BackToNorm(void)
{
	// just remember to reset it.
	m_flStartCooking	= -1;
	m_bIsQuickThrow		= false;
	m_ulStatus			&= ~WPN_FLAG_QUICKUSING;

	// need to remove QuickThrow flags before we attempt to holster GR.
	m_ulStatus |= WPN_FLAG_SKIPHOLSTER;
	SwitchWeapon(g_pPlayerLastItem);

	SetFunc(m_pfnItemPostFrame,	&CBaseGrenade::Gr_ItemPostFrame);
}

float CBaseGrenade::GetCookedTime(void)
{
	if (m_flStartCooking > 0.0f)
		return (UTIL_WeaponTimeBase() - m_flStartCooking);

	// means that m_flStartCooking is a default value -1.0f
	return 0.0f;
}

inline bool CBaseGrenade::IsUprising(void)
{
	return !!(m_iGrenadeStage == STAGE_PULLPIN || m_iGrenadeStage == STAGE_CHARGING);	// THROW and CHARGED excluded.
}

inline bool CBaseGrenade::IsReadyThrowing(void)
{
	return !!(m_iGrenadeStage == STAGE_CHARGED || m_iGrenadeStage == STAGE_COOKING);
}

inline bool CBaseGrenade::IsUnrevokable(void)
{
	return !!(m_iGrenadeStage == STAGE_COOKING || m_iGrenadeStage == STAGE_THROW);
}

inline bool CBaseGrenade::IsBusy(void)
{
	return !!(m_iGrenadeStage == STAGE_PULLPIN || m_iGrenadeStage == STAGE_CHARGING || m_iGrenadeStage == STAGE_CHARGED || m_iGrenadeStage == STAGE_THROW || m_iGrenadeStage == STAGE_REVOKE || m_iGrenadeStage == STAGE_PLUGPIN);
}

inline bool CBaseGrenade::IsQuickThrow(void)
{
	return !!(m_bIsQuickThrow || (m_ulStatus & WPN_FLAG_QUICKUSING));
}

bool CBaseGrenade::CanItemHolster(void)
{
	if (IsUnrevokable() || IsQuickThrow())
		return false;

	if (m_ulStatus & WPN_FLAG_SKIPHOLSTER)
	{
		m_ulStatus &= ~WPN_FLAG_SKIPHOLSTER;
		m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;
		return true;
	}
	
	if (m_ulStatus & WPN_FLAG_HOLSTERING && !(m_ulStatus & WPN_FLAG_CAN_HOLSTER))
		return false;
	
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_HOLSTER;
		return false;
	}

	// when it is in the progress of these stages, we should consider playing withdrawal animations.
	// STAGE_PULLPIN || STAGE_CHARGING || STAGE_CHARGED || STAGE_REVOKE || STAGE_PLUGPIN
	if (IsBusy())
	{
		// FLAG_SHOULD_HOLSTER will be added while processing m_bInRevokeHolster in GR_ItemPostFrame()
		m_bInRevokeHolster = true;
		return false;
	}

	if (!(m_ulStatus & WPN_FLAG_CAN_HOLSTER))
	{
		m_ulStatus &= ~WPN_FLAG_SHOULD_HOLSTER;
		m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;
		m_ulStatus |= WPN_FLAG_HOLSTERING;
		WeaponAnim(&WPNANIM(HOLSTER), 2);

		if (IsSuperior())
			m_pAltWeapon->Ifr_PlayHolsterAnim();

		return false;
	}

	return true;
}

bool CBaseGrenade::CanItemDropped(void)
{
	return (!IsUnrevokable() && CBaseWeapons::CanItemDropped() && !IsQuickThrow());
}

void CBaseGrenade::RunStart(void)
{
	if (IsBusy())
		return;

	return CBaseWeapons::RunStart();
}

void CBaseGrenade::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	m_iGrenadeStage		= STAGE_IDLE;
	m_flStartCooking	= -1;
	m_flForce			= 450.0f;
	m_bInRevokeHolster	= false;
	m_bInWithdrawal		= false;
	m_bIsQuickThrow		= false;
	m_flTimeExplosion	= m_sItemData.m_pAmmoDB->m_flFuseTime;	// this value should never be zero!!!
	m_flTimeGrSpawn		= WPNANIM_EFT(THROW);
	m_flTimeQTGrSpawn	= WPNANIM_EFT(QUICKTHROW);

	SetFunc(m_pfnItemPreFrame,	&CBaseGrenade::Gr_ItemPreFrame);
	SetFunc(m_pfnItemDeploy,	&CBaseGrenade::Gr_ItemDeploy);
	SetFunc(m_pfnItemPostFrame,	&CBaseGrenade::Gr_ItemPostFrame);
	SetFunc(m_pfnItemHolster,	&CBaseGrenade::Gr_ItemHolster);
}

void CBaseGrenade::BindDataToHud(void)
{
	// clear it first, avoid some break down.
	memset(&gStdWpnHud::m_sPriWpn, NULL, sizeof(gStdWpnHud::m_sPriWpn));

	// link def hud database.
	gStdWpnHud::m_sPriWpn.m_bDisplay	= true;
	gStdWpnHud::m_sPriWpn.m_pbitsFlags	= &m_ulStatus;
	gStdWpnHud::m_sPriWpn.m_piBpNum		= &(m_sItemData.m_pMagDB ? g_cMagManager.m_iMagAmount[m_sItemData.m_pMagDB->m_iType] : g_cMagManager.m_iAmmoAmount[m_sItemData.m_pAmmoDB->m_iType]);
	gStdWpnHud::m_sPriWpn.m_piBpMax		= NULL;
	gStdWpnHud::m_sPriWpn.m_piWpnDxt	= &m_sItemData.m_iIdWeaponIcon;
	gStdWpnHud::m_sPriWpn.m_pszBpName	= m_sItemData.m_pAmmoDB->m_wszEndoName;
	gStdWpnHud::m_sPriWpn.m_pszEndoName	= m_sItemData.m_wszEndoName;

	// update def hud database.
	gStdWpnHud::UpdateWpnName();
}

void CBaseGrenade::Melee(void)	// use Melee() function to bind MOUSE3 as cooking button.
{
	// for idle status, of course you can melee.
	if (m_iGrenadeStage == STAGE_IDLE)
	{
		CBaseWeapons::Melee();
		return;
	}

	// these are the codes for cooking grenades.
	if (m_iGrenadeStage != STAGE_CHARGED)
		return;

	m_flStartCooking	= UTIL_WeaponTimeBase();
	m_iGrenadeStage		= STAGE_COOKING;
}

bool CBaseGrenade::MouseWheel(bool bUp)
{
	// if charged/cooking: no changing weapon allowed. wheel can only be used as force dial.
	// if no charged: good to go.

	if (IsReadyThrowing() || IsUnrevokable())
	{
		// wheel up: +10 unit of force
		// wheel down: -10 unit of force
		m_flForce	+= (bUp ? 10.0f : -10.0f);

		// and then make sure it stays in proper range.
		if (m_flForce < 100.0f)
			m_flForce = 100.0f;
		else if (m_flForce > 800.0f)
			m_flForce = 800.0f;

		// block the normal weapon swap.
		return MOUSEWHEEL_HANDLED;
	}

	return MOUSEWHEEL_CONTINUE;
}

void CBaseGrenade::Gr_ItemPreFrame(void)
{
	if (m_ulStatus & WPN_FLAG_QUICKUSING)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_QUICKUSING;

		QuickThrow();
		return;
	}

	Def_ItemPreFrame();
}

void CBaseGrenade::Gr_ItemDeploy(void)
{
	Def_ItemDeploy();	// not require CBaseGrenade in the front, since we can cover Def_() in custom classes.

	m_iGrenadeStage		= STAGE_IDLE;
	m_flStartCooking	= -1;
	m_bInRevokeHolster	= false;
	m_bInWithdrawal		= false;
}

void CBaseGrenade::Gr_ItemPostFrame(void)
{
	// the standard part of ItemPostFrame(), copied from def_ipf().
	// quick melee should be reserved.
	// Block() is meanless here.

	if (m_ulStatus & WPN_FLAG_HOLSTERING)
	{
		m_ulStatus |= WPN_FLAG_CAN_HOLSTER;
		SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_HOLSTER)
	{
		if (!m_pSwitchTo)
			SwitchWeapon(UTIL_SortItemsBySlot());
		else if (CanItemHolster())
			SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_MELEE)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;

		Melee();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RUN)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;

		RunStart();
		return;
	}

	/*
	
	Base rule:
	MOUSE1: click to charge for throwing.
	MOUSE2: click at anytime to revoke charging.
	WHEEL:	after charged, wheel can be used to adjust the throwing force.	// in MouseWheel()
	MOUSE3: click to start cooking grenade, it's unrevokable now.			// in Melee()

	*/

	// no grenade ammo == item should be removed.
	if (!AMMUNITION)
	{
		ItemKill();
		return;
	}

	// overcooked: BOOOOOOOOOM!!!
	if (GetCookedTime() >= m_flTimeExplosion)
	{
		AMMUNITION --;

		// spawn a grenade downword to explo yourself.
		SU_Begin		(HGR_CMD_SPAWN);
		SU_WriteInteger	(m_iItemType);
		SU_WriteVector	(GetMuzzleOrigin());
		SU_WriteVector	(g_pparams.viewangles);
		SU_WriteFloat	(0.001f);	// means, explo, RIGHT FUCING NOW
		SU_WriteFloat	(1.0f);		// no extra force given, so just drop down.
		SU_End			();

		// play the deploy anim, if there're still any grenade remains.
		if (AMMUNITION)
			ItemDeploy();	// STAGE reset is included.

		return;
	}

	// in replace of WeaponIdle(), part I, fix the bug of no running screen shake.
	if (IS_RUNNING)
	{
		// fix when player hit a wall of even release W button, but still playing RUN anim...
		if (g_sLocalState.client.velocity.Length2D() < GetWalkSpeed() * 0.85f)
			RunStop();
		else if (m_iDisplayingAnim != WPNANIM_NUM(RUN_LOOP))
			WeaponAnim(&WPNANIM(RUN_LOOP), -1);
	}

	// remove all function if running.(aiming?!)
	if (IS_RUNNING || IS_AIMING)
		return;

	// get all buttons
	int bitsButtons = CL_GetButtonBits();

	// answer to ATTACK2 or withdraw sequence before ATTACK1.
	if ( (bitsButtons & IN_ATTACK2 && !IsUnrevokable())
		|| m_bInRevokeHolster || m_bInWithdrawal)
	{
		switch (m_iGrenadeStage)
		{
			// if we enter this stage due to m_bInRevokeHolster, it means we should enter the true holster phase now.
			case STAGE_IDLE:
				if (m_bInRevokeHolster)
				{
					m_ulStatus			|= WPN_FLAG_SHOULD_HOLSTER;
					m_bInRevokeHolster	= false;
					return;
				}
				break;

			// when we in this flag, it means that we just finished the plug in animation.
			// reset the flag and everything back to normal.
			case STAGE_PLUGPIN:
				m_iGrenadeStage = STAGE_IDLE;
				m_bInWithdrawal	= false;
				return;

			// pin out? don't worry, let's find it and plug it in.
			case STAGE_PULLPIN:
			// the REVOKE flag means that player just finished the revoke animation.
			case STAGE_REVOKE:
				PlugPin();
				return;

			// when charging or charged, anim of revoking charge should be played.
			case STAGE_CHARGING:
			case STAGE_CHARGED:
				Revoke();
				return;

			default:
				break;
		}

		// if ATTACK2 is pressed under any condition, no further action can be done.
		return;
	}

	// if IN_ATTACK is downed, try to get into CHARGED stage.
	// if player presse but quickly release the button, it should still be considered as a throwing.
	if (bitsButtons & IN_ATTACK || IsUprising())
	{
		switch (m_iGrenadeStage)
		{
			// idle should enter pull pin.
			case STAGE_IDLE:
				PullPin();
				return;
				
			// pull pin should enter charging.
			case STAGE_PULLPIN:
				Charging();
				return;

			// entering CHARGED stage, but not actually doing something, this flag is only for enabling spcifiy functions.
			case STAGE_CHARGING:
				m_iGrenadeStage = STAGE_CHARGED;
				break;

			default:
				break;
		}
	}

	// assuming player will throw this grenade.
	if (IsReadyThrowing() && !(bitsButtons & IN_ATTACK))
	{
		// start block checking now. if the grenade model origin is blocked, you cannot throw it.
		if (CheckBlocked())
			return;

		Throw();
		return;
	}

	// after pre-throwing animation. Signaling server to generate a grenade.
	// UNDONE ? post-note: this is already done in GrSpawn()
	if (m_iGrenadeStage == STAGE_THROW)
	{
		AMMUNITION --;

		// play the deploy anim, if there're still any grenade remains.
		if (AMMUNITION)
			ItemDeploy();	// STAGE reset is included.
	}

	// in replace of WeaponIdle(), part II
	if (m_iGrenadeStage == STAGE_IDLE && m_iDisplayingAnim != WPNANIM_NUM(IDLE))	// careful with this one if it's grenade.
		WeaponAnim(&WPNANIM(IDLE), -1);
}

void CBaseGrenade::Gr_ItemHolster(void)
{
	Def_ItemHolster();	// not require CBaseGrenade in the front, since we can cover Def_() in custom classes.

	m_bIsQuickThrow	= false;	// !!! this value can change the whole story !!! reset it to false every holster !!!

	// no grenade ammo == item should be removed.
	// UNTESTED, could be a potential bug.
	if (!AMMUNITION)
		ItemKill();
}
