/***

Modern Warfare Develop Team
Coder/Author: Luna the Reborn

Create Date: 2017/12

***/

#ifndef _LOAD_WPN_H_
#define _LOAD_WPN_H_

// for vector.
#include <vector>

#ifndef CSMW_SERVER_DLL

#include "cl_util.h"

#else

#include "extdll.h"

#endif

#include "newkeyvalues.h"
#include "vector.h"

/*
===================================

Constants definition

===================================
*/

#define	MAX_AMMOTYPE	128
#define MAX_WEAPONS		128
#define MAX_XMODELS		MAX_WEAPONS
#define MAX_SUBS		12
#define MAX_ACCESSORIES	64

#define NORMAL_CHARLEN	63
#define SHOT_CHARLEN	31

#define CSMW_FIREMODE_COUNT	5

/*
===================================

Load weapon utils

===================================
*/

#define RECORD_INT(kvd,var)			else if (!strcmp(p->GetName(), #kvd)) \
										##var = p->GetInt();

#define RECORD_FLOAT(kvd,var)		else if (!strcmp(p->GetName(), #kvd)) \
										##var = p->GetFloat();

#define RECORD_STRING(kvd,var)		else if (!strcmp(p->GetName(), #kvd)) \
										strncpy_s(##var, p->GetString(), _TRUNCATE);

#define RECORD_BOOL(kvd,var)		else if (!strcmp(p->GetName(), #kvd)) \
										##var = !!(strstr(p->GetString(), "true") || strstr(p->GetString(), "True") || strstr(p->GetString(), "TRUE") || p->GetInt() > 0);

#define RECORD_VECTOR(kvd,var)		else if (!strcmp(p->GetName(), #kvd)) \
										##var = GetVectorFromString(p->GetString());

#define RECORD_DOUBLE(kvd,var)		else if (!strcmp(p->GetName(), #kvd)) \
										##var = atof(p->GetString());

#define RECORD_ANIM_F(keyname,var)	else if (!strcmp(p->GetName(), #keyname)) \
										var.m_i = p->GetInt(); \
									else if (!strcmp(p->GetName(), "time_"#keyname"")) \
										var.m_fd = var.m_fe = p->GetFloat(); \
									else if (!strcmp(p->GetName(), "eft_"#keyname"")) \
										var.m_fe = p->GetFloat();

#define RECORD_ANIM_S(keyname,var)	else if (!strcmp(p->GetName(), #keyname)) \
										var.m_i = p->GetInt(); \
									else if (!strcmp(p->GetName(), "time_"#keyname"")) \
										var.m_fd = var.m_fe = p->GetFloat();

// anim utils
#define WPNANIM(x)		m_sAnims[WPN_COMMON_ANIM_##x]
#define WPNANIM_NUM(x)	m_sAnims[WPN_COMMON_ANIM_##x].m_i
#define WPNANIM_DUR(x)	m_sAnims[WPN_COMMON_ANIM_##x].m_fd
#define WPNANIM_EFT(x)	m_sAnims[WPN_COMMON_ANIM_##x].m_fe
#define QD_WPNANIM(x)		g_sItemData[m_iItemType].m_sDefaultAnims[WPN_COMMON_ANIM_##x]
#define QD_WPNANIM_NUM(x)	g_sItemData[m_iItemType].m_sDefaultAnims[WPN_COMMON_ANIM_##x].m_i
#define QD_WPNANIM_DUR(x)	g_sItemData[m_iItemType].m_sDefaultAnims[WPN_COMMON_ANIM_##x].m_fd
#define QD_WPNANIM_EFT(x)	g_sItemData[m_iItemType].m_sDefaultAnims[WPN_COMMON_ANIM_##x].m_fe

/*
===================================

database struct definition

===================================
*/

struct sXModels
{
	char	m_szModel[NORMAL_CHARLEN+1];
	int		m_iAmount;
};

typedef struct sAmmo
{
	// classical
	int			m_iType;
	float		m_flBulletWt;
	float		m_flProjectileWt;
	float		m_flDragCoefficient;
	double		m_flArea;
	char		m_szAmmoName[SHOT_CHARLEN + 1];
	char		m_szIcon[SHOT_CHARLEN + 1];
	wchar_t		m_wszEndoName[SHOT_CHARLEN + 1];
	unsigned	m_iIdAmmoIcons[CSMW_FIREMODE_COUNT];

	// about bullet hole.
	char		m_szHole[64];
	std::vector<int>	m_vHoleDecalId;

	// about shell.
	char		m_szShellModel[NORMAL_CHARLEN + 1];
	int			m_iShellBody;
	int			m_iShellSoundType;

	// for grenade rounds.
	float		m_flSafeDist;
	float		m_flRadius;
	float		m_flInitVel;	// REMEMBER: not for guns!!!
	float		m_flImpact;
	char		m_szExploSnd[NORMAL_CHARLEN + 1];

	// for hand grenades.
	float		m_flFuseTime;

} ammo_t;

typedef struct sMagazine
{
	int		m_iType;
	sAmmo	*m_pAmmoType;
	int		m_iClip;
	char	m_szName[SHOT_CHARLEN + 1];
} mag_t;

typedef struct sSight
{
	Vector	m_vecOfs;
	float	m_flFOV;
} sight_t;

typedef struct sRecoilData
{
	float up_base;
	float lateral_base;
	float up_modifier;
	float lateral_modifier;
	float up_max;
	float lateral_max;
	int direction_change;
} recdb_t;

typedef struct sWalkSpeed
{
	float	m_flWalkSpeed;
	float	m_flRunOfs;
	float	m_flAimOfs;
} walkspeed_t;

typedef struct sAnimData
{
	int		m_i;
	float	m_fd;
	float	m_fe;
} animdb_t;

enum WPN_ANIMLIST_e
{
	// Standard Weapons
	WPN_COMMON_ANIM_IDLE,
	WPN_COMMON_ANIM_SHOOT,
	WPN_COMMON_ANIM_AIM_SHOOT,
	WPN_COMMON_ANIM_AIM_SHOOT_2,
	WPN_COMMON_ANIM_AIM_SHOOT_3,
	WPN_COMMON_ANIM_RELOAD,
	WPN_COMMON_ANIM_RELOAD_EMPTY,
	WPN_COMMON_ANIM_DRAW,
	WPN_COMMON_ANIM_DRAW_FIRST,
	WPN_COMMON_ANIM_JUMP,
	WPN_COMMON_ANIM_VAULT,
	WPN_COMMON_ANIM_HOLSTER,
	WPN_COMMON_ANIM_RUN_START,
	WPN_COMMON_ANIM_RUN_LOOP,
	WPN_COMMON_ANIM_RUN_STOP,
	WPN_COMMON_ANIM_MELEE,
	WPN_COMMON_ANIM_SELECTOR_A,
	WPN_COMMON_ANIM_SELECTOR_B,
	WPN_COMMON_ANIM_BLOCK_UP,
	WPN_COMMON_ANIM_BLOCK_IDLE,
	WPN_COMMON_ANIM_BLOCK_DOWN,
	WPN_COMMON_ANIM_HAND_UP,
	WPN_COMMON_ANIM_HAND_DOWN,
	WPN_COMMON_ANIM_PRONE_IN,
	WPN_COMMON_ANIM_PRONE_IDLE,
	WPN_COMMON_ANIM_PRONE_MOVE_IN,
	WPN_COMMON_ANIM_PRONE_MOVE,
	WPN_COMMON_ANIM_PRONE_MOVE_OUT,
	WPN_COMMON_ANIM_PRONE_OUT,

	// Pistols
	WPN_COMMON_ANIM_SHOOT_LAST,
	WPN_COMMON_ANIM_AIM_SHOOT_LAST,

	// Shotguns and Snipers
	WPN_COMMON_ANIM_START_RELOAD,
	WPN_COMMON_ANIM_AFTER_RELOAD,
	WPN_COMMON_ANIM_RECHAMBER,

	// Grenades and Throwables
	WPN_COMMON_ANIM_PULLPIN,
	WPN_COMMON_ANIM_PLUGPIN,
	WPN_COMMON_ANIM_CHARGING,
	WPN_COMMON_ANIM_REVOKE,
	WPN_COMMON_ANIM_THROW,
	WPN_COMMON_ANIM_QUICKPULLPIN,
	WPN_COMMON_ANIM_QUICKTHROW,
	
	// Compatible with old weapons
	WPN_COMMON_ANIM_AIM_UP,
	WPN_COMMON_ANIM_AIM_IDLE,
	WPN_COMMON_ANIM_AIM_DOWN,

	WPN_STANDARD_ANIM_COUNTS
};

// special names, but which can replace by normal enum.
#define WPN_COMMON_ANIM_INSERT				WPN_COMMON_ANIM_RELOAD
#define WPN_COMMON_ANIM_RELOAD_LOOP			WPN_COMMON_ANIM_RELOAD
#define WPN_COMMON_ANIM_AFTER_RELOAD_EMPTY	WPN_COMMON_ANIM_RELOAD_EMPTY
#define WPN_COMMON_ANIM_PUMP				WPN_COMMON_ANIM_RECHAMBER

typedef enum
{
	AS_NONE = 0,

	// for normal guns
	AS_MUZZLE,
	AS_BARREL,
	AS_FOREARM,
	AS_FOREGRIP,
	AS_GADGET,
	AS_FRONT_SIGHT,
	AS_OPTICAL_SIGHT,
	AS_REAR_SIGHT,
	AS_UPPER_RECEIVER,
	AS_LOWER_RECEIVER,
	AS_GRIP,
	AS_ACTION,
	AS_TRIGGER,
	AS_MAGAZINE,
	AS_STOCK,

	// for bullpup guns
	AS_BUTT,

	// for pistols
	AS_SLIDE,

	// for bolt-action rifles
	AS_BOLT,
	AS_CHAMBER,

	ACCESSORY_SLOTS_COUNT

} ACCESSORY_SLOTS;

typedef struct sAccessory
{
	int				m_iType;
	ACCESSORY_SLOTS	m_iSlot;
	char			m_szName[64];
	char			m_szHUDName[64];
	char			m_szCustomData[128];

} acc_t;

struct sItem
{
	// classical AMX members.
	int		m_iChamberClip;
	int		m_iSlot;						// cant set
	char	m_szBodyAnim[NORMAL_CHARLEN+1];
	bool	m_bSingleShoot;
	float	m_flInitVel;
	int		m_iMultiFiredBullets;
	int		m_iLimitWaterLevel;
	int		m_iGunFlash;
	int		m_iGunVolume;
	int		m_iPWSubModel;
	int		m_iEffectiveAngle;
	int		m_iEffectiveRange;
	int		m_iZoomRange[2];
	
	float	m_flNextPriAttack;
	float	m_flNextSedAttack;
	float	m_flGravity;
	float	m_flSoundAttenuation;
	float	m_flBulletSpin;
	float	m_flTwist;
	float	m_flBarrelLength;

	// make CS model compatible
	bool	m_bReverseVMDL;

	// for some model...
	bool	m_bUseCodeRun;

	// integrated struct.
	walkspeed_t	m_sWalkSpeed;
	animdb_t	m_sDefaultAnims[WPN_STANDARD_ANIM_COUNTS];
	animdb_t	m_sSingleHandAnims[WPN_STANDARD_ANIM_COUNTS];
	
	// classical AMX string members.
	char m_szViewModel[NORMAL_CHARLEN+1];
	char m_szWorldModel[NORMAL_CHARLEN+1];
	char m_szPersonModel[NORMAL_CHARLEN+1];
	char m_szShootingSound[NORMAL_CHARLEN+1];
	char m_szSilencerSound[NORMAL_CHARLEN+1];
	char m_szDryFireSound[NORMAL_CHARLEN+1];
	char m_szClassname[NORMAL_CHARLEN+1];			// cant set

	sRecoilData m_srJumping;
	sRecoilData m_srMoving;
	sRecoilData m_srDucking;
	sRecoilData m_srOtherwise;

	// acc.
	int		m_iaAvailableAcc[MAX_ACCESSORIES];
	int		m_iAvailableAccCount;
	sight_t m_sSteelSt;
	sight_t	m_sRedDot;
	sight_t m_sHolo;
	sight_t m_sACOG;
	sight_t m_sRound;

	Vector	m_vecSHOFS;

	// mag/ammunition
	const mag_t		*m_pMagDB;
	const ammo_t	*m_pAmmoDB;

	// HUD relatated.
	wchar_t		m_wszEndoName[64];
	unsigned	m_iIdWeaponIcon;
	char		m_szScopeName[32];
	unsigned	m_iIdScope;
	int			m_iScopeCrosshairSize[2];
	char		m_szScopeShadowName[32];
	unsigned	m_iIdScopeShadow;

	// custom loading after def loading
	void	(*Initialize)		(NewKeyValues *pRoot, int iType);

#ifdef CSMW_SERVER_DLL
	void	(*ItemAddToPlayer)	(void *pPlayer, int iType);
	void	(*ItemDeploy)		(void *pPlayer, int iType);
	void	(*ItemPostFrame)	(void *pPlayer, int iType);
	void	(*PrimaryAttack)	(void *pPlayer, int iType, Vector vecSrc, Vector vecAngle, float flAimBaseline);
	void	(*SecondaryAttack)	(void *pPlayer, int iType);
	void	(*WeaponReload)		(void *pPlayer, int iType);
	void	(*Holster)			(void *pPlayer, int iType);
	void	(*ItemDropped)		(void *pPlayer, int iType);
	void	(*ItemKill)			(void *pPlayer, int iType);

	void	(*ChangeMode)		(void *pPlayer, int iType);
	void	(*ProjectileSpawn)	(void *pPlayer, int iType);
#endif
};

/*
===================================

Vars and funcs

===================================
*/

extern sAmmo		g_sAmmoData[MAX_AMMOTYPE];
extern sItem		g_sItemData[MAX_WEAPONS + MAX_SUBS];
extern sXModels		g_sXModelsData[MAX_XMODELS];
extern sMagazine	g_sMagData[MAX_WEAPONS];
extern sAccessory	g_sAccData[MAX_ACCESSORIES];
extern int			g_iAmmoTypes;
extern int			g_iItemTypes;
extern int			g_iXModels;
extern int			g_iMagTypes;
extern int			g_iSubsTypes;
extern int			g_iAccTypes;

int GetWeaponTypeFromName	(const char *szWords);
int FindAmmoTypeByName		(const char *szName);
int SearchMagTypeViaName	(const char *szName);

void InitializeWpnDB	( void );
void LoadDirectory		( void );

// export some loading funcs for custom init funcs.
void LoadWeaponRecoil(NewKeyValues *pRoot, sRecoilData *pdb);
void LoadWeaponSight(NewKeyValues *pRoot, sSight *pdb, const char *szKey);
int ChangeIntoVolume(const char *sz);
int ChangeIntoFlashLevel(const char *sz);
inline double ChangeSoundRangeIntoAttenuation(double flRange);

/*
===================================

Link a class to a script weapon

===================================
*/
#define LINK_FUNCTION_FOR_INIT(name, function)	else if (!strcmp(szName, #name))	\
													g_sItemData[iType].Initialize	= function

/*
===================================

items for server.dll only.

===================================
*/

#ifdef CSMW_SERVER_DLL

#define Q_PRECACHE_MODEL(x)	if (strlen(x) > 0) \
								PRECACHE_MODEL(x);
#define Q_PRECACHE_SOUND(x)	if (strlen(x) > 0) \
								PRECACHE_SOUND(x);

void LoadPrecacheModels(void);

#endif




































#endif