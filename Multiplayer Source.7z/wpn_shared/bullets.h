#ifndef _BULLETS_H_
#define _BULLETS_H_

#include "loadwpn.h"

#define PENETRATE_STEPS	25.0f
#define PENETRATE_MAX	101.0f

#define PENETRATE_K_REQ	900.0		// how many energy require to penetrate a 1m wall ?
#define BOUNCE_EK_REQ	200.0
#define STUCK_EK_REQ	2.1125

#define DENSITY_WATER	1000.0	// kg/m^3
#define DENSITY_AIR		1.293	// kg/m^3
#define DENSITY_LAVA	3100.0	// kg/m^3

#define GRAV_ACC		-9.80665	// m/s^2

#define L_KINETIC_DECAY	// per meter
#define A_KINETIC_DECAY	// per meter

typedef class CBaseBullets
{
public:
	static Vector	s_vecHullMaxs;
	static Vector	s_vecHullMins;

public:
	CBaseBullets(void);
	virtual ~CBaseBullets(void);

public:
	Vector	m_vecLastOrigin;	// inches
	Vector	m_vecOrigin;		// inches
	Vector	m_vecLastHit;		// inches
	VecDbl	m_vecForce;			// N = kg*m/s^2
	VecDbl	m_vecVelocity;		// m/s
	VecDbl	m_vecAcceleration;	// m/s^2
	
	color24			m_sColor;
	const ammo_t	*m_pAmmo;	// in kg
	sItem			*m_pItem;
	CBasePlayer		*m_pPlayer;
	bool			m_bRemove;
	int				m_iHitCount;
	double			m_flSpin;	// in Hz

	CBaseBullets	*m_pNext;

public:
	virtual	void	Think		( double flFrameRate );
	virtual void	ChainThink	( double flFrameRate );

public:
	inline	double	GetLinearKinetic	( void )	{ return 0.5 * m_pAmmo->m_flProjectileWt * DotProduct(m_vecVelocity, m_vecVelocity);	}

	inline	void	ReduceLinearKinetic	( double number );	//{ m_vecVelocity = m_vecVelocity.SetLength(sqrt(max( (GetLinearKinetic() - number) * 2.0 / m_pAmmo->m_flProjectileWt, 0) ) );	}

} bullet_t;

extern CBaseBullets	*g_pBulletsRoot;

void CheckBulletsChain(void);
void UTIL_GunShotEfx(TraceResult *pTrace, Vector vecSrc, int iWeaponType = 0);


















































#endif