/***

Modern Warfare Develop Team
Coder/Author: Luna the Reborn

Create Date: 2017/12

***/

#include <sysdef.h>
#include "loadwpn.h"
#include "newkeyvalues.h"

#ifndef CSMW_SERVER_DLL

#include "hud.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "dxt.h"

#else

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "weapons.h"
extern enginefuncs_t g_engfuncs;

#endif

int g_iAmmoTypes	= 0;
int g_iItemTypes	= 0;
int g_iXModels		= 0;
int g_iMagTypes		= 0;
int g_iSubsTypes	= 0;
int	g_iAccTypes		= 0;

sAmmo		g_sAmmoData[MAX_AMMOTYPE];
sItem		g_sItemData[MAX_WEAPONS + MAX_SUBS];
sXModels	g_sXModelsData[MAX_XMODELS];
sMagazine	g_sMagData[MAX_WEAPONS];
sAccessory	g_sAccData[MAX_ACCESSORIES];

/*
===================================

Init func

===================================
*/

void InitializeWpnDB(void)
{
	g_iAmmoTypes	= 0;
	g_iItemTypes	= 0;
	g_iXModels		= 0;
	g_iMagTypes		= 0;
	g_iSubsTypes	= 0;
	g_iAccTypes		= 0;

	memset(g_sAmmoData,		NULL,	sizeof(g_sAmmoData));
	memset(g_sItemData,		NULL,	sizeof(g_sItemData));
	memset(g_sXModelsData,	NULL,	sizeof(g_sXModelsData));
	memset(g_sMagData,		NULL,	sizeof(g_sMagData));
	memset(g_sAccData,		NULL,	sizeof(g_sAccData));
}

/*
===================================

Search Database

===================================
*/

int GetWeaponTypeFromName(const char *szWords)
{
	for (int i = 1; i <= g_iItemTypes; i ++)
		if (!strcmp(g_sItemData[i].m_szClassname, szWords))
			return i;
	
	return 0;
}

int FindAmmoTypeByName(const char *szName)
{
	for (int i = 1; i <= g_iAmmoTypes; i ++)
		if (!strcmp(szName, g_sAmmoData[i].m_szAmmoName))
			return i;

	return 0;
}

int SearchMagTypeViaName(const char *szName)
{
	for (int i = 1; i <= g_iMagTypes; i ++)
		if (!strcmp(szName, g_sMagData[i].m_szName))
			return i;

	return 0;
}

int LoopupSubsTypeInSeqs(const char *szName)
{
	for (int i = g_iItemTypes + 1; i <= g_iSubsTypes; i ++)
		if (!strcmp(g_sItemData[i].m_szClassname, szName))
			return i;

	return 0;
}

int TranslateAccNameIntoIndex(const char *szName)
{
	for (int i = 1; i <= g_iAccTypes; i ++)
		if (!strcmp(szName, g_sAccData[i].m_szName))
			return i;

	return 0;
}

/*
===================================

Loading Utils

===================================
*/

#define LOUD_GUN_VOLUME		1000
#define NORMAL_GUN_VOLUME	600
#define QUIET_GUN_VOLUME	200

#define BRIGHT_GUN_FLASH	512
#define NORMAL_GUN_FLASH	256
#define DIM_GUN_FLASH		128

#define BIG_EXPLOSION_VOLUME	2048
#define NORMAL_EXPLOSION_VOLUME	1024
#define SMALL_EXPLOSION_VOLUME	512

#define WEAPON_ACTIVITY_VOLUME	64

int ChangeIntoVolume(const char *sz)
{
	if (!strcmp(sz, "LOUD_GUN_VOLUME"))
		return LOUD_GUN_VOLUME;
	else if (!strcmp(sz, "NORMAL_GUN_VOLUME"))
		return NORMAL_GUN_VOLUME;
	else if (!strcmp(sz, "QUIET_GUN_VOLUME"))
		return QUIET_GUN_VOLUME;
	else if (!strcmp(sz, "BIG_EXPLOSION_VOLUME"))
		return BIG_EXPLOSION_VOLUME;
	else if (!strcmp(sz, "NORMAL_EXPLOSION_VOLUME"))
		return NORMAL_EXPLOSION_VOLUME;
	else if (!strcmp(sz, "SMALL_EXPLOSION_VOLUME"))
		return SMALL_EXPLOSION_VOLUME;
	else if (!strcmp(sz, "WEAPON_ACTIVITY_VOLUME"))
		return WEAPON_ACTIVITY_VOLUME;

	return NULL;
}

int ChangeIntoFlashLevel(const char *sz)
{
	if (!strcmp(sz, "BRIGHT_GUN_FLASH"))
		return BRIGHT_GUN_FLASH;
	else if (!strcmp(sz, "NORMAL_GUN_FLASH"))
		return NORMAL_GUN_FLASH;
	else if (!strcmp(sz, "DIM_GUN_FLASH"))
		return DIM_GUN_FLASH;

	return atoi(sz);
}

inline double ChangeSoundRangeIntoAttenuation(double flRange)
{
	if (flRange <= 1345.0)
		return 10.67692969 - 1.306511461 * log(flRange);

	return 3.450988798 * pow(2.718281828459, -0.000746379065 * flRange);
}

/*
===================================

Load Ammunition

===================================
*/

void SetupAmmunition(NewKeyValues *pRoot, int iType)
{
	if (!pRoot || iType >= MAX_AMMOTYPE || iType <= 0)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_STRING	(name,			g_sAmmoData[iType].m_szAmmoName)
		RECORD_STRING	(type,			g_sAmmoData[iType].m_szIcon)
		RECORD_FLOAT	(bulletwt,		g_sAmmoData[iType].m_flBulletWt)
		RECORD_FLOAT	(mass,			g_sAmmoData[iType].m_flProjectileWt)
		RECORD_FLOAT	(dragcoef,		g_sAmmoData[iType].m_flDragCoefficient)
		RECORD_DOUBLE	(area,			g_sAmmoData[iType].m_flArea)
		RECORD_STRING	(hole,			g_sAmmoData[iType].m_szHole)

		RECORD_STRING	(shellmdl,		g_sAmmoData[iType].m_szShellModel)
		RECORD_INT		(shellbody,		g_sAmmoData[iType].m_iShellBody)
		RECORD_INT		(shellsnd,		g_sAmmoData[iType].m_iShellSoundType)

		RECORD_FLOAT	(safe,			g_sAmmoData[iType].m_flSafeDist)
		RECORD_FLOAT	(range,			g_sAmmoData[iType].m_flRadius)
		RECORD_FLOAT	(initvel,		g_sAmmoData[iType].m_flInitVel)
		RECORD_FLOAT	(explo_knock,	g_sAmmoData[iType].m_flImpact)
		RECORD_STRING	(explo_sound,	g_sAmmoData[iType].m_szExploSnd)

		RECORD_FLOAT	(fusetime,		g_sAmmoData[iType].m_flFuseTime)

		p = p->GetNextValue();
	}

	g_sAmmoData[iType].m_flSafeDist		/= 0.0254f;	// meters to inches
	g_sAmmoData[iType].m_flRadius		/= 0.0254f;
	g_sAmmoData[iType].m_flInitVel		/= 0.0254f;

	g_sAmmoData[iType].m_iType = iType;
	wcsncpy_s( g_sAmmoData[iType].m_wszEndoName, UTF8ToUnicode(pRoot->GetName()), _TRUNCATE );
}

void LoadAmmunition(NewKeyValues *pRoot)
{
	if (!pRoot)
		return;

	NewKeyValues	*pSubKey	= pRoot->GetFirstSubKey();
	NewKeyValues	*p			= NULL;
	int				iType		= 0;

	// ammo
	while (pSubKey)
	{
		if ( (p = pSubKey->FindKey("name")) )
			iType = FindAmmoTypeByName(p->GetString());
		else
			iType = -1;	// negative number means it doesn't input a suitable name

		if (!iType)
		{
			if (g_iAmmoTypes >= MAX_AMMOTYPE)
				break;

			SetupAmmunition(pSubKey, ++g_iAmmoTypes);
		}
		else if (iType < 0)
			return;
		else
			SetupAmmunition(pSubKey, iType);

		pSubKey = pSubKey->GetNextKey();
	}
}

/*
===================================

Load Magazine

===================================
*/

void SetupMagazine(NewKeyValues *pRoot, int iType)
{
	if (!pRoot || iType >= MAX_WEAPONS || iType <= 0)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_INT		(clip,	g_sMagData[iType].m_iClip)

		else if (!strcmp(p->GetName(), "ammo"))
			g_sMagData[iType].m_pAmmoType	= &g_sAmmoData[FindAmmoTypeByName(p->GetString())];

		p = p->GetNextValue();
	}

	// mag's name is the typename.
	strcpy(g_sMagData[iType].m_szName, pRoot->GetName());

	// magtype
	g_sMagData[iType].m_iType = iType;
}

void LoadMagazine(NewKeyValues *pRoot)
{
	if (!pRoot)
		return;

	NewKeyValues	*pSubKey	= pRoot->GetFirstSubKey();
	NewKeyValues	*p			= NULL;
	int				iType		= 0;

	// ammo
	while (pSubKey)
	{
		if ( (p = pSubKey->FindKey("name")) )
			iType = SearchMagTypeViaName(p->GetString());

		if (!iType)
		{
			if (g_iMagTypes >= MAX_WEAPONS)
				break;

			SetupMagazine(pSubKey, ++g_iMagTypes);
		}
		else
			SetupMagazine(pSubKey, iType);

		pSubKey = pSubKey->GetNextKey();
	}
}

/*
===================================

Load X Models

===================================
*/

void LoadXModels(NewKeyValues *pRoot)
{
	if (!pRoot || g_iXModels >= MAX_XMODELS)
		return;

	NewKeyValues *pValue = pRoot->GetFirstValue();

	while (pValue)
	{
		bool bSkip = false;

		for (int i = 0; i < g_iXModels; i ++)
		{
			if (!strcmp(g_sXModelsData[i].m_szModel, pValue->GetName()))
			{
				g_sXModelsData[i].m_iAmount = pValue->GetInt();
				bSkip = true;
				break;
			}
		}

		if (bSkip)
		{
			pValue = pValue->GetNextValue();
			continue;
		}

		strcpy(g_sXModelsData[g_iXModels].m_szModel, pValue->GetName());
		g_sXModelsData[g_iXModels].m_iAmount = pValue->GetInt();

		g_iXModels ++;	// starts from 0, stop at g_iXModels - 1
		if (g_iXModels >= MAX_XMODELS)
			break;

		pValue = pValue->GetNextValue();
	}
}

/*
===================================

Load Items

===================================
*/

void SetupCustomInitialization(const char *szName, int iType)
{
#ifdef CSMW_SERVER_DLL
	g_sItemData[iType].ItemAddToPlayer	= gWpnHandler::ItemAddToPlayer;
	g_sItemData[iType].ItemDeploy		= gWpnHandler::ItemDeploy;
	g_sItemData[iType].PrimaryAttack	= gWpnHandler::PrimaryAttack;
	g_sItemData[iType].WeaponReload		= gWpnHandler::WeaponReload;
	g_sItemData[iType].Holster			= gWpnHandler::Holster;
	g_sItemData[iType].ItemDropped		= gWpnHandler::ItemDropped;
	g_sItemData[iType].ItemKill			= gWpnHandler::ItemKill;

	g_sItemData[iType].ProjectileSpawn	= gWpnHandler::ProjectileSpawn;
#endif

	if (FALSE)	// useless, just a start mark.
		return;	// then you can use LINK_FUNCTION_FOR_INIT on below.
				// BTW, you need to set your other function inside the customized initialize func.

	LINK_FUNCTION_FOR_INIT(wpn_knife,		CKnife::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_arc3,		CARC3::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_m203,		CM203::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_hl_gauss,	CGauss::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_rpg7,		CRPG7::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_xm29,		CXM29::Initialize);

#ifndef CSMW_SERVER_DLL
	LINK_FUNCTION_FOR_INIT(wpn_m1014,		CM1014::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_xm26,		CXM26::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_m870mcs,		CM870MCS::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_msr,			CMSR::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_ar15custom,	CAR15::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_acr,			CMasada::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_mk46,		CMK46::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_cm901,		CCM901::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_93r,			C93R::Initialize);
	LINK_FUNCTION_FOR_INIT(wpn_an94,		CAN94::Initialize);
#endif
}

static animdb_t	*s_pCurrentWriting = NULL;

#undef WPNANIM
#undef WPNANIM_NUM
#undef WPNANIM_DUR
#undef WPNANIM_EFT

#define WPNANIM(x)		s_pCurrentWriting[WPN_COMMON_ANIM_##x]
#define WPNANIM_NUM(x)	s_pCurrentWriting[WPN_COMMON_ANIM_##x].m_i
#define WPNANIM_DUR(x)	s_pCurrentWriting[WPN_COMMON_ANIM_##x].m_fd
#define WPNANIM_EFT(x)	s_pCurrentWriting[WPN_COMMON_ANIM_##x].m_fe

#undef RECORD_ANIM_F
#undef RECORD_ANIM_S

#define RECORD_ANIM_F(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_pCurrentWriting[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_pCurrentWriting[##enumname].m_fd = s_pCurrentWriting[##enumname].m_fe = p->GetFloat(); \
											else if (!strcmp(p->GetName(), "eft_"#keyname"")) \
												s_pCurrentWriting[##enumname].m_fe = p->GetFloat()

#define RECORD_ANIM_S(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_pCurrentWriting[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_pCurrentWriting[##enumname].m_fd = s_pCurrentWriting[##enumname].m_fe = p->GetFloat()
// Don't input "single_" again.
#define RECORD_SHANIM_F(keyname,enumname)	else if (!strcmp(p->GetName(), "single_"#keyname"")) \
												g_sItemData[iType].m_sSingleHandAnims[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_single_"#keyname"")) \
												g_sItemData[iType].m_sSingleHandAnims[##enumname].m_fd = g_sItemData[iType].m_sSingleHandAnims[##enumname].m_fe = p->GetFloat(); \
											else if (!strcmp(p->GetName(), "eft_single_"#keyname"")) \
												g_sItemData[iType].m_sSingleHandAnims[##enumname].m_fe = p->GetFloat()

#define RECORD_SHANIM_S(keyname,enumname)	else if (!strcmp(p->GetName(), "single_"#keyname"")) \
												g_sItemData[iType].m_sSingleHandAnims[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_single_"#keyname"")) \
												g_sItemData[iType].m_sSingleHandAnims[##enumname].m_fd = g_sItemData[iType].m_sSingleHandAnims[##enumname].m_fe = p->GetFloat()

void RationalizeCurrentAnimSet(void)
{
	// for loop anims, time is useless
	WPNANIM_DUR(IDLE) = WPNANIM_EFT(IDLE) = 9999.0f;
	WPNANIM_DUR(RUN_LOOP) = WPNANIM_EFT(RUN_LOOP) = 9999.0f;
	WPNANIM_DUR(AIM_IDLE) = WPNANIM_EFT(AIM_IDLE) = 9999.0f;

	// arrange replacements for the absences.
	if (WPNANIM_NUM(DRAW_FIRST) <= 0)
		WPNANIM(DRAW_FIRST) = WPNANIM(DRAW);
	if (WPNANIM_NUM(RELOAD_EMPTY) <= 0)
		WPNANIM(RELOAD_EMPTY) = WPNANIM(RELOAD);
	if (WPNANIM_NUM(AIM_IDLE) <= 0)
		WPNANIM(AIM_IDLE) = WPNANIM(IDLE);
	if (WPNANIM_NUM(AIM_SHOOT) <= 0)
		WPNANIM(AIM_SHOOT) = WPNANIM(SHOOT);
	if (WPNANIM_NUM(AIM_SHOOT_2) <= 0)
		WPNANIM(AIM_SHOOT_2) = WPNANIM(AIM_SHOOT);
	if (WPNANIM_NUM(AIM_SHOOT_3) <= 0)
		WPNANIM(AIM_SHOOT_3) = WPNANIM(AIM_SHOOT);
	if (WPNANIM_NUM(SELECTOR_A) <= 0 && WPNANIM_NUM(SELECTOR_B) > 0)
		WPNANIM(SELECTOR_A) = WPNANIM(SELECTOR_B);
	if (WPNANIM_NUM(SELECTOR_B) <= 0 && WPNANIM_NUM(SELECTOR_A) > 0)
		WPNANIM(SELECTOR_B) = WPNANIM(SELECTOR_B);
}

void LoadWeaponAnims(NewKeyValues *pRoot, int iType)
{
	if (!pRoot)
		return;

	// setup for default writing target.
	s_pCurrentWriting = g_sItemData[iType].m_sDefaultAnims;

	NewKeyValues *p = pRoot->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		// Standard Weapons
		RECORD_ANIM_S(idle,				WPN_COMMON_ANIM_IDLE);
		RECORD_ANIM_S(shoot,			WPN_COMMON_ANIM_SHOOT);
		RECORD_ANIM_S(aim_shoot,		WPN_COMMON_ANIM_AIM_SHOOT);
		RECORD_ANIM_S(aim_shoot_2,		WPN_COMMON_ANIM_AIM_SHOOT_2);
		RECORD_ANIM_S(aim_shoot_3,		WPN_COMMON_ANIM_AIM_SHOOT_3);
		RECORD_ANIM_F(reload,			WPN_COMMON_ANIM_RELOAD);
		RECORD_ANIM_F(reload_full,		WPN_COMMON_ANIM_RELOAD_EMPTY);
		RECORD_ANIM_S(draw,				WPN_COMMON_ANIM_DRAW);
		RECORD_ANIM_S(draw_first,		WPN_COMMON_ANIM_DRAW_FIRST);
		RECORD_ANIM_S(jump,				WPN_COMMON_ANIM_JUMP);
		RECORD_ANIM_S(vault,			WPN_COMMON_ANIM_VAULT);
		RECORD_ANIM_S(holster,			WPN_COMMON_ANIM_HOLSTER);
		RECORD_ANIM_S(runstart,			WPN_COMMON_ANIM_RUN_START);
		RECORD_ANIM_S(runloop,			WPN_COMMON_ANIM_RUN_LOOP);
		RECORD_ANIM_S(runstop,			WPN_COMMON_ANIM_RUN_STOP);
		RECORD_ANIM_S(melee,			WPN_COMMON_ANIM_MELEE);
		RECORD_ANIM_S(selector,			WPN_COMMON_ANIM_SELECTOR_A);
		RECORD_ANIM_S(selector_A,		WPN_COMMON_ANIM_SELECTOR_A);
		RECORD_ANIM_S(selector_B,		WPN_COMMON_ANIM_SELECTOR_B);
		RECORD_ANIM_S(block_up,			WPN_COMMON_ANIM_BLOCK_UP);
		RECORD_ANIM_S(block_idle,		WPN_COMMON_ANIM_BLOCK_IDLE);
		RECORD_ANIM_S(block_down,		WPN_COMMON_ANIM_BLOCK_DOWN);
		RECORD_ANIM_S(hand_up,			WPN_COMMON_ANIM_HAND_UP);
		RECORD_ANIM_S(hand_down,		WPN_COMMON_ANIM_HAND_DOWN);
		RECORD_ANIM_S(prone_in,			WPN_COMMON_ANIM_PRONE_IN);
		RECORD_ANIM_S(prone_idle,		WPN_COMMON_ANIM_PRONE_IDLE);
		RECORD_ANIM_S(prone_move_in,	WPN_COMMON_ANIM_PRONE_MOVE_IN);
		RECORD_ANIM_S(prone_move,		WPN_COMMON_ANIM_PRONE_MOVE);
		RECORD_ANIM_S(prone_move_out,	WPN_COMMON_ANIM_PRONE_MOVE_OUT);
		RECORD_ANIM_S(prone_out,		WPN_COMMON_ANIM_PRONE_OUT);
			
		// Pistols
		RECORD_ANIM_S(shoot_last,		WPN_COMMON_ANIM_SHOOT_LAST);
		RECORD_ANIM_S(aim_shoot_last,	WPN_COMMON_ANIM_AIM_SHOOT_LAST);

		// Shotguns and Snipers
		RECORD_ANIM_S(reload_start,	WPN_COMMON_ANIM_START_RELOAD);
		RECORD_ANIM_S(insert,		WPN_COMMON_ANIM_INSERT);
		RECORD_ANIM_S(reload_loop,	WPN_COMMON_ANIM_RELOAD_LOOP);
		RECORD_ANIM_S(reload_end,	WPN_COMMON_ANIM_AFTER_RELOAD);
		RECORD_ANIM_S(reload_pump,	WPN_COMMON_ANIM_AFTER_RELOAD_EMPTY);
		RECORD_ANIM_S(rechamber,	WPN_COMMON_ANIM_RECHAMBER);
		RECORD_ANIM_S(pump,			WPN_COMMON_ANIM_PUMP);

		// Grenades and Throwables
		RECORD_ANIM_S(pullpin,			WPN_COMMON_ANIM_PULLPIN);
		RECORD_ANIM_S(plugpin,			WPN_COMMON_ANIM_PLUGPIN);
		RECORD_ANIM_S(charging,			WPN_COMMON_ANIM_CHARGING);
		RECORD_ANIM_S(revoke,			WPN_COMMON_ANIM_REVOKE);
		RECORD_ANIM_F(throw,			WPN_COMMON_ANIM_THROW);
		RECORD_ANIM_S(quick_pullpin,	WPN_COMMON_ANIM_QUICKPULLPIN);
		RECORD_ANIM_F(quick_throw,		WPN_COMMON_ANIM_QUICKTHROW);

		// Compatible with old weapons
		RECORD_ANIM_S(aim_up,	WPN_COMMON_ANIM_AIM_UP);
		RECORD_ANIM_S(aim_idle,	WPN_COMMON_ANIM_AIM_IDLE);
		RECORD_ANIM_S(aim_down,	WPN_COMMON_ANIM_AIM_DOWN);

		p = p->GetNextValue();
	}

	// fill in blanks ...??
	RationalizeCurrentAnimSet();

	// copy to SH anims, as their default anims' set.
	// don't do it now, since we haven't rationlize it yet.
	//memcpy_s(g_sItemData[iType].m_sSingleHandAnims, sizeof(g_sItemData[iType].m_sSingleHandAnims), g_sItemData[iType].m_sAnims, sizeof(g_sItemData[iType].m_sAnims));

	// processing SH anim set.
	s_pCurrentWriting = g_sItemData[iType].m_sSingleHandAnims;

	// then read in & override, start over again.
	p = pRoot->GetFirstValue();

	while (p)
	{
		if (!strstr(p->GetName(), "single_"))
			goto LAB_LOADWPN_SH_CONTINUE;

		// Standard Weapons
		RECORD_SHANIM_S(idle,			WPN_COMMON_ANIM_IDLE);
		RECORD_SHANIM_S(shoot,			WPN_COMMON_ANIM_SHOOT);
		RECORD_SHANIM_S(aim_shoot,		WPN_COMMON_ANIM_AIM_SHOOT);
		RECORD_SHANIM_S(aim_shoot_2,	WPN_COMMON_ANIM_AIM_SHOOT_2);
		RECORD_SHANIM_S(aim_shoot_3,	WPN_COMMON_ANIM_AIM_SHOOT_3);
		RECORD_SHANIM_F(reload,			WPN_COMMON_ANIM_RELOAD);
		RECORD_SHANIM_F(reload_full,	WPN_COMMON_ANIM_RELOAD_EMPTY);
		RECORD_SHANIM_S(draw,			WPN_COMMON_ANIM_DRAW);
		RECORD_SHANIM_S(draw_first,		WPN_COMMON_ANIM_DRAW_FIRST);
		RECORD_SHANIM_S(jump,			WPN_COMMON_ANIM_JUMP);
		RECORD_SHANIM_S(vault,			WPN_COMMON_ANIM_VAULT);
		RECORD_SHANIM_S(holster,		WPN_COMMON_ANIM_HOLSTER);
		RECORD_SHANIM_S(runstart,		WPN_COMMON_ANIM_RUN_START);
		RECORD_SHANIM_S(runloop,		WPN_COMMON_ANIM_RUN_LOOP);
		RECORD_SHANIM_S(runstop,		WPN_COMMON_ANIM_RUN_STOP);
		RECORD_SHANIM_S(melee,			WPN_COMMON_ANIM_MELEE);
		RECORD_SHANIM_S(selector,		WPN_COMMON_ANIM_SELECTOR_A);
		RECORD_SHANIM_S(selector_A,		WPN_COMMON_ANIM_SELECTOR_A);
		RECORD_SHANIM_S(selector_B,		WPN_COMMON_ANIM_SELECTOR_B);
		RECORD_SHANIM_S(block_up,		WPN_COMMON_ANIM_BLOCK_UP);
		RECORD_SHANIM_S(block_idle,		WPN_COMMON_ANIM_BLOCK_IDLE);
		RECORD_SHANIM_S(block_down,		WPN_COMMON_ANIM_BLOCK_DOWN);
		RECORD_SHANIM_S(hand_up,		WPN_COMMON_ANIM_HAND_UP);
		RECORD_SHANIM_S(hand_down,		WPN_COMMON_ANIM_HAND_DOWN);
		RECORD_SHANIM_S(prone_in,		WPN_COMMON_ANIM_PRONE_IN);
		RECORD_SHANIM_S(prone_idle,		WPN_COMMON_ANIM_PRONE_IDLE);
		RECORD_SHANIM_S(prone_move_in,	WPN_COMMON_ANIM_PRONE_MOVE_IN);
		RECORD_SHANIM_S(prone_move,		WPN_COMMON_ANIM_PRONE_MOVE);
		RECORD_SHANIM_S(prone_move_out,	WPN_COMMON_ANIM_PRONE_MOVE_OUT);
		RECORD_SHANIM_S(prone_out,		WPN_COMMON_ANIM_PRONE_OUT);
			
		// Pistols
		RECORD_SHANIM_S(shoot_last,		WPN_COMMON_ANIM_SHOOT_LAST);
		RECORD_SHANIM_S(aim_shoot_last,	WPN_COMMON_ANIM_AIM_SHOOT_LAST);

LAB_LOADWPN_SH_CONTINUE:
		p = p->GetNextValue();
	}

	// again, fill in blanks.
	RationalizeCurrentAnimSet();

	// if no data on certain anim, then use its corresponding default anim instead.
	for (short i = 0; i < WPN_STANDARD_ANIM_COUNTS; i ++)
	{
		if (g_sItemData[iType].m_sSingleHandAnims[i].m_i <= 0)
			g_sItemData[iType].m_sSingleHandAnims[i] = g_sItemData[iType].m_sDefaultAnims[i];
	}
}

void LoadWeaponRecoil(NewKeyValues *pRoot, sRecoilData *pdb)
{
	if (!pRoot || !pdb)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_FLOAT(up_base,			pdb->up_base)
		RECORD_FLOAT(lateral_base,		pdb->lateral_base)
		RECORD_FLOAT(up_modifier,		pdb->up_modifier)
		RECORD_FLOAT(lateral_modifier,	pdb->lateral_modifier)
		RECORD_FLOAT(up_max,			pdb->up_max)
		RECORD_FLOAT(lateral_max,		pdb->lateral_max)
		RECORD_INT(direction_change,	pdb->direction_change)

		p = p->GetNextValue();
	}
}

void LoadWeaponSight(NewKeyValues *pRoot, sSight *pdb, const char *szKey)
{
	if (!pRoot || !pdb ||!szKey)
		return;

	NewKeyValues *p = NULL;

	char szFOV[128], szOFS[128];
	snprintf(szFOV, _TRUNCATE, "%s_aim_fov", szKey);
	snprintf(szOFS, _TRUNCATE, "%s_aim_offset", szKey);

	if ( (p = pRoot->FindKey(szFOV)) )
		pdb->m_flFOV = p->GetFloat();

	if ( (p = pRoot->FindKey(szOFS)) )
		pdb->m_vecOfs = GetVectorFromString(p->GetString());
}

void LoadWeaponSight(NewKeyValues *pRoot, int iType)
{
	if (!pRoot)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_VECTOR	(aim_offset,		g_sItemData[iType].m_sSteelSt.m_vecOfs)
		RECORD_FLOAT	(aim_fov,			g_sItemData[iType].m_sSteelSt.m_flFOV)
		RECORD_VECTOR	(holo_aim_offset,	g_sItemData[iType].m_sHolo.m_vecOfs)
		RECORD_FLOAT	(holo_aim_fov,		g_sItemData[iType].m_sHolo.m_flFOV)
		RECORD_VECTOR	(dot_aim_offset,	g_sItemData[iType].m_sRedDot.m_vecOfs)
		RECORD_FLOAT	(dot_aim_fov,		g_sItemData[iType].m_sRedDot.m_flFOV)
		RECORD_VECTOR	(acog_aim_offset,	g_sItemData[iType].m_sACOG.m_vecOfs)
		RECORD_FLOAT	(acog_aim_fov,		g_sItemData[iType].m_sACOG.m_flFOV)
		RECORD_VECTOR	(round_aim_offset,	g_sItemData[iType].m_sRound.m_vecOfs)
		RECORD_FLOAT	(round_aim_fov,		g_sItemData[iType].m_sRound.m_flFOV)

		RECORD_VECTOR	(single_handed_ofs,	g_sItemData[iType].m_vecSHOFS)

		RECORD_STRING	(scopetexture,		g_sItemData[iType].m_szScopeName)
		RECORD_STRING	(scopeshadow,		g_sItemData[iType].m_szScopeShadowName)

		RECORD_INT		(zoom_min,			g_sItemData[iType].m_iZoomRange[0])
		RECORD_INT		(zoom_max,			g_sItemData[iType].m_iZoomRange[1])

		p = p->GetNextValue();
	}
}

void SetupItem(NewKeyValues *pRoot, int iType)
{
	if (!pRoot || iType >= MAX_WEAPONS || iType <= 0)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	// basic data
	while (p)
	{
		if (FALSE)
			return;

		RECORD_STRING	(classname,	g_sItemData[iType].m_szClassname)

		RECORD_STRING	(vmdl,	g_sItemData[iType].m_szViewModel)
		RECORD_STRING	(wmdl,	g_sItemData[iType].m_szWorldModel)
		RECORD_STRING	(pmdl,	g_sItemData[iType].m_szPersonModel)

		else if (!strcmp(p->GetName(), "xmdl"))
		{
			strcpy(g_sItemData[iType].m_szWorldModel, p->GetString());
			strcpy(g_sItemData[iType].m_szPersonModel, p->GetString());
		}

		RECORD_BOOL		(reflectvmdl,	g_sItemData[iType].m_bReverseVMDL)
		RECORD_BOOL		(usecoderun,	g_sItemData[iType].m_bUseCodeRun)
		RECORD_INT		(x_submodel,	g_sItemData[iType].m_iPWSubModel)

		#ifndef CSMW_SERVER_DLL
		else if (!strcmp(p->GetName(), "p_submodel"))		// client version, server version should change to w_submodel
		#else
		else if (!strcmp(p->GetName(), "w_submodel"))
		#endif
			g_sItemData[iType].m_iPWSubModel = p->GetInt();

		else if (!strcmp(p->GetName(), "magtype"))
		{
			g_sItemData[iType].m_pMagDB		= &g_sMagData[SearchMagTypeViaName(p->GetString())];
			g_sItemData[iType].m_pAmmoDB	= g_sItemData[iType].m_pMagDB->m_pAmmoType;
		}
		else if (!strcmp(p->GetName(), "ammotype"))
		{
			g_sItemData[iType].m_pMagDB		= NULL;
			g_sItemData[iType].m_pAmmoDB	= &g_sAmmoData[FindAmmoTypeByName(p->GetString())];
		}

		RECORD_INT		(chamberclip,		g_sItemData[iType].m_iChamberClip)
		RECORD_STRING	(firesound,			g_sItemData[iType].m_szShootingSound)
		RECORD_STRING	(dryfiresound,		g_sItemData[iType].m_szDryFireSound)
		RECORD_STRING	(silencersound,		g_sItemData[iType].m_szSilencerSound)
		RECORD_INT		(slot,				g_sItemData[iType].m_iSlot)
		RECORD_STRING	(playerbodyanim,	g_sItemData[iType].m_szBodyAnim)
		RECORD_BOOL		(is_single_shot,	g_sItemData[iType].m_bSingleShoot)
		RECORD_FLOAT	(initvel,			g_sItemData[iType].m_flInitVel)
		RECORD_FLOAT	(twist,				g_sItemData[iType].m_flTwist)
		RECORD_FLOAT	(barrellength,		g_sItemData[iType].m_flBarrelLength)
		RECORD_INT		(bulletamount,		g_sItemData[iType].m_iMultiFiredBullets)

		else if (!strcmp(p->GetName(), "gunshotvolume"))
		{
			if (p->GetFloat())
				g_sItemData[iType].m_iGunVolume = p->GetFloat();
			else if (p->GetInt())
				g_sItemData[iType].m_iGunVolume = p->GetInt();
			else
				g_sItemData[iType].m_iGunVolume = ChangeIntoVolume(p->GetString());

			double flAttenuation = -1.0;
			switch (g_sItemData[iType].m_iGunVolume)
			{
				case BIG_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(9999.0); break;
				case NORMAL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(6689.0); break;
				case LOUD_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(3937.0); break;
				case SMALL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2952.0); break;
				case NORMAL_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2559.0); break;
				case QUIET_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(984.0); break;
				default: flAttenuation = ChangeSoundRangeIntoAttenuation(1500.0); break;
			}

			if (flAttenuation >= 0.0)
				g_sItemData[iType].m_flSoundAttenuation = flAttenuation;
		}
		else if (!strcmp(p->GetName(), "gunsoundrange"))
		{
			if (ChangeIntoVolume(p->GetString()))
			{
				double flAttenuation = 0.0;
				switch (ChangeIntoVolume(p->GetString()))
				{
					case BIG_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(9999.0); break;
					case NORMAL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(6689.0); break;
					case LOUD_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(3937.0); break;
					case SMALL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2952.0); break;
					case NORMAL_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2559.0); break;
					case QUIET_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(984.0); break;
				}

				g_sItemData[iType].m_flSoundAttenuation = flAttenuation;
			}
			else
			{
				bool bInch = true;
				char szWords[128];
				strcpy(szWords, p->GetString());
				if (strstr(p->GetString(), "m"))
				{
					bInch = false;
					strcpy(szWords, strtok(szWords, "m"));
				}
				else if (strstr(p->GetString(), "in"))
					strcpy(szWords, strtok(szWords, "in"));

				double flValue = 0.0;
				if (strstr(szWords, "."))
					flValue = atof(szWords);
				else
					flValue = (double)atoi(szWords);

				if (!bInch)
					flValue *= 39.37007874015748;	// meter to inch

				g_sItemData[iType].m_flSoundAttenuation = ChangeSoundRangeIntoAttenuation(flValue);
			}
		}
		else if (!strcmp(p->GetName(), "gunshotflashlevel"))
			g_sItemData[iType].m_iGunFlash = ChangeIntoFlashLevel(p->GetString());

		RECORD_FLOAT	(pri_att_rate,	g_sItemData[iType].m_flNextPriAttack)
		RECORD_FLOAT	(sed_att_rate,	g_sItemData[iType].m_flNextSedAttack)

		else if (!strcmp(p->GetName(), "RPM"))
			g_sItemData[iType].m_flNextPriAttack = 60.0f / max(1, p->GetFloat());
		else if (!strcmp(p->GetName(), "walkspeed"))
		{
			g_sItemData[iType].m_sWalkSpeed.m_flWalkSpeed	= p->GetFloat();
			g_sItemData[iType].m_sWalkSpeed.m_flRunOfs		= p->GetFloat() * 0.65f;
			g_sItemData[iType].m_sWalkSpeed.m_flAimOfs		= -p->GetFloat() * 0.25f;
		}

		RECORD_FLOAT	(gravity,			g_sItemData[iType].m_flGravity)
		RECORD_INT		(effectivedist,		g_sItemData[iType].m_iEffectiveRange)
		RECORD_INT		(effectiveangle,	g_sItemData[iType].m_iEffectiveAngle)
		RECORD_FLOAT	(bulletspin,		g_sItemData[iType].m_flBulletSpin)

		RECORD_FLOAT	(run_speed_ofs,		g_sItemData[iType].m_sWalkSpeed.m_flRunOfs)
		RECORD_FLOAT	(aim_speed_ofs,		g_sItemData[iType].m_sWalkSpeed.m_flAimOfs)

		p = p->GetNextValue();
	}

	// anims
	if ( (p = pRoot->FindKey("animations")) )
		LoadWeaponAnims(p, iType);

	// recoils
	if ( (p = pRoot->FindKey("recoil")) )
	{
		LoadWeaponRecoil(p, &g_sItemData[iType].m_srOtherwise);

		g_sItemData[iType].m_srDucking	= g_sItemData[iType].m_srOtherwise;
		g_sItemData[iType].m_srJumping	= g_sItemData[iType].m_srOtherwise;
		g_sItemData[iType].m_srMoving	= g_sItemData[iType].m_srOtherwise;
	}

	LoadWeaponRecoil(pRoot->FindKey("recoil_jumping"),		&g_sItemData[iType].m_srJumping);
	LoadWeaponRecoil(pRoot->FindKey("recoil_moving"),		&g_sItemData[iType].m_srMoving);
	LoadWeaponRecoil(pRoot->FindKey("recoil_ducking"),		&g_sItemData[iType].m_srDucking);
	LoadWeaponRecoil(pRoot->FindKey("recoil_otherwise"),	&g_sItemData[iType].m_srOtherwise);

	// sight info
	if ( (p = pRoot->FindKey("sight")) )
		LoadWeaponSight(p, iType);

	// save name.
	wcsncpy_s(g_sItemData[iType].m_wszEndoName, UTF8ToUnicode(pRoot->GetName()), _TRUNCATE);

	// install custom init func
	SetupCustomInitialization(g_sItemData[iType].m_szClassname, iType);

	// custom init
	if (g_sItemData[iType].Initialize)
		g_sItemData[iType].Initialize(pRoot, iType);
}

void LoadItems(NewKeyValues *pRoot)
{
	if (!pRoot)
		return;

	NewKeyValues	*pSubKey	= pRoot->GetFirstSubKey();
	NewKeyValues	*p			= NULL;
	int				iType		= 0;

	// items
	while (pSubKey)
	{
		if ( (p = pSubKey->FindKey("classname")) )
			iType = GetWeaponTypeFromName(p->GetString());

		if (!iType)
		{
			if (g_iItemTypes >= MAX_WEAPONS)
				break;

			SetupItem(pSubKey, ++g_iItemTypes);
		}
		else
			SetupItem(pSubKey, iType);

		pSubKey = pSubKey->GetNextKey();
	}
}

/*
===================================

Load Subs

===================================
*/

void SetupSubs(NewKeyValues *pRoot, int iType)
{
	if (!pRoot || iType >= MAX_WEAPONS + MAX_SUBS || iType <= 0)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	// basic data
	while (p)
	{
		if (FALSE)
			return;

		RECORD_STRING	(classname,	g_sItemData[iType].m_szClassname)

		else if (!strcmp(p->GetName(), "magtype"))
		{
			g_sItemData[iType].m_pMagDB		= &g_sMagData[SearchMagTypeViaName(p->GetString())];
			g_sItemData[iType].m_pAmmoDB	= g_sItemData[iType].m_pMagDB->m_pAmmoType;
		}
		else if (!strcmp(p->GetName(), "ammotype"))
		{
			g_sItemData[iType].m_pMagDB		= NULL;
			g_sItemData[iType].m_pAmmoDB	= &g_sAmmoData[FindAmmoTypeByName(p->GetString())];
		}

		RECORD_INT		(chamberclip,		g_sItemData[iType].m_iChamberClip)
		RECORD_STRING	(firesound,			g_sItemData[iType].m_szShootingSound)
		RECORD_STRING	(dryfiresound,		g_sItemData[iType].m_szDryFireSound)
		RECORD_BOOL		(is_single_shot,	g_sItemData[iType].m_bSingleShoot)
		RECORD_FLOAT	(initvel,			g_sItemData[iType].m_flInitVel)
		RECORD_FLOAT	(twist,				g_sItemData[iType].m_flTwist)
		RECORD_FLOAT	(barrellength,		g_sItemData[iType].m_flBarrelLength)
		RECORD_INT		(bulletamount,		g_sItemData[iType].m_iMultiFiredBullets)

		else if (!strcmp(p->GetName(), "gunshotvolume"))
		{
			if (p->GetFloat())
				g_sItemData[iType].m_iGunVolume = p->GetFloat();
			else if (p->GetInt())
				g_sItemData[iType].m_iGunVolume = p->GetInt();
			else
				g_sItemData[iType].m_iGunVolume = ChangeIntoVolume(p->GetString());

			double flAttenuation = -1.0;
			switch (g_sItemData[iType].m_iGunVolume)
			{
				case BIG_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(9999.0); break;
				case NORMAL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(6689.0); break;
				case LOUD_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(3937.0); break;
				case SMALL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2952.0); break;
				case NORMAL_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2559.0); break;
				case QUIET_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(984.0); break;
				default: flAttenuation = ChangeSoundRangeIntoAttenuation(1500.0); break;
			}

			if (flAttenuation >= 0.0)
				g_sItemData[iType].m_flSoundAttenuation = flAttenuation;
		}
		else if (!strcmp(p->GetName(), "gunsoundrange"))
		{
			if (ChangeIntoVolume(p->GetString()))
			{
				double flAttenuation = 0.0;
				switch (ChangeIntoVolume(p->GetString()))
				{
					case BIG_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(9999.0); break;
					case NORMAL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(6689.0); break;
					case LOUD_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(3937.0); break;
					case SMALL_EXPLOSION_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2952.0); break;
					case NORMAL_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(2559.0); break;
					case QUIET_GUN_VOLUME: flAttenuation = ChangeSoundRangeIntoAttenuation(984.0); break;
				}

				g_sItemData[iType].m_flSoundAttenuation = flAttenuation;
			}
			else
			{
				bool bInch = true;
				char szWords[128];
				strcpy(szWords, p->GetString());
				if (strstr(p->GetString(), "m"))
				{
					bInch = false;
					strcpy(szWords, strtok(szWords, "m"));
				}
				else if (strstr(p->GetString(), "in"))
					strcpy(szWords, strtok(szWords, "in"));

				double flValue = 0.0;
				if (strstr(szWords, "."))
					flValue = atof(szWords);
				else
					flValue = (double)atoi(szWords);

				if (!bInch)
					flValue *= 39.37007874015748;	// meter to inch

				g_sItemData[iType].m_flSoundAttenuation = ChangeSoundRangeIntoAttenuation(flValue);
			}
		}
		else if (!strcmp(p->GetName(), "gunshotflashlevel"))
			g_sItemData[iType].m_iGunFlash = ChangeIntoFlashLevel(p->GetString());

		RECORD_FLOAT	(pri_att_rate,	g_sItemData[iType].m_flNextPriAttack)
		RECORD_FLOAT	(sed_att_rate,	g_sItemData[iType].m_flNextSedAttack)

		else if (!strcmp(p->GetName(), "RPM"))
			g_sItemData[iType].m_flNextPriAttack = 60.0f / max(1, p->GetFloat());

		RECORD_INT		(effectivedist,		g_sItemData[iType].m_iEffectiveRange)
		RECORD_INT		(effectiveangle,	g_sItemData[iType].m_iEffectiveAngle)
		RECORD_FLOAT	(bulletspin,		g_sItemData[iType].m_flBulletSpin)

		p = p->GetNextValue();
	}

	// recoils
	if ( (p = pRoot->FindKey("recoil")) )
	{
		LoadWeaponRecoil(p, &g_sItemData[iType].m_srOtherwise);

		g_sItemData[iType].m_srDucking	= g_sItemData[iType].m_srOtherwise;
		g_sItemData[iType].m_srJumping	= g_sItemData[iType].m_srOtherwise;
		g_sItemData[iType].m_srMoving	= g_sItemData[iType].m_srOtherwise;
	}

	LoadWeaponRecoil(pRoot->FindKey("recoil_jumping"),		&g_sItemData[iType].m_srJumping);
	LoadWeaponRecoil(pRoot->FindKey("recoil_moving"),		&g_sItemData[iType].m_srMoving);
	LoadWeaponRecoil(pRoot->FindKey("recoil_ducking"),		&g_sItemData[iType].m_srDucking);
	LoadWeaponRecoil(pRoot->FindKey("recoil_otherwise"),	&g_sItemData[iType].m_srOtherwise);

	// save name.
	wcsncpy_s(g_sItemData[iType].m_wszEndoName, UTF8ToUnicode(pRoot->GetName()), _TRUNCATE);

	// install custom init func
	SetupCustomInitialization(g_sItemData[iType].m_szClassname, iType);

	// custom init
	if (g_sItemData[iType].Initialize)
		g_sItemData[iType].Initialize(pRoot, iType);
}

void LoadSubs(NewKeyValues *pRoot)
{
	if (!pRoot)
		return;

	NewKeyValues	*pSubKey	= pRoot->GetFirstSubKey();
	NewKeyValues	*p			= NULL;
	int				iType		= 0;

	// subs
	while (pSubKey)
	{
		if ( (p = pSubKey->FindKey("classname")) )
			iType = LoopupSubsTypeInSeqs(p->GetString());

		if (!iType)
		{
			if (g_iSubsTypes >= MAX_WEAPONS + MAX_SUBS)
				break;

			SetupSubs(pSubKey, ++g_iSubsTypes);
		}
		else
			SetupSubs(pSubKey, iType);

		pSubKey = pSubKey->GetNextKey();
	}
}

/*
===================================

Load Accessories

===================================
*/

#define CONST_TO_IF(keyname)	if (!strcmp(sz, #keyname))	\
									return keyname
#define CONST_TO_ELIF(keyname)	else if (!strcmp(sz, #keyname))	\
									return keyname

ACCESSORY_SLOTS TranslateAccSlotToEnumMember(const char *sz)
{
	// for normal guns
	CONST_TO_IF(AS_MUZZLE);
	CONST_TO_ELIF(AS_BARREL);
	CONST_TO_ELIF(AS_FOREARM);
	CONST_TO_ELIF(AS_FOREGRIP);
	CONST_TO_ELIF(AS_GADGET);
	CONST_TO_ELIF(AS_FRONT_SIGHT);
	CONST_TO_ELIF(AS_OPTICAL_SIGHT);
	CONST_TO_ELIF(AS_REAR_SIGHT);
	CONST_TO_ELIF(AS_UPPER_RECEIVER);
	CONST_TO_ELIF(AS_LOWER_RECEIVER);
	CONST_TO_ELIF(AS_GRIP);
	CONST_TO_ELIF(AS_ACTION);
	CONST_TO_ELIF(AS_TRIGGER);
	CONST_TO_ELIF(AS_MAGAZINE);
	CONST_TO_ELIF(AS_STOCK);

	// for bullpup guns
	CONST_TO_ELIF(AS_BUTT);

	// for pistols
	CONST_TO_ELIF(AS_SLIDE);

	// for bolt-action rifles
	CONST_TO_ELIF(AS_BOLT);
	CONST_TO_ELIF(AS_CHAMBER);

	// finally.
	return AS_NONE;
}

void SetupAccessory(NewKeyValues *pRoot, int iType)
{
	if (!pRoot || iType >= MAX_ACCESSORIES || iType <= 0)
		return;

	NewKeyValues *p = pRoot->GetFirstValue();

	while (p)
	{
		if (!strcmp(p->GetName(), "slot"))
			g_sAccData[iType].m_iSlot = TranslateAccSlotToEnumMember(p->GetString());

		RECORD_STRING(HUD_Name,	g_sAccData[iType].m_szHUDName)
		RECORD_STRING(db_chunk,	g_sAccData[iType].m_szCustomData)

		p = p->GetNextValue();
	}

	// acc's name is the typename.
	strcpy(g_sAccData[iType].m_szName, pRoot->GetName());

	// acctype assignment
	g_sAccData[iType].m_iType = iType;
}

void LoadAccessory(NewKeyValues *pRoot)
{
	if (!pRoot)
		return;

	NewKeyValues	*pSubKey	= pRoot->GetFirstSubKey();
	NewKeyValues	*p			= NULL;
	int				iType		= 0;

	// ammo
	while (pSubKey)
	{
		if ( (p = pSubKey->FindKey("name")) )
			iType = TranslateAccNameIntoIndex(p->GetString());

		if (!iType)
		{
			if (g_iAccTypes >= MAX_WEAPONS)
				break;

			SetupAccessory(pSubKey, ++g_iAccTypes);
		}
		else
			SetupAccessory(pSubKey, iType);

		pSubKey = pSubKey->GetNextKey();
	}
}

/*
===================================
Scan Directory

We need to LoadAllAmmo->LoadAllMag->LoadAllXMDL->LoadAllItems
===================================
*/

void LoadAllAmmo(void)
{
	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[512], szGameDir[64];

#ifndef CSMW_SERVER_DLL
	strcpy(szGameDir, gEngfuncs.pfnGetGameDirectory());
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#else
	g_engfuncs.pfnGetGameDir(szGameDir);
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#endif

	if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
	{
		do
		{
			if (sInfo.attrib & _A_SUBDIR && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
			{
				// ammo
				sprintf(szPath, "%s//wpnconfig//%s//ammunition.txt", szGameDir, sInfo.name);
				if (_access(szPath, 4) != -1)
				{
					NewKeyValues *pKey	= new NewKeyValues(szPath);
					pKey->LoadFromFile(szPath);

					LoadAmmunition(pKey);

					pKey->deleteThis();
				}
			}
		}
		while (_findnext(hFile, &sInfo) == 0);

		_findclose(hFile);
	}
}

void LoadAllMag(void)
{
	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[512], szGameDir[64];

#ifndef CSMW_SERVER_DLL
	strcpy(szGameDir, gEngfuncs.pfnGetGameDirectory());
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#else
	g_engfuncs.pfnGetGameDir(szGameDir);
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#endif

	if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
	{
		do
		{
			if (sInfo.attrib & _A_SUBDIR && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
			{
				// magazine
				sprintf(szPath, "%s//wpnconfig//%s//magazine.txt", szGameDir, sInfo.name);
				if (_access(szPath, 4) != -1)
				{
					NewKeyValues *pKey	= new NewKeyValues(szPath);
					pKey->LoadFromFile(szPath);

					LoadMagazine(pKey);

					pKey->deleteThis();
				}
			}
		}
		while (_findnext(hFile, &sInfo) == 0);

		_findclose(hFile);
	}
}

void LoadAllXMDL(void)
{
	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[512], szGameDir[64];

#ifndef CSMW_SERVER_DLL
	strcpy(szGameDir, gEngfuncs.pfnGetGameDirectory());
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#else
	g_engfuncs.pfnGetGameDir(szGameDir);
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#endif

	if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
	{
		do
		{
			if (sInfo.attrib & _A_SUBDIR && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
			{
				// xmodel
				sprintf(szPath, "%s//wpnconfig//%s//xmodel.txt", szGameDir, sInfo.name);
				if (_access(szPath, 4) != -1)
				{
					NewKeyValues *pKey	= new NewKeyValues(szPath);
					pKey->LoadFromFile(szPath);

					LoadXModels(pKey);

					pKey->deleteThis();
				}
			}
		}
		while (_findnext(hFile, &sInfo) == 0);

		_findclose(hFile);
	}
}

void LoadAllItems(void)
{
	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[512], szGameDir[64];

#ifndef CSMW_SERVER_DLL
	strcpy(szGameDir, gEngfuncs.pfnGetGameDirectory());
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#else
	g_engfuncs.pfnGetGameDir(szGameDir);
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#endif

	if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
	{
		do
		{
			if (sInfo.attrib & _A_SUBDIR && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
			{
				// item
				sprintf(szPath, "%s//wpnconfig//%s//items.txt", szGameDir, sInfo.name);
				if (_access(szPath, 4) != -1)
				{
					NewKeyValues *pKey	= new NewKeyValues(szPath);
					pKey->LoadFromFile(szPath);

					LoadItems(pKey);

					pKey->deleteThis();
				}
			}
		}
		while (_findnext(hFile, &sInfo) == 0);

		_findclose(hFile);
	}
}

void LoadAllSubs(void)	// NOTE: This must be called after LoadItems()!!!
{
	// this is why we need to load items first.
	g_iSubsTypes = g_iItemTypes;

	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[512], szGameDir[64];

#ifndef CSMW_SERVER_DLL
	strcpy(szGameDir, gEngfuncs.pfnGetGameDirectory());
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#else
	g_engfuncs.pfnGetGameDir(szGameDir);
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#endif

	if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
	{
		do
		{
			if (sInfo.attrib & _A_SUBDIR && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
			{
				// subs
				sprintf(szPath, "%s//wpnconfig//%s//subs.txt", szGameDir, sInfo.name);
				if (_access(szPath, 4) != -1)
				{
					NewKeyValues *pKey	= new NewKeyValues(szPath);
					pKey->LoadFromFile(szPath);

					LoadSubs(pKey);

					pKey->deleteThis();
				}
			}
		}
		while (_findnext(hFile, &sInfo) == 0);

		_findclose(hFile);
	}
}

void LoadAllAccessories(void)
{
	// handle
	intptr_t	hFile = NULL;

	// file info
	_finddata_t	sInfo;

	char szPath[512], szGameDir[64];

#ifndef CSMW_SERVER_DLL
	strcpy(szGameDir, gEngfuncs.pfnGetGameDirectory());
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#else
	g_engfuncs.pfnGetGameDir(szGameDir);
	sprintf(szPath, "%s//wpnconfig//*.*", szGameDir);
#endif

	if ( (hFile = _findfirst(szPath, & sInfo)) != -1 )
	{
		do
		{
			if (sInfo.attrib & _A_SUBDIR && strcmp(sInfo.name, ".") && strcmp(sInfo.name, ".."))
			{
				// item
				sprintf(szPath, "%s//wpnconfig//%s//accessories.txt", szGameDir, sInfo.name);
				if (_access(szPath, 4) != -1)
				{
					NewKeyValues *pKey	= new NewKeyValues(szPath);
					pKey->LoadFromFile(szPath);

					LoadAccessory(pKey);

					pKey->deleteThis();
				}
			}
		}
		while (_findnext(hFile, &sInfo) == 0);

		_findclose(hFile);
	}
}

void LoadDirectory(void)
{
	LoadAllAmmo();
	LoadAllMag();
	LoadAllXMDL();
	LoadAllItems();
	LoadAllSubs();
}

#ifdef CSMW_SERVER_DLL

void LoadPrecacheModels(void)
{
	for (int i = 1; i <= g_iSubsTypes; i ++)
	{
		//Q_PRECACHE_MODEL(g_sItemData[i].m_szViewModel);	// NOTE: since some strange code in client.dll, we dont need to precache vmdl at SV anymore
		Q_PRECACHE_MODEL(g_sItemData[i].m_szWorldModel);
		Q_PRECACHE_MODEL(g_sItemData[i].m_szPersonModel);

		Q_PRECACHE_SOUND(g_sItemData[i].m_szDryFireSound);
		Q_PRECACHE_SOUND(g_sItemData[i].m_szShootingSound);
		Q_PRECACHE_SOUND(g_sItemData[i].m_szSilencerSound)
	}

	for (int i = 1; i <= g_iAmmoTypes; i ++)
	{
		Q_PRECACHE_MODEL(g_sAmmoData[i].m_szShellModel);
	}
}

#endif