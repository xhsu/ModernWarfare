#ifndef _WPN_CMD_SHARED_H_
#define _WPN_CMD_SHARED_H_

#define WPN_CMD_DEPLOY	"__wpn_deployed"
#define WPN_CMD_ADD		"__wpn_added"
#define WPN_CMD_PRIATK	"__wpn_priatk"
#define WPN_CMD_SEDATK	"__wpn_sedatk"
#define WPN_CMD_RELOAD	"__wpn_reload"
#define WPN_CMD_HOLSTER	"__wpn_holster"
#define WPN_CMD_DROP	"__wpn_drop"
#define WPN_CMD_KILL	"__wpn_kill"
#define WPN_CMD_FOV		"__wpn_fov"
#define GLB_CMD_LEAN	"__glb_lean"
#define WPN_CMD_CHG		"__wpn_change"
#define GLB_CMD_CURSOR	"__glb_cursor"
#define	HGR_CMD_SPAWN	"__hgr_spawn"

#define DEF_CURSOR_DIST	100

// some flags.
#define WPN_CMD_FLAG_STD	0
#define WPN_CMD_FLAG_SIL	(1<<0)	// silencer
#define WPN_CMD_FLAG_HGR	(1<<2)	// hand grenade

#ifndef CSMW_SERVER_DLL

void SU_Begin		( const char *szCoreCmd );
void SU_WriteFloat	( float value );
void SU_WriteVector	( Vector value );
void SU_WriteInteger( int value );
void SU_WriteString	( const char *words );
bool SU_End			( void );

#else

void		SU_Begin			( void );
double		SU_ReadFloat		( void );
Vector		SU_ReadVector		( void );
int			SU_ReadInteger		( void );
const char	*SU_ReadString		( void );
void		SU_SetParamToRead	( int i );

#endif










































#endif