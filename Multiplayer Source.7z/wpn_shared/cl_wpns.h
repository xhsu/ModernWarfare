#ifndef _CL_WPN_H_
#define _CL_WPN_H_


#include "loadwpn.h"
#include "cl_entity.h"
#include "newkeyvalues.h"
#include "pmtrace.h"
#include "cl_wpns_util.h"
#include "hud_menu.h"

// classes declear
class CBaseItems;
class CBaseSubItems;
class CBaseWeapons;
class CBaseMelee;
class CBaseGrenade;

// item types
#define WPN_CLASS_ERROR		0
#define WPN_CLASS_NORM		(1<<0)
#define WPN_CLASS_CSMW		(1<<1)
#define WPN_CLASS_SUBITEM	(1<<2)
#define WPN_CLASS_MELEE		(1<<3)
#define WPN_CLASS_ASSAULT	(1<<4)
#define WPN_CLASS_PISTOL	(1<<5)
#define WPN_CLASS_TUBULAR	(1<<6)
#define WPN_CLASS_SHOTGUN	(1<<7)
#define WPN_CLASS_GRENADE	(1<<8)
#define WPN_CLASS_HGRENADE	(1<<9)
#define WPN_CLASS_SNIPER	(1<<10)
#define WPN_CLASS_RECHAMBER	(1<<11)	// weapon mark for this flag will not spawn shell model when shooting.
#define WPN_CLASS_LMG		(1<<12)

enum CSMW_FIREMODE_e
{
	CSMW_FIREMODE_OFF = 0,
	CSMW_FIREMODE_SINGLE,
	CSMW_FIREMODE_DOUBLE,
	CSMW_FIREMODE_TRIPLE,
	CSMW_FIREMODE_MULTIPLE
};

#define WPN_FLAG_AIM			(1<<0)
#define WPN_FLAG_RUN			(1<<1)
#define WPN_FLAG_SHOULD_RELOAD	(1<<2)
#define WPN_FLAG_HOLSTERING		(1<<3)
#define WPN_FLAG_CAN_HOLSTER	(1<<4)
#define WPN_FLAG_FIRSTUSE		(1<<5)
#define WPN_FLAG_SKIPHOLSTER	(1<<6)
#define WPN_FLAG_QUICKUSING		(1<<7)
#define WPN_FLAG_SHOULD_AIM		(1<<8)
#define WPN_FLAG_SHOULD_RUN		(1<<9)
#define WPN_FLAG_SHOULD_MELEE	(1<<10)
#define WPN_FLAG_SHOULD_QT		(1<<11)
#define WPN_FLAG_SHOULD_HOLSTER	(1<<12)
#define WPN_FLAG_SHOULD_USE_SUB	(1<<13)
#define WPN_FLAG_TRY_UNTIL_DONE	(1<<14)
#define WPN_FLAG_CONTINUE_ANIM	(1<<15)
#define WPN_FLAG_MARK_FOR_DEL	(1<<16)
#define WPN_FLAG_COUNT			(1<<17)
/*
enum WPN_FLAGS(<<1)
{
	WPN_FLAG_AIM = (1<<0),
	WPN_FLAG_RUN,
	WPN_FLAG_SHOULD_RELOAD,
	WPN_FLAG_HOLSTERING,
	WPN_FLAG_CAN_HOLSTER,
	WPN_FLAG_FIRSTUSE,
	WPN_FLAG_SKIPHOLSTER,
	WPN_FLAG_QUICKUSING,
	WPN_FLAG_SHOULD_AIM,
	WPN_FLAG_SHOULD_RUN,
	WPN_FLAG_SHOULD_MELEE,
	WPN_FLAG_SHOULD_HOLSTER,
	WPN_FLAG_TRY_UNTIL_DONE,

	COUNT_WPN_FLAG_LAST
};*/

#define ACC_LASER			(1<<0)
#define ACC_HOLO			(1<<1)
#define ACC_DOT				(1<<2)
#define ACC_ROUND			(1<<3)
#define ACC_ACOG			(1<<4)
#define ACC_SIGHT			(ACC_HOLO|ACC_DOT|ACC_ACOG|ACC_ROUND)
#define ACC_SILENCER		(1<<5)
#define ACC_MUZZLEBREAKER	(1<<6)
#define ACC_FLASHHIDER		(1<<7)
#define ACC_COMPENSATOR		(1<<8)
#define ACC_MUZZLE			(ACC_SILENCER|ACC_MUZZLEBREAKER|ACC_FLASHHIDER|ACC_COMPENSATOR)
#define ACC_COUNT			9
#define ACC_LAST			(1<<ACC_COUNT)

// for MouseWheel(bool) return values.
#define	MOUSEWHEEL_HANDLED	false
#define	MOUSEWHEEL_CONTINUE	true

// ItemFrame() settings
#define SetFunc(target,by)	target = static_cast<void (CBaseItems::*)(void)>(by)
#define SetAddFunc(a)		m_pfnItemAddToPlayer = static_cast<bool (CBaseItems::*)(void)>(a)

// some vars
extern CBaseWeapons	*g_pPlayerActivityItem;
extern CBaseWeapons	*g_pPlayerLastItem;
extern CBaseMelee	*g_pPlayerFavMelee;
extern CBaseGrenade	*g_pPlayerPriGr;
extern CBaseGrenade	*g_pPlayerSedGr;

// struct, use to Pop or Push current anim.
typedef struct entanim_s
{
	int			m_iSequence;
	float		m_flAnimtime;
	float		m_flFramerate;
	float		m_flFrame;

	float		m_flNextPriAttack;
	float		m_flNextSedAttack;
	float		m_flNextIdle;
	float		m_flNextFrame;

	// for FakePlayer.
	float		m_flEjectBrass;

} entanim_t;

/*
===================================

classes definition

===================================
*/

class CBaseItems
{
public:	// avoid the complex memset();
	void *operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void *ptr)
	{
		free(ptr);
	}
	CBaseItems(void);

public:
	int				m_iItemType;
	const sItem		*m_pOriginalDB;
	sItem			m_sItemData;
	float			m_flNextPriAttack;
	float			m_flNextSedAttack;
	float			m_flNextIdle;
	unsigned		m_ulStatus;
	float			m_flNextFrame;
	float			m_flNextThink;
	int				m_iClip;
	int				m_iChamberClip;
	cl_entity_t		*m_pPlayer;
	bool			m_bInReload;
	int				m_iFireMode;
	int				m_iShotsFired;
	bool			m_bDirection;
	animdb_t		m_sAnims[WPN_STANDARD_ANIM_COUNTS];

	// function vars
	void (CBaseItems::*m_pfnThink)				( void );
	bool (CBaseItems::*m_pfnItemAddToPlayer)	( void );
	void (CBaseItems::*m_pfnItemPreFrame)		( void );
	void (CBaseItems::*m_pfnItemDeploy)			( void );
	void (CBaseItems::*m_pfnItemPostFrame)		( void );
	void (CBaseItems::*m_pfnPrimaryAttack)		( void );
	void (CBaseItems::*m_pfnSecondaryAttack)	( void );
	void (CBaseItems::*m_pfnWeaponIdle)			( void );
	void (CBaseItems::*m_pfnWeaponReload)		( void );
	void (CBaseItems::*m_pfnItemHolster)		( void );
	void (CBaseItems::*m_pfnItemDropped)		( void );
	void (CBaseItems::*m_pfnItemKill)			( void );

	// basic logic funcs
	virtual void	Think						( void )										{ if (m_pfnThink) (this->*m_pfnThink)();	}
	virtual bool	ItemAddToPlayer				( void )										{ if (m_pfnItemAddToPlayer) return (this->*m_pfnItemAddToPlayer)(); else return false;	}
	virtual void	ItemPreFrame				( void )										{ if (m_pfnItemPreFrame) (this->*m_pfnItemPreFrame)();	}
	virtual void	ItemDeploy					( void )										{ if (m_pfnItemDeploy) (this->*m_pfnItemDeploy)();	}
	virtual void	ItemPostFrame				( void )										{ if (m_pfnItemPostFrame) (this->*m_pfnItemPostFrame)();	}
	virtual void	PrimaryAttack				( void )										{ if (m_pfnPrimaryAttack) (this->*m_pfnPrimaryAttack)();	}
	virtual void	SecondaryAttack				( void )										{ if (m_pfnSecondaryAttack) (this->*m_pfnSecondaryAttack)();	}
	virtual void	WeaponIdle					( void )										{ if (m_pfnWeaponIdle) (this->*m_pfnWeaponIdle)();	}
	virtual void	WeaponReload				( void )										{ if (m_pfnWeaponReload) (this->*m_pfnWeaponReload)();	}
	virtual void	ItemHolster					( void )										{ if (m_pfnItemHolster) (this->*m_pfnItemHolster)();	}
	virtual void	ItemDropped					( void )										{ if (m_pfnItemDropped) (this->*m_pfnItemDropped)();	}
	virtual void	ItemKill					( void )										{ if (m_pfnItemKill) (this->*m_pfnItemKill)();	}

	// util funcs
	virtual void	UpdateItemStatus			( void )										{ }
	virtual bool	GiveAmmo					( void )										{ return false;	}
	virtual void	DoNothing					( void )										{ }
	virtual bool	IsWeaponEmpty				( void )										{ return !!(m_iClip <= 0 && m_iChamberClip <= 0);	}
	virtual void	KickBack					( recdb_t *pRecoil = NULL );
	virtual	bool	AnimationSet				( const animdb_t sSet[WPN_STANDARD_ANIM_COUNTS] );

	// override funcs
	virtual void	OnNewRound					( bool bActiveItem )							{ }
	virtual int		GetWeaponClass				( void )										{ return WPN_CLASS_ERROR;	}
};

class CBaseSubItems : public CBaseItems
{
public:
	CBaseSubItems(void);
	virtual ~CBaseSubItems(void);

	CBaseWeapons	*m_pMaster;
	entanim_t		m_sAnimStack;

	// function vars
	void (CBaseItems::*m_pfnUse)				( void );

protected:
	bool			m_bTakeOver;

public:
	// Basic Functions
	virtual bool	ItemAttachToWeapon			( CBaseWeapons *p );
	virtual void	Sub_PreFrame				( void );
	virtual void	Sub_Deploy					( void );
	virtual	void	Use							( void )	{ if (m_pfnUse) (this->*m_pfnUse)();	}	// this should be the input of all signal.
	virtual void	Sub_Holster					( void );
	virtual void	Sub_Destroy					( void );

	// override funcs
	virtual bool	CanWeaponFire				( void );
	virtual bool	CanWeaponReload				( void )				{ return false;		}
	virtual int		GetWeaponClass				( void )				{ return WPN_CLASS_SUBITEM;		}
	virtual bool	IsTakeOver					( void )				{ return m_bTakeOver;	}
	virtual void	OnNewRound					( bool bActiveItem );
	virtual void	BindDataToHud				( void );
	virtual	void	Pause						( void );	// interrupt reload.
	virtual void	Restore						( void );	// restore reload.

	// Util Functions
	virtual bool	GiveAmmo					( void );
	virtual void	WeaponAnim					( animdb_t * pAnim, int iCDType = 0, bool bSyncMaster = true );
	virtual void	PushAnim					( bool bSyncMaster = true );
	virtual bool	PopAnim						( bool bSyncMaster = true );
};

class CBaseWeapons : public CBaseItems
{
public:
	CBaseWeapons(void);
	virtual ~CBaseWeapons(void);

	// New Vars
	unsigned		m_bitsAccessories;
	unsigned		m_bitsFlags;
	bool			m_bAltWeapon;
	CBaseWeapons	*m_pAltWeapon;
	CBaseSubItems	*m_pSubsItem;
	int				m_iDisplayingAnim;
	int				m_iSubModelStatus;
	entanim_t		m_sAnimStack;
	CBaseMenuTable	m_sAccMenu;
	int				m_iLastZoomFOV;
	Vector			m_vecBlockOffset;
	short			m_iSavedQuickSlot;

	float			m_flDecreaseShotsFired;
	float			m_flAccuracy;
	float			m_flNextBlockCheck;
	float			m_flLastReload;

	bool			m_bDelayFire;
	bool			m_bTriggerRel;
	bool			m_bAimCoolDown;
	bool			m_bInScope;
	bool			m_bUsingSubs;
	bool			m_bBlocked;

public:
	CBaseWeapons	*m_pChain;
	CBaseWeapons	*m_pSwitchTo;
	CBaseWeapons	*m_pNext;

public:
	void (CBaseItems::*m_pfnRunStart)			( void );
	void (CBaseItems::*m_pfnRunStop)			( void );

public:
	// New Functions
	virtual void	AimUp						( void );
	virtual void	AimDown						( void );
	virtual void	RunStart					( void )										{ if (m_pfnRunStart) (this->*m_pfnRunStart)();	}
	virtual void	RunStop						( void )										{ if (m_pfnRunStop) (this->*m_pfnRunStop)();	}
	virtual void	Jump						( void );
	virtual void	SwitchSwitcher				( void );
	virtual void	ChangeMode					( void )										{ if (m_pSubsItem) { m_bUsingSubs = true; m_pSubsItem->Use(); m_bUsingSubs = false; }	}
	virtual void	Melee						( void );
	virtual	void	QuickThrow					( short iQuickSlot );
	virtual bool	InstallAltWeapon			( CBaseWeapons *pAnother, bool bBecomeMaster );
	virtual void	UninstallAltWeapon			( void );
	virtual void	ScopeIn						( void );
	virtual void	ScopeOut					( void );
	virtual void	ScopeThink					( void );
	virtual bool	AllocSubItem				( int iType )									{ return false; }	// use CanSubsAttach() to test first!!
	virtual bool	MouseWheel					( bool bUp	);		// if not bUp, then it's down.
	virtual void	KeyEvent					( int down, int key, const char *pszCurBinding ){ }
 
	// override funcs
	virtual bool	CanItemHolster				( void );
	virtual bool	CanItemDropped				( void );
	virtual float	GetWalkSpeed				( void );
	virtual int		GetWeaponClass				( void )										{ return WPN_CLASS_CSMW; }
	virtual void	OnSpawnPost					( void );
	virtual void	OnNewRound					( bool bActiveItem );
	virtual bool	CanDoubleHold				( void )										{ return false;	}
	virtual int		GetViewModelSubModelStatus	( void )										{ return 0; }
	virtual bool	CheckAttachment				( int iAttachment );
	virtual bool	CanWeaponFire				( void );
	virtual bool	CanSubsAttach				( int iType )									{ return false; }
	virtual	bool	CheckBlocked				( void );
 
	// util funcs
	virtual void	SetShell					( float flTime = 0.0f );
	virtual void	UpdateItemStatus			( void );
	virtual void	WeaponAnim					( animdb_t *p, int iCDType = 0 );
	virtual void	PushAnim					( void );
	virtual void	PopAnim						( void );
	virtual bool	GiveAmmo					( void );
	virtual int		GetMuzzleEnum				( void )										{ return 0;	}
	virtual int		GetShellEnum				( void )										{ return 1;	}
	virtual Vector	GetMuzzleOrigin				( void );
	virtual Vector	GetShellOrigin				( void );
	virtual void	BindDataToHud				( void );
	virtual int		GetFireMode					( void )										{ return m_iFireMode;	}
	virtual int		GetAimFOV					( void );
	virtual Vector	GetAimOffset				( void );
	inline	bool	IsDoubleHolding				( void )										{ return !!(m_pAltWeapon > 0);	}
	inline	bool	IsInferior					( void )										{ return (IsDoubleHolding() && m_bAltWeapon);	}
	inline	bool	IsSuperior					( void )										{ return (IsDoubleHolding() && !m_bAltWeapon);	}
	inline	void	SetCoolDown					( float time = 0 )								{ m_flNextFrame = m_flNextIdle = m_flNextPriAttack = m_flNextSedAttack = time;	}
	inline	void	ResetPlayerSpeed			( void )										{ g_sFakePlayer.m_flMaxSpeed = GetWalkSpeed();	}
	virtual void	PlayShootingAnim			( void );
	virtual void	ResetAimAnim				( void )										{ }
	virtual	void	PauseReload					( void );
 
	// Hud/UI funcs
	virtual	void	HUD_Think3D					( void );
	virtual void	HUD_Draw3D					( void );
	virtual	void	HUD_Think2D					( void );
	virtual void	HUD_Draw2D					( void );
	virtual void	HUD_AccMenu					( void );
	virtual void	HUD_GenerateAccMenu			( void );

	// EFX funcs
	virtual void	DrawGunSmoke				( void );
	virtual	void	DrawWorldCustomObjects		( void );

	// def logic funcs
	virtual bool	Def_ItemAddToPlayer			( void );
	virtual void	Def_ItemPreFrame			( void );
	virtual void	Def_ItemDeploy				( void );
	virtual void	Def_ItemPostFrame			( void );
	virtual void	Def_PrimaryAttack			( void );
	virtual void	Def_SteelSight				( void );
	virtual void	Def_Scope					( void );
	virtual void	Def_WeaponIdle				( void );
	virtual void	Def_RunStart				( void );
	virtual void	Def_RunStop					( void );
	virtual void	Def_WeaponReload			( void );
	virtual void	Def_ItemHolster				( void );
	virtual void	Def_ItemDropped				( void );
	virtual void	Def_ItemKill				( void );

	// dual funcs: Main parts.
	static	void	SH_MakeAlts					( wpn_c *pSuperior, wpn_c *pInferior);
	virtual	void	SH_ResetAnims				( void );
	virtual	void	SH_WeaponReload				( void );	// common use between SUPERIOR and INFERIOR.

	// dual funcs: Superior Wpn parts.
	virtual	void	Spr_RunStart				( void );
	virtual	void	Spr_RunStop					( void );
	virtual	void	Spr_ItemPreFrame			( void );
	virtual	void	Spr_ItemDeploy				( void );
	virtual	void	Spr_ItemPostFrame			( void );
	virtual void	Spr_ItemHolster				( void );

	// dual funcs: Inferior Wpn parts.
	virtual	void	Ifr_RunStart				( void );
	virtual	void	Ifr_RunStop					( void );
	virtual	void	Ifr_PlayHolsterAnim			( void );	// inferior weapon cant refuse holstering.
	virtual	void	Ifr_ItemPreFrame			( void );	// called by Spr_ItemPreFrame(); call ItemPostFrame() inside.
	virtual	void	Ifr_ItemDeploy				( void );	// called by Spr_ItemDeploy();
	virtual	void	Ifr_ItemPostFrame			( void );	// only called by Ifr_ItemPreFrame() !!!
	virtual void	Ifr_ItemHolster				( void );	// called by Spr_Holster();

};

extern CBaseWeapons *g_pWeaponChainRoot;

class CMagazineManager
{
public:
	CMagazineManager	( void );

	unsigned int	m_iAmmoAmount[MAX_AMMOTYPE];
	unsigned int	m_iMagAmount[MAX_WEAPONS];
};

extern CMagazineManager g_cMagManager;

/*
===================================

utils

===================================
*/

inline	bool	UTIL_IsPlayerRunning(void)	{ return !!(g_pPlayerActivityItem && (g_pPlayerActivityItem->m_ulStatus & WPN_FLAG_RUN));	}
inline	bool	UTIL_IsPlayerAiming(void)	{ return !!(g_pPlayerActivityItem && (g_pPlayerActivityItem->m_ulStatus & WPN_FLAG_AIM));	}
void			UTIL_RemoveAllItems(void);
CBaseWeapons	*CreateWeapon(const char *sz);

/*
===================================

Classes derived from CBaseWeapons

===================================
*/

class CAA12 : public CBaseWeapons
{
public:

	int		GetWeaponClass				( void )	{ return WPN_CLASS_SHOTGUN;	}

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_DOT|ACC_HOLO|ACC_ROUND|ACC_MUZZLEBREAKER)); }
};

class CAR15 : public CBaseWeapons
{
public:
	typedef enum
	{
		ANIM_IDLE = 0,
		ANIM_SHOOT,
		ANIM_SHOOT_LEFT,
		ANIM_SHOOT_RIGHT,
		ANIM_SHOOT_PARTS,
		ANIM_RECHAMBER,

		ANIM_RELOAD,
		ANIM_RELOAD_EMPTY,

		ANIM_RELOAD_M203,

		ANIM_RELOAD_XM26,
		ANIM_RELOAD_XM26_EMPTY,

		ANIM_RELOAD_M870_START,
		ANIM_RELOAD_M870_FIRST,
		ANIM_RELOAD_M870_LOOP,
		ANIM_RELOAD_M870_STOP,
		ANIM_RELOAD_M870_EMPTY,

		ANIM_COUNT
	} anim_e;

	static	int			s_iItemType;
	static	animdb_t	s_AnimData[ANIM_COUNT];
	static	float		s_flRifleClipOut;
	static	float		s_flM870ClipAdd;
	static	float		s_flRechamberShell;
	static	float		s_flM870ReloadShell;
	static	float		s_flM203ChangeNail;
	static	float		s_flFirstAmmoInsert;
	static	float		s_flFirstShellOut;

	static void	Initialize(NewKeyValues *pRoot, int iType);

public:

	float	m_flTimeNullShell;

	int		GetWeaponClass				( void )	{ return WPN_CLASS_ASSAULT;	}

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SIGHT|ACC_SILENCER|ACC_MUZZLEBREAKER|ACC_FLASHHIDER)); }
	bool	CanSubsAttach				( int iType );
	bool	AllocSubItem				( int iType );
	void	HUD_GenerateAccMenu			( void );
	void	ChangeMode					( void );

	int		GetMuzzleEnum				( void );
	int		GetShellEnum				( void );
	void	PlayShootingAnim			( void );

	void	WeaponReload				( void );
	void	ItemHolster					( void );
};
 
class CMSR : public CBaseWeapons
{
public:
	static	float	s_flShootRechamberTime;
	static	float	s_flReloadRechamberTime;
	static	void	Initialize(NewKeyValues *pRoot, int iType);

	int		GetWeaponClass				( void )				{ return WPN_CLASS_SNIPER|WPN_CLASS_RECHAMBER;	}
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_ACOG|ACC_DOT|ACC_HOLO));	}

	void	OnSpawnPost			( void );

	void	ItemPostFrame		( void );
	void	PrimaryAttack		( void );
	void	WeaponReload		( void );
};

class CGauss : public CBaseWeapons
{
public:
	typedef enum
	{
		ANIM_IDLE = 0,
		ANIM_IDLE2,
		ANIM_FIDGET,
		ANIM_SPINUP,
		ANIM_SPIN,
		ANIM_FIRE,
		ANIM_FIRE2,
		ANIM_HOLSTER,
		ANIM_DRAW,

		ANIM_COUNT
	} anim_e;

	static	int			s_iItemType;
	static	animdb_t	s_AnimData[ANIM_COUNT];

	static void	Initialize(NewKeyValues *pRoot, int iType);
	void EV_FireGauss( event_args_t *args );
	static void EV_StopPreviousGauss( int idx );
	inline float GetFullChargeTime(void)	{ return 4;	}

public:
	// was this weapon just fired primary or secondary?
	// we need to know so we can pick the right set of effects. 
	BOOL m_fPrimaryFire;
	int m_iSoundState; // don't save this

	// LUNA: strange things from hl's cbase.h
	int m_fInAttack;
	float m_flStartCharge;
	float m_flAmmoChargeEnd;
	float m_flPlayAftershock;
	float m_flNextAmmoBurn;// while charging, when to absorb another unit of player's ammo?

	bool	CanWeaponFire				( void );
	void	OnSpawnPost					( void );

	void	ItemPostFrame				( void );
	void	PrimaryAttack				( void );
	void	SecondaryAttack				( void );
	void	StartFire					( void );
	void	Fire						( Vector vecOrigSrc, Vector vecDir, float flDamage );
	void	WeaponIdle					( void );
};

class CMasada : public CBaseWeapons
{
public:
	static	const int	MASADA_FLAG_CHANGING	= WPN_FLAG_COUNT;

public:
	// static database members.
	static	sight_t	s_sOpticAimOfs;
	static	float	s_flOpticOutChangeSubModel;
	static	float	s_flOpticInChangeSubModel;
	static	bool	s_bOpticSniperZoom;
	static	float	s_flHeartbeatSensor_Range;
	static	float	s_flHeartbeatSensor_VertiAgl;
	static	float	s_flHeartbeatSensor_HrztlAgl;
	static	float	s_flHeartbeatSensor_PointSize;
	static	bool	s_bHeartbeatSensor_Realistic;

	static	animdb_t	s_Anim_OpticIn;
	static	animdb_t	s_Anim_OpticOut;

	static	void	Initialize				( NewKeyValues *pRoot, int iType );

	// members.
	bool	m_bOptic;
	bool	m_bCrosshairUp;
	float	m_flTimeChangeSubmodel;

	int		GetWeaponClass				( void )	{ return WPN_CLASS_ASSAULT;	}
	int		GetAimFOV					( void );
	Vector	GetAimOffset				( void );
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_DOT|ACC_HOLO|ACC_SILENCER)); }

	void	OnSpawnPost					( void );
	void	ChangeMode					( void );
	void	DrawWorldCustomObjects		( void );

	void	ItemPreFrame				( void );
	void	ItemDeploy					( void );
	void	ItemPostFrame				( void );
	void	ItemHolster					( void );

	void	ModelInit					( void );
	void	DrawRealSensor				( void );
	void	DrawNormSensor				( void );

	inline	void	SetController		( int which = 0, int value = 0 );
};

class CMK46 : public CBaseWeapons
{
public:

	bool	m_bFullChain;
	int		m_iChainMdlBody;
	float	m_flChainThink;	// Think() and m_flThink is occupied by scope.

	int		GetWeaponClass				( void )	{ return WPN_CLASS_LMG;	}
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_SIGHT|MK46_ACC_NEW_OPTIC|ACC_SILENCER|ACC_MUZZLEBREAKER|ACC_FLASHHIDER|ACC_LASER)); }
	void	HUD_GenerateAccMenu			( void );
	int		GetAimFOV					( void );
	Vector	GetAimOffset				( void );
	void	SetShell					( float flTime = 0.0f );

	void	OnSpawnPost					( void );
	bool	MouseWheel					( bool bUp	)	{ return true;	}	// we can't zoom on this MG.

	void	ItemPreFrame				( void );
	void	WeaponReload				( void );

	static	const int	MK46_ACC_NEW_OPTIC = ACC_LAST;
	static	float		s_flTimeChainSwitch;
	static	sight_t		s_NewOpticSight;
	static	int			s_iShellBandIndex;
	static	int			s_iBandSpawningAttm;
	static	int			s_iBandSoundType;

	static	void	Initialize				( NewKeyValues *pRoot, int iType );
};

class CCM901 : public CBaseWeapons
{
public:
	typedef enum
	{
		ANIM_IDLE = 0,
		ANIM_SHOOT,
		ANIM_SHOOT_PARTS,
		ANIM_RECHAMBER,
		ANIM_RELOAD,
		ANIM_RELOAD_EMPTY,
		ANIM_RELOAD_M870_START,
		ANIM_RELOAD_M870_LOOP,
		ANIM_RELOAD_M870_EMPTY,
		ANIM_RELOAD_M870_STOP,
		ANIM_DRAW_FIRST,
		ANIM_DRAW,
		ANIM_HOLSTER,
		ANIM_RUN_START,
		ANIM_RUN_LOOP,
		ANIM_RUN_STOP,
		ANIM_SHOOT_AIM,

		ANIM_COUNT
	} anim_e;

	static	int			s_iItemType;
	static	animdb_t	s_AnimData[ANIM_COUNT];
	static	float		s_flM870ClipAdd;
	static	float		s_flRechamberShell;
	static	float		s_flM870ReloadShell;

	static void	Initialize(NewKeyValues *pRoot, int iType);

public:
	int		GetWeaponClass				( void )	{ return WPN_CLASS_ASSAULT;	}

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_ACOG|ACC_DOT|ACC_HOLO));	}
	bool	CanSubsAttach				( int iType );
	bool	AllocSubItem				( int iType );
	void	HUD_GenerateAccMenu			( void );
	void	ChangeMode					( void );

	int		GetMuzzleEnum				( void );
	int		GetShellEnum				( void );

	void	WeaponReload				( void );
};

class CAN94 : public CBaseWeapons
{
public:

	static	float		s_flBrustFireRate;

	static	void	Initialize			( NewKeyValues *pRoot, int iType );

public:
	int		m_iBurstFire;

	int		GetWeaponClass				( void )	{ return WPN_CLASS_ASSAULT;	}
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_ACOG|ACC_DOT|ACC_HOLO|ACC_SILENCER));	}
	void	SwitchSwitcher				( void );
	void	OnSpawnPost					( void );


	bool	CanItemHolster				( void );
	bool	CanItemDropped				( void );

	void	ItemPostFrame				( void );
	void	PrimaryAttack				( void );
};

class CRPG7 : public CBaseWeapons
{
public:
	static	int		s_iItemType;

	static	float	s_flAngularRecoil;
	static	float	s_flLinearRecoil;

	static	char	s_szExploSound[NORMAL_CHARLEN+1];
	static	float	s_flExploRange;
	static	float	s_flExploPunch;
	static	float	s_flExploKnock;
	static	float	s_flExploDamage;

	static	float	s_flRocketSpeed;
	static	float	s_flRocketOffset;
	static	Vector	s_vecRocketSpawn;
	static	float	s_flRocketSize;
	static	float	s_flRocketGravity;
	static	char	s_szRocketModel[NORMAL_CHARLEN+1];

	static	void	Initialize			( NewKeyValues *pRoot, int iType );

public:
	void	SwitchSwitcher				( void ) { }
	int		GetViewModelSubModelStatus	( void );

	void	PrimaryAttack				( void );
};

class CG36C : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_ACOG|ACC_DOT|ACC_HOLO)); }
};

class CM16A4 : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_ACOG|ACC_DOT|ACC_HOLO)); }
};

class CMP5KPDW : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_MUZZLE|ACC_ACOG|ACC_DOT|ACC_HOLO)); }
};

class CSCARH : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_ACOG|ACC_DOT|ACC_HOLO)); }
};

class CQBZ97 : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_ACOG|ACC_DOT|ACC_HOLO)); }
};

class CP90 : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_ACOG|ACC_DOT|ACC_HOLO)); }
};

class CUMP45 : public CBaseWeapons
{
public:
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_ACOG|ACC_DOT|ACC_HOLO|ACC_SILENCER)); }
};

/*
===================================

Classes derived from CBaseSubItems

===================================
*/

class CM203 : public CBaseSubItems
{
public:
	CM203(void);

	static	int	s_iItemType;

	static	CBaseMenuItem	*AddToList	( CBaseWeapons *pWeapon );
	static	void			Initialize	( NewKeyValues *pRoot, int iType );	

	void	ItemPostFrame	( void );
	void	PrimaryAttack	( void );
	void	WeaponReload	( void );

	bool	CanWeaponReload	( void )				{ return !!(m_iChamberClip < m_sItemData.m_iChamberClip && AMMUNITION);		}
};

class CXM26 : public CBaseSubItems
{
public:
	CXM26(void);

	static	int	s_iItemType;

	static	CBaseMenuItem	*AddToList	( CBaseWeapons *pWeapon );
	static	void			Initialize	( NewKeyValues *pRoot, int iType );	

public:
	float	m_flDecreaseShotsFired;

	void	ItemPostFrame	( void );
	void	PrimaryAttack	( void );
	void	WeaponReload	( void );

	bool	CanWeaponReload	( void )				{ return !!(m_iClip < m_sItemData.m_pMagDB->m_iClip && BP_MAGAZINE);		}
};

class CM870MCS : public CBaseSubItems
{
public:
	CM870MCS(void);

	static	int	s_iItemType;

	static	CBaseMenuItem	*AddToList	( CBaseWeapons *pWeapon );
	static	void			Initialize	( NewKeyValues *pRoot, int iType );	

public:
	struct
	{
		float	m_flNextInsertAnim;
		float	m_flNextAddAmmo;
		bool	m_bStartedFromEmpty;
		bool	m_bSetForceStopReload;
		bool	m_bRechamber;

	} m_sExtraAnimStack;

public:
	float	m_flNextInsertAnim;
	float	m_flNextAddAmmo;
	bool	m_bStartedFromEmpty;
	bool	m_bSetForceStopReload;
	float	m_flDecreaseShotsFired;
	float	*m_pflAddAmmoLoop;
	bool	m_bRechamber;
	float	*m_pflRechamberShell;
	float	*m_pflReloadShell;

	animdb_t	*m_pAnimStart;
	animdb_t	*m_pAnimInsert;
	animdb_t	*m_pAnimEnd;
	animdb_t	*m_pAnimEndRec;
	animdb_t	*m_pAnimRechamber;

	virtual	void	ItemPostFrame	( void );
	virtual	void	PrimaryAttack	( void );
	virtual	void	WeaponReload	( void );
	virtual	void	ItemHolster		( void );

	virtual	bool	CanWeaponReload	( void )				{ return !!(m_iChamberClip < m_sItemData.m_iChamberClip && AMMUNITION);		}
	virtual	bool	CanWeaponFire	( void );

	virtual	void	Rechamber		( void );

	virtual	void	Pause			( void )				{ CBaseSubItems::Pause();	m_bTakeOver = false;	}	// interrupt reload.
	virtual	void	Restore			( void )				{ CBaseSubItems::Restore();	m_bTakeOver = true;		}	// restore reload.
	virtual	void	PushAnim		( bool bSyncMaster = true );
	virtual	bool	PopAnim			( bool bSyncMaster = true );
};

class CM870MCS_2 : public CM870MCS	// a variant of M870MCS's code. inherit everything but reload.
{
public:
	float		*m_pflFirstAmmoInsert;
	float		*m_pflFirstShellOut;
	animdb_t	*m_pAnimFirstIns;

	virtual	void	ItemPostFrame	( void );
	virtual	void	WeaponReload	( void );
};

/*
===================================

CBase

===================================
*/

class CBaseMelee : public CBaseWeapons
{
public:

	animdb_t	m_sQuickMeleeAnim;
	bool		m_bQuickMelee;

	// override
	virtual int		GetWeaponClass		( void )	{ return WPN_CLASS_MELEE;	}
	virtual void	OnSpawnPost			( void );
	virtual void	Melee				( void )	{ }	// in this case, it's melee weapon itself.
	virtual void	BindDataToHud		( void );

	virtual void	Mel_ItemPreFrame	( void );
	virtual void	Mel_ItemPostFrame	( void );

	// new funcs
	virtual void	QuickMelee			( void )	{ }
};

class CBasePistol : public CBaseWeapons
{
public:

	virtual int		GetWeaponClass		( void )	{ return WPN_CLASS_PISTOL;	}

	virtual	bool	IsNonslidemoveAnim	( int iAnim );
	virtual void	PlayShootingAnim	( void );
};

class CBaseTubularWeapon : public CBaseWeapons
{
public:

	float	m_flNextInsertAnim;
	float	m_flNextAddAmmo;
	bool	m_bStartedFromEmpty;
	bool	m_bSetForceStopReload;
	float	*m_pflAddAmmoLoop;

	virtual int		GetWeaponClass		( void )	{ return WPN_CLASS_TUBULAR;	}

	static	float	LoadForAmmoAddLoop	( NewKeyValues *pRoot, float flDef = 0.1f );

	virtual	void	RunStart			( void );
	virtual void	OnSpawnPost			( void );

	virtual	void	Tbl_ItemPostFrame	( void );
	virtual	void	Tbl_WeaponReload	( void );
	virtual	void	Tbl_ItemHolster		( void );
};

class CBaseHighTecWeapon : public CBaseWeapons
{
public:
	typedef enum { SIGHT_BLOCK = 0, SIGHT_OK, SIGHT_DANGER, SIGHT_TYPECOUNT	}	FCS_RESULT;
	static const char *s_szFCSwords[SIGHT_TYPECOUNT];
	static const wchar_t *s_wszFCSwords[SIGHT_TYPECOUNT];

	typedef enum { GR_TOUCH = 0, GR_TOUCH_DELAY, GR_DELAY, GR_TYPECOUNT }	GR_TYPES;
	static const char *s_szGrenadeMode[GR_TYPECOUNT];
	static const wchar_t *s_wszGrenadeMode[GR_TYPECOUNT];

	static const char *s_szFCSadjust;
	static const wchar_t *s_wszFCSadjust;

public:
	int			m_iGrenadeClip;
	int			m_iGrChamberClip;
	bool		m_bGrenadeMode;
	Vector		m_vecGrPredictHit;
	FCS_RESULT	m_iFCSstatus;
	color24		m_sFCScolor;
	GR_TYPES	m_iGrenadeType;
	float		m_flGrenadeDelay;

	// any child classes must assign these vars.
	const ammo_t	*m_pGrenadeAmmoDB;

	virtual	int		GetWeaponClass				( void )			{ return WPN_CLASS_ASSAULT|WPN_CLASS_GRENADE;	}
	virtual	bool	IsWeaponEmpty				( void )			{ return (m_bGrenadeMode ? !!(m_iGrenadeClip <= 0 && m_iGrChamberClip <= 0) : CBaseWeapons::IsWeaponEmpty());	}
	
	virtual	bool	HTW_MouseWheel				( bool bUp );

	virtual	void	HTW_ItemHolster				( void );

	virtual	void	FCS_SwitchGrenadeMode		( void );
	virtual	void	FCS_Initialize				( void );
	virtual	void	FCS_DrawText				( void );
	virtual	void	FCS_Prediction				( void );
	virtual	void	FCS_ShowResult				( void );
};

class CBaseGrenade : public CBaseWeapons
{
public:
	typedef enum { STAGE_ERROR,	STAGE_IDLE,	STAGE_PULLPIN,	STAGE_CHARGING,	STAGE_CHARGED,	STAGE_THROW,	STAGE_COOKING,	STAGE_REVOKE,	STAGE_PLUGPIN }	GR_STAGE;

	GR_STAGE	m_iGrenadeStage;
	float		m_flStartCooking;
	float		m_flForce;
	bool		m_bInRevokeHolster;
	bool		m_bInWithdrawal;
	bool		m_bIsQuickThrow;
	int			m_bitsQTSlot;

	// database
	float		m_flTimeExplosion;
	float		m_flTimeGrSpawn;
	float		m_flTimeQTGrSpawn;

	// hand grenade new basic logic function.
	virtual	void	PullPin		( void );
	virtual void	Charging	( void );
	virtual	void	Throw		( void );
	virtual	void	GrSpawn		( void );
	virtual void	Revoke		( void );
	virtual void	PlugPin		( void );

	//virtual	void	QuickThrow	( short iQuickSlot )	{ }	// we DON'T need to disable this one, since it's convinient to throw another grenade. why not?
	virtual	void	QuickThrow		( void );
	virtual	void	QT_WaitForRel	( void );
	virtual	void	QT_BackToNorm	( void );

	// util funcs.
	virtual	float	GetCookedTime	( void );

	inline	bool	IsUprising		( void );
	inline	bool	IsReadyThrowing	( void );
	inline	bool	IsUnrevokable	( void );
	inline	bool	IsBusy			( void );
	inline	bool	IsQuickThrow	( void );

	// overrides.
	virtual int		GetWeaponClass	( void )	{ return WPN_CLASS_HGRENADE;	}
	virtual bool	CanItemHolster	( void );
	virtual bool	CanItemDropped	( void );

	virtual	void	RunStart		( void );
	virtual void	OnSpawnPost		( void );
	virtual void	BindDataToHud	( void );
	virtual void	Melee			( void );
	virtual bool	MouseWheel		( bool bUp	);

	virtual	void	Gr_ItemPreFrame		( void );
	virtual	void	Gr_ItemDeploy		( void );
	virtual void	Gr_ItemPostFrame	( void );
	virtual	void	Gr_ItemHolster		( void );

};

/*
===================================

Classes derived from CBaseMelee

===================================
*/

class CKnife : public CBaseMelee
{
public:
	typedef enum
	{
		A_idle1 = 0,
		A_idle2,
		A_SlashLeft,
		A_SlashRight,
		A_StabHit,
		A_StabMiss,
		A_To_B,
		A_Draw,
		A_Jump,
		A_Vault,
		A_Holster,
		A_HandUp,
		A_HandDown,
		A_RunStart,
		A_RunLoop,
		A_RunEnd,

		B_idle1,
		B_idle2,
		B_SlashLeft,
		B_SlashRight,
		B_StabHit,
		B_StabMiss,
		QuickSlash,
		B_Draw,
		B_Jump,
		B_Vault,
		B_Holster,
		B_HandUp,
		B_HandDown,
		B_RunStart,
		B_RunLoop,
		B_RunEnd,

		KNIFE_ANIM_COUNT,

	} ANIM_ENUM;
	typedef enum
	{
		KNIFE_FLAG_A_TO_B_1 = WPN_FLAG_COUNT,
		KNIFE_FLAG_A_TO_B_2 = KNIFE_FLAG_A_TO_B_1 * 2,
		KNIFE_FLAG_B_TO_A_1 = KNIFE_FLAG_A_TO_B_2 * 2,
		KNIFE_FLAG_B_TO_A_2 = KNIFE_FLAG_B_TO_A_1 * 2,
		KNIFE_FLAG_CHANGING	= KNIFE_FLAG_A_TO_B_1|KNIFE_FLAG_A_TO_B_2|KNIFE_FLAG_B_TO_A_1|KNIFE_FLAG_B_TO_A_2,

	} KNIFE_FLAGS;
	typedef enum
	{
		KNIFE_IDLE = 0,
		KNIFE_A_SLASH = 1,
		KNIFE_A_STAB,
		KNIFE_B_SLASH,
		KNIFE_B_STAB,

	} ATTACK_TYPE;

	static animdb_t	s_AnimData[KNIFE_ANIM_COUNT];
	static float	s_flAStabHitDelay;
	static float	s_flAStabMissDelay;
	static float	s_flBStabHitDelay;
	static float	s_flBStabMissDelay;
	static unsigned	s_iIdDualKnifeIcon;

	static void	Initialize(NewKeyValues *pRoot, int iType);

public:
	animdb_t	*m_pBoringAnim;
	animdb_t	*m_pSlashLeft;
	animdb_t	*m_pSlashRight;
	animdb_t	*m_pStabHit;
	animdb_t	*m_pStabMiss;
	float		m_flBoringThink;
	bool		m_bDualKnife;
	ATTACK_TYPE	m_iAttackType;
	unsigned	m_iFakeStatus;

	// overrides
	int		GetViewModelSubModelStatus	( void );

	void	OnSpawnPost		( void );
	void	ChangeMode		( void );
	void	QuickMelee		( void );
	void	BindDataToHud	( void );

	bool	CanItemDropped	( void )	{ return (!m_bQuickMelee && !(m_ulStatus & KNIFE_FLAG_CHANGING) && CBaseMelee::CanItemDropped());	}
	bool	CanItemHolster	( void )	{ return (!m_bQuickMelee && !(m_ulStatus & KNIFE_FLAG_CHANGING) && CBaseMelee::CanItemHolster());	}
 
	void	Deploy			( void );
	void	Slash			( void );
	void	Stab			( void );
	void	Idle			( void );

	// new funcs
	void	SetAnimToA			( void );
	void	SetAnimToB			( void );
	void	Spec_ItemPostFrame	( void );
	void	DelayStab			( void );
	void	CancelStab			( void );
	void	AfterQuickMelee		( void );
};

/*
===================================

Classes derived from CBasePistol

===================================
*/

class CGlock18C : public CBasePistol
{
public:

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_COMPENSATOR|ACC_FLASHHIDER|ACC_DOT)); }

	void	SH_ResetAnims				( void );
	bool	CanDoubleHold				( void )				{ return true;	}
};

class CFN57 : public CBasePistol
{
public:

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER|ACC_COMPENSATOR|ACC_DOT)); }

	void	SH_ResetAnims				( void );
	bool	CanDoubleHold				( void )				{ return true;	}
};

class C92F : public CBasePistol
{
public:

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_MUZZLEBREAKER|ACC_SILENCER|ACC_DOT)); }

	bool	CanDoubleHold				( void )				{ return true;	}
};

class C93R : public CBasePistol
{
public:

	static	float	s_flBrustFireRate;
	static	void	Initialize			( NewKeyValues *pRoot, int iType );

	int		m_iBurstFire;

public:

	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_SILENCER)); }

	bool	CanDoubleHold				( void )				{ return true;	}
	void	OnSpawnPost					( void );

	void	ItemPostFrame	( void );
	void	PrimaryAttack	( void );

	void	SwitchSwitcher	( void );
	bool	CanItemHolster	( void );
	bool	CanItemDropped	( void );
};

/*
===================================

Classes derived from CBaseTubularWeapon

===================================
*/

class CM1014 : public CBaseTubularWeapon
{
public:

	static float s_flNextAddAmmoCycle;
	static void	Initialize(NewKeyValues *pRoot, int iType);

	int		GetWeaponClass				( void )	{ return WPN_CLASS_TUBULAR|WPN_CLASS_SHOTGUN;	}

	void	OnSpawnPost					( void );
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )		{ return !!(iAttachment & (ACC_LASER|ACC_DOT|ACC_HOLO|M1014_ACC_REFLECT|ACC_COMPENSATOR)); }
	void	HUD_GenerateAccMenu			( void );
	int		GetAimFOV					( void );
	Vector	GetAimOffset				( void );

	static const int M1014_ACC_REFLECT = ACC_LAST;
	static sight_t s_sReflectAimOfs;
	static sight_t s_sLaserAimOfs;
};

/*
===================================

Classes derived from CBaseHighTecWeapon

===================================
*/

class CARC3 : public CBaseHighTecWeapon
{
public:
	static const int ARC3_ACC_DEFAULT_SIGHT = ACC_LAST;
	static const int ARC3_GRENADE_FIREMODE = CSMW_FIREMODE_SINGLE;

	static	ammo_t		*s_pGrenadeAmmoDB;
	static	int			s_iGrenadeAmmoType;
	static	unsigned	*s_piGrenadeAmmo;
	static	int			s_iGrenadeClipMax;
	static	animdb_t	s_Anim_ChangeMode;
	static	animdb_t	s_Anim_GrenadeReload;
	static	animdb_t	s_Anim_GrenadeShoot;
	static	sight_t		s_sARC3_SpecScope;
	static	recdb_t		s_sARC3_GrRecoil;
	
	static	void	Initialize(NewKeyValues *pRoot, int iType);	

public:
	bool		m_bChanging;

	// override
	int		GetWeaponClass				( void )			{ return WPN_CLASS_ASSAULT|WPN_CLASS_GRENADE;	}
	int		GetViewModelSubModelStatus	( void );
	bool	CheckAttachment				( int iAttachment )	{ return !!(iAttachment & (ACC_LASER|ACC_ACOG|ACC_DOT|ACC_HOLO|ARC3_ACC_DEFAULT_SIGHT)); }
	void	HUD_GenerateAccMenu			( void );
	void	BindDataToHud				( void );
	void	SwitchSwitcher				( void );
	void	ChangeMode					( void );
	int		GetAimFOV					( void );
	Vector	GetAimOffset				( void );
	void	OnSpawnPost					( void );
	bool	IsWeaponEmpty				( void );
	void	HUD_Draw2D					( void );
	void	HUD_Think3D					( void );
	void	HUD_Draw3D					( void );
	bool	MouseWheel					( bool bUp );

	bool	CanItemDropped	( void )	{ return (!m_bChanging && CBaseHighTecWeapon::CanItemDropped());	}
	bool	CanItemHolster	( void )	{ return (!m_bChanging && CBaseHighTecWeapon::CanItemHolster());	}

	void	Def_ItemPreFrame			( void );
	void	Def_ItemHolster				( void );

	// new funcs.
	void	Spec_ItemPostFrame	( void );
	void	Gr_PrimaryAttack	( void );
	void	Gr_ItemPostFrame	( void );
	void	Gr_WeaponReload		( void );
};

class CXM29 : public CBaseHighTecWeapon
{
public:
	typedef enum
	{
		ANIM_KE_IDLE = 0,
		ANIM_KE_SHOOT,
		ANIM_HE_SHOOT,
		ANIM_KE_RELOAD,
		ANIM_HE_RELOAD,
		ANIM_KE_RELOAD_EMPTY,
		ANIM_HE_RELOAD_EMPTY,
		ANIM_DRAW_FIRST,
		ANIM_DRAW,
		ANIM_HOLSTER,
		ANIM_RUN_START,
		ANIM_RUN_LOOP,
		ANIM_RUN_STOP,
		ANIM_SELECTOR_TO_SEMI,
		ANIM_SELECTOR_TO_AUTO,
		ANIM_CHANGE_MODE,
		ANIM_BLOCK_UP,
		ANIM_BLOCK_DOWN,
		ANIM_TO_HE,
		ANIM_TO_KE,

		ANIM_COUNT
	} anim_e;

	static const int XM29_GRENADE_FIREMODE = CSMW_FIREMODE_SINGLE;

	static	int			s_iItemType;
	static	animdb_t	s_AnimData[ANIM_COUNT];
	static	recdb_t		s_sXM29_GrRecoil;
	static	mag_t		*s_pGrMag;
	static	unsigned	*s_piGrenadeMag;
	static	ammo_t		*s_pGrAmmoType;
	
	static	void	Initialize(NewKeyValues *pRoot, int iType);	

public:
	bool		m_bChanging;

	// override
	int		GetWeaponClass				( void )			{ return WPN_CLASS_ASSAULT|WPN_CLASS_GRENADE;	}
	int		GetViewModelSubModelStatus	( void );
	void	BindDataToHud				( void );
	void	SwitchSwitcher				( void );
	void	ChangeMode					( void );
	void	OnSpawnPost					( void );
	void	HUD_Draw2D					( void );
	void	HUD_Think3D					( void );
	void	HUD_Draw3D					( void );
	bool	MouseWheel					( bool bUp );

	int		GetMuzzleEnum				( void );
	int		GetShellEnum				( void );

	bool	CanItemDropped	( void )	{ return (!m_bChanging && CBaseHighTecWeapon::CanItemDropped());	}
	bool	CanItemHolster	( void )	{ return (!m_bChanging && CBaseHighTecWeapon::CanItemHolster());	}

	void	ItemHolster					( void );

	// new funcs.
	void	Spec_ItemPostFrame	( void );
	void	Gr_PrimaryAttack	( void );
	void	Gr_ItemPostFrame	( void );	// we can't avoid these, since we're using m_iGrenadeClip instead of default m_iClip.
	void	Gr_WeaponReload		( void );
};

/*
===================================

Classes derived from CBaseGrenade

===================================
*/


































































#endif