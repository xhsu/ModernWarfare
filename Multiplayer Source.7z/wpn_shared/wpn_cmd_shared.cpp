/***

Modern Warfare Develop Team
Coder/Author: Luna the Reborn

Create Date: 2018/02/26

***/

#include <sysdef.h>

#ifndef CSMW_SERVER_DLL

#include "hud.h"
#include "cl_util.h"

/*
=====================
Stream Uploaded Functions (SUFs)

LUNA: use to upload message to servers.
=====================
*/

static char s_szCommandBuffer[512];
static char s_szSprintfBuffer[512];
static bool	s_bSend = false;

#define SUF_BUFFER_LEN	sizeof(s_szCommandBuffer)

void SU_Begin(const char *szCoreCmd)
{
	if (!szCoreCmd || !strlen(szCoreCmd))
	{
		s_bSend = false;
		return;
	}

	strncpy_s(s_szCommandBuffer, szCoreCmd, SUF_BUFFER_LEN);
	s_bSend = true;
}

void SU_WriteFloat(float value)
{
	sprintf_s(s_szSprintfBuffer, SUF_BUFFER_LEN, " %f", value);
	strncat_s(s_szCommandBuffer, s_szSprintfBuffer, SUF_BUFFER_LEN);
}

void SU_WriteVector(Vector value)
{
	sprintf_s(s_szSprintfBuffer, SUF_BUFFER_LEN, " %f %f %f", value.x, value.y, value.z);
	strncat_s(s_szCommandBuffer, s_szSprintfBuffer, SUF_BUFFER_LEN);
}

void SU_WriteInteger(int value)
{
	sprintf_s(s_szSprintfBuffer, SUF_BUFFER_LEN, " %d", value);
	strncat_s(s_szCommandBuffer, s_szSprintfBuffer, SUF_BUFFER_LEN);
}

void SU_WriteString(const char *words)
{
	if (!words || !strlen(words))
		return;

	sprintf_s(s_szSprintfBuffer, SUF_BUFFER_LEN, " %s", words);
	strncat_s(s_szCommandBuffer, s_szSprintfBuffer, SUF_BUFFER_LEN);
}

bool SU_End(void)
{
	if (!s_bSend)
		return s_bSend;

	gEngfuncs.pfnServerCmd(s_szCommandBuffer);
	s_bSend = false;	// avoid re-send.
	return true;
}

#else

#include "extdll.h"
#include "util.h"
#include "cbase.h"

extern enginefuncs_t g_engfuncs;

static int s_iCurParam = 1;

/*
=====================
Stream Uploaded Functions (SUFs)

LUNA: use to read from clients.
=====================
*/

void SU_Begin(void)
{
	s_iCurParam = 1;	// start from param 1
}

double SU_ReadFloat(void)
{
	return atof(g_engfuncs.pfnCmd_Argv(s_iCurParam ++));
}

Vector SU_ReadVector(void)
{
	Vector vec;
	vec.x	= SU_ReadFloat();
	vec.y	= SU_ReadFloat();
	vec.z	= SU_ReadFloat();

	return vec;
}

int SU_ReadInteger(void)
{
	return atoi(g_engfuncs.pfnCmd_Argv(s_iCurParam ++));
}

const char *SU_ReadString(void)
{
	return g_engfuncs.pfnCmd_Argv(s_iCurParam ++);
}

void SU_SetParamToRead(int i)
{
	s_iCurParam = i;
}

#endif