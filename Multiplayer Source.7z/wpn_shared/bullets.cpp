#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "bullets.h"
#include "weapons.h"
#include "decals.h"

// show ballistic path.
//#define DEBUG_BULLETS_PATH

CBaseBullets *g_pBulletsRoot = NULL;
Vector	CBaseBullets::s_vecHullMaxs	= Vector(0.5f, 0.5f, 0.5f);		// 12.7mm
Vector	CBaseBullets::s_vecHullMins	= Vector(-0.5f, -0.5f, -0.5f);

/*
===================================
Constructor & Destructor

Chains are here.
===================================
*/
CBaseBullets::CBaseBullets(void)
{
	m_vecLastOrigin		= Vector();
	m_vecOrigin			= Vector();
	m_vecLastHit		= Vector();
	m_vecForce			= VecDbl();
	m_vecVelocity		= VecDbl();
	m_vecAcceleration	= VecDbl();

	m_pAmmo				= NULL;
	m_pItem				= NULL;
	m_pPlayer			= NULL;
	m_bRemove			= false;
	m_iHitCount			= 0;
	m_flSpin			= 0;

	m_sColor.r	= RANDOM_LONG(0, 255);
	m_sColor.g	= RANDOM_LONG(0, 255);
	m_sColor.b	= RANDOM_LONG(0, 255);

	m_pNext		= NULL;

	CBaseBullets *p = g_pBulletsRoot;
	while (p)
	{
		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// p == NULL means this is the first.
	if (!p)
		g_pBulletsRoot = this;
	else
		p->m_pNext = this;
}

CBaseBullets::~CBaseBullets(void)
{
	// if killing chain root, give chair to his next.
	if (g_pBulletsRoot == this)
	{
		g_pBulletsRoot = m_pNext;
		return;
	}

	// otherwise, which means at least two bullets in chain, and g_pBulletsRoot->m_pNext != NULL
	CBaseBullets *pl	= g_pBulletsRoot;
	CBaseBullets *p		= g_pBulletsRoot->m_pNext;

	while (p)
	{
		if ( p == this )
		{
			pl->m_pNext	= m_pNext;
			break;
		}

		pl	= p;
		p	= p->m_pNext;
	}
}

/*
===================================
Think

Update everything.
===================================
*/

extern int gmsgGunShot;
void UTIL_GunShotEfx(TraceResult *pTrace, Vector vecSrc, int iWeaponType)
{
	if (!pTrace->pHit)
		return;

	if (pTrace->pHit->v.solid != SOLID_BSP && pTrace->pHit->v.movetype != MOVETYPE_PUSHSTEP)
		return;

	MESSAGE_BEGIN( MSG_PAS, gmsgGunShot, pTrace->vecEndPos );
		WRITE_COORD( pTrace->vecEndPos.x - pTrace->vecPlaneNormal.x );
		WRITE_COORD( pTrace->vecEndPos.y - pTrace->vecPlaneNormal.y );
		WRITE_COORD( pTrace->vecEndPos.z - pTrace->vecPlaneNormal.z );
		WRITE_COORD( vecSrc.x );
		WRITE_COORD( vecSrc.y );
		WRITE_COORD( vecSrc.z );
		WRITE_BYTE( iWeaponType );
	MESSAGE_END();
}

void UTIL_BeamPoints(Vector vecSrc, Vector vecEnd, short iModel, int iStartFrame, int iLife, int iWidth, int iAmplitude, int R, int G, int B, int iBrightness, int iScrollSpeed)
{
	MESSAGE_BEGIN( MSG_PAS, SVC_TEMPENTITY, vecSrc );
	WRITE_BYTE(TE_BEAMPOINTS);
	WRITE_COORD(vecSrc.x);
	WRITE_COORD(vecSrc.y);
	WRITE_COORD(vecSrc.z);
	WRITE_COORD(vecEnd.x);
	WRITE_COORD(vecEnd.y);
	WRITE_COORD(vecEnd.z);
	WRITE_SHORT(iModel);
	WRITE_BYTE(iStartFrame);
	WRITE_BYTE(30);	// framerate
	WRITE_BYTE(iLife);
	WRITE_BYTE(iWidth);
	WRITE_BYTE(iAmplitude);
	WRITE_BYTE(R);
	WRITE_BYTE(G);
	WRITE_BYTE(B);
	WRITE_BYTE(iBrightness);
	WRITE_BYTE(iScrollSpeed);
	MESSAGE_END();
}

void CBaseBullets::Think(double flFrameRate)
{
	double	flDensity	= DENSITY_AIR;

	switch (POINT_CONTENTS(m_vecOrigin))
	{
	case CONTENT_LAVA:
		flDensity = DENSITY_LAVA;
		break;

	case CONTENT_WATER:
		flDensity = DENSITY_WATER;
		break;

	case CONTENT_SKY:
		m_bRemove = true;
		return;
	}

	// in the air, the angle of bullect will have some random movement.
	// get cur angle by velocity.
	Vector vecAngles;
	VEC_TO_ANGLES(Vector(m_vecVelocity), vecAngles);

	// some strange reason, that only this way it can works fine. pev->v_angle????
	vecAngles.x	= -vecAngles.x;

	// create a random factor to change angles. it's nearly impossible to move upward.
	Vector vecAngChange(RANDOM_FLOAT(-0.1, 0.5), RANDOM_FLOAT(-2.5, 2.5), 0);

	// a faster spin will reduce the change of angle.
	vecAngChange /= max(m_flSpin / 100.0, 1.0);

	// angle will effect on the dir of vel.
	MAKE_VECTORS(vecAngles + vecAngChange);
	m_vecVelocity = VecDbl(gpGlobals->v_forward * m_vecVelocity.Length());

	// drag force		=	-vel(dir) * 1/2 * �� * v^2 * Cd * A
	m_vecForce			=	-m_vecVelocity.Normalize() * 0.5 * flDensity * DotProduct(m_vecVelocity, m_vecVelocity) * m_pAmmo->m_flDragCoefficient * m_pAmmo->m_flArea;
	m_vecAcceleration	=	m_vecForce / double(m_pAmmo->m_flProjectileWt);
	m_vecAcceleration	+=	VecDbl(0, 0, GRAV_ACC);	// negative sign is included

	m_vecLastOrigin		=	m_vecOrigin;
	m_vecVelocity		+=	m_vecAcceleration * flFrameRate;
	m_vecOrigin			+=	Vector((m_vecVelocity / 0.0254) * flFrameRate);	// convert meter to inches.

	m_flSpin			*=	RANDOM_FLOAT(0.65, 0.75);

	TraceResult tr;
	UTIL_TraceCustomHull(m_vecLastOrigin, m_vecOrigin, dont_ignore_monsters, dont_ignore_glass, s_vecHullMins, s_vecHullMaxs, NULL, &tr);

	if (tr.flFraction >= 1)
	{
#ifdef DEBUG_BULLETS_PATH
		UTIL_BeamPoints(m_vecOrigin, m_vecLastOrigin, MODEL_INDEX(g_pModelNameLaser), 0, 200, 20, 0, 255, 255, 255, 255, 0);
#endif
		return;
	}
	else	// only do damage over here.
	{
		UTIL_GunShotEfx(&tr, m_vecLastOrigin, m_pAmmo->m_iType);

		// get impact as damage.
		// I = F*dt = m * (dv / dt)
		// In this case, dv = a * dt
		int iDamage = m_pAmmo->m_flProjectileWt * m_vecAcceleration.Length() * RANDOM_FLOAT(10, 20);

		ClearMultiDamage();
		gMultiDamage.type = DMG_BULLET | DMG_NEVERGIB;

		// do damage, paint decals
		CBaseEntity *pEntity = CBaseEntity::Instance(tr.pHit);

		// dont shoot a godmode thing.
		if (pEntity->pev->takedamage == DAMAGE_NO)
			iDamage = 0;

		if ( iDamage )
		{
			pEntity->TraceAttack(m_pPlayer->pev, iDamage, Vector(m_vecVelocity.Normalize()), &tr, DMG_BULLET | DMG_NEVERGIB);

			TEXTURETYPE_PlaySound(&tr, m_vecLastOrigin, m_vecOrigin);
		}

		// only decal glass
		if ( !FNullEnt(tr.pHit) && VARS(tr.pHit)->rendermode != 0)
		{
			UTIL_DecalTrace( &tr, DECAL_GLASSBREAK1 + RANDOM_LONG(0,2) );
		}

		// make bullet trails
		UTIL_BubbleTrail( m_vecLastOrigin, tr.vecEndPos, Vector(m_vecLastOrigin - tr.vecEndPos).Length() / 64.0f );

		ApplyMultiDamage(m_pPlayer->pev, m_pPlayer->pev);	// UNDONE: player not the real Inflictor.
	}

	Vector	vecExpected = m_vecOrigin;
	Vector	vecSteps	= (vecExpected - tr.vecEndPos).SetLength(PENETRATE_STEPS);
	Vector	vecSrc		= tr.vecEndPos;
	bool	bFound		= false;

	for (short i = 0; i < int(PENETRATE_MAX/PENETRATE_STEPS); i ++)
	{
		vecSrc	+=	vecSteps;	// then the vecSrc will become the point after the wall

		int iResult = POINT_CONTENTS(vecSrc);
		if (iResult == CONTENT_EMPTY || iResult == CONTENT_LAVA || iResult == CONTENT_WATER)
		{
			bFound = true;
			break;
		}
	}

	m_vecOrigin = tr.vecEndPos;
	m_iHitCount ++;
	m_bRemove = !!(m_iHitCount > 3);

	// if cant found a point to penetrate, check refraction
	if (!bFound)
	{
LAB_REFRACTION:
		Plane plWall	= Plane(tr.vecPlaneNormal, tr.flPlaneDist);
		m_vecVelocity	= VecDbl(plWall.Refraction(Vector(m_vecVelocity)));

		ReduceLinearKinetic(GetLinearKinetic() * (0.9 / (1.0 - m_pAmmo->m_flArea * 1000.0)) );

		m_flSpin		*= 0.5;

#ifdef DEBUG_BULLETS_PATH
		UTIL_BeamPoints(m_vecOrigin, m_vecLastOrigin, MODEL_INDEX(g_pModelNameLaser), 0, 200, 20, 0, 255, 255, 255, 255, 0);
#endif
		return;
	}

	TraceResult tr2;
	UTIL_TraceCustomHull(vecSrc, tr.vecEndPos, dont_ignore_monsters, dont_ignore_glass, s_vecHullMins, s_vecHullMaxs, NULL, &tr);

	float flThickness = (tr.vecEndPos - tr2.vecEndPos).Length();	// these are the two point on wall.

	if (flThickness * 0.0254f * PENETRATE_K_REQ > GetLinearKinetic())
		goto LAB_REFRACTION;

	m_vecOrigin = tr2.vecEndPos;
	ReduceLinearKinetic(flThickness * 0.0254f * PENETRATE_K_REQ);

	// after through wall, angle will change.
	// the steps is same as before.
	// create a random factor to change angles.
	float flAngleMax= 45.0f * (flThickness / PENETRATE_MAX);
	vecAngChange.x	= RANDOM_FLOAT(-flAngleMax, flAngleMax);
	vecAngChange.y	= RANDOM_FLOAT(-flAngleMax, flAngleMax);

	// a faster spin will reduce the change of angle.
	// you cant enlarge the change!
	vecAngChange /= max(m_flSpin / 1000.0, 1.0);

	// angle will effect on the dir of vel.
	MAKE_VECTORS(vecAngles + vecAngChange);
	m_vecVelocity = VecDbl(gpGlobals->v_forward * m_vecVelocity.Length());

	// cost of half current spin.
	m_flSpin		*= 0.5;

	UTIL_GunShotEfx(&tr2, vecSrc, m_pAmmo->m_iType);

#ifdef DEBUG_BULLETS_PATH
	UTIL_BeamPoints(m_vecOrigin, m_vecLastOrigin, MODEL_INDEX(g_pModelNameLaser), 0, 200, 20, 0, 255, 255, 255, 255, 0);
#endif

}

void CBaseBullets::ChainThink(double flFrameRate)
{
	Think(flFrameRate);

	if (m_pNext)
		m_pNext->ChainThink(flFrameRate);
}

void CBaseBullets::ReduceLinearKinetic(double number)
{
	double Ek = GetLinearKinetic();
	if (Ek < number)
	{
		m_vecVelocity = VecDbl();
		m_bRemove = true;
		return;
	}
	else
	{
		m_vecVelocity = m_vecVelocity.SetLength(sqrt((Ek - number) * 2.0 / m_pAmmo->m_flProjectileWt));
	}
}

void CheckBulletsChain(void)
{
	bullet_t *p = g_pBulletsRoot;

	while (p)
	{
		if (p->GetLinearKinetic() <= STUCK_EK_REQ || p->m_bRemove)
		{
			bullet_t *save = p->m_pNext;
			delete p;
			p = save;
		}
		else
			p = p->m_pNext;
	}
}