﻿/***

Modern Warfare Develop Team
CXM29.cpp - Luna's Weapon Pack

Coder:	Luna the Reborn
Model:	Innocent Blue	(Soviet Defender for old version.)
Sound:	Matoilet
Dxt/Hud:Usagi Chan
Scope:	Innocent Blue & avJäger

Create Date: 2018/07/11
Reborn Date: 2018/10/31

***/

#include <sysdef.h>

#ifndef CSMW_SERVER_DLL

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "wpn_cmd_shared.h"
#include "input.h"
#include "view.h"
#include "pm_defs.h"
#include "event_api.h"
#include "triangleapi.h"
#include "DrawFonts.h"
#include "GameStudioModelRenderer.h"

#undef RECORD_ANIM_F
#undef RECORD_ANIM_S

#define RECORD_ANIM_F(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat(); \
											else if (!strcmp(p->GetName(), "eft_"#keyname"")) \
												s_AnimData[##enumname].m_fe = p->GetFloat();

#define RECORD_ANIM_S(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat();

#else

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "monsters.h"
#include "weapons.h"
#include "decals.h"
#include "bullets.h"
#include "soundent.h"
#include "newkeyvalues.h"
#include "wpn_cmd_shared.h"

#endif

#ifndef CSMW_SERVER_DLL

int			CXM29::s_iItemType	= 0;
animdb_t	CXM29::s_AnimData[ANIM_COUNT];
recdb_t		CXM29::s_sXM29_GrRecoil;
mag_t		*CXM29::s_pGrMag		= NULL;
unsigned	*CXM29::s_piGrenadeMag	= NULL;
ammo_t		*CXM29::s_pGrAmmoType	= NULL;


void CXM29::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;

	// GET DATA
	NewKeyValues *pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (!strcmp(p->GetName(), "grenade_magtype"))
			s_pGrMag = &g_sMagData[SearchMagTypeViaName(p->GetString())];

		p = p->GetNextValue();
	}

	s_piGrenadeMag = &(g_cMagManager.m_iMagAmount[s_pGrMag->m_iType]);
	s_pGrAmmoType = s_pGrMag->m_pAmmoType;

	// GET ANIMS
	pDatabase = pRoot->FindKey("animations");
	if (!pDatabase)
		return;

	p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_ANIM_S(gr_shoot,			ANIM_HE_SHOOT)
		RECORD_ANIM_F(gr_reload,		ANIM_HE_RELOAD)
		RECORD_ANIM_F(gr_reload_full,	ANIM_HE_RELOAD_EMPTY)
		RECORD_ANIM_F(changemode,		ANIM_CHANGE_MODE)
		RECORD_ANIM_S(switch_to_HE,		ANIM_TO_HE)
		RECORD_ANIM_S(switch_to_KE,		ANIM_TO_KE)

		p = p->GetNextValue();
	}

	// GET GRENADE RECOIL
	pDatabase = pRoot->FindKey("recoil_grenade");
	LoadWeaponRecoil(pDatabase, &s_sXM29_GrRecoil);
}

int CXM29::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 1 },	// gun			= 3;
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 2 },	// KE_selector	= 10;
		{ 0, 2 },	// MODE_selector= 11;
	};

	if (m_iFireMode == CSMW_FIREMODE_SINGLE &&	// even in HE mode, this still stands, since grenade codes doesn't change this value at all.
		m_iDisplayingAnim != WPNANIM_NUM(SELECTOR_A) &&	// shouldn't use this submodel when playing switching anim.
		m_iDisplayingAnim != WPNANIM_NUM(SELECTOR_B))	// since these anims are made based on body=0 state.
		info[10].body = 1;

	if (m_bGrenadeMode && !m_bChanging)	// same reason above.
		info[11].body = 1;

	return CalcBody(info, 12);
}

void CXM29::BindDataToHud(void)
{
	CBaseWeapons::BindDataToHud();

	// still use pri.bpammo to show GR ammo.
	gStdWpnHud::m_sPriWpn.m_piClip		= m_bGrenadeMode ? &m_iGrenadeClip : &m_iClip;
	gStdWpnHud::m_sPriWpn.m_piClipMax	= m_bGrenadeMode ? &s_pGrMag->m_iClip : &m_sItemData.m_pMagDB->m_iClip;
	gStdWpnHud::m_sPriWpn.m_piBpNum		= m_bGrenadeMode ? s_piGrenadeMag : &BP_MAGAZINE;
	gStdWpnHud::m_sPriWpn.m_piBpMax		= NULL;

	gStdWpnHud::m_sSedWpn.m_bDisplay			= true;
	gStdWpnHud::m_sSedWpn.m_pbitsFlags			= &m_ulStatus;
	gStdWpnHud::m_sSedWpn.m_piFireMode			= &XM29_GRENADE_FIREMODE;
	gStdWpnHud::m_sSedWpn.m_piszFireModeIcons	= m_pGrenadeAmmoDB->m_iIdAmmoIcons;
	gStdWpnHud::m_sSedWpn.m_pszBpName			= m_pGrenadeAmmoDB->m_wszEndoName;
}

void CXM29::SwitchSwitcher(void)
{
	if (!m_bGrenadeMode || !m_bInScope)	// only avaliable in XM29 original scope.
		return CBaseWeapons::SwitchSwitcher();

	// when in grenade mode, switcher key use to change grenade mode.
	FCS_SwitchGrenadeMode();
}

void CXM29::ChangeMode(void)
{
	WeaponAnim(m_bGrenadeMode ? &s_AnimData[ANIM_TO_KE] : &s_AnimData[ANIM_TO_HE], 1);
	m_bChanging = true;

	SetFunc(m_pfnItemPostFrame, &CXM29::Spec_ItemPostFrame);
}

void CXM29::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	m_iGrenadeClip = s_pGrMag->m_iClip;
	m_iGrChamberClip = 1;

	// FIXME: for test
	(*s_piGrenadeMag) += 20;

	FCS_Initialize();

	// assign the must-use var.
	m_pGrenadeAmmoDB = s_pGrMag->m_pAmmoType;

	// this gun currently has only FCS scope.
	SetFunc(m_pfnSecondaryAttack,	&CXM29::Def_Scope);
}

void CXM29::HUD_Draw2D(void)
{
	CBaseWeapons::HUD_Draw2D();

	if (!m_bInScope || !m_bGrenadeMode)	// only draw in XM29 original scope.
		return;

	FCS_DrawText();
}

void CXM29::HUD_Think3D(void)
{
	CBaseWeapons::HUD_Think3D();

	if (!m_bGrenadeMode)
		return;

	FCS_Prediction();
}

void CXM29::HUD_Draw3D(void)
{
	CBaseWeapons::HUD_Draw3D();

	if (!m_bGrenadeMode)
		return;

	FCS_ShowResult();
}

bool CXM29::MouseWheel(bool bUp)
{
	if (!m_bGrenadeMode || !m_bInScope || m_iGrenadeType == GR_TOUCH)	// only avaliable in XM29 original scope.
		return CBaseWeapons::MouseWheel(bUp);

	return HTW_MouseWheel(bUp);
}

int CXM29::GetMuzzleEnum(void)
{
	if (m_bGrenadeMode)	// for FCS_Prediction()
		return 2;
	else
		return 0;
}

int CXM29::GetShellEnum(void)
{
	if (m_bGrenadeMode)	// XM25s have grenade shell cases.
		return 3;
	else
		return 1;
}

void CXM29::ItemHolster(void)
{
	Def_ItemHolster();
	HTW_ItemHolster();

	m_bChanging = false;
}

void CXM29::Spec_ItemPostFrame(void)
{
	m_bChanging = false;

	if (m_bGrenadeMode)	// change to rifle mode
	{
		m_bGrenadeMode = false;

		// function swap.
		SetFunc(m_pfnPrimaryAttack,		&CXM29::Def_PrimaryAttack);
		SetFunc(m_pfnItemPostFrame,		&CXM29::Def_ItemPostFrame);
		SetFunc(m_pfnWeaponReload,		&CXM29::Def_WeaponReload);

		// database swap.
		// Use global database, since we didn't record KE data first place
		WPNANIM(SHOOT)			= QD_WPNANIM(SHOOT);
		WPNANIM(RELOAD)			= QD_WPNANIM(RELOAD);
		WPNANIM(RELOAD_EMPTY)	= QD_WPNANIM(RELOAD_EMPTY);

		m_sItemData.m_pMagDB	= g_sItemData[s_iItemType].m_pMagDB;
		m_sItemData.m_pAmmoDB	= g_sItemData[s_iItemType].m_pAmmoDB;
	}
	else	// change to grenade mode
	{
		m_bGrenadeMode = true;

		SetFunc(m_pfnPrimaryAttack,		&CXM29::Gr_PrimaryAttack);
		SetFunc(m_pfnItemPostFrame,		&CXM29::Gr_ItemPostFrame);
		SetFunc(m_pfnWeaponReload,		&CXM29::Gr_WeaponReload);

		WPNANIM(SHOOT)			= s_AnimData[ANIM_HE_SHOOT];
		WPNANIM(RELOAD)			= s_AnimData[ANIM_HE_RELOAD];
		WPNANIM(RELOAD_EMPTY)	= s_AnimData[ANIM_HE_RELOAD_EMPTY];

		m_sItemData.m_pMagDB	= s_pGrMag;
		m_sItemData.m_pAmmoDB	= s_pGrMag->m_pAmmoType;
	}

	gStdWpnHud::m_sPriWpn.m_piClip		= m_bGrenadeMode ? &m_iGrenadeClip : &m_iClip;
	gStdWpnHud::m_sPriWpn.m_piClipMax	= m_bGrenadeMode ? &s_pGrMag->m_iClip : &m_sItemData.m_pMagDB->m_iClip;
	gStdWpnHud::m_sPriWpn.m_piBpNum		= m_bGrenadeMode ? s_piGrenadeMag : &BP_MAGAZINE;
	gStdWpnHud::m_sPriWpn.m_piBpMax		= NULL;
}

void CXM29::Gr_PrimaryAttack(void)
{
	int truecontents;
	if (gEngfuncs.PM_PointContents(GetMuzzleOrigin(), &truecontents) != CONTENT_EMPTY)
	{
		gHUD::AddHintText("#MW_Hint_WallLauncher");
		return;
	}

	pmtrace_t tr;
	UTIL_TraceLine(g_pparams.vieworg, GetMuzzleOrigin(), PM_STUDIO_BOX, -1, &tr, m_pPlayer->index, 2);
	if (tr.fraction < 1)
	{
		gHUD::AddHintText("#MW_Hint_WallFire");
		return;
	}

	WeaponAnim(&s_AnimData[ANIM_HE_SHOOT], 1);
	KickBack(&s_sXM29_GrRecoil);

	DrawGunSmoke();

	if (!m_iGrenadeClip)
		m_iGrChamberClip --;
	else
		m_iGrenadeClip --;

	// for XM25 only: it has shell cases, we need to draw it.
	// stored in grenade ammo database.
	SpawnShell(m_pPlayer,
			   gEngfuncs.pEventAPI->EV_FindModelIndex(s_pGrAmmoType->m_szShellModel),
			   GetShellOrigin(),
			   s_pGrAmmoType->m_iShellSoundType,
			   s_pGrAmmoType->m_iShellBody);

	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(GetMuzzleOrigin());
	SU_WriteVector	(g_pparams.viewangles);
	SU_WriteFloat	(0.0f);	// aiming baseline is useless here.
	SU_WriteInteger	(m_iGrenadeType);
	SU_WriteFloat	(m_flGrenadeDelay);
	SU_End			();

	m_flNextPriAttack = s_AnimData[ANIM_HE_SHOOT].m_fe;	// use this value for GR attack rate.
}

void CXM29::Gr_ItemPostFrame(void)
{
	if (m_ulStatus & WPN_FLAG_HOLSTERING)
	{
		m_ulStatus |= WPN_FLAG_CAN_HOLSTER;
		SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_HOLSTER)
	{
		if (!m_pSwitchTo)
			SwitchWeapon(UTIL_SortItemsBySlot());
		else if (CanItemHolster())
			SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_USE_SUB && !(m_ulStatus & WPN_FLAG_RUN))
	{
		// not support WPN_FLAG_TRY_UNTIL_DONE, since no function to cancel the flag.
		m_ulStatus &= ~WPN_FLAG_SHOULD_USE_SUB;

		if (m_pSubsItem)
		{
			m_bUsingSubs = true;
			m_pSubsItem->Use();
			m_bUsingSubs = false;
		}
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RELOAD && !(m_ulStatus & WPN_FLAG_RUN))	// I have no other way to achieve it...
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;

		WeaponReload();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_MELEE)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_MELEE;

		Melee();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_QT)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_QT;

		QuickThrow(m_iSavedQuickSlot);
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_RUN)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_RUN;

		RunStart();
		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_AIM)
	{
		if (!(m_ulStatus & WPN_FLAG_TRY_UNTIL_DONE))
			m_ulStatus &= ~WPN_FLAG_SHOULD_AIM;

		AimUp();
		return;
	}

	if (m_flNextBlockCheck < UTIL_WeaponTimeBase())
	{
		CheckBlocked();
		m_flNextBlockCheck = UTIL_WeaponTimeBase() + 0.08;

		if ( m_bBlocked && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_UP)
			&& ( !WPNANIM_NUM(BLOCK_IDLE) || (WPNANIM_NUM(BLOCK_IDLE) && m_iDisplayingAnim != WPNANIM_NUM(BLOCK_IDLE)) )	/* only check BLOCK_IDLE when there is one. */
			&& ( !IS_RUNNING && !IS_AIMING )	/* if playing RUN_IDLE or AIM_IDLE, don't bother. */
			)
		{
			WeaponAnim(&WPNANIM(BLOCK_UP), 2);
		}
		else if (!m_bBlocked && m_iDisplayingAnim == WPNANIM_NUM(BLOCK_UP))
		{
			WeaponAnim(&WPNANIM(BLOCK_DOWN), 2);
		}
	}

	if (m_bInReload && m_sItemData.m_pMagDB)
	{
		// there is an anim that rechamber the first bullet into chamber...
		if (m_iGrenadeClip <= 0 && m_iGrChamberClip <= 0)
		{
			m_iGrenadeClip	= m_sItemData.m_pMagDB->m_iClip - m_sItemData.m_iChamberClip;
			m_iGrChamberClip	= m_sItemData.m_iChamberClip;
		}
		else
			m_iGrenadeClip	= m_sItemData.m_pMagDB->m_iClip;

		BP_MAGAZINE	= max(BP_MAGAZINE - 1, 0);
		m_bInReload	= false;
	}
	else if (m_bInReload)	// which means chamber-mag weapons.
	{
		// we need to avoid the 29->30 rounds' bug.
		m_iGrChamberClip = 0;

		// here from HLSDK
		int j = min(m_sItemData.m_iChamberClip - m_iGrChamberClip, int(AMMUNITION) );
		
		m_iGrChamberClip += j;
		AMMUNITION -= j;
		m_bInReload = false;

		// no more bounce ammo, since this time it's all in chamber.
	}

	int bitsButton = CL_GetButtonBits();
	if (!(bitsButton & IN_ATTACK) && m_iShotsFired > 0 && UTIL_WeaponTimeBase() > m_flDecreaseShotsFired)
	{
		m_bTriggerRel = true;
		m_iShotsFired --;
		m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + (m_bDelayFire ? 0.4f : 0.0225f);

		if (m_bDelayFire)
			m_bDelayFire = false;
	}
	else if (!(bitsButton & IN_ATTACK) )
		m_bTriggerRel = true;

	if (!(bitsButton & IN_ATTACK2) )
		m_bAimCoolDown = true;
	
	if (bitsButton & IN_ATTACK && CanWeaponFire())
		PrimaryAttack();
	else if (bitsButton & IN_ATTACK && IS_RUNNING)	// required by avJager.
		RunStop();
	if (m_bAimCoolDown && bitsButton & IN_ATTACK2 && m_flNextSedAttack <= 0.0f)
		SecondaryAttack();
	else if (bitsButton & IN_RELOAD)
		WeaponReload();
	else if (m_flNextIdle <= 0.0f)
		WeaponIdle();
}

void CXM29::Gr_WeaponReload(void)
{
	if ( (m_sItemData.m_pMagDB && (m_iGrenadeClip >= m_sItemData.m_pMagDB->m_iClip || m_sItemData.m_pMagDB->m_iClip < 0 || BP_MAGAZINE <= 0) )			/* condiction for the mag function presented. */
		 || (!m_sItemData.m_pMagDB && (m_iGrChamberClip >= m_sItemData.m_iChamberClip || m_sItemData.m_iChamberClip < 0 || AMMUNITION <= 0)) )	/* condiction for non-mag weapon. */
	{
		return;
	}

	// if aim down anim presented, you cant skip it or play it at the same time.
	if (m_ulStatus & WPN_FLAG_AIM)
	{
		SecondaryAttack();

		if (WPNANIM_NUM(AIM_DOWN) > 0)
		{
			// come back later plz.
			m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
			return;
		}
	}

	// running is defnately a fully anim.
	if (m_ulStatus & WPN_FLAG_RUN)
	{
		RunStop();
		m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
		return;
	}

	m_iShotsFired	= 0;
	m_bInReload		= true;

	WeaponAnim((m_iGrChamberClip <= 0) ? &WPNANIM(RELOAD_EMPTY) : &WPNANIM(RELOAD), 2);

	// it should be came from something interrupt reloading??
	if (m_ulStatus & WPN_FLAG_CONTINUE_ANIM)
	{
		PopAnim();
		m_ulStatus &= ~WPN_FLAG_CONTINUE_ANIM;
	}

	m_ulStatus &= ~WPN_FLAG_SHOULD_RELOAD;
	m_ulStatus &= ~WPN_FLAG_TRY_UNTIL_DONE;

	SU_Begin		(WPN_CMD_RELOAD);
	SU_WriteInteger	(m_iItemType);
	SU_End			();
}


#else

char	CXM29::s_szGrenadeLaunchSound[64];
char	CXM29::s_szGrenadeModel[64];
int		CXM29::s_iItemType = 0;
ammo_t	*CXM29::s_pGrAmmoType = NULL;

void CXM29::Initialize(NewKeyValues * pRoot, int iType)
{
	g_sItemData[iType].PrimaryAttack = PrimaryAttack;

	// GET DATA
	NewKeyValues *pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (!strcmp(p->GetName(), "grenade_magtype"))
			s_pGrAmmoType = g_sMagData[SearchMagTypeViaName(p->GetString())].m_pAmmoType;

		RECORD_STRING	(grenade_shootsnd,	s_szGrenadeLaunchSound)
		RECORD_STRING	(grenade_model,		s_szGrenadeModel)

		p = p->GetNextValue();
	}
}

void CXM29::Precache(void)
{
	if (!GetWeaponTypeFromName("wpn_xm29"))
		return;

	PRECACHE_SOUND(s_szGrenadeLaunchSound);
	PRECACHE_MODEL(s_szGrenadeModel);
}

void CXM29::PrimaryAttack(void *pEntity, int iType, Vector vecSrc, Vector vecAngle, float flAimBaseline)
{
	if (CMD_ARGC() <= 9)	// which means it's the normal shoot.
		return gWpnHandler::PrimaryAttack(pEntity, iType, vecSrc, vecAngle, flAimBaseline);

	CBasePlayer	*pPlayer = (CBasePlayer	*)CBasePlayer::Instance((edict_t *)pEntity);

	if (!pPlayer)
		return;

	// player anims.
	pPlayer->SetAnimation(PLAYER_ATTACK1);

	// sound here
	CSoundEnt::InsertSound(bits_SOUND_COMBAT|bits_SOUND_PLAYER, vecSrc, g_sItemData[iType].m_iGunVolume, 0.2);
	g_engfuncs.pfnEmitSound(pPlayer->edict(), CHAN_WEAPON, s_szGrenadeLaunchSound, VOL_NORM, g_sItemData[iType].m_flSoundAttenuation, NULL, 98 + RANDOM_LONG(-3, 3));
	pPlayer->m_iWeaponFlash		=	g_sItemData[iType].m_iGunFlash;
	pPlayer->m_iWeaponVolume	=	g_sItemData[iType].m_iGunVolume;
	pPlayer->pev->effects		|=	EF_MUZZLEFLASH;

	int iGrType = SU_ReadInteger();
	float flDelay = SU_ReadFloat();

	CGrenade::Launch( pPlayer->pev, vecSrc, s_pGrAmmoType, iGrType, s_iItemType, flDelay );
}

#endif