/***

Modern Warfare Develop Team
CFN57.cpp

Coder:	Luna the Reborn
Model:	Innocent Blue
Sound:	Innocent Blue
Dxt/Hud:Usagi Chan

Create Date: 2018/07/05

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"


int CFN57::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands	= 0
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },	// studio	= 3

		{ 0, 2 },	// slide	= 4
		{ 0, 2 },	// scope	= 5
		{ 0, 3 },	// muzzle	= 6
		{ 0, 2 },	// laser	= 7
	};

	if (IsNonslidemoveAnim(m_iDisplayingAnim) && IsWeaponEmpty())
		info[4].body = 1;

	if (m_bitsAccessories & ACC_DOT)
		info[5].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[6].body = 1;
	else if (m_bitsAccessories & ACC_COMPENSATOR)
		info[6].body = 2;

	if (m_bitsAccessories & ACC_LASER)
		info[7].body = 1;

	return CalcBody(info, 8);
}

void CFN57::SH_ResetAnims(void)
{
	CBasePistol::SH_ResetAnims();

	// but IB's FN57 using two hands to draw_first, let's remove this glitch.
	if (IsDoubleHolding())
		WPNANIM(DRAW_FIRST) = WPNANIM(DRAW);
}