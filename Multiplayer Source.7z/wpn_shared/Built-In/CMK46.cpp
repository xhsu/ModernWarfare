/***

Modern Warfare Develop Team
CMK46.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/04

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "event_api.h"
#include "GameStudioModelRenderer.h"


float		CMK46::s_flTimeChainSwitch	= float(2.558139534883721);
static		gStdWpnHud::CBaseMenuAcc s_Acc_Mk46_NewOptic;
sight_t		CMK46::s_NewOpticSight = { Vector(-4.05, -12, 0), 50 };
int			CMK46::s_iShellBandIndex = 5;
int			CMK46::s_iBandSpawningAttm = 2;
int			CMK46::s_iBandSoundType = 2;


void CMK46::Initialize(NewKeyValues * pRoot, int iType)
{
	// GET OPTICAL SCOPE
	LoadWeaponSight(pRoot->FindKey("sight"), &s_NewOpticSight, "new");

	// GET DATA
	NewKeyValues *pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_FLOAT	(flTimeChainSwitch,	s_flTimeChainSwitch)
		RECORD_INT		(iShellBandIndex,	s_iShellBandIndex)
		RECORD_INT		(iBandSpawningAttm,	s_iBandSpawningAttm)
		RECORD_INT		(iBandSoundType,	s_iBandSoundType)

		p = p->GetNextValue();
	}
}

int CMK46::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 2 },	// hands	= 0
		{ 0, 1 },
		{ 0, 1 },	// gun		= 2
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 16 },	// bullets	= 5
		{ 0, 6 },	// scope	= 6
		{ 0, 4 },	// muzzle	= 7
		{ 0, 2 },	// laser	= 8
	};

	// chain bullets' effect. Save the value and use it later.
	info[5].body = m_iChainMdlBody = SET_RANGE(16 - m_iClip, 15, 0);

	if (m_bFullChain)	// it's inserting a full ammo box or sth...
		info[5].body = 0;

	if (m_bitsAccessories & ACC_ROUND)
		info[6].body = 1;
	else if (m_bitsAccessories & ACC_HOLO)
		info[6].body = 2;
	else if (m_bitsAccessories & ACC_DOT)
		info[6].body = 3;
	else if (m_bitsAccessories & ACC_ACOG)
		info[6].body = 4;
	else if (m_bitsAccessories & MK46_ACC_NEW_OPTIC)
		info[6].body = 5;

	if (m_bitsAccessories & ACC_SILENCER)
		info[7].body = 1;
	else if (m_bitsAccessories & ACC_MUZZLEBREAKER)
		info[7].body = 2;
	else if (m_bitsAccessories & ACC_FLASHHIDER)
		info[7].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[8].body = 1;

	return CalcBody(info, 9);
}

void CMK46::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	m_bFullChain	= false;
}

void CMK46::ItemPreFrame(void)
{
	Def_ItemPreFrame();

	// updates about sight.
	if (m_bitsAccessories & MK46_ACC_NEW_OPTIC)
		SetFunc(m_pfnSecondaryAttack, &CMK46::Def_Scope);
	else
		SetFunc(m_pfnSecondaryAttack, &CMK46::Def_SteelSight);

	if (m_flChainThink && m_flChainThink <= UTIL_WeaponTimeBase())
	{
		if (m_bInReload)	// reloading effect.
		{
			m_bFullChain	= true;
			m_flChainThink	= UTIL_WeaponTimeBase() + WPNANIM_DUR(RELOAD_EMPTY) - s_flTimeChainSwitch;
		}
		else	// stop m_bFullChain controlling
		{
			m_bFullChain	= false;
		}
	}
}

void CMK46::WeaponReload(void)
{
	if (m_iChainMdlBody > 3)	// at this point, we shall use full_reload
	{
		m_iClip = 0;
		m_iChamberClip = 0;
	}

	Def_WeaponReload();

	m_flChainThink	= UTIL_WeaponTimeBase() + s_flTimeChainSwitch;
	m_bFullChain	= false;
}

void CMK46::HUD_GenerateAccMenu(void)
{
	using namespace gStdWpnHud;

	CBaseWeapons::HUD_GenerateAccMenu();

	// add conflict to other sight acc.
	CBaseMenuAcc *pOtherAcc = dynamic_cast<CBaseMenuAcc *>(m_sAccMenu.m_pFirstChild);
	while (pOtherAcc)
	{
		if (pOtherAcc->m_bitsIndex & ACC_SIGHT)
		{
			pOtherAcc->m_bitsConflict |= MK46_ACC_NEW_OPTIC;
		}

		pOtherAcc = dynamic_cast<CBaseMenuAcc *>(pOtherAcc->m_pNext);
	}

	// set the values.
	s_Acc_Mk46_NewOptic.m_bitsIndex		= MK46_ACC_NEW_OPTIC;
	s_Acc_Mk46_NewOptic.m_pBitsCurAcc	= &m_bitsAccessories;
	s_Acc_Mk46_NewOptic.m_bitsConflict	= ACC_SIGHT;

	// use util, it's easier.
	UTIL_SearchInLocalize("#MW_Acc_Mk46_NewOptic", s_Acc_Mk46_NewOptic.m_wszString, "#MW_Acc_Error");

	// install to m_sAccMenu
	m_sAccMenu.AddChild(&s_Acc_Mk46_NewOptic);
}

int CMK46::GetAimFOV(void)
{
	if (m_bitsAccessories & MK46_ACC_NEW_OPTIC)
		return s_NewOpticSight.m_flFOV;
	else
		return CBaseWeapons::GetAimFOV();
}

Vector CMK46::GetAimOffset(void)
{
	if (m_bitsAccessories & MK46_ACC_NEW_OPTIC)
		return s_NewOpticSight.m_vecOfs;
	else
		return CBaseWeapons::GetAimOffset();
}

void CMK46::SetShell(float flTime)
{
	if (flTime <= 0.0f)	// a shell case and a shell binding.
	{
		// for normal shell case.
		SpawnShell(m_pPlayer,
				   gEngfuncs.pEventAPI->EV_FindModelIndex(m_sItemData.m_pAmmoDB->m_szShellModel),
				   GetShellOrigin(),
				   m_sItemData.m_pAmmoDB->m_iShellSoundType,
				   m_sItemData.m_pAmmoDB->m_iShellBody);

		// and a shell binding, spawining from a different location.
		SpawnShell(m_pPlayer,
				   gEngfuncs.pEventAPI->EV_FindModelIndex(m_sItemData.m_pAmmoDB->m_szShellModel),
				   g_pViewEnt->attachment[s_iBandSpawningAttm],
				   s_iBandSoundType,
				   s_iShellBandIndex);
	}
	else
		CBaseWeapons::SetShell(flTime);
}
