/***

Modern Warfare Develop Team
CSCARH.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/09

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



int CSCARH::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 1 },	// rifle		= 3;
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 4 },	// scopes		= 8;
		{ 0, 2 },	// silencer		= 9;
		{ 0, 2 },	// laser		= 10;
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[8].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[8].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[8].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[10].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[9].body = 1;

	return CalcBody(info, 11);
}