/***

Modern Warfare Develop Team
CMSR.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/04/08

***/

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "event_api.h"

#define WPN_MSR_FLAG_RECHAMBER	WPN_FLAG_COUNT
#define WPN_MSR_FLAG_FIRST_USE	(WPN_MSR_FLAG_RECHAMBER * 2)	// I am lazy for overwirte the Def_ItemDeploy().


float	CMSR::s_flShootRechamberTime	= 0.3333333333333333f;
float	CMSR::s_flReloadRechamberTime	= 0.36f;


void CMSR::Initialize(NewKeyValues * pRoot, int iType)
{
	NewKeyValues *pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			return;

		RECORD_FLOAT	(time_chambershell,		s_flShootRechamberTime)
		RECORD_FLOAT	(time_fullreloadshell,	s_flReloadRechamberTime)

		p = p->GetNextValue();
	}
}

int CMSR::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands	= 0
		{ 0, 1 },	// weapons	= 1
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 4 },	// scope	= 5
		{ 0, 2 },	// muzzle	= 6
		{ 0, 2 },	// laser	= 7
	};

	if (m_bitsAccessories & ACC_LASER)
		info[7].body = 1;

	if (m_bitsAccessories & ACC_HOLO)
		info[5].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[5].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[5].body = 3;

	if (m_bitsAccessories & ACC_SILENCER)
		info[6].body = 1;

	return CalcBody(info, 8);
}

void CMSR::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	m_ulStatus	|=	WPN_MSR_FLAG_FIRST_USE;
	SetFunc(m_pfnSecondaryAttack, &CMSR::Def_Scope);
}

void CMSR::ItemPostFrame(void)
{
	if (m_bitsAccessories & ACC_SIGHT)
		SetFunc(m_pfnSecondaryAttack, &CMSR::Def_SteelSight);
	else
		SetFunc(m_pfnSecondaryAttack, &CMSR::Def_Scope);

	if (m_ulStatus & WPN_MSR_FLAG_FIRST_USE)	// only the first rechamber (for efx) will auto-execute.
	{
		WeaponAnim(&WPNANIM(RECHAMBER), 2);
		m_ulStatus &= ~WPN_MSR_FLAG_FIRST_USE;
		SetShell(s_flShootRechamberTime);
	}

	Def_ItemPostFrame();
}

void CMSR::PrimaryAttack(void)
{
	if (m_ulStatus & WPN_MSR_FLAG_RECHAMBER)	// in reality, it's like a empty gun.
	{
		if (!m_bInScope)	// you cant rechamber when you're in scope.
		{
			WeaponAnim(&WPNANIM(RECHAMBER), 2);
			m_ulStatus &= ~WPN_MSR_FLAG_RECHAMBER;
			SetShell(s_flShootRechamberTime);
		}
		else
		{
			// otherwise, empty sound will replace shooting sound, things will get strange.
			// update: problem still exist then scoping. use CHAN_ITEM instead.
			gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_ITEM, m_sItemData.m_szDryFireSound, 0.8, ATTN_NORM, 0, PITCH_NORM);
			m_flNextPriAttack = 0.8;
		}

		return;
	}

	Def_PrimaryAttack();

	if (m_iDisplayingAnim == WPNANIM_NUM(SHOOT))
	{
		if (!m_bInScope)	// if player is in scope, then ignore the force-fully-play shooting anim.
			WeaponAnim(&WPNANIM(SHOOT), 2);	// fully play shooting anim, or rechamber anim will cover it.

		if (!IsWeaponEmpty())	// if weapon is empty, don't play rechamber anim, since full-reload anim include rechamber.
			m_ulStatus |= WPN_MSR_FLAG_RECHAMBER;
	}
}

void CMSR::WeaponReload(void)
{
	Def_WeaponReload();

	if (m_iDisplayingAnim == WPNANIM_NUM(RELOAD_EMPTY))
	{
		SetShell(s_flReloadRechamberTime);
	}
}
