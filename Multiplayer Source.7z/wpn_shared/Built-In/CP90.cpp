/***

Modern Warfare Develop Team
CP90.cpp

Coder:	Luna the Reborn
Model:	Innocent Blue
Sound:	Innocent Blue
Dxt/Hud:Usagi Chan

Create Date: 2018/07/09

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



int CP90::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;

		{ 0, 1 },	// gun			= 1;
		{ 0, 1 },

		{ 0, 4 },	// scopes		= 3;
		{ 0, 2 },	// laser		= 4;
		{ 0, 6 },	// laser dot	= 5;	(USELESS)
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[3].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[3].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[3].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[4].body = 1;

	return CalcBody(info, 6);
}