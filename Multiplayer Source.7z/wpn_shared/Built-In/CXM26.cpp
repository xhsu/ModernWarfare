/***

Modern Warfare Develop Team
CXM26.cpp

Coder:	Luna the Reborn
Model:	Soviet Defencer
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/03/17

***/

#include <sysdef.h>
#include <event_api.h>
#include <pm_defs.h>
#include <r_efx.h>
#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "wpn_cmd_shared.h"
#include "view.h"


int	CXM26::s_iItemType = 0;

class CMenuItemXM26 : public CBaseMenuItem
{
public:
	CBaseWeapons	*m_pWeapon;

	void	Select	( void )
	{
		if (g_pPlayerActivityItem != m_pWeapon)
			return;

		if (!m_pWeapon->CanSubsAttach(CXM26::s_iItemType))
			return;

		if (m_pWeapon->m_pSubsItem)
		{
			if (m_pWeapon->m_pSubsItem->m_iItemType == CXM26::s_iItemType)	// unattach this item.
			{
				m_pWeapon->m_pSubsItem->ItemKill();
				return;
			}

			m_pWeapon->m_pSubsItem->ItemKill();
		}

		m_pWeapon->AllocSubItem(CXM26::s_iItemType);
	}
	
	void	Think	( void )
	{
		if (!m_pWeapon->m_pSubsItem || m_pWeapon->m_pSubsItem->m_iItemType != CXM26::s_iItemType)
			m_sColor = UnpackRGB(RGB_WHITE);
		else
			m_sColor = UnpackRGB(RGB_GREENISH);
	}
};


CXM26::CXM26(void)
{
	SetFunc(m_pfnUse, &CXM26::PrimaryAttack);

	m_sItemData		= g_sItemData[s_iItemType];
	m_iItemType		= s_iItemType;
	m_iFireMode		= CSMW_FIREMODE_SINGLE;
	m_iChamberClip	= m_sItemData.m_iChamberClip;
	m_iClip			= m_sItemData.m_pMagDB->m_iClip;

	// FIXME: just for test
	BP_MAGAZINE += 10;
}

CBaseMenuItem * CXM26::AddToList(CBaseWeapons * pWeapon)
{
	CMenuItemXM26 *ptr = new CMenuItemXM26;

	ptr->m_pWeapon		= pWeapon;
	ptr->m_bCanDelete	= true;

	wcsncpy_s(ptr->m_wszString, g_sItemData[s_iItemType].m_wszEndoName, _TRUNCATE);

	ptr->AddParent(&pWeapon->m_sAccMenu);	// add and return.

	return ptr;
}

void CXM26::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;
}

void CXM26::ItemPostFrame(void)
{
	if (m_bInReload && m_sItemData.m_pMagDB)
	{
		// there is an anim that rechamber the first bullet into chamber...
		if (m_iClip <= 0 && m_iChamberClip <= 0)
		{
			m_iClip			= m_sItemData.m_pMagDB->m_iClip - m_sItemData.m_iChamberClip;
			m_iChamberClip	= m_sItemData.m_iChamberClip;
		}
		else
			m_iClip	= m_sItemData.m_pMagDB->m_iClip;

		BP_MAGAZINE	= max(BP_MAGAZINE - 1, 0);
		m_bInReload	= false;

		SetFunc(m_pfnUse, &CXM26::PrimaryAttack);
	}

	if (m_iShotsFired > 0 && gEngfuncs.GetClientTime() > m_flDecreaseShotsFired)
	{
		m_iShotsFired --;
		m_flDecreaseShotsFired = gEngfuncs.GetClientTime() + 0.25f;
	}
}

void CXM26::PrimaryAttack(void)
{
	KickBack();

	// mag ammo first, then chamber clip.
	if (m_iClip > 0)
		m_iClip --;
	else
		m_iChamberClip --;

	// refill chamber, if not normal gun(e.g. KSG12), set your self.
	if (m_iChamberClip < m_sItemData.m_iChamberClip && m_iClip > 0)
	{
		int j = min(m_sItemData.m_iChamberClip - m_iChamberClip, m_iClip);
		
		m_iChamberClip	+= j;
		m_iClip			-= j;
	}
	
	m_flNextPriAttack = m_sItemData.m_flNextPriAttack;
	m_iShotsFired ++;
	m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + 0.4f;

	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(m_pMaster->GetMuzzleOrigin());
	SU_WriteVector	(g_pparams.viewangles);
	SU_WriteFloat	(0.0f);
	SU_End			();

	// local efx.
	SpawnShell(m_pPlayer, gEngfuncs.pEventAPI->EV_FindModelIndex(m_sItemData.m_pAmmoDB->m_szShellModel), m_pMaster->GetShellOrigin(), m_sItemData.m_pAmmoDB->m_iShellSoundType, m_sItemData.m_pAmmoDB->m_iShellBody);
	m_pMaster->DrawGunSmoke();
	DrawLight(m_pMaster->GetMuzzleOrigin(), m_sItemData.m_iGunFlash);

	if (m_sItemData.m_pAmmoDB && m_sItemData.m_iEffectiveAngle > 0 && m_sItemData.m_iEffectiveRange > 0)
	{
		Vector vecForward, vecRight, vecUp, vecDir, vecEnd;
		gEngfuncs.pfnAngleVectors(g_pparams.viewangles, vecForward, vecRight, vecUp);

		Vector vecSpread(abs(sin(Math::DegreeToRadian(m_sItemData.m_iEffectiveAngle) / 2.0f)));

		int iCount = RANDOM_LONG(12, 20);
		pmtrace_t tr;

		gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
		gEngfuncs.pEventAPI->EV_PushPMStates();
		gEngfuncs.pEventAPI->EV_SetSolidPlayers ( m_pPlayer->index - 1 );
		gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
		
		for (int i = 1; i <= iCount; i ++)
		{
			float x, y, z;
			do
			{
				x = RANDOM_FLOAT(-0.5, 0.5) + RANDOM_FLOAT(-0.5, 0.5);
				y = RANDOM_FLOAT(-0.5, 0.5) + RANDOM_FLOAT(-0.5, 0.5);
				z = x * x + y * y;

			} while (z > 1);

			vecDir = vecForward + x * vecSpread.x * vecRight + y * vecSpread.y * vecUp;
			vecEnd = m_pMaster->GetMuzzleOrigin() + vecDir.Normalize() * m_sItemData.m_iEffectiveRange;

			gEngfuncs.pEventAPI->EV_PlayerTrace( m_pMaster->GetMuzzleOrigin(), vecEnd, PM_STUDIO_BOX, -1, &tr );
			gEngfuncs.pEfxAPI->R_TracerEffect(m_pMaster->GetMuzzleOrigin(), tr.endpos);
		}
	}

	gEngfuncs.pEventAPI->EV_PopPMStates();

	// change Use() to reload.
	if (IsWeaponEmpty())
		SetFunc(m_pfnUse, &CXM26::WeaponReload);

	// UNDONE: 3rd personal gunfire efx.
}

void CXM26::WeaponReload(void)
{
	if (m_bInReload)
		return;

	SU_Begin		(WPN_CMD_RELOAD);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	m_bInReload		= true;
	m_iShotsFired	= 0;

	// incase it's interrupt by something else, add Pop func in.
	SetFunc(m_pfnUse,	&CXM26::Restore);
}

