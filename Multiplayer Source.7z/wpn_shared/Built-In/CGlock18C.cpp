﻿/***

Modern Warfare Develop Team
CGlock18C.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet & avJäger
Dxt/Hud:Usagi Chan

Create Date: 2018/03/08

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"


int CGlock18C::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands	= 0,
		{ 0, 1 },	// weapon	= 1,

		{ 0, 2 },	// slide	= 2,
		{ 0, 4 },	// selector	= 3,
		{ 0, 3 },	// scope	= 4,
		{ 0, 4 },	// muzzle	= 5,
		{ 0, 2 },	// laser	= 6
	};

	if (m_bitsAccessories & ACC_LASER)
		info[6].body = 1;

	if (m_bitsAccessories & ACC_COMPENSATOR)
		info[5].body = 2;
	else if (m_bitsAccessories & ACC_SILENCER)
		info[5].body = 1;
	else if (m_bitsAccessories & ACC_FLASHHIDER)
		info[5].body = 3;

	if (m_bitsAccessories & ACC_DOT)
		info[4].body = 1;

	if (m_sItemData.m_bSingleShoot)
		info[3].body = 1;

	if (IsNonslidemoveAnim(m_iDisplayingAnim) && IsWeaponEmpty())
	{
		info[2].body = 1;	// move slide.
		info[3].body += 2;	// move selector.

		if (m_bitsAccessories & ACC_SIGHT)
			info[4].body ++;	// scopes will shift follow by slide.
	}

	return CalcBody(info, 7);
}

void CGlock18C::SH_ResetAnims(void)
{
	CBasePistol::SH_ResetAnims();

	// but Matoilet's G18C using two hands to draw_first, let's remove this glitch.
	if (IsDoubleHolding())
		WPNANIM(DRAW_FIRST) = WPNANIM(DRAW);
}
