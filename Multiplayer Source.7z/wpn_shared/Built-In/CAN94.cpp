/***

Modern Warfare Develop Team
CAN94.cpp

Coder:	Luna the Reborn (debug: Soviet Defender)
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/05

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "input.h"
#include "view.h"


float	CAN94::s_flBrustFireRate	= float(60) / float(1800);	// default: 1800 RPM @ burst fire.


void CAN94::Initialize(NewKeyValues * pRoot, int iType)
{
	NewKeyValues *pCustom = pRoot->FindKey("customdata");
	NewKeyValues *p = NULL;

	if ((p = pCustom->FindKey("AN94_BrustFireRate")))
		s_flBrustFireRate = p->GetFloat();
}

int CAN94::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },

		{ 0, 1 },	// rifle		= 2;
		{ 0, 1 },

		{ 0, 4 },	// scopes		= 4;
		{ 0, 2 },	// silencer		= 5;
		{ 0, 2 },	// laser		= 6;
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[4].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[4].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[4].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[6].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[5].body = 1;

	return CalcBody(info, 7);
}

void CAN94::ItemPostFrame(void)
{
	if (!m_iChamberClip)
		m_iBurstFire = -1;

	// once player stop pressing MOUSE1, set it back to DOUBLE shots.
	if (m_iFireMode == CSMW_FIREMODE_MULTIPLE && !m_flNextPriAttack && !(CL_GetButtonBits() & IN_ATTACK))
	{
		m_iFireMode = CSMW_FIREMODE_DOUBLE;
	}

	// normal case, use normal ItemPostFrame();
	if (m_iFireMode != CSMW_FIREMODE_DOUBLE || m_iBurstFire == -1)
	{
		return Def_ItemPostFrame();
	}
	
	m_iBurstFire --;
	m_iShotsFired = 0;	// clear that to bounce player.
	PrimaryAttack();

	if (m_iBurstFire > 0)
		m_flNextFrame = s_flBrustFireRate;
	else
	{
		m_iBurstFire = -1;

		// switch to normal firemode ( speed down, like a real AN94 )
		m_iFireMode = CSMW_FIREMODE_MULTIPLE;
	}
}

void CAN94::PrimaryAttack(void)
{
	Def_PrimaryAttack();

	if (m_iFireMode == CSMW_FIREMODE_DOUBLE && m_iBurstFire == -1)
	{
		m_iBurstFire = 1;
		m_flNextFrame = s_flBrustFireRate;
	}
}

void CAN94::SwitchSwitcher(void)
{
	if (m_iBurstFire > 0)
		return;

	if (m_iFireMode == CSMW_FIREMODE_SINGLE)
	{
		m_sItemData.m_bSingleShoot = false;
		//UTIL_ShowTextMsg(m_pEntity->v.owner, HUD_PRINTCENTER, "#Switch_To_FullAuto");
		SPK_SOUND("weapons/Switcher1.wav");
		m_iFireMode = CSMW_FIREMODE_DOUBLE;
	}
	else
	{
		m_sItemData.m_bSingleShoot = true;
		//UTIL_ShowTextMsg(m_pEntity->v.owner, HUD_PRINTCENTER, "#Switch_To_SemiAuto");
		SPK_SOUND("weapons/Switcher2.wav");
		m_iFireMode = CSMW_FIREMODE_SINGLE;
	}

	m_iBurstFire = -1;
}

void CAN94::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	// without this, you can't switch weapon until you fire first couple rounds.
	m_iBurstFire = -1;
}

bool CAN94::CanItemHolster(void)
{
	if (m_iBurstFire != -1)
		return false;

	return CBaseWeapons::CanItemHolster();
}

bool CAN94::CanItemDropped(void)
{
	if (m_iBurstFire != -1)
		return false;

	return CBaseWeapons::CanItemDropped();
}
