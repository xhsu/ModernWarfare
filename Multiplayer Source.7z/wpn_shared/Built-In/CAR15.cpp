﻿/***

Modern Warfare Develop Team
CAR15.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet & avJäger
Dxt/Hud:Usagi Chan

Create Date: 2018/03/08

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "GameStudioModelRenderer.h"



#undef RECORD_ANIM_F
#undef RECORD_ANIM_S

#define RECORD_ANIM_F(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat(); \
											else if (!strcmp(p->GetName(), "eft_"#keyname"")) \
												s_AnimData[##enumname].m_fe = p->GetFloat();

#define RECORD_ANIM_S(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat();


int			CAR15::s_iItemType			= 0;
float		CAR15::s_flRifleClipOut		= 0.6f;
float		CAR15::s_flM870ClipAdd		= 0.5f;
float		CAR15::s_flRechamberShell	= 0.4333333333333333f;
float		CAR15::s_flM870ReloadShell	= 0.5454545454545455f;
float		CAR15::s_flM203ChangeNail	= 2.0f;
animdb_t	CAR15::s_AnimData[ANIM_COUNT];
float		CAR15::s_flFirstAmmoInsert	= 1.266666666666667f;
float		CAR15::s_flFirstShellOut	= 0.4f;


void CAR15::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;

	memset(&s_AnimData, NULL, sizeof(s_AnimData));

	NewKeyValues *pDatabase = pRoot->FindKey("animations");
	if (!pDatabase)
		return;
	
	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_ANIM_S(shoot,			ANIM_SHOOT)
		RECORD_ANIM_S(shoot_left,		ANIM_SHOOT_LEFT)
		RECORD_ANIM_S(shoot_right,		ANIM_SHOOT_RIGHT)
		RECORD_ANIM_F(shoot_parts,		ANIM_SHOOT_PARTS)
		RECORD_ANIM_F(rechamber_m870,	ANIM_RECHAMBER)
		RECORD_ANIM_F(reload_m203,		ANIM_RELOAD_M203)
		RECORD_ANIM_F(reload_xm26,		ANIM_RELOAD_XM26)
		RECORD_ANIM_F(reload_xm26_f,	ANIM_RELOAD_XM26_EMPTY)
		RECORD_ANIM_F(reload_m870_in,	ANIM_RELOAD_M870_START)
		RECORD_ANIM_F(reload_m870_1st,	ANIM_RELOAD_M870_FIRST)
		RECORD_ANIM_F(reload_m870_loop,	ANIM_RELOAD_M870_LOOP)
		RECORD_ANIM_F(reload_m870_rec,	ANIM_RELOAD_M870_EMPTY)
		RECORD_ANIM_F(reload_m870_out,	ANIM_RELOAD_M870_STOP)

		p = p->GetNextValue();
	}

	pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	p = pDatabase->GetFirstValue();
	
	while (p)
	{
		if (FALSE)
			break;

		RECORD_FLOAT(Rifle_ClipOut,			s_flRifleClipOut)
		RECORD_FLOAT(M870_ClipAdd,			s_flM870ClipAdd)
		RECORD_FLOAT(M870_RecShellOut,		s_flRechamberShell)
		RECORD_FLOAT(M870_ReloadShellOut,	s_flM870ReloadShell)
		RECORD_FLOAT(M870_ClipAdd,			s_flM870ClipAdd)
		RECORD_FLOAT(M870_FirstAmmoInsert,	s_flFirstAmmoInsert)
		RECORD_FLOAT(M870_FirstShellOut,	s_flFirstShellOut)

		p = p->GetNextValue();
	}
}

int CAR15::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 2 },	// hands		= 0;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 1 },	// rifle		= 3;
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 3 },	// steel sight	= 7;
		{ 0, 6 },	// scopes		= 8;
		{ 0, 4 },	// attachments	= 9;
		{ 0, 2 },	// nail/shell	= 10;
		{ 0, 4 },	// muzzle		= 11;
		{ 0, 2 },	// laser		= 12;
	};

	if (m_bitsAccessories & ACC_ROUND)
		info[8].body = 1;
	else if (m_bitsAccessories & ACC_HOLO)
		info[8].body = 2;
	else if (m_bitsAccessories & ACC_DOT)
		info[8].body = 3;
	else if (m_bitsAccessories & ACC_ACOG)
		info[8].body = 4;

	if (m_bitsAccessories & ACC_ACOG)
		info[7].body = 2;	// no iron sight.
	else if (m_bitsAccessories & ACC_SIGHT)
		info[7].body = 1;	// flip down.

	if (m_bitsAccessories & ACC_LASER)
		info[12].body = 1;

	if (m_pSubsItem)
	{
		if (m_pSubsItem->m_iItemType == CM203::s_iItemType)
			info[9].body = 1;
		else if (m_pSubsItem->m_iItemType == CXM26::s_iItemType)
			info[9].body = 3;
		else if (m_pSubsItem->m_iItemType == CM870MCS::s_iItemType)
			info[9].body = 2;
	}

	if (m_flTimeNullShell > gEngfuncs.GetClientTime())
		info[10].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[11].body = 1;
	else if (m_bitsAccessories & ACC_MUZZLEBREAKER)
		info[11].body = 2;
	else if (m_bitsAccessories & ACC_FLASHHIDER)
		info[11].body = 3;

	return CalcBody(info, 13);
}

bool CAR15::CanSubsAttach(int iType)
{
	if (iType == CM203::s_iItemType || iType == CXM26::s_iItemType || iType == CM870MCS::s_iItemType)
		return true;

	return false;
}

bool CAR15::AllocSubItem(int iType)
{
	if (!CanSubsAttach(iType))
		return false;

	// not delete cur subs until sure there is a new one.
	if (m_pSubsItem)
		m_pSubsItem->ItemKill();

	if (iType == CM203::s_iItemType)
	{
		m_pSubsItem = new CM203;
	}
	else if (iType == CXM26::s_iItemType)
	{
		m_pSubsItem = new CXM26;
	}
	else if (iType == CM870MCS::s_iItemType)	// since we have special anim for this M870, use it's alternative code group.
	{
		CM870MCS_2 *ptr = new CM870MCS_2;	// LUNA: this is why C++ is superior than C: CM870MCS_2 is a child of CM870MCS, any code try to treat CM870MCS_2* as CM870MCS* will function well on.

		ptr->m_pAnimStart			= &s_AnimData[ANIM_RELOAD_M870_START];
		ptr->m_pAnimFirstIns		= &s_AnimData[ANIM_RELOAD_M870_FIRST];
		ptr->m_pAnimInsert			= &s_AnimData[ANIM_RELOAD_M870_LOOP];
		ptr->m_pAnimEnd				= &s_AnimData[ANIM_RELOAD_M870_STOP];
		ptr->m_pAnimEndRec			= &s_AnimData[ANIM_RELOAD_M870_EMPTY];
		ptr->m_pAnimRechamber		= &s_AnimData[ANIM_RECHAMBER];
		ptr->m_pflAddAmmoLoop		= &s_flM870ClipAdd;
		ptr->m_pflRechamberShell	= &s_flRechamberShell;
		ptr->m_pflReloadShell		= &s_flM870ReloadShell;
		ptr->m_pflFirstAmmoInsert	= &s_flFirstAmmoInsert;
		ptr->m_pflFirstShellOut		= &s_flFirstShellOut;

		m_pSubsItem = ptr;
	}

	m_pSubsItem->ItemAttachToWeapon(this);
	m_pSubsItem->ItemDeploy();

	return true;
}

void CAR15::HUD_GenerateAccMenu(void)
{
	CBaseWeapons::HUD_GenerateAccMenu();

	CM203::AddToList(this);
	CXM26::AddToList(this);
	CM870MCS::AddToList(this);
}

void CAR15::ChangeMode(void)
{
	if (!m_pSubsItem || IS_RUNNING)
		return;

	m_bUsingSubs = true;

	if (m_pSubsItem->m_iItemType == CM203::s_iItemType && m_pSubsItem->m_flNextFrame <= 0)
	{
		if (m_pSubsItem->m_iChamberClip > 0)
		{
			PauseReload();
			m_pSubsItem->WeaponAnim(&s_AnimData[ANIM_SHOOT_PARTS], 1);

			m_pSubsItem->Use();
		}
		else if (m_pSubsItem->CanWeaponReload() && !m_bInReload)
		{
			if (IS_AIMING)
				SecondaryAttack();

			m_pSubsItem->WeaponAnim(&s_AnimData[ANIM_RELOAD_M203], 2);
			m_flTimeNullShell = gEngfuncs.GetClientTime() + s_flM203ChangeNail;

			m_pSubsItem->Use();
		}
	}
	else if (m_pSubsItem->m_iItemType == CXM26::s_iItemType && m_pSubsItem->m_flNextFrame <= 0)
	{
		if (m_pSubsItem->CanWeaponFire())
		{
			PauseReload();
			m_pSubsItem->WeaponAnim(&s_AnimData[ANIM_SHOOT_PARTS], 1);

			m_pSubsItem->Use();
		}
		else if (m_pSubsItem->CanWeaponReload() && !m_bInReload)
		{
			if (IS_AIMING)
				SecondaryAttack();

			m_pSubsItem->WeaponAnim(&s_AnimData[m_pSubsItem->m_iChamberClip <= 0 ? ANIM_RELOAD_XM26_EMPTY : ANIM_RELOAD_XM26], 2);
			m_pSubsItem->Use();
		}
	}
	else if (m_pSubsItem->m_iItemType == CM870MCS::s_iItemType && m_pSubsItem->m_flNextFrame <= 0)
	{
		CM870MCS *ptr = (CM870MCS *)m_pSubsItem;

		if (m_pSubsItem->CanWeaponFire())
		{
			PauseReload();
			m_pSubsItem->WeaponAnim(&s_AnimData[ANIM_SHOOT_PARTS], 1);

			// dont need shoot anim here.
			m_pSubsItem->Use();
		}
		else if (!m_bInReload)	// including rechamber and reload.
		{
			if (IS_AIMING)
				SecondaryAttack();

			m_pSubsItem->Use();
		}
	}

	m_bUsingSubs = false;
}

int CAR15::GetMuzzleEnum(void)
{
	if (m_bUsingSubs)
		return 2;
	else
		return CBaseWeapons::GetMuzzleEnum();
}

int CAR15::GetShellEnum(void)
{
	if (m_bUsingSubs)
		return 3;
	else
		return CBaseWeapons::GetShellEnum();
}

void CAR15::PlayShootingAnim(void)
{
	// since there are no difference from aim_shoot and shoot...
	WeaponAnim(&s_AnimData[RANDOM_LONG(ANIM_SHOOT, ANIM_SHOOT_RIGHT)]);
}

void CAR15::WeaponReload(void)
{
	if (m_pSubsItem && m_iClip >= m_sItemData.m_pMagDB->m_iClip * 0.85f && m_pSubsItem->CanWeaponReload() && m_pSubsItem->m_flNextFrame <= 0)
	{
		if (IS_AIMING)
			SecondaryAttack();

		// running is defnately a fully anim.
		if (m_ulStatus & WPN_FLAG_RUN)
		{
			RunStop();
			m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
			return;
		}

		m_bUsingSubs = true;

		if (m_pSubsItem->m_iItemType == CM203::s_iItemType)
		{
			m_pSubsItem->WeaponAnim(&s_AnimData[ANIM_RELOAD_M203], 2);
			m_flTimeNullShell = gEngfuncs.GetClientTime() + s_flM203ChangeNail;
		}
		else if (m_pSubsItem->m_iItemType == CXM26::s_iItemType)
		{
			m_pSubsItem->WeaponAnim(&s_AnimData[m_pSubsItem->m_iChamberClip <= 0 ? ANIM_RELOAD_XM26_EMPTY : ANIM_RELOAD_XM26], 2);
		}

		m_pSubsItem->WeaponReload();
		m_bUsingSubs = false;

		return;
	}

	return Def_WeaponReload();
}

void CAR15::ItemHolster(void)
{
	bool bSave = m_bInReload;
	float flDelta = gEngfuncs.GetClientTime() - m_flLastReload;

	Def_ItemHolster();

	// must make sure normal holster is before this, since it will reset m_bInReload.
	if ( bSave
		&& flDelta >= s_flRifleClipOut
		&& ( (!m_iChamberClip && flDelta <= WPNANIM_EFT(RELOAD_EMPTY)) || (m_iChamberClip && flDelta <= WPNANIM_EFT(RELOAD)) )
		)
	{
		m_bInReload		= true;
		m_ulStatus		|= WPN_FLAG_FIRSTUSE;
		m_flLastReload	= -1;
	}
}