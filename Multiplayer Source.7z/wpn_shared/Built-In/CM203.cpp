/***

Modern Warfare Develop Team
CM203.cpp

Coder:	Luna the Reborn
Model:	Matoilet & Innocent Blue
Sound:	?
Dxt/Hud:Usagi Chan

Create Date: 2018/03/15

***/

#include <sysdef.h>

#ifndef CSMW_SERVER_DLL

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "wpn_cmd_shared.h"
#include "view.h"

#else

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "monsters.h"
#include "weapons.h"
#include "decals.h"
#include "bullets.h"
#include "soundent.h"
#include "newkeyvalues.h"
#include "wpn_cmd_shared.h"

#endif


int	CM203::s_iItemType = 0;

#ifndef CSMW_SERVER_DLL

class CMenuItemM203 : public CBaseMenuItem
{
public:
	CBaseWeapons	*m_pWeapon;

	void	Select	( void )
	{
		if (g_pPlayerActivityItem != m_pWeapon)
			return;

		if (!m_pWeapon->CanSubsAttach(CM203::s_iItemType))
			return;

		if (m_pWeapon->m_pSubsItem)
		{
			if (m_pWeapon->m_pSubsItem->m_iItemType == CM203::s_iItemType)	// unattach this item.
			{
				m_pWeapon->m_pSubsItem->ItemKill();
				return;
			}

			m_pWeapon->m_pSubsItem->ItemKill();
		}

		m_pWeapon->AllocSubItem(CM203::s_iItemType);
	}
	
	void	Think	( void )
	{
		if (!m_pWeapon->m_pSubsItem || m_pWeapon->m_pSubsItem->m_iItemType != CM203::s_iItemType)
			m_sColor = UnpackRGB(RGB_WHITE);
		else
			m_sColor = UnpackRGB(RGB_GREENISH);
	}
};

CM203::CM203(void)
{
	SetFunc(m_pfnUse,	&CM203::PrimaryAttack);

	m_sItemData		= g_sItemData[s_iItemType];
	m_iItemType		= s_iItemType;
	m_iFireMode		= CSMW_FIREMODE_SINGLE;
	m_iChamberClip	= m_sItemData.m_iChamberClip;

	// FIXME: just for test
	AMMUNITION += 100;
}

CBaseMenuItem * CM203::AddToList(CBaseWeapons *pWeapon)
{
	CMenuItemM203 *ptr = new CMenuItemM203;

	ptr->m_pWeapon		= pWeapon;
	ptr->m_bCanDelete	= true;

	wcsncpy_s(ptr->m_wszString, g_sItemData[s_iItemType].m_wszEndoName, _TRUNCATE);

	ptr->AddParent(&pWeapon->m_sAccMenu);	// add and return.

	return ptr;
}

void CM203::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;
}

void CM203::ItemPostFrame(void)
{
	if (m_bInReload)
	{
		// we need to avoid the 29->30 rounds' bug.
		m_iClip = 0;

		// here from HLSDK
		int j = min(m_sItemData.m_iChamberClip - m_iChamberClip, int(AMMUNITION));
		
		m_iChamberClip	= m_iChamberClip + j;
		AMMUNITION		-= j;
		m_bInReload		= false;

		SetFunc(m_pfnUse,	&CM203::PrimaryAttack);
	}
}

void CM203::PrimaryAttack(void)
{
	if (m_iChamberClip <= 0)
	{
		WeaponReload();
		return;
	}

	m_iChamberClip --;

	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(m_pMaster->GetMuzzleOrigin());	// UNDONE: maybe we can let the CBaseWeapons::GetMuzzleOrigin() return special coords when it's using grenade?
	SU_WriteVector	(g_pparams.viewangles);
	SU_WriteFloat	(0.0f);
	SU_WriteInteger	(CARC3::GR_TOUCH);
	SU_End			();

	KickBack();
	m_pMaster->DrawGunSmoke();
	DrawLight(m_pMaster->GetMuzzleOrigin(), m_sItemData.m_iGunFlash);

	if (m_iChamberClip <= 0)
		SetFunc(m_pfnUse, &CM203::WeaponReload);
}

void CM203::WeaponReload(void)
{
	if (m_bInReload)
		return;

	SU_Begin		(WPN_CMD_RELOAD);
	SU_WriteInteger	(m_iItemType);
	SU_End			();

	m_bInReload = true;

	// incase it's interrupt by something else, add Pop func in.
	SetFunc(m_pfnUse,	&CM203::Restore);
}

#else

void CM203::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;

	g_sItemData[iType].PrimaryAttack = PrimaryAttack;
}

void CM203::PrimaryAttack(void * pEntity, int iType, Vector vecSrc, Vector vecAngle, float flBaseline)
{
	CBasePlayer	*pPlayer = (CBasePlayer	*)CBasePlayer::Instance((edict_t *)pEntity);

	if (!pPlayer)
		return;

	// player anims.
	pPlayer->SetAnimation(PLAYER_ATTACK1);

	// sound here
	CSoundEnt::InsertSound(bits_SOUND_COMBAT|bits_SOUND_PLAYER, vecSrc, g_sItemData[iType].m_iGunVolume, 0.2);
	g_engfuncs.pfnEmitSound(pPlayer->edict(), CHAN_WEAPON, g_sItemData[s_iItemType].m_szShootingSound, VOL_NORM, g_sItemData[iType].m_flSoundAttenuation, NULL, 98 + RANDOM_LONG(-3, 3));
	pPlayer->m_iWeaponFlash		=	g_sItemData[iType].m_iGunFlash;
	pPlayer->m_iWeaponVolume	=	g_sItemData[iType].m_iGunVolume;
	pPlayer->pev->effects		|=	EF_MUZZLEFLASH;

	CGrenade *pGrenade = CGrenade::Launch( pPlayer->pev, vecSrc, g_sItemData[s_iItemType].m_pAmmoDB, CARC3::GR_TOUCH, s_iItemType, 0 );
	pGrenade->pev->gravity = 0.5f;	// too fucking heavy...
}

#endif