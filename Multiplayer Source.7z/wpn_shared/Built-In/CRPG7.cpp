﻿/***

Modern Warfare Develop Team
CRPG7.cpp

Coder:	Luna the Reborn	(Original: DSHGFHDS)	(debug: avJäger)
Model:	Matoilet		(Original: 咸鱼为人)
Sound:	Matoilet		(Original: 咸鱼为人)
Dxt/Hud:Usagi Chan		(Original: 咸鱼为人)

Create Date: 2018/07/05

***/

#include <sysdef.h>

#ifndef CSMW_SERVER_DLL

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "view.h"
#include "wpn_cmd_shared.h"

#else

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "monsters.h"
#include "weapons.h"
#include "decals.h"
#include "bullets.h"
#include "soundent.h"
#include "newkeyvalues.h"
#include "wpn_cmd_shared.h"

#endif


int		CRPG7::s_iItemType			= 0;

float	CRPG7::s_flAngularRecoil	= 15;
float	CRPG7::s_flLinearRecoil		= 200;

char	CRPG7::s_szExploSound[NORMAL_CHARLEN+1] = "weapons/rocke_explode.wav";
float	CRPG7::s_flExploRange		= 550;
float	CRPG7::s_flExploPunch		= 20;
float	CRPG7::s_flExploKnock		= 700;
float	CRPG7::s_flExploDamage		= 550;

float	CRPG7::s_flRocketSpeed		= 1500;
float	CRPG7::s_flRocketOffset		= 1.0f;
Vector	CRPG7::s_vecRocketSpawn		= Vector(32.0f, 4.0f, 1.0f);
float	CRPG7::s_flRocketSize		= 2.0f;
float	CRPG7::s_flRocketGravity	= 2.0f;
char	CRPG7::s_szRocketModel[NORMAL_CHARLEN+1] = "models/rpg_rocket.mdl";


void CRPG7::Initialize(NewKeyValues *pRoot, int iType)
{
	s_iItemType	= iType;

#ifdef CSMW_SERVER_DLL

	g_sItemData[iType].PrimaryAttack = PrimaryAttack;

#endif

	NewKeyValues *pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_FLOAT	(launch_recoil_angular,	s_flAngularRecoil)
		RECORD_FLOAT	(launch_recoil_linear,	s_flLinearRecoil)

		RECORD_STRING	(explosive_sound,		s_szExploSound)
		RECORD_FLOAT	(explosive_range,		s_flExploRange)
		RECORD_FLOAT	(explosive_punch,		s_flExploPunch)
		RECORD_FLOAT	(explosive_knock,		s_flExploKnock)
		RECORD_FLOAT	(explosive_damage,		s_flExploDamage)

		RECORD_VECTOR	(rocket_spawn,			s_vecRocketSpawn)
		RECORD_FLOAT	(rocket_gravity,		s_flRocketGravity)
		RECORD_FLOAT	(rocket_size,			s_flRocketSize)
		RECORD_FLOAT	(rocket_flyspeed,		s_flRocketSpeed)
		RECORD_FLOAT	(rocket_flyoffset,		s_flRocketOffset)
		RECORD_STRING	(rocket_model,			s_szRocketModel)

		p = p->GetNextValue();
	}
}

#ifndef CSMW_SERVER_DLL

int CRPG7::GetViewModelSubModelStatus(void)
{
	if (!m_iChamberClip && !m_bInReload)	// when you're reloading, a rocket model is required.
		return 0;

	return 1;
}

void CRPG7::PrimaryAttack(void)
{
	// RPG still need this..
	WeaponAnim(IS_AIMING ? &WPNANIM(AIM_SHOOT) : &WPNANIM(SHOOT));

	g_vecFixAngleOfs.x -= s_flAngularRecoil;
	g_vecPunchOrigin.x -= s_flLinearRecoil;

	m_iChamberClip --;
	m_sItemData.m_iPWSubModel = 0;

	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(Vector(g_pparams.vieworg) + s_vecRocketSpawn);	// FIXME: need to use model attachment instead.
	SU_WriteVector	(g_pparams.viewangles);
	SU_WriteFloat	(0.0f);	// aiming baseline, meaningless in RPG launching.
	SU_End			();	// SILENCER parameter is not required.
}

#else

void CRPG7::PrimaryAttack(void * pEntity, int iType, Vector vecSrc, Vector vecAngle, float flAimBaseline)
{
	CBasePlayer	*pPlayer = (CBasePlayer	*)CBasePlayer::Instance((edict_t *)pEntity);

	if (!pPlayer)
		return;

	// player anims.
	pPlayer->SetAnimation(PLAYER_ATTACK1);

	// sound here
	CSoundEnt::InsertSound(bits_SOUND_COMBAT|bits_SOUND_PLAYER, vecSrc, g_sItemData[iType].m_iGunVolume, 0.2);
	g_engfuncs.pfnEmitSound(pPlayer->edict(), CHAN_AUTO, g_sItemData[s_iItemType].m_szShootingSound, VOL_NORM, g_sItemData[iType].m_flSoundAttenuation, NULL, 98 + RANDOM_LONG(-3, 3));	// FIXME: unknow bug, CHAN_WEAP is jammed.
	pPlayer->m_iWeaponFlash		=	g_sItemData[iType].m_iGunFlash;
	pPlayer->m_iWeaponVolume	=	g_sItemData[iType].m_iGunVolume;
	pPlayer->pev->effects		|=	EF_MUZZLEFLASH;

	// rocket out.
	CRocket *pRocket = CRocket::Launch(vecSrc, pPlayer, s_szRocketModel, s_flRocketSize, s_flRocketGravity, s_flExploDamage, s_flRocketSpeed, g_sItemData[s_iItemType].m_pAmmoDB);
	pRocket->m_flExploRange		= s_flExploRange;
	pRocket->m_flExploPunch		= s_flExploPunch;
	pRocket->m_flExploKnock		= s_flExploPunch;
	strncpy_s(pRocket->m_szExploSound, s_szExploSound,	_TRUNCATE);
	pRocket->m_flRocketOffset	= s_flRocketOffset;
	pRocket->m_flRocketSpeed	= s_flRocketSpeed;
}

void CRPG7::Precache(void)
{
	if (!GetWeaponTypeFromName("wpn_rpg7"))
		return;

	g_engfuncs.pfnPrecacheSound("weapons/rpg_travel.wav");
	g_engfuncs.pfnPrecacheSound(s_szExploSound);
	g_engfuncs.pfnPrecacheModel("sprites/hotglow.spr");
	g_engfuncs.pfnPrecacheModel("sprites/gas_smoke1.spr");
	g_engfuncs.pfnPrecacheModel("sprites/wall_puff1.spr");
	g_engfuncs.pfnPrecacheModel("sprites/exsmoke.spr");
	g_engfuncs.pfnPrecacheModel("sprites/rockefire.spr");
	g_engfuncs.pfnPrecacheModel("sprites/tdm_smoke.spr");
	g_engfuncs.pfnPrecacheModel(s_szRocketModel);	// NEVER FORGET THIS SHIT
	g_engfuncs.pfnPrecacheSound("weapons/RPG/rpg_travel.wav");
}

#endif