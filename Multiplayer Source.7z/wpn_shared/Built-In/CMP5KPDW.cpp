/***

Modern Warfare Develop Team
CMP5KPDW.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/09

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



int CMP5KPDW::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 1 },	// rifle		= 3;
		{ 0, 1 },

		{ 0, 4 },	// scopes		= 5;
		{ 0, 3 },	// muzzle		= 6;
		{ 0, 2 },	// laser		= 7;
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[5].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[5].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[5].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[7].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[6].body = 2;
	else if (m_bitsAccessories & ACC_MUZZLEBREAKER)
		info[6].body = 1;

	return CalcBody(info, 8);
}