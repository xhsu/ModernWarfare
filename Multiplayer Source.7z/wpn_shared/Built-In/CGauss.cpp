﻿/***

Modern Warfare Develop Team
CGauss.cpp - Luna's Weapon Pack

Coder:	Luna the Reborn
Model:	HL&CL
Sound:	HL&CL
Dxt/Hud:Usagi Chan

Create Date: 2018/04/30	- in member the 241th BirthDay of Johann Carl Friedrich Gauß

***/

#include <sysdef.h>

#ifdef CLIENT_DLL

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "view.h"
#include "event_api.h"
#include "pm_defs.h"
#include "events.h"
#include "GameStudioModelRenderer.h"
#include "r_efx.h"
#include "input.h"
#include "wpn_cmd_shared.h"

#define	GAUSS_PRIMARY_CHARGE_VOLUME	256	// how loud gauss is while charging
#define GAUSS_PRIMARY_FIRE_VOLUME	450	// how loud gauss is when discharged

#undef RECORD_ANIM_F
#undef RECORD_ANIM_S

#define RECORD_ANIM_F(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat(); \
											else if (!strcmp(p->GetName(), "eft_"#keyname"")) \
												s_AnimData[##enumname].m_fe = p->GetFloat();

#define RECORD_ANIM_S(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat();


int			CGauss::s_iItemType	= 0;
animdb_t	CGauss::s_AnimData[ANIM_COUNT];


void CGauss::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;

	memset(&s_AnimData, NULL, sizeof(s_AnimData));

	NewKeyValues *pDatabase = pRoot->FindKey("animations");
	if (!pDatabase)
		return;
	
	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_ANIM_S(idle,		ANIM_IDLE)
		RECORD_ANIM_S(idle2,	ANIM_IDLE2)
		RECORD_ANIM_S(fidget,	ANIM_FIDGET)
		RECORD_ANIM_S(spin,		ANIM_SPIN)
		RECORD_ANIM_S(spinup,	ANIM_SPINUP)
		RECORD_ANIM_S(fire,		ANIM_FIRE)
		RECORD_ANIM_S(fire2,	ANIM_FIRE2)

		p = p->GetNextValue();
	}
}

void CGauss::EV_FireGauss(event_args_t * args)
{
	int idx;
	vec3_t origin;
	vec3_t angles;
	vec3_t velocity;
	float flDamage = args->fparam1;
	int primaryfire = args->bparam1;

	int m_fPrimaryFire = args->bparam1;
	int m_iWeaponVolume = GAUSS_PRIMARY_FIRE_VOLUME;
	vec3_t vecSrc;
	vec3_t vecDest;
	edict_t		*pentIgnore;
	pmtrace_t tr, beam_tr;
	float flMaxFrac = 1.0;
	int	nTotal = 0;
	int fHasPunched = 0;
	int fFirstBeam = 1;
	int	nMaxHits = 10;
	physent_t *pEntity;
	int m_iBeam, m_iGlow, m_iBalls;
	vec3_t up, right, forward;
	Vector vecSrcSave, vecEndSave;	// LUNA: save data for DrawGunShot();

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );
	VectorCopy( args->velocity, velocity );

	if ( args->bparam2 )
	{
		EV_StopPreviousGauss( idx );
		return;
	}

//	Con_Printf( "Firing gauss with %f\n", flDamage );
	EV_GetGunPosition( args, vecSrc, origin );

	m_iBeam = gEngfuncs.pEventAPI->EV_FindModelIndex( "sprites/smoke.spr" );
	m_iBalls = m_iGlow = gEngfuncs.pEventAPI->EV_FindModelIndex( "sprites/hotglow.spr" );
	
	gEngfuncs.pfnAngleVectors( angles, forward, right, up );

	VectorMA( vecSrc, 8192, forward, vecDest );

	if ( EV_IsLocal( idx ) )
	{
		g_vecFixAngleOfs.x -= 2;
		WeaponAnim(&s_AnimData[ANIM_FIRE2], 1);

		// UNDONE: feels no good at client.dll
		// try another method at server to add a velocity?
		/*if ( m_fPrimaryFire == false )
			 g_vecPunchOrigin.x = flDamage;*/
	}

	gEngfuncs.pEventAPI->EV_PlaySound( idx, origin, CHAN_WEAPON, "weapons/gauss2.wav", 0.5 + flDamage * (1.0 / 400.0), ATTN_NORM, 0, 85 + gEngfuncs.pfnRandomLong( 0, 0x1f ) );

	while (flDamage > 10 && nMaxHits > 0)
	{
		nMaxHits--;

		gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
		
		// Store off the old count
		gEngfuncs.pEventAPI->EV_PushPMStates();
	
		// Now add in all of the players.
		gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

		gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
		gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1, &tr );

		gEngfuncs.pEventAPI->EV_PopPMStates();

		// save for later.
		vecSrcSave = vecSrc;
		vecEndSave = vecDest;

		if ( tr.allsolid )
			break;

		if (fFirstBeam)
		{
			if ( EV_IsLocal( idx ) )
			{
				// Add muzzle flash to current weapon model
				g_pViewEnt->curstate.effects |= EF_MUZZLEFLASH;
			}
			fFirstBeam = 0;

			gEngfuncs.pEfxAPI->R_BeamEntPoint( 
				idx | 0x1000,
				tr.endpos,
				m_iBeam,
				0.1,
				m_fPrimaryFire ? 1.0 : 2.5,
				0.0,
				m_fPrimaryFire ? 128.0 : flDamage,
				0,
				0,
				0,
				m_fPrimaryFire ? 255 : 255,
				m_fPrimaryFire ? 128 : 255,
				m_fPrimaryFire ? 0 : 255
			);
		}
		else
		{
			gEngfuncs.pEfxAPI->R_BeamPoints( vecSrc,
				tr.endpos,
				m_iBeam,
				0.1,
				m_fPrimaryFire ? 1.0 : 2.5,
				0.0,
				m_fPrimaryFire ? 128.0 : flDamage,
				0,
				0,
				0,
				m_fPrimaryFire ? 255 : 255,
				m_fPrimaryFire ? 128 : 255,
				m_fPrimaryFire ? 0 : 255
			);
		}

		pEntity = gEngfuncs.pEventAPI->EV_GetPhysent( tr.ent );
		if ( pEntity == NULL )
			break;

		if ( pEntity->solid == SOLID_BSP )
		{
			float n;

			pentIgnore = NULL;

			n = -DotProduct( tr.plane.normal, forward );

			if (n < 0.5) // 60 degrees	
			{
				// ALERT( at_console, "reflect %f\n", n );
				// reflect
				vec3_t r;
			
				VectorMA( forward, 2.0 * n, tr.plane.normal, r );

				flMaxFrac = flMaxFrac - tr.fraction;
				
				VectorCopy( r, forward );

				VectorMA( tr.endpos, 8.0, forward, vecSrc );
				VectorMA( vecSrc, 8192.0, forward, vecDest );

				gEngfuncs.pEfxAPI->R_TempSprite( tr.endpos, vec3_origin, 0.2, m_iGlow, kRenderGlow, kRenderFxNoDissipation, flDamage * n / 255.0, flDamage * n * 0.5 * 0.1, FTENT_FADEOUT );

				vec3_t fwd;
				VectorAdd( tr.endpos, tr.plane.normal, fwd );

				gEngfuncs.pEfxAPI->R_Sprite_Trail( TE_SPRITETRAIL, tr.endpos, fwd, m_iBalls, 3, 0.1, gEngfuncs.pfnRandomFloat( 10, 20 ) / 100.0, 100,
									255, 100 );

				// lose energy
				if ( n == 0 )
				{
					n = 0.1;
				}
				
				flDamage = flDamage * (1 - n);

			}
			else
			{
				// tunnel
				DrawGunShot(vecSrcSave, vecEndSave);

				gEngfuncs.pEfxAPI->R_TempSprite( tr.endpos, vec3_origin, 1.0, m_iGlow, kRenderGlow, kRenderFxNoDissipation, flDamage / 255.0, 6.0, FTENT_FADEOUT );

				// limit it to one hole punch
				if (fHasPunched)
				{
					break;
				}
				fHasPunched = 1;
				
				// try punching through wall if secondary attack (primary is incapable of breaking through)
				if ( !m_fPrimaryFire )
				{
					vec3_t start;

					VectorMA( tr.endpos, 8.0, forward, start );

					// Store off the old count
					gEngfuncs.pEventAPI->EV_PushPMStates();
						
					// Now add in all of the players.
					gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

					gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
					gEngfuncs.pEventAPI->EV_PlayerTrace( start, vecDest, PM_STUDIO_BOX, -1, &beam_tr );

					if ( !beam_tr.allsolid )
					{
						vec3_t delta;
						float n;

						// trace backwards to find exit point
						// we need to pre-save for later, since the trace data will be override.
						vecSrcSave = beam_tr.endpos;
						vecEndSave = tr.endpos;
						gEngfuncs.pEventAPI->EV_PlayerTrace( beam_tr.endpos, tr.endpos, PM_STUDIO_BOX, -1, &beam_tr );


						VectorSubtract( beam_tr.endpos, tr.endpos, delta );
						
						n = Length( delta );

						if (n < flDamage)
						{
							if (n == 0)
								n = 1;
							flDamage -= n;

							// absorption balls
							{
								vec3_t fwd;
								VectorSubtract( tr.endpos, forward, fwd );
								gEngfuncs.pEfxAPI->R_Sprite_Trail( TE_SPRITETRAIL, tr.endpos, fwd, m_iBalls, 3, 0.1, gEngfuncs.pfnRandomFloat( 10, 20 ) / 100.0, 100,
									255, 100 );
							}

	//////////////////////////////////// WHAT TO DO HERE
							// CSoundEnt::InsertSound ( bits_SOUND_COMBAT, pev->origin, NORMAL_EXPLOSION_VOLUME, 3.0 );

							DrawGunShot(vecSrcSave, vecEndSave);
							
							gEngfuncs.pEfxAPI->R_TempSprite( beam_tr.endpos, vec3_origin, 0.1, m_iGlow, kRenderGlow, kRenderFxNoDissipation, flDamage / 255.0, 6.0, FTENT_FADEOUT );
			
							// balls
							{
								vec3_t fwd;
								VectorSubtract( beam_tr.endpos, forward, fwd );
								gEngfuncs.pEfxAPI->R_Sprite_Trail( TE_SPRITETRAIL, beam_tr.endpos, fwd, m_iBalls, (int)(flDamage * 0.3), 0.1, gEngfuncs.pfnRandomFloat( 10, 20 ) / 100.0, 200,
									255, 40 );
							}
							
							VectorAdd( beam_tr.endpos, forward, vecSrc );
						}
					}
					else
					{
						flDamage = 0;
					}

					gEngfuncs.pEventAPI->EV_PopPMStates();
				}
				else
				{
					if ( m_fPrimaryFire )
					{
						// slug doesn't punch through ever with primary 
						// fire, so leave a little glowy bit and make some balls
						gEngfuncs.pEfxAPI->R_TempSprite( tr.endpos, vec3_origin, 0.2, m_iGlow, kRenderGlow, kRenderFxNoDissipation, 200.0 / 255.0, 0.3, FTENT_FADEOUT );
			
						{
							vec3_t fwd;
							VectorAdd( tr.endpos, tr.plane.normal, fwd );
							gEngfuncs.pEfxAPI->R_Sprite_Trail( TE_SPRITETRAIL, tr.endpos, fwd, m_iBalls, 8, 0.6, gEngfuncs.pfnRandomFloat( 10, 20 ) / 100.0, 100,
								255, 200 );
						}
					}

					flDamage = 0;
				}
			}
		}
		else
		{
			VectorAdd( tr.endpos, forward, vecSrc );
		}
	}
}

void CGauss::EV_StopPreviousGauss(int idx)
{
	// Make sure we don't have a gauss spin event in the queue for this guy
	gEngfuncs.pEventAPI->EV_KillEvents( idx, "events/gaussspin.sc" );
	gEngfuncs.pEventAPI->EV_StopSound( idx, CHAN_WEAPON, "ambience/pulsemachine.wav" );
}

bool CGauss::CanWeaponFire(void)
{
	// don't fire underwater
	if (g_pparams.waterlevel == 3 || AMMUNITION < 2)
	{
		gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, m_sItemData.m_szDryFireSound, 0.8, ATTN_NORM, 0, PITCH_NORM);
		m_flNextPriAttack = 0.5;		// play efx not so quick.

		return false;
	}

	if (IS_RUNNING || m_bInReload || m_flNextPriAttack > 0 || m_flNextFrame > 0)
		return false;

	if (m_sItemData.m_bSingleShoot && !m_bTriggerRel)
		return false;

	return true;
}

void CGauss::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	AMMUNITION += 2000;
}

void CGauss::PrimaryAttack(void)
{
	m_fPrimaryFire = TRUE;

	AMMUNITION -= 2;

	StartFire();
	m_fInAttack = 0;
	m_flNextIdle = 1.0;
	m_flNextFrame = 0.2;
}

void CGauss::SecondaryAttack(void)
{
	// don't fire underwater
	if ( g_pparams.waterlevel == 3 )
	{
		if ( m_fInAttack != 0 )
		{
			gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "weapons/electro4.wav", 1.0, ATTN_NORM, 0, 80 + RANDOM_LONG(0,0x3f));
			WeaponAnim(&s_AnimData[ANIM_IDLE]);
			m_fInAttack = 0;
		}
		else
		{
			gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, m_sItemData.m_szDryFireSound, 0.8, ATTN_NORM, 0, PITCH_NORM);
		}

		m_flNextSedAttack = m_flNextPriAttack = 0.5;
		return;
	}

	if ( m_fInAttack == 0 )
	{
		if ( AMMUNITION <= 0 )
		{
			gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "weapons/357_cock1.wav", 0.8, ATTN_NORM, 0, PITCH_NORM);
			m_flNextFrame = 0.5;
			return;
		}

		m_fPrimaryFire = FALSE;

		AMMUNITION --;// take one ammo just to start the spin
		m_flNextAmmoBurn = UTIL_WeaponTimeBase();

		// spin up
		// UNDONE: m_iWeaponVolume at server
		//m_pPlayer->m_iWeaponVolume = GAUSS_PRIMARY_CHARGE_VOLUME;
		
		WeaponAnim(&s_AnimData[ANIM_SPINUP], 1);
		m_fInAttack = 1;
		m_flNextIdle = 0.5;
		m_flStartCharge = UTIL_WeaponTimeBase();
		m_flAmmoChargeEnd = UTIL_WeaponTimeBase() + GetFullChargeTime();

		gEngfuncs.pEventAPI->EV_PlaySound( m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "ambience/pulsemachine.wav", 1.0, ATTN_NORM, m_iSoundState, 110 );

		m_iSoundState = SND_CHANGE_PITCH;
	}
	else if (m_fInAttack == 1)
	{
		if (m_flNextIdle <= 0)
		{
			WeaponAnim( &s_AnimData[ANIM_SPIN] );
			m_fInAttack = 2;
		}
	}
	else
	{
		// during the charging process, eat one bit of ammo every once in a while
		if ( UTIL_WeaponTimeBase() >= m_flNextAmmoBurn && m_flNextAmmoBurn != 1000 )
		{
			AMMUNITION --;
			m_flNextAmmoBurn = UTIL_WeaponTimeBase() + 0.1;
		}

		if ( AMMUNITION <= 0 )
		{
			// out of ammo! force the gun to fire
			StartFire();
			m_fInAttack = 0;
			m_flNextIdle = 1.0;
			m_flNextFrame = 1;
			return;
		}
		
		if ( UTIL_WeaponTimeBase() >= m_flAmmoChargeEnd )
		{
			// don't eat any more ammo after gun is fully charged.
			m_flNextAmmoBurn = 1000;
		}

		int pitch = ( UTIL_WeaponTimeBase() - m_flStartCharge ) * ( 150 / GetFullChargeTime() ) + 100;
		if ( pitch > 250 ) 
			 pitch = 250;

		gEngfuncs.pEventAPI->EV_PlaySound( m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "ambience/pulsemachine.wav", 1.0, ATTN_NORM, m_iSoundState, pitch );

		m_iSoundState = SND_CHANGE_PITCH; // hack for going through level transitions

		// UNDONE: change server m_iWeaponVolume
		//m_pPlayer->m_iWeaponVolume = GAUSS_PRIMARY_CHARGE_VOLUME;
		
		// m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + 0.1;
		if ( m_flStartCharge < UTIL_WeaponTimeBase() - 10 )
		{
			// Player charged up too long. Zap him.
			gEngfuncs.pEventAPI->EV_PlaySound( m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "weapons/electro4.wav", 1.0, ATTN_NORM, 0, 80 + RANDOM_LONG(0,0x3f));
			gEngfuncs.pEventAPI->EV_PlaySound( m_pPlayer->index, m_pPlayer->origin, CHAN_ITEM,   "weapons/electro6.wav", 1.0, ATTN_NORM, 0, 75 + RANDOM_LONG(0,0x3f));
			
			m_fInAttack = 0;
			m_flNextIdle = 1.0;
			m_flNextFrame = 1.0;
			
			// for shock player self
			SU_Begin		(WPN_CMD_SEDATK);
			SU_WriteInteger	(m_iItemType);
			SU_WriteInteger	(TRUE);	// useless arg.
			SU_End			();

			g_cScreenFade.SetAlpha(128, 0);
			g_cScreenFade.SetCurrentColor(255, 128, 0);
			g_cScreenFade.SetTargetColor(255, 128, 0);
			g_cScreenFade.SetFadeSpeed(512);
			g_cScreenFade.Start();
			g_cScreenFade.SetStayLength(1);

			WeaponAnim(&s_AnimData[ANIM_IDLE]);
			
			// Player may have been killed and this weapon dropped, don't execute any more code after this!
			return;
		}
	}
}

//=========================================================
// StartFire- since all of this code has to run and then 
// call Fire(), it was easier at this point to rip it out 
// of weaponidle() and make its own function then to try to
// merge this into Fire(), which has some identical variable names 
//=========================================================
void CGauss::StartFire( void )
{
	float flDamage;
	Vector vecFwd, vecRight, vecUp;

	Vector(g_pparams.viewangles).AngleVectors(vecFwd, vecRight, vecUp);
	Vector vecSrc = g_pparams.vieworg; // + gpGlobals->v_up * -8 + gpGlobals->v_right * 8;
	
	if ( UTIL_WeaponTimeBase() - m_flStartCharge > GetFullChargeTime() )
	{
		flDamage = 200;
	}
	else
	{
		flDamage = 200 * (( UTIL_WeaponTimeBase() - m_flStartCharge) / GetFullChargeTime() );
	}

	if ( m_fPrimaryFire )
	{
		// UNDONE
		// fixed damage on primary attack
#ifdef CLIENT_DLL
		flDamage = 20;
#else 
		flDamage = gSkillData.plrDmgGauss;
#endif
	}

	if (m_fInAttack != 3)
	{
		// used to launch player.
		SU_Begin		(WPN_CMD_SEDATK);
		SU_WriteInteger	(m_iItemType);
		SU_WriteFloat	(flDamage);
		SU_WriteInteger	(TRUE);	// useless arg.
		SU_End			();

		// player "shoot" animation move to player Fire() at mp.dll
		//m_pPlayer->SetAnimation( PLAYER_ATTACK1 );
	}

	// time until aftershock 'static discharge' sound
	m_flPlayAftershock = UTIL_WeaponTimeBase() + RANDOM_FLOAT( 0.3, 0.8 );

	Fire( vecSrc, vecFwd, flDamage );
}

void CGauss::Fire( Vector vecOrigSrc, Vector vecDir, float flDamage )
{
	// damage on mp.dll
	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(vecOrigSrc);
	SU_WriteVector	(vecDir);
	SU_WriteFloat	(0.0f);
	SU_WriteFloat	(flDamage);
	SU_WriteInteger	(m_fPrimaryFire);
	SU_End			();
	
	// The main firing event is sent unreliably so it won't be delayed.
	event_args_t data;
	memset(&data, NULL, sizeof(event_args_t));
	m_pPlayer->origin.CopyToArray(data.origin);
	Vector(g_pparams.viewangles).CopyToArray(data.angles);
	m_pPlayer->curstate.velocity.CopyToArray(data.velocity);
	data.entindex = m_pPlayer->index;
	data.fparam1 = flDamage;
	data.bparam1 = m_fPrimaryFire ? 1 : 0;
	EV_FireGauss(&data);

	// This reliable event is used to stop the spinning sound
	// It's delayed by a fraction of second to make sure it is delayed by 1 frame on the client
	// It's sent reliably anyway, which could lead to other delays

	EV_StopPreviousGauss(m_pPlayer->index);
}

void CGauss::WeaponIdle( void )
{
	// play aftershock static discharge
	if ( m_flPlayAftershock && m_flPlayAftershock < UTIL_WeaponTimeBase() )
	{
		switch (RANDOM_LONG(0,3))
		{
		case 0:	gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "weapons/electro4.wav", RANDOM_FLOAT(0.7, 0.8), ATTN_NORM, 0, PITCH_NORM); break;
		case 1:	gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "weapons/electro5.wav", RANDOM_FLOAT(0.7, 0.8), ATTN_NORM, 0, PITCH_NORM); break;
		case 2:	gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, "weapons/electro6.wav", RANDOM_FLOAT(0.7, 0.8), ATTN_NORM, 0, PITCH_NORM); break;
		case 3:	break; // no sound
		}
		m_flPlayAftershock = 0.0;
	}

	if (m_flNextIdle > 0)
		return;

	if (m_fInAttack != 0)
	{
		StartFire();
		m_fInAttack = 0;
		m_flNextIdle = 2.0;
	}
	else
	{
		float flRand = RANDOM_FLOAT(0, 1);
		if (flRand <= 0.5)
		{
			WeaponAnim(&s_AnimData[ANIM_IDLE]);
			m_flNextIdle = RANDOM_FLOAT( 10, 15 );
		}
		else if (flRand <= 0.75)
		{
			WeaponAnim(&s_AnimData[ANIM_IDLE2]);
			m_flNextIdle = RANDOM_FLOAT( 10, 15 );
		}
		else
		{
			WeaponAnim(&s_AnimData[ANIM_FIDGET]);
			m_flNextIdle = 3;
		}
	}
}

void CGauss::ItemPostFrame( void )
{
	// holster logic must included, otherwise it will stuck.
	if (m_ulStatus & WPN_FLAG_HOLSTERING)
	{
		m_ulStatus |= WPN_FLAG_CAN_HOLSTER;
		SwitchWeapon(m_pSwitchTo);

		return;
	}

	if (m_ulStatus & WPN_FLAG_SHOULD_HOLSTER)
	{
		if (!m_pSwitchTo)
			SwitchWeapon(UTIL_SortItemsBySlot());
		else if (CanItemHolster())
			SwitchWeapon(m_pSwitchTo);

		return;
	}

	int bitsButton = CL_GetButtonBits();

	if ((bitsButton & IN_ATTACK2) && m_flNextSedAttack <= 0 )
	{
		SecondaryAttack();
	}
	else if ((bitsButton & IN_ATTACK) && m_flNextPriAttack <= 0 )
	{
		if ( CanWeaponFire() )	// LUNA: by HL, only check this..
			PrimaryAttack();
	}
	else if ( !(bitsButton & (IN_ATTACK|IN_ATTACK2) ) )
	{
		WeaponIdle( );
		return;
	}
}

#else

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "weapons.h"
#include "player.h"
#include "soundent.h"
#include "wpn_cmd_shared.h"

#define	GAUSS_PRIMARY_CHARGE_VOLUME	256	// how loud gauss is while charging
#define GAUSS_PRIMARY_FIRE_VOLUME	450	// how loud gauss is when discharged

int		CGauss::s_iItemType = 0;

void CGauss::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;

	g_sItemData[iType].PrimaryAttack	= CGauss::PrimaryAttack;
	g_sItemData[iType].SecondaryAttack	= CGauss::SecondaryAttack;
}

void CGauss::Precache(void)
{
	if (!GetWeaponTypeFromName("wpn_hl_gauss"))
		return;

	PRECACHE_MODEL( "sprites/hotglow.spr" );
	PRECACHE_MODEL( "sprites/hotglow.spr" );
	PRECACHE_MODEL( "sprites/smoke.spr" );
}

void CGauss::PrimaryAttack(void * pEntity, int iType, Vector vecSrc, Vector vecAngle, float flBaseline)
{
	float flDamage = SU_ReadFloat();
	BOOL FPrimaryFire = SU_ReadInteger();

	// NOTE: vecAngle is actrually vecAiming!!!!!
	Fire(pEntity, vecSrc, vecAngle, flDamage, FPrimaryFire);
}

void CGauss::SecondaryAttack(void * pEntity, int iType)
{
	int iArgCount = CMD_ARGC();

	if (iArgCount == 3)
	{
		SelfShock(pEntity);
	}
	else if (iArgCount == 4)
	{
		float flDamage = SU_ReadFloat();
		// ARG(4) is useless.
		KnockPlayer(pEntity, flDamage);
	}
}

void CGauss::SelfShock(void *pEntity)
{
	CBasePlayer	*pPlayer = (CBasePlayer	*)CBasePlayer::Instance((edict_t *)pEntity);

	if (!pPlayer || !pPlayer->IsAlive())
		return;
	
	int index = pPlayer->entindex();

	// only include code which shock player self.
	pPlayer->TakeDamage( VARS(eoNullEntity), VARS(eoNullEntity), 50, DMG_SHOCK );
}

void CGauss::KnockPlayer(void *pEntity, float flDamage)
{
	CBasePlayer	*pPlayer = (CBasePlayer	*)CBasePlayer::Instance((edict_t *)pEntity);

	if (!pPlayer || !pPlayer->IsAlive())
		return;
	
	int index = pPlayer->entindex();

	UTIL_MakeVectors(pPlayer->pev->v_angle + pPlayer->pev->punchangle);

	pPlayer->pev->velocity = pPlayer->pev->velocity - gpGlobals->v_forward * flDamage * 5;
}

void CGauss::Fire( void *pPlayerEdict, Vector vecOrigSrc, Vector vecDir, float flDamage, BOOL m_fPrimaryFire )
{
	CBasePlayer	*pPlayer = (CBasePlayer	*)CBasePlayer::Instance((edict_t *)pPlayerEdict);

	if (!pPlayer || !pPlayer->IsAlive())
		return;
	
	int index = pPlayer->entindex();

	pPlayer->m_iWeaponVolume = GAUSS_PRIMARY_FIRE_VOLUME;

	Vector vecSrc = vecOrigSrc;
	Vector vecDest = vecSrc + vecDir * 8192;
	edict_t		*pentIgnore;
	TraceResult tr, beam_tr;
	float flMaxFrac = 1.0;
	int	nTotal = 0;
	int fHasPunched = 0;
	int fFirstBeam = 1;
	int	nMaxHits = 10;

	pentIgnore = ENT( pPlayer->pev );

	// no more playback events, since this function is called when client.dll agree.

	// SetAnimation() moves to here.
	pPlayer->SetAnimation( PLAYER_ATTACK1 );

	while (flDamage > 10 && nMaxHits > 0)
	{
		nMaxHits--;

		// ALERT( at_console, "." );
		UTIL_TraceLine(vecSrc, vecDest, dont_ignore_monsters, pentIgnore, &tr);

		if (tr.fAllSolid)
			break;

		CBaseEntity *pEntity = CBaseEntity::Instance(tr.pHit);

		if (pEntity == NULL)
			break;

		if ( fFirstBeam )
		{
			pPlayer->pev->effects |= EF_MUZZLEFLASH;
			fFirstBeam = 0;
	
			nTotal += 26;
		}
		
		if (pEntity->pev->takedamage)
		{
			ClearMultiDamage();
			pEntity->TraceAttack( pPlayer->pev, flDamage, vecDir, &tr, DMG_BULLET );
			ApplyMultiDamage(pPlayer->pev, pPlayer->pev);
		}

		if ( pEntity->ReflectGauss() )
		{
			float n;

			pentIgnore = NULL;

			n = -DotProduct(tr.vecPlaneNormal, vecDir);

			if (n < 0.5) // 60 degrees
			{
				// ALERT( at_console, "reflect %f\n", n );
				// reflect
				Vector r;
			
				r = 2.0f * tr.vecPlaneNormal * n + vecDir;
				flMaxFrac = flMaxFrac - tr.flFraction;
				vecDir = r;
				vecSrc = tr.vecEndPos + vecDir * 8;
				vecDest = vecSrc + vecDir * 8192;

				// explode a bit
				pPlayer->RadiusDamage( tr.vecEndPos, pPlayer->pev, pPlayer->pev, flDamage * n, CLASS_NONE, DMG_BLAST );

				nTotal += 34;
				
				// lose energy
				if (n == 0) n = 0.1;
				flDamage = flDamage * (1 - n);
			}
			else
			{
				nTotal += 13;

				// limit it to one hole punch
				if (fHasPunched)
					break;
				fHasPunched = 1;

				// try punching through wall if secondary attack (primary is incapable of breaking through)
				if ( !m_fPrimaryFire )
				{
					UTIL_TraceLine( tr.vecEndPos + vecDir * 8, vecDest, dont_ignore_monsters, pentIgnore, &beam_tr);
					if (!beam_tr.fAllSolid)
					{
						// trace backwards to find exit point
						UTIL_TraceLine( beam_tr.vecEndPos, tr.vecEndPos, dont_ignore_monsters, pentIgnore, &beam_tr);

						float n = (beam_tr.vecEndPos - tr.vecEndPos).Length( );

						if (n < flDamage)
						{
							if (n == 0) n = 1;
							flDamage -= n;

							// ALERT( at_console, "punch %f\n", n );
							nTotal += 21;

							// exit blast damage
							//m_pPlayer->RadiusDamage( beam_tr.vecEndPos + vecDir * 8, pev, m_pPlayer->pev, flDamage, CLASS_NONE, DMG_BLAST );
							float damage_radius = flDamage * 2.5;

							::RadiusDamage( beam_tr.vecEndPos + vecDir * 8, pPlayer->pev, pPlayer->pev, flDamage, damage_radius, CLASS_NONE, DMG_BLAST );

							CSoundEnt::InsertSound ( bits_SOUND_COMBAT, pPlayer->GetGunPosition(), NORMAL_EXPLOSION_VOLUME, 3.0 );

							nTotal += 53;

							vecSrc = beam_tr.vecEndPos + vecDir;
						}
					}
					else
					{
						 //ALERT( at_console, "blocked %f\n", n );
						flDamage = 0;
					}
				}
				else
				{
					//ALERT( at_console, "blocked solid\n" );
					
					flDamage = 0;
				}

			}
		}
		else
		{
			vecSrc = tr.vecEndPos + vecDir;
			pentIgnore = ENT( pEntity->pev );
		}
	}
}

#endif