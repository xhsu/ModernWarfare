/***

Modern Warfare Develop Team
CMasada.cpp - Innocent Blue's Weapon Pack

Coder:	Luna the Reborn
Model:	Innocent Blue
Sound:	Innocent Blue
Dxt/Hud:Usagi Chan

Create Date: 2018/06/21

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "GameStudioModelRenderer.h"
#include "entity.h"
#include "view.h"


sight_t	CMasada::s_sOpticAimOfs						= { Vector(-9.58, -5, -2.41), 90 };
float	CMasada::s_flOpticOutChangeSubModel			= 0.4333333333333333f;
float	CMasada::s_flOpticInChangeSubModel			= 0.9f;
bool	CMasada::s_bOpticSniperZoom					= false;
float	CMasada::s_flHeartbeatSensor_Range			= 1000;
float	CMasada::s_flHeartbeatSensor_VertiAgl		= 45;
float	CMasada::s_flHeartbeatSensor_HrztlAgl		= 140;
float	CMasada::s_flHeartbeatSensor_PointSize		= 0.1f;
bool	CMasada::s_bHeartbeatSensor_Realistic		= true;

animdb_t	CMasada::s_Anim_OpticIn		= { 11, 1.2f, 1.2f };
animdb_t	CMasada::s_Anim_OpticOut	= { 12, 0.2666666666666667f, 0.2666666666666667f };


void CMasada::Initialize(NewKeyValues * pRoot, int iType)
{
	LoadWeaponSight(pRoot->FindKey("sight"), &s_sOpticAimOfs, "optic");

	// GET DATA
	NewKeyValues *pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (!strcmp(p->GetName(), "HeartbeatSensor_Angle"))
			s_flHeartbeatSensor_VertiAgl = s_flHeartbeatSensor_HrztlAgl = p->GetFloat();

		RECORD_FLOAT	(OpticOutChangeSubModel,	s_flOpticOutChangeSubModel)
		RECORD_FLOAT	(OpticInChangeSubModel,		s_flOpticInChangeSubModel)
		RECORD_BOOL		(OpticSniperZoom,			s_bOpticSniperZoom)

		RECORD_FLOAT	(HeartbeatSensor_Range,		s_flHeartbeatSensor_Range)
		RECORD_FLOAT	(HeartbeatSensor_VertiAgl,	s_flHeartbeatSensor_VertiAgl)
		RECORD_FLOAT	(HeartbeatSensor_HrztlAgl,	s_flHeartbeatSensor_HrztlAgl)
		RECORD_FLOAT	(HeartbeatSensor_PointSize,	s_flHeartbeatSensor_PointSize)
		RECORD_BOOL		(HeartbeatSensor_Realistic,	s_bHeartbeatSensor_Realistic)

		p = p->GetNextValue();
	}

	if (s_flHeartbeatSensor_VertiAgl <= 0 || s_flHeartbeatSensor_VertiAgl >= 180)
		s_flHeartbeatSensor_VertiAgl = 90;

	if (s_flHeartbeatSensor_HrztlAgl <= 0 || s_flHeartbeatSensor_HrztlAgl >= 180)
		s_flHeartbeatSensor_HrztlAgl = 90;

	// AngleBetweenVecPlane() returning radian.
	s_flHeartbeatSensor_VertiAgl	= DEGREE_RADIAN(s_flHeartbeatSensor_VertiAgl);
	s_flHeartbeatSensor_HrztlAgl	= DEGREE_RADIAN(s_flHeartbeatSensor_HrztlAgl);

	// GET ANIMS
	pDatabase = pRoot->FindKey("animations");
	if (!pDatabase)
		return;

	p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_ANIM_S(optic_out,	s_Anim_OpticOut)
		RECORD_ANIM_S(optic_in,		s_Anim_OpticIn)

		p = p->GetNextValue();
	}
}

int CMasada::GetAimFOV(void)
{
	if (m_bOptic)
		return s_sOpticAimOfs.m_flFOV;
	else
		return CBaseWeapons::GetAimFOV();
}

Vector CMasada::GetAimOffset(void)
{
	if (m_bOptic)
		return s_sOpticAimOfs.m_vecOfs;
	else
		return CBaseWeapons::GetAimOffset();
}

int CMasada::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands	= 0,

		{ 0, 1 },	// rifle	= 1,
		{ 0, 1 },

		{ 0, 4 },	// scope	= 3,
		{ 0, 2 },	// laser	= 4,
		{ 0, 2 },	// silencer	= 5,
	};

	if (m_bCrosshairUp && !(m_bitsAccessories & ACC_SIGHT))
		info[3].body = 1;
	else if (m_bitsAccessories & ACC_HOLO)
		info[3].body = 2;
	else if (m_bitsAccessories & ACC_DOT)
		info[3].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[4].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[5].body = 1;

	return CalcBody(info, 6);
}

void CMasada::OnSpawnPost(void)
{
	CBaseWeapons::OnSpawnPost();

	m_bOptic = false;
	m_bCrosshairUp = true;
	m_flTimeChangeSubmodel = 9999;

	if (s_bOpticSniperZoom)
		SetFunc(m_pfnSecondaryAttack, &CMasada::Def_Scope);
	else
		SetFunc(m_pfnSecondaryAttack, &CMasada::Def_SteelSight);
}

void CMasada::ChangeMode(void)
{
	if (IS_AIMING)
		SecondaryAttack();
	else if (IS_RUNNING)
	{
		RunStop();
		return;
	}

	WeaponAnim(m_bOptic ? &s_Anim_OpticOut : &s_Anim_OpticIn, 2);
	m_flTimeChangeSubmodel = gEngfuncs.GetClientTime() + (m_bOptic ? s_flOpticOutChangeSubModel : s_flOpticInChangeSubModel);
	m_ulStatus |= MASADA_FLAG_CHANGING;

	m_bOptic = !m_bOptic;

	// LUNA: Innocent Blue's all anim is based on controller = 0
	// so let's reset it before any anim.
	SetController();
}

void CMasada::ItemPreFrame(void)
{
	Def_ItemPreFrame();

	// submodel think
	if (m_flTimeChangeSubmodel <= gEngfuncs.GetClientTime())
	{
		m_flTimeChangeSubmodel = gEngfuncs.GetClientTime() + 9999.0f;

		m_bCrosshairUp = !m_bCrosshairUp;
	}
}

void CMasada::ItemDeploy(void)
{
	Def_ItemDeploy();

	SetController(0, m_bOptic ? 0 : 255);
}

void CMasada::ItemPostFrame(void)
{
	Def_ItemPostFrame();

	if (m_ulStatus & MASADA_FLAG_CHANGING)
	{
		m_ulStatus &= ~MASADA_FLAG_CHANGING;

		SetController(0, m_bOptic ? 0 : 255);
	}
}

void CMasada::ItemHolster(void)
{
	Def_ItemHolster();

	// dont be ugly on next weapon...
	SetController();
}

inline void CMasada::SetController(int which, int value)
{
	g_pViewEnt->curstate.controller[which] = g_pViewEnt->latched.prevcontroller[which] = value;
}


bool	m_bModelDataInit;
double	m_flCriticalAngle;
float	m_flScreenHeight;
float	m_flScreenHalfWid;
float	m_flSensorDistScale = 0.01f;

void CMasada::ModelInit(void)
{
	Vector vecDrawOri	= (g_vecViewModelAttmt[4] + g_vecViewModelAttmt[5]) / 2.0f;
	Vector vecUp		= g_vecViewModelAttmt[2] - g_vecViewModelAttmt[5];
	Vector vecRight		= g_vecViewModelAttmt[4] - g_vecViewModelAttmt[5];
	Vector vecCritical	= g_vecViewModelAttmt[2] - vecDrawOri;

	m_flCriticalAngle	= vecCritical ^ vecUp;
	m_flScreenHalfWid	= vecRight.Length() * 0.5f;
	m_flScreenHeight	= vecUp.Length();
	m_flSensorDistScale	= vecCritical.Length() / s_flHeartbeatSensor_Range;

	if (m_flCriticalAngle >= 90 || m_flCriticalAngle <= 0)
		return;

	m_bModelDataInit = true;
}

void CMasada::DrawWorldCustomObjects(void)
{
	CBaseWeapons::DrawWorldCustomObjects();

	if (!m_bModelDataInit)
	{
		ModelInit();
		return;
	}

	glPushAttrib(GL_ALL_ATTRIB_BITS);	// Save current depth range value
	glDepthRange(0.09, 0.1);			// Change depth range for laser dot drawing, VMDL draw at 0.1~0.29

	if (s_bHeartbeatSensor_Realistic)
		DrawRealSensor();
	else
		DrawNormSensor();

	glPopAttrib();						// Restore depth range value
}

void CMasada::DrawRealSensor ( void )
{
	// determind screen draw dir
	Vector	vecDrawOri	= (g_vecViewModelAttmt[4] + g_vecViewModelAttmt[5]) / 2.0f;	// center of the bottom line is the "player"
	Vector	vecScrUp	= Vector(gEngfuncs.GetViewModel()->attachment[2]) - g_vecViewModelAttmt[5];	// determind the UP dir
	Vector	vecScrRight	= g_vecViewModelAttmt[4] - g_vecViewModelAttmt[5];			// determind the RIGHT dir

	vecScrUp	= vecScrUp.Normalize();		// normalize them.
	vecScrRight	= vecScrRight.Normalize();

	// update vecUp, right, forward.
	gEngfuncs.pfnAngleVectors(g_pparams.viewangles, gHUD::TriDimnHud::m_vecForward, gHUD::TriDimnHud::m_vecRight, gHUD::TriDimnHud::m_vecUp);

	// get 3 points to determind a plane
	Vector vecPoints[3];
	vecPoints[0] = gEngfuncs.GetLocalPlayer()->origin;
	vecPoints[1] = vecPoints[0] + gHUD::TriDimnHud::m_vecForward;
	vecPoints[2] = vecPoints[0] + gHUD::TriDimnHud::m_vecRight;

	// find a plane which is horizontal to eye sight
	Plane plHorizontal = Plane(vecPoints[0], vecPoints[1], vecPoints[2]); 

	// this time find another plane vertical to eye sight
	vecPoints[2] = vecPoints[0] + gHUD::TriDimnHud::m_vecUp;
	Plane plVertical = Plane(vecPoints[0], vecPoints[1], vecPoints[2]); 

	// player is index between 1 and 32
	cl_entity_t *pPlayer = NULL;

	for (int i = 1; i < 1500; i ++)	// FIXME: this value should be replace by gpGlobals->maxEntities
	{
		pPlayer = INDEXENT(i);

		// FIXME: maybe can be used later to show other player ??
		/*if (!pPlayer || !pPlayer->player)	// no such player then dont draw.
			continue;

		if (pPlayer == gEngfuncs.GetLocalPlayer())	// local player then dont draw
			continue;

		if (g_sClientInfo[i].m_bitsFlags & SCOREBOARD_FL_DEAD)	// skip dead player
			continue;*/

		if (g_aiEntType[i] != TYPE_LIVED_NPC)	// if this is not a lived NPC, for example, a zombie, skip it.
			continue;

		// Check whether in angle range.
		// method 1: vertical and horizontal scan angle almost the same.
		if (abs(s_flHeartbeatSensor_HrztlAgl - s_flHeartbeatSensor_VertiAgl) <= 1 && !fm_is_in_viewcone(s_flHeartbeatSensor_HrztlAgl, pPlayer->origin))
			continue;

		// method 2: test vertical and horizontal separatly.
		Vector vecDir	= Vector(pPlayer->origin) - Vector(gEngfuncs.GetLocalPlayer()->origin);

		// step 1: check whether emeny is back of you.
		if (DotProduct(vecDir, gHUD::TriDimnHud::m_vecForward) <= 0)
			continue;

		// step 2: check vertical angle. compare to plane which HORIZONTAL to eye sight.
		if ((vecDir ^ plHorizontal) > (s_flHeartbeatSensor_VertiAgl * 0.5f) )
			continue;

		Vector	vecProj	= plHorizontal.Projection(pPlayer->origin);				// proj enemy's origin to the horizontal eyesight plane
		Vector	vecDist	= vecProj - Vector(gEngfuncs.GetLocalPlayer()->origin);	// find dir vec, from your location to enemy's projected origin
		float	flAngle	= vecDist ^ gHUD::TriDimnHud::m_vecForward;							// find the angle between your front and the projected vec
		bool	bRight	= !!(DotProduct(vecDist, gHUD::TriDimnHud::m_vecRight) > 0.0f);		// determind which side is your enemy

		// step 3: check horizontal angle. Use projected point.
		if (flAngle > (s_flHeartbeatSensor_HrztlAgl * 0.5f) )
			continue;

		if (vecDir.Length() > s_flHeartbeatSensor_Range)	// check 3D linear distance.
			continue;

		// check whether the point is in the screen
		float	flOfsLen	= vecDist.Length() * m_flSensorDistScale;
		if (flAngle < m_flCriticalAngle && flOfsLen > (m_flScreenHeight / cos(flAngle)) )
			continue;
		else if (flAngle > m_flCriticalAngle && flOfsLen > (m_flScreenHalfWid / sin(flAngle)) )
			continue;

		// ScreenOrigin = ScreenDrawOrigin + OFS
		Vector	vecScrOri;
		if (bRight)	// if it's right side, then +vecRight
		{
			vecScrOri = vecDrawOri + (vecScrUp + vecScrRight * tan(flAngle)).SetLength(flOfsLen);
		}
		else
		{
			vecScrOri = vecDrawOri + (vecScrUp - vecScrRight * tan(flAngle)).SetLength(flOfsLen);
		}

		//gEngfuncs.Con_Printf("%f\n", vecScrOri.x);

		Vector vecs[4];
		vecs[0] = vecScrOri;
		vecs[1] = vecs[0] + vecScrRight * s_flHeartbeatSensor_PointSize;
		vecs[2] = vecs[1] - vecScrUp * s_flHeartbeatSensor_PointSize;
		vecs[3] = vecs[0] - vecScrUp * s_flHeartbeatSensor_PointSize;

		glDisable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glColor4f(1, 1, 1, 1);

		glBegin(GL_QUADS);	// fill
		glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
		glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
		glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
		glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
		glEnd();

		glDisable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
	}
}

void CMasada::DrawNormSensor ( void )
{
	// determind screen draw dir
	Vector	vecDrawOri	= (g_vecViewModelAttmt[4] + g_vecViewModelAttmt[5]) / 2.0f;	// center of the bottom line is the "player"
	Vector	vecScrUp	= g_vecViewModelAttmt[2] - g_vecViewModelAttmt[5];			// determind the UP dir
	Vector	vecScrRight	= g_vecViewModelAttmt[4] - g_vecViewModelAttmt[5];			// determind the RIGHT dir

	vecScrUp	= vecScrUp.Normalize();		// normalize them.
	vecScrRight	= vecScrRight.Normalize();

	// update vecUp, right, forward.
	gEngfuncs.pfnAngleVectors(g_pparams.viewangles, gHUD::TriDimnHud::m_vecForward, gHUD::TriDimnHud::m_vecRight, gHUD::TriDimnHud::m_vecUp);

	// get 3 points to determind a plane
	Vector vecPoints[3];
	vecPoints[0] = gEngfuncs.GetLocalPlayer()->origin;
	vecPoints[1] = vecPoints[0] + gHUD::TriDimnHud::m_vecForward;
	vecPoints[2] = vecPoints[0] + gHUD::TriDimnHud::m_vecRight;

	// find a plane which is horizontal to eye sight
	Plane plHorizontal = Plane(vecPoints[0], vecPoints[1], vecPoints[2]); 

	// this time find another plane vertical to eye sight
	vecPoints[2] = vecPoints[0] + gHUD::TriDimnHud::m_vecUp;
	Plane plVertical = Plane(vecPoints[0], vecPoints[1], vecPoints[2]); 

	// player is index between 1 and 32
	cl_entity_t *pPlayer = NULL;

	for (int i = 1; i < 1500; i ++)	// FIXME: this value should be replace by gpGlobals->maxEntities
	{
		pPlayer = INDEXENT(i);

		/*if (!pPlayer || !pPlayer->player)	// no such player then dont draw.
			continue;

		if (pPlayer == gEngfuncs.GetLocalPlayer())	// local player then dont draw
			continue;

		if (g_sClientInfo[i].m_bitsFlags & SCOREBOARD_FL_DEAD)	// skip dead player
			continue;*/

		if (g_aiEntType[i] != TYPE_LIVED_NPC)	// if this is not a lived NPC, for example, a zombie, skip it.
			continue;

		// Check whether in angle range.
		// method 1: vertical and horizontal scan angle almost the same.
		if (abs(s_flHeartbeatSensor_HrztlAgl - s_flHeartbeatSensor_VertiAgl) <= 1 && !fm_is_in_viewcone(s_flHeartbeatSensor_HrztlAgl, pPlayer->origin))
			continue;

		// method 2: test vertical and horizontal separatly.
		Vector vecDir	= Vector(pPlayer->origin) - Vector(gEngfuncs.GetLocalPlayer()->origin);	// determind dir points to emeny

		// step 0: check whether emeny is back of you.
		if (DotProduct(vecDir, gHUD::TriDimnHud::m_vecForward) <= 0)
			continue;

		// step 1: check horizontal angle. compare to plane which VERTICAL to eye sight.
		if ((vecDir ^ plVertical) > (s_flHeartbeatSensor_HrztlAgl * 0.5f) )
			continue;

		// step 2: check vertical angle. compare to plane which HORIZONTAL to eye sight.
		if ((vecDir ^ plHorizontal) > (s_flHeartbeatSensor_VertiAgl * 0.5f) )
			continue;

		double	flAngle	= vecDir.Make2D() ^ gHUD::TriDimnHud::m_vecForward.Make2D();							// find 2D angle between dir and your front
		bool	bRight	= !!(DotProduct(vecDir.Make2D(), gHUD::TriDimnHud::m_vecRight.Make2D()) > 0.0f);		// determind which side is your enemy

		if (vecDir.Length() > s_flHeartbeatSensor_Range)	// 3D distance to decide whether draw or not.
			continue;

		// 2D distance to decide screen drawing
		float	flOfsLen	= vecDir.Length2D() * m_flSensorDistScale;

		// check whether the point is in the screen.
		if (flAngle < m_flCriticalAngle && flOfsLen > (m_flScreenHeight / cos(flAngle)) )
			continue;
		else if (flAngle > m_flCriticalAngle && flOfsLen > (m_flScreenHalfWid / sin(flAngle)) )
			continue;

		// ScreenOrigin = ScreenDrawOrigin + OFS
		Vector	vecScrOri;
		if (bRight)	// if it's right side, then +vecRight
		{
			vecScrOri = vecDrawOri + (vecScrUp + vecScrRight * tan(flAngle)).SetLength(flOfsLen);
		}
		else
		{
			vecScrOri = vecDrawOri + (vecScrUp - vecScrRight * tan(flAngle)).SetLength(flOfsLen);
		}

		Vector vecs[4];
		vecs[0] = vecScrOri;
		vecs[1] = vecs[0] + vecScrRight * s_flHeartbeatSensor_PointSize;
		vecs[2] = vecs[1] - vecScrUp * s_flHeartbeatSensor_PointSize;
		vecs[3] = vecs[0] - vecScrUp * s_flHeartbeatSensor_PointSize;

		glDisable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glColor4f(1, 1, 1, 1);

		glBegin(GL_QUADS);	// fill
		glVertex3f(vecs[0].x, vecs[0].y, vecs[0].z);
		glVertex3f(vecs[1].x, vecs[1].y, vecs[1].z);
		glVertex3f(vecs[2].x, vecs[2].y, vecs[2].z);
		glVertex3f(vecs[3].x, vecs[3].y, vecs[3].z);
		glEnd();

		glDisable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
	}
}
