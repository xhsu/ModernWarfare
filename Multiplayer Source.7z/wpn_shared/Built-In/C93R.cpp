/***

Modern Warfare Develop Team
C93R.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/05

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "view.h"


float	C93R::s_flBrustFireRate	= float(60) / float(110);	// default: 110 RPM @ between burst fires.


void C93R::Initialize(NewKeyValues * pRoot, int iType)
{
	NewKeyValues *pCustom = pRoot->FindKey("customdata");
	NewKeyValues *p = NULL;

	if ((p = pCustom->FindKey("93R_BrustFireRate")))
		s_flBrustFireRate = p->GetFloat();
}

int C93R::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// left hand	= 0,
		{ 0, 2 },	// right hand	= 1,
		{ 0, 1 },	// sleeve		= 2,
		{ 0, 1 },	// weapon		= 3,

		{ 0, 2 },	// slide		= 4,
		{ 0, 2 },	// muzzle		= 5,
		{ 0, 2 },	// laser		= 6
	};

	if (!IsDoubleHolding())
		info[1].body = 1;

	if (m_bitsAccessories & ACC_LASER)
		info[6].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[5].body = 1;

	if (IsNonslidemoveAnim(m_iDisplayingAnim) && IsWeaponEmpty())
		info[4].body = 1;

	return CalcBody(info, 7);
}

void C93R::OnSpawnPost(void)
{
	CBasePistol::OnSpawnPost();

	// without this, you can't switch weapon until you switch speed selector.
	m_iBurstFire = -1;
}

void C93R::ItemPostFrame(void)
{
	if (!m_iChamberClip)
		m_iBurstFire = -1;

	if (m_iFireMode != CSMW_FIREMODE_TRIPLE || m_iBurstFire == -1)
	{
		if (IsSuperior())
			Spr_ItemPostFrame();
		else if (IsInferior())
			Ifr_ItemPostFrame();
		else
			Def_ItemPostFrame();

		return;
	}

	// from now on, is burst code.
	
	m_iBurstFire --;
	m_iShotsFired = 0;	// clear that to bounce player.

	PrimaryAttack();

	if (m_iBurstFire > 0)
	{
		m_flNextFrame		= m_sItemData.m_flNextPriAttack;
	}
	else
	{
		m_iBurstFire		= -1;
		m_flNextPriAttack	= s_flBrustFireRate;
	}
}

void C93R::PrimaryAttack(void)
{
	Def_PrimaryAttack();

	if (m_iFireMode == CSMW_FIREMODE_TRIPLE && m_iBurstFire == -1)
	{
		m_iBurstFire	= 2;
		m_flNextFrame	= m_sItemData.m_flNextPriAttack;
	}
}

void C93R::SwitchSwitcher(void)
{
	if (m_iBurstFire > 0)
		return;

	if (m_iFireMode == CSMW_FIREMODE_TRIPLE)
	{
		m_sItemData.m_bSingleShoot = true;

		//UTIL_ShowTextMsg(pPlayer, HUD_PRINTCENTER, "#Switch_To_SemiAuto");
		SPK_SOUND("weapons/Switcher2.wav");
		m_iFireMode = CSMW_FIREMODE_SINGLE;
	}
	else
	{
		m_iBurstFire = -1;
		m_sItemData.m_bSingleShoot = false;

		//UTIL_ShowTextMsg(pPlayer, HUD_PRINTCENTER, "#Switch_To_BurstFire");
		SPK_SOUND("weapons/Switcher1.wav");
		m_iFireMode = CSMW_FIREMODE_TRIPLE;
	}
}

bool C93R::CanItemHolster(void)
{
	if (m_iBurstFire != -1)
		return false;

	return CBasePistol::CanItemHolster();
}

bool C93R::CanItemDropped(void)
{
	if (m_iBurstFire != -1)
		return false;

	return CBasePistol::CanItemDropped();
}