/***

Modern Warfare Develop Team
CM870MCS.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/03/17

***/

#include <sysdef.h>
#include <event_api.h>
#include <pm_defs.h>
#include <r_efx.h>
#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"
#include "wpn_cmd_shared.h"
#include "view.h"
#include "input.h"


int	CM870MCS::s_iItemType = 0;

class CMenuItemM870MCS : public CBaseMenuItem
{
public:
	CBaseWeapons	*m_pWeapon;

	void	Select	( void )
	{
		if (g_pPlayerActivityItem != m_pWeapon)
			return;

		if (!m_pWeapon->CanSubsAttach(CM870MCS::s_iItemType))
			return;

		if (m_pWeapon->m_pSubsItem)
		{
			if (m_pWeapon->m_pSubsItem->m_iItemType == CM870MCS::s_iItemType)	// unattach this item.
			{
				m_pWeapon->m_pSubsItem->ItemKill();
				return;
			}

			m_pWeapon->m_pSubsItem->ItemKill();
		}

		m_pWeapon->AllocSubItem(CM870MCS::s_iItemType);
	}
	
	void	Think	( void )
	{
		if (!m_pWeapon->m_pSubsItem || m_pWeapon->m_pSubsItem->m_iItemType != CM870MCS::s_iItemType)
			m_sColor = UnpackRGB(RGB_WHITE);
		else
			m_sColor = UnpackRGB(RGB_GREENISH);
	}
};


CM870MCS::CM870MCS(void)
{
	SetFunc(m_pfnUse, &CM870MCS::PrimaryAttack);

	m_sItemData		= g_sItemData[s_iItemType];
	m_iItemType		= s_iItemType;
	m_iFireMode		= CSMW_FIREMODE_SINGLE;
	m_iChamberClip	= m_sItemData.m_iChamberClip;

	// FIXME: just for test
	AMMUNITION += 30;
}

CBaseMenuItem * CM870MCS::AddToList(CBaseWeapons * pWeapon)
{
	CMenuItemM870MCS *ptr = new CMenuItemM870MCS;

	ptr->m_pWeapon		= pWeapon;
	ptr->m_bCanDelete	= true;

	wcsncpy_s(ptr->m_wszString, g_sItemData[s_iItemType].m_wszEndoName, _TRUNCATE);

	ptr->AddParent(&pWeapon->m_sAccMenu);	// add and return.

	return ptr;
}

void CM870MCS::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;
}

void CM870MCS::ItemPostFrame(void)
{
	if (m_bInReload)
	{
		if (AMMUNITION > 0 && m_flNextInsertAnim <= gEngfuncs.GetClientTime() && m_iChamberClip < m_sItemData.m_iChamberClip)
		{
			WeaponAnim(m_pAnimInsert);
			
			SU_Begin		(WPN_CMD_RELOAD);
			SU_WriteInteger	(m_iItemType);
			SU_End			();

			m_flNextInsertAnim = gEngfuncs.GetClientTime() + m_pAnimInsert->m_fd;
		}

		if (AMMUNITION > 0 && m_flNextAddAmmo <= gEngfuncs.GetClientTime() && m_iChamberClip < m_sItemData.m_iChamberClip)
		{
			m_iChamberClip ++;
			AMMUNITION --;

			m_flNextAddAmmo = gEngfuncs.GetClientTime() + m_pAnimInsert->m_fd;
		}

		// have already cover IN_ATTACK, no reason to make another PrimaryAttack() condition.
		if ( ( (m_iChamberClip >= m_sItemData.m_iChamberClip || AMMUNITION <= 0) && m_flNextInsertAnim <= gEngfuncs.GetClientTime())
			|| m_bSetForceStopReload || CL_GetButtonBits() & (IN_ATTACK|IN_RUN) )
		{
			WeaponAnim(m_bStartedFromEmpty ? m_pAnimEndRec : m_pAnimEnd, 2);

			if (m_bStartedFromEmpty)
				m_pMaster->SetShell(*m_pflReloadShell);

			m_bInReload				= false;
			m_bStartedFromEmpty		= false;
			m_bSetForceStopReload	= false;
			m_bTakeOver				= false;

			SetFunc(m_pfnUse, &CM870MCS::PrimaryAttack);
		}
	}

	if (m_iShotsFired > 0 && gEngfuncs.GetClientTime() > m_flDecreaseShotsFired)
	{
		m_iShotsFired --;
		m_flDecreaseShotsFired = gEngfuncs.GetClientTime() + 0.25f;
	}
}

bool CM870MCS::CanWeaponFire(void)
{
	if (m_pMaster->m_ulStatus & WPN_FLAG_RUN || m_bInReload || m_bRechamber || m_pMaster->m_bBlocked)
		return false;

	if (IsWeaponEmpty())
	{
		gEngfuncs.pEventAPI->EV_PlaySound(m_pPlayer->index, m_pPlayer->origin, CHAN_WEAPON, m_sItemData.m_szDryFireSound, 0.8, ATTN_NORM, 0, PITCH_NORM);
		m_flNextPriAttack = 0.8;		// play efx not so quick.

		return false;
	}

	return true;
}

void CM870MCS::PrimaryAttack(void)
{
	KickBack();

	// chamber clip only
	m_iChamberClip --;
	
	m_bRechamber = true;
	m_flNextPriAttack = m_sItemData.m_flNextPriAttack;
	m_iShotsFired ++;
	m_flDecreaseShotsFired = UTIL_WeaponTimeBase() + 0.4f;

	SU_Begin		(WPN_CMD_PRIATK);
	SU_WriteInteger	(m_iItemType);
	SU_WriteVector	(m_pMaster->GetMuzzleOrigin());
	SU_WriteVector	(g_pparams.viewangles);
	SU_WriteFloat	(0.0f);
	SU_End			();

	// local efx. no shell here.
	m_pMaster->DrawGunSmoke();
	DrawLight(m_pMaster->GetMuzzleOrigin(), m_sItemData.m_iGunFlash);

	if (m_sItemData.m_pAmmoDB && m_sItemData.m_iEffectiveAngle > 0 && m_sItemData.m_iEffectiveRange > 0)
	{
		Vector vecForward, vecRight, vecUp, vecDir, vecEnd;
		gEngfuncs.pfnAngleVectors(g_pparams.viewangles, vecForward, vecRight, vecUp);

		Vector vecSpread(abs(sin(Math::DegreeToRadian(m_sItemData.m_iEffectiveAngle) / 2.0f)));

		int iCount = RANDOM_LONG(12, 20);
		pmtrace_t tr;

		gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
		gEngfuncs.pEventAPI->EV_PushPMStates();
		gEngfuncs.pEventAPI->EV_SetSolidPlayers ( m_pPlayer->index - 1 );
		gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
		
		for (int i = 1; i <= iCount; i ++)
		{
			float x, y, z;
			do
			{
				x = RANDOM_FLOAT(-0.5, 0.5) + RANDOM_FLOAT(-0.5, 0.5);
				y = RANDOM_FLOAT(-0.5, 0.5) + RANDOM_FLOAT(-0.5, 0.5);
				z = x * x + y * y;

			} while (z > 1);

			vecDir = vecForward + x * vecSpread.x * vecRight + y * vecSpread.y * vecUp;
			vecEnd = m_pMaster->GetMuzzleOrigin() + vecDir.Normalize() * m_sItemData.m_iEffectiveRange;

			gEngfuncs.pEventAPI->EV_PlayerTrace( m_pMaster->GetMuzzleOrigin(), vecEnd, PM_STUDIO_BOX, -1, &tr );
			gEngfuncs.pEfxAPI->R_TracerEffect(m_pMaster->GetMuzzleOrigin(), tr.endpos);
		}
	}

	gEngfuncs.pEventAPI->EV_PopPMStates();

	// change Use() to reload.
	if (IsWeaponEmpty())
		SetFunc(m_pfnUse, &CM870MCS::WeaponReload);
	else
		SetFunc(m_pfnUse, &CM870MCS::Rechamber);

	// UNDONE: 3rd personal gunfire efx.
}

void CM870MCS::WeaponReload(void)
{
	if (m_bInReload || !CanWeaponReload())
		return;

	m_bInReload = true;
	m_bTakeOver = true;

	WeaponAnim(m_pAnimStart, 2);

	m_flNextInsertAnim = gEngfuncs.GetClientTime() + m_pAnimStart->m_fd;
	m_flNextAddAmmo = gEngfuncs.GetClientTime() + (*m_pflAddAmmoLoop) + m_pAnimStart->m_fd;

	if (m_iChamberClip <= 0 || m_bRechamber)
	{
		m_bStartedFromEmpty = true;
		m_bRechamber = false;
	}
}

void CM870MCS::ItemHolster(void)
{
	Sub_Holster();

	if (m_bStartedFromEmpty)
		m_bRechamber = true;

	m_flNextInsertAnim		= 0;
	m_flNextAddAmmo			= 0;
	m_bSetForceStopReload	= false;
	m_bStartedFromEmpty		= false;
	m_bTakeOver				= false;

	memset(&m_sExtraAnimStack, NULL, sizeof(m_sExtraAnimStack));
}

void CM870MCS::Rechamber(void)
{
	SetFunc(m_pfnUse, &CM870MCS::PrimaryAttack);

	WeaponAnim(m_pAnimRechamber, 2);

	m_bRechamber = false;

	m_pMaster->SetShell(*m_pflRechamberShell);
}

void CM870MCS::PushAnim(bool bSyncMaster)
{
	CBaseSubItems::PushAnim(bSyncMaster);

	m_sExtraAnimStack.m_bRechamber			= m_bRechamber;
	m_sExtraAnimStack.m_bSetForceStopReload	= m_bSetForceStopReload;
	m_sExtraAnimStack.m_bStartedFromEmpty	= m_bStartedFromEmpty;
	m_sExtraAnimStack.m_flNextAddAmmo		= m_flNextAddAmmo;
	m_sExtraAnimStack.m_flNextInsertAnim	= m_flNextInsertAnim;
}

bool CM870MCS::PopAnim(bool bSyncMaster)
{
	if (!CBaseSubItems::PopAnim(bSyncMaster))
		return false;

	m_bRechamber			= m_sExtraAnimStack.m_bRechamber;
	m_bSetForceStopReload	= m_sExtraAnimStack.m_bSetForceStopReload;
	m_bStartedFromEmpty		= m_sExtraAnimStack.m_bStartedFromEmpty;
	m_flNextAddAmmo			= m_sExtraAnimStack.m_flNextAddAmmo;
	m_flNextInsertAnim		= m_sExtraAnimStack.m_flNextInsertAnim;

	memset(&m_sExtraAnimStack, NULL, sizeof(m_sExtraAnimStack));

	return true;
}


/*
===================================

A M870 M.C.S. variant which will apply special-first-reload anim.

===================================
*/

void CM870MCS_2::ItemPostFrame(void)
{
	if (m_bInReload)
	{
		if (AMMUNITION > 0 && m_flNextInsertAnim <= gEngfuncs.GetClientTime() && m_iChamberClip < m_sItemData.m_iChamberClip)
		{
			WeaponAnim(m_pAnimInsert);
			
			SU_Begin		(WPN_CMD_RELOAD);
			SU_WriteInteger	(m_iItemType);
			SU_End			();

			m_flNextInsertAnim = gEngfuncs.GetClientTime() + m_pAnimInsert->m_fd;
		}

		if (AMMUNITION > 0 && m_flNextAddAmmo <= gEngfuncs.GetClientTime() && m_iChamberClip < m_sItemData.m_iChamberClip)
		{
			m_iChamberClip ++;
			AMMUNITION --;

			m_flNextAddAmmo = gEngfuncs.GetClientTime() + (HUD_GetWeaponAnim() == m_pAnimFirstIns->m_i ?	// use HUD_GetWeaponAnim() for a GLOBAL current anim, instead of m_iDisplayAnim, because there are two WeaponAnim() out there.
																						(m_pAnimFirstIns->m_fd - (*m_pflFirstAmmoInsert) + (*m_pflAddAmmoLoop)) :	// for FIRST anim.
																						m_pAnimInsert->m_fd	);	// for normal insert anim.
		}

		// have already cover IN_ATTACK, no reason to make another PrimaryAttack() condition.
		if ( ( (m_iChamberClip >= m_sItemData.m_iChamberClip || AMMUNITION <= 0) && m_flNextInsertAnim <= gEngfuncs.GetClientTime())
			|| m_bSetForceStopReload || CL_GetButtonBits() & (IN_ATTACK|IN_RUN) )
		{
			// in this variant, end-rechamber anim only appears on non-rechamber situation.
			WeaponAnim(m_bRechamber ? m_pAnimEndRec : m_pAnimEnd, 2);

			if (m_bRechamber)
				m_pMaster->SetShell(*m_pflReloadShell);

			m_bInReload				= false;
			m_bStartedFromEmpty		= false;
			m_bSetForceStopReload	= false;
			m_bTakeOver				= false;
			m_bRechamber			= false;	// move from WeaponReload() to here.

			SetFunc(m_pfnUse, &CM870MCS_2::PrimaryAttack);
		}
	}

	if (m_iShotsFired > 0 && gEngfuncs.GetClientTime() > m_flDecreaseShotsFired)
	{
		m_iShotsFired --;
		m_flDecreaseShotsFired = gEngfuncs.GetClientTime() + 0.25f;
	}
}

void CM870MCS_2::WeaponReload(void)
{
	if (m_bInReload || !CanWeaponReload())
		return;

	// assign status of m_bStartedFromEmpty FIRST !!!
	if (m_iChamberClip <= 0)
	{
		m_bStartedFromEmpty = true;
		m_bRechamber = false;	// rechamber mark should be removed, since RELOAD_FIRST include a shell out.
	}

	m_bInReload = true;
	m_bTakeOver = true;

	WeaponAnim(m_bStartedFromEmpty ? m_pAnimFirstIns : m_pAnimStart);	// this time we need to add ammo in the middle of RELOAD_IN, so we shouldn't block m_flNextFrame.

	m_flNextInsertAnim = gEngfuncs.GetClientTime() + (m_bStartedFromEmpty ? m_pAnimFirstIns->m_fd : m_pAnimStart->m_fd);
	m_flNextAddAmmo = gEngfuncs.GetClientTime() + (m_bStartedFromEmpty ? (*m_pflFirstAmmoInsert) : (m_pAnimStart->m_fd + (*m_pflAddAmmoLoop)) );	// since the RELOAD_FIRST anim include shell insertion.

	// when you pull silder back, a shell will pump out.
	if (m_bStartedFromEmpty)
		m_pMaster->SetShell(*m_pflFirstShellOut);
}