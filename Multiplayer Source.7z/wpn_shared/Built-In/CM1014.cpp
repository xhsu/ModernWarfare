/***

Modern Warfare Develop Team
CM1014.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/03/09

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"


float	CM1014::s_flNextAddAmmoCycle = 0.5f;
sight_t	CM1014::s_sReflectAimOfs = { Vector(-4.5, -6, 0.38), 85 };
sight_t	CM1014::s_sLaserAimOfs	 = { Vector(-4.5, -8.5, 0), 90 };
static gStdWpnHud::CBaseMenuAcc s_Acc_M1014_Reflect;

void CM1014::Initialize(NewKeyValues *pRoot, int iType)
{
	s_flNextAddAmmoCycle = LoadForAmmoAddLoop(pRoot, s_flNextAddAmmoCycle);

	NewKeyValues *pSight = pRoot->FindKey("sight");
	NewKeyValues *p = NULL;

	if (pSight)
	{
		if ( (p = pSight->FindKey("reflect_aim_offset")) )
			s_sReflectAimOfs.m_vecOfs = GetVectorFromString(p->GetString());

		if ( (p = pSight->FindKey("reflect_aim_fov")) )
			s_sReflectAimOfs.m_flFOV = p->GetFloat();

		if ( (p = pSight->FindKey("laser_aim_offset")) )
			s_sLaserAimOfs.m_vecOfs = GetVectorFromString(p->GetString());

		if ( (p = pSight->FindKey("laser_aim_fov")) )
			s_sLaserAimOfs.m_flFOV = p->GetFloat();
	}
}

void CM1014::OnSpawnPost(void)
{
	CBaseTubularWeapon::OnSpawnPost();

	m_pflAddAmmoLoop = &s_flNextAddAmmoCycle;
}

int CM1014::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands	= 0,
		{ 0, 1 },

		{ 0, 1 },	// weapon	= 2,
		{ 0, 1 },

		{ 0, 4 },	// scopes	= 4,
		{ 0, 2 },	// muzzle	= 5,
		{ 0, 2 },	// laser	= 6
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[4].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[4].body = 2;
	else if (m_bitsAccessories & M1014_ACC_REFLECT)
		info[4].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[6].body = 1;

	if (m_bitsAccessories & ACC_COMPENSATOR)
		info[5].body = 1;

	return CalcBody(info, 7);
}

void CM1014::HUD_GenerateAccMenu(void)
{
	using namespace gStdWpnHud;

	CBaseWeapons::HUD_GenerateAccMenu();

	// add conflict to other sight acc.
	CBaseMenuAcc *pOtherAcc = dynamic_cast<CBaseMenuAcc *>(m_sAccMenu.m_pFirstChild);
	while (pOtherAcc)
	{
		if (pOtherAcc->m_bitsIndex & ACC_SIGHT)
		{
			pOtherAcc->m_bitsConflict |= M1014_ACC_REFLECT;
		}

		pOtherAcc = dynamic_cast<CBaseMenuAcc *>(pOtherAcc->m_pNext);
	}

	// set the values.
	s_Acc_M1014_Reflect.m_bitsIndex		= M1014_ACC_REFLECT;
	s_Acc_M1014_Reflect.m_pBitsCurAcc	= &m_bitsAccessories;
	s_Acc_M1014_Reflect.m_bitsConflict	= ACC_SIGHT;

	char *pToken	= "#MW_Acc_M1014_Reflect";
	wchar_t	*pChars	= gpLocalize->Find(pToken);

	// secondary check.
	if (!pChars)
	{
		pToken	= "#MW_Acc_Error";
		pChars	= gpLocalize->Find(pToken);
	}

	if (pChars)
	{
		wcsncpy_s(s_Acc_M1014_Reflect.m_wszString, pChars, _TRUNCATE);
	}
	else
	{
		wchar_t *sz = ANSIToUnicode(pToken);
		wcsncpy_s(s_Acc_M1014_Reflect.m_wszString, sz, _TRUNCATE);
	}

	// install to m_sAccMenu
	m_sAccMenu.AddChild(&s_Acc_M1014_Reflect);
}

int CM1014::GetAimFOV(void)
{
	if (m_bitsAccessories & M1014_ACC_REFLECT)
		return s_sReflectAimOfs.m_flFOV;
	else if (!(m_bitsAccessories & (ACC_SIGHT|M1014_ACC_REFLECT)) && m_bitsAccessories & ACC_LASER)
		return s_sLaserAimOfs.m_flFOV;
	else
		return CBaseTubularWeapon::GetAimFOV();
}

Vector CM1014::GetAimOffset(void)
{
	if (m_bitsAccessories & M1014_ACC_REFLECT)
		return s_sReflectAimOfs.m_vecOfs;
	else if (!(m_bitsAccessories & (ACC_SIGHT|M1014_ACC_REFLECT)) && m_bitsAccessories & ACC_LASER)
		return s_sLaserAimOfs.m_vecOfs;
	else
		return CBaseTubularWeapon::GetAimOffset();
}
