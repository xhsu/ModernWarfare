/***

Modern Warfare Develop Team
CAA12.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/03/08

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



int CAA12::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands	= 0

		{ 0, 1 },	// studio	= 1
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 4 },	// scopes	= 4
		{ 0, 2 },	// rail		= 5
		{ 0, 2 },	// muzzle	= 6
		{ 0, 2 },	// laser	= 7
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[4].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[4].body = 2;
	else if (m_bitsAccessories & ACC_ROUND)
		info[4].body = 3;

	// rail
	if (info[4].body)
		info[5].body = 1;

	if (m_bitsAccessories & ACC_LASER)
		info[7].body = 1;

	if (m_bitsAccessories & ACC_MUZZLEBREAKER)
		info[6].body = 1;

	return CalcBody(info, 8);
}