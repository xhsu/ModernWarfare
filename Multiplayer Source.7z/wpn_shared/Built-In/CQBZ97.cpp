/***

Modern Warfare Develop Team
CQBZ97.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/09

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



int CQBZ97::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 1 },	// rifle		= 3;
		{ 0, 1 },
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 4 },	// scopes		= 7;
		{ 0, 2 },	// silencer		= 8;
		{ 0, 2 },	// laser		= 9;
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[7].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[7].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[7].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[9].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[8].body = 1;

	return CalcBody(info, 10);
}