/***

Modern Warfare Develop Team
CCM901.cpp - Innocent Blue's Weapon Pack

Coder:	Luna the Reborn
Model:	Innocent Blue
Sound:	Innocent Blue
Dxt/Hud:Usagi Chan

Create Date: 2018/07/04

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



#undef RECORD_ANIM_F
#undef RECORD_ANIM_S

#define RECORD_ANIM_F(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat(); \
											else if (!strcmp(p->GetName(), "eft_"#keyname"")) \
												s_AnimData[##enumname].m_fe = p->GetFloat();

#define RECORD_ANIM_S(keyname,enumname)		else if (!strcmp(p->GetName(), #keyname)) \
												s_AnimData[##enumname].m_i = p->GetInt(); \
											else if (!strcmp(p->GetName(), "time_"#keyname"")) \
												s_AnimData[##enumname].m_fd = s_AnimData[##enumname].m_fe = p->GetFloat();


int			CCM901::s_iItemType			= 0;
float		CCM901::s_flM870ClipAdd		= 0.4333333333333333f;
float		CCM901::s_flRechamberShell	= 0.4f;
float		CCM901::s_flM870ReloadShell	= 0.4666666666666667f;
animdb_t	CCM901::s_AnimData[ANIM_COUNT];


void CCM901::Initialize(NewKeyValues * pRoot, int iType)
{
	s_iItemType = iType;

	memset(&s_AnimData, NULL, sizeof(s_AnimData));

	NewKeyValues *pDatabase = pRoot->FindKey("animations");
	if (!pDatabase)
		return;
	
	NewKeyValues *p = pDatabase->GetFirstValue();

	while (p)
	{
		if (FALSE)
			break;

		RECORD_ANIM_F(shoot_m870,		ANIM_SHOOT_PARTS)
		RECORD_ANIM_F(rechamber_m870,	ANIM_RECHAMBER)
		RECORD_ANIM_F(reload_m870_in,	ANIM_RELOAD_M870_START)
		RECORD_ANIM_F(reload_m870_loop,	ANIM_RELOAD_M870_LOOP)
		RECORD_ANIM_F(reload_m870_rec,	ANIM_RELOAD_M870_EMPTY)
		RECORD_ANIM_F(reload_m870_out,	ANIM_RELOAD_M870_STOP)

		p = p->GetNextValue();
	}

	pDatabase = pRoot->FindKey("customdata");
	if (!pDatabase)
		return;

	p = pDatabase->GetFirstValue();
	
	while (p)
	{
		if (FALSE)
			break;

		RECORD_FLOAT(M870_ClipAdd,		s_flM870ClipAdd)
		RECORD_FLOAT(M870_RecShellOut,	s_flRechamberShell)
		RECORD_FLOAT(M870_ReloadShellOut,s_flM870ReloadShell)

		p = p->GetNextValue();
	}
}

int CCM901::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 1 },	// rifle		= 3;
		{ 0, 1 },

		{ 0, 2 },	// attachments	= 5;
		{ 0, 4 },	// scopes		= 6;
		{ 0, 2 },	// laser		= 7;
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[6].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[6].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[6].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[7].body = 1;

	if (m_pSubsItem)
	{
		if (m_pSubsItem->m_iItemType == CM870MCS::s_iItemType)
			info[5].body = 1;
	}

	return CalcBody(info, 8);
}

bool CCM901::CanSubsAttach(int iType)
{
	return !!(iType == CM870MCS::s_iItemType);
}

bool CCM901::AllocSubItem(int iType)
{
	if (!CanSubsAttach(iType))
		return false;

	// not delete cur subs until sure there is a new one.
	if (m_pSubsItem)
		m_pSubsItem->ItemKill();

	if (iType == CM870MCS::s_iItemType)
	{
		CM870MCS *ptr = new CM870MCS;

		ptr->m_pAnimStart		= &s_AnimData[ANIM_RELOAD_M870_START];
		ptr->m_pAnimInsert		= &s_AnimData[ANIM_RELOAD_M870_LOOP];
		ptr->m_pAnimEnd			= &s_AnimData[ANIM_RELOAD_M870_STOP];
		ptr->m_pAnimEndRec		= &s_AnimData[ANIM_RELOAD_M870_EMPTY];
		ptr->m_pAnimRechamber	= &s_AnimData[ANIM_RECHAMBER];
		ptr->m_pflAddAmmoLoop	= &s_flM870ClipAdd;
		ptr->m_pflRechamberShell= &s_flRechamberShell;
		ptr->m_pflReloadShell	= &s_flM870ReloadShell;

		m_pSubsItem = ptr;
	}

	m_pSubsItem->ItemAttachToWeapon(this);
	m_pSubsItem->ItemDeploy();

	return true;
}

void CCM901::HUD_GenerateAccMenu(void)
{
	CBaseWeapons::HUD_GenerateAccMenu();

	CM870MCS::AddToList(this);
}

void CCM901::ChangeMode(void)
{
	if (!m_pSubsItem || IS_RUNNING)
		return;

	m_bUsingSubs = true;

	if (m_pSubsItem->m_iItemType == CM870MCS::s_iItemType && m_pSubsItem->m_flNextFrame <= 0)
	{
		CM870MCS *ptr = (CM870MCS *)m_pSubsItem;

		if (m_pSubsItem->CanWeaponFire())
		{
			PauseReload();
			m_pSubsItem->WeaponAnim(&s_AnimData[ANIM_SHOOT_PARTS], 1);

			// dont need shoot anim here.
			m_pSubsItem->Use();
		}
		else if (!m_bInReload)	// including rechamber and reload.
		{
			if (IS_AIMING)
				SecondaryAttack();

			m_pSubsItem->Use();
		}
	}

	m_bUsingSubs = false;
}

int CCM901::GetMuzzleEnum(void)
{
	if (m_bUsingSubs)
		return 2;
	else
		return CBaseWeapons::GetMuzzleEnum();
}

int CCM901::GetShellEnum(void)
{
	if (m_bUsingSubs)
		return 3;
	else
		return CBaseWeapons::GetShellEnum();
}

void CCM901::WeaponReload(void)
{
	if (m_pSubsItem && m_iClip >= m_sItemData.m_pMagDB->m_iClip * 0.85f && m_pSubsItem->CanWeaponReload() && m_pSubsItem->m_flNextFrame <= 0)
	{
		if (IS_AIMING)
			SecondaryAttack();
	
		// running is defnately a fully anim.
		if (m_ulStatus & WPN_FLAG_RUN)
		{
			RunStop();
			m_ulStatus |= WPN_FLAG_SHOULD_RELOAD;
			return;
		}

		m_bUsingSubs = true;
		m_pSubsItem->WeaponReload();
		m_bUsingSubs = false;
	
		return;
	}

	return Def_WeaponReload();
}
