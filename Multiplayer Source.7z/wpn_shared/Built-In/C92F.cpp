/***

Modern Warfare Develop Team
C92F.cpp

Coder:	Luna the Reborn
Model:	Matoilet
Sound:	Matoilet
Dxt/Hud:Usagi Chan

Create Date: 2018/07/05

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"


int C92F::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// left hand	= 0,
		{ 0, 2 },	// right hand	= 1,
		{ 0, 1 },	// weapon		= 2,

		{ 0, 2 },	// slide		= 3,
		{ 0, 3 },	// sight		= 4,
		{ 0, 3 },	// muzzle		= 5,
		{ 0, 2 },	// laser		= 6
	};

	if (IsDoubleHolding())
		info[1].body = 1;

	if (m_bitsAccessories & ACC_DOT)
		info[4].body = 1;

	if (m_bitsAccessories & ACC_LASER)
		info[6].body = 1;

	if (m_bitsAccessories & ACC_MUZZLEBREAKER)
		info[5].body = 1;
	else if (m_bitsAccessories & ACC_SILENCER)
		info[5].body = 2;

	if (IsNonslidemoveAnim(m_iDisplayingAnim) && IsWeaponEmpty())
	{
		info[3].body = 1;

		if (m_bitsAccessories & ACC_SIGHT)
			info[4].body ++;	// scopes will shift follow by slide.
	}

	return CalcBody(info, 7);
}
