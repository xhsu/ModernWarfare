/***

Modern Warfare Develop Team
CUMP45.cpp

Coder:	Luna the Reborn
Model:	Innocent Blue
Sound:	Innocent Blue
Dxt/Hud:Usagi Chan

Create Date: 2018/07/09

***/

#include <sysdef.h>

#include "hud.h"
#include "hud_wpn.h"
#include "cl_util.h"
#include "cl_wpns.h"



int CUMP45::GetViewModelSubModelStatus(void)
{
	BodyEnumInfo_t info[] = 
	{
		{ 0, 1 },	// hands		= 0;
		{ 0, 1 },

		{ 0, 1 },	// gun			= 2;
		{ 0, 1 },
		{ 0, 1 },

		{ 0, 4 },	// scopes		= 5;
		{ 0, 2 },	// silencer		= 6;
		{ 0, 2 },	// laser		= 7;
	};

	if (m_bitsAccessories & ACC_HOLO)
		info[5].body = 1;
	else if (m_bitsAccessories & ACC_DOT)
		info[5].body = 2;
	else if (m_bitsAccessories & ACC_ACOG)
		info[5].body = 3;

	if (m_bitsAccessories & ACC_LASER)
		info[7].body = 1;

	if (m_bitsAccessories & ACC_SILENCER)
		info[6].body = 1;

	return CalcBody(info, 8);
}
