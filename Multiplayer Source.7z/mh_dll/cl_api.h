#pragma once
#ifndef _MH_CL_API_H_
#define _MH_CL_API_H_

#include "decal.h"

#define MW_MH_API_CURRENT_VERSION	2

typedef struct mw_mh_apis_s
{
	unsigned short	version;

	int			(*pfnLoadTGA)			(char *szFilename, unsigned char *buffer, int bufferSize, int *width, int *height);
	int			(*pfnRegisterDecal)		(decaltexture_t *pData);
	int			(*pfnAllocateDecal)		(unsigned idGLTexture, int iWidth, int iHeight);
	short		(*pfnDrawCustomDecal)	(int index, int iEntity, int iModel, float *vecOrigin, int bitsFlags, float flScale);
	bool		(*pfnRemoveCustomDecal)	(short iEngineIndex);
	const char	*(*Key_NameForBinding)	(const char *pBinding);
}
mw_mh_apis_t;

typedef bool (*MH_GetAPIFunc)	(mw_mh_apis_t *pFuncSetReturn);














































#endif // !_MH_CL_API_H_
