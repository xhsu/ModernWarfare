#include <VGUI\IPanel.h>
#include <VGUI\ISurface.h>
#include <VGUI\ISurface.h>
#include <VGUI\IScheme.h>
#include <VGUI\ILocalize.h>
#include <IBaseUI.h>

extern DWORD g_dwEngineBuildnum;

extern vgui::ISurface *g_pSurface;
extern vgui::ISchemeManager *g_pScheme;
extern vgui::IPanel *g_pPanel;
extern vgui::HFont font;

void BaseUI_InstallHook(void);

void FontInit();
void VGUI_DrawPrintText(int x, int y, int r, int g, int b, int a, vgui::HFont font, wchar_t *fmt, ...);
void HUD_DrawPrintText(int x, int y, int r, int g, int b, int a, vgui::HFont font, wchar_t *text);
void HUD_DrawPrintTextAdd(int x, int y, int r, int g, int b, vgui::HFont font, wchar_t *text);