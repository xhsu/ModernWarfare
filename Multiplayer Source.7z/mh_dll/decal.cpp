/***
Method by Crsky.
http://www.cnblogs.com/crsky/p/8322424.html
***/

#include <metahook.h>
#include "plugins.h"
#include "decal.h"

FUNC_R_DecalShoot_		g_pfnR_DecalShoot_		= NULL;
FUNC_Draw_DecalTexture	g_pfnDraw_DecalTexture	= NULL;

// define a value.
#define MAX_CUSTOM_DECAL	255

// mark for internal index.
int	g_iCustomDecals = 0;
decaltexture_t *g_pCustomDecals[MAX_CUSTOM_DECAL+1];
CTempDecal *CTempDecal::s_pRoot = NULL;
short CTempDecal::s_iUsedEngineIndex = MIN_DECAL_TEXTURE_INDEX;

CTempDecal::CTempDecal(void)
{
	CTempDecal *p = s_pRoot;
	while (p)
	{
		if ( p->m_pNext )
			p = p->m_pNext;
		else
			break;
	}

	// p == NULL means this is the first.
	if (!p)
		s_pRoot = this;
	else
		p->m_pNext = this;
}

CTempDecal::~CTempDecal(void)
{
	// if killing chain root, give chair to his next.
	if (s_pRoot == this)
	{
		s_pRoot = m_pNext;
		return;
	}

	// otherwise, which means at least two weapons in chain, and g_pWeaponChainRoot->m_pNext != NULL
	CTempDecal *pl	= s_pRoot;
	CTempDecal *p	= s_pRoot->m_pNext;

	while (p)
	{
		if ( p == this )
		{
			pl->m_pNext	= m_pNext;
			break;
		}

		pl	= p;
		p	= p->m_pNext;
	}
}

// this function is use to allocate a new index mark for engine.
short CTempDecal::AllocEngineIndex(void)
{
	// old style, could cause some problem, since engine will not alway require our data.
	// so when we allocate same index to another decal, maybe draw some picture we dont expected.
	/*for (short index = MIN_DECAL_TEXTURE_INDEX; index <= MAX_DECAL_TEXTURE_INDEX; index ++)
	{
		CTempDecal *p = s_pRoot;
		bool bOccupied = false;

		while (p)
		{
			if (p->m_iEngineIndex == index)
			{
				bOccupied = true;
				break;
			}

			p = p->m_pNext;
		}

		if (!bOccupied)
			return index;
	}

	return MIN_DECAL_TEXTURE_INDEX;*/

	s_iUsedEngineIndex ++;

	if (s_iUsedEngineIndex >= MAX_DECAL_TEXTURE_INDEX)
		s_iUsedEngineIndex = MIN_DECAL_TEXTURE_INDEX;

	return s_iUsedEngineIndex;
}

// this function is use to create a new temp decal database.
CTempDecal * CTempDecal::Create(int iMHIndex)
{
	CTempDecal *p = new CTempDecal;

	p->m_iEngineIndex	= AllocEngineIndex();
	p->m_iMHIndex		= iMHIndex;
	p->m_pTextureData	= g_pCustomDecals[iMHIndex];

	return p;
}

bool CTempDecal::Delete(short iEngineIndex)
{
	gEngfuncs.pEfxAPI->R_DecalRemoveAll(iEngineIndex);

	CTempDecal *p = CTempDecal::s_pRoot;
	while (p)
	{
		if (iEngineIndex == p->m_iEngineIndex)
		{
			delete p;
			break;
		}

		p = p->m_pNext;
	}

	return true;
}

// this function is for client.dll to register a index(used in metahook.dll)
// nothing to do with engine's index.
int CL_RegisterDecal(decaltexture_t *pData)
{
	if (g_iCustomDecals >= MAX_CUSTOM_DECAL || !pData)
		return -1;	// in that case, -1 means register fail.

	for (int i = 1; i <= g_iCustomDecals; i ++)
		if (g_pCustomDecals[i]->gl_texturenum == pData->gl_texturenum)
			return i;	// avoid repeatly register.

	g_pCustomDecals[++ g_iCustomDecals] = pData;
	return g_iCustomDecals;
}

// simplified register function.
int CL_AllocateDecal(unsigned idGLTexture, int iWidth, int iHeight)
{
	if (g_iCustomDecals >= MAX_CUSTOM_DECAL)
		return -1;	// in that case, -1 means register fail.

	for (int i = 1; i <= g_iCustomDecals; i ++)
		if (g_pCustomDecals[i]->gl_texturenum == idGLTexture)
			return i;	// avoid repeatly register.

	g_pCustomDecals[++ g_iCustomDecals] = new decaltexture_t;
	memset(g_pCustomDecals[g_iCustomDecals], NULL, sizeof(decaltexture_t));

	g_pCustomDecals[g_iCustomDecals]->gl_texturenum = idGLTexture;
	g_pCustomDecals[g_iCustomDecals]->width = iWidth;
	g_pCustomDecals[g_iCustomDecals]->height = iHeight;

	return g_iCustomDecals;
}

// fill the para with the return value of CL_RegisterDecal();
short CL_DrawCustomDecal(int index, int iEntity, int iModel, float *vecOrigin, int bitsFlags, float flScale)
{
	if (index < 0 || index > g_iCustomDecals)
		return NULL;

	CTempDecal *p = CTempDecal::Create(index);
	g_pfnR_DecalShoot_(g_pCustomDecals[index], p->m_iEngineIndex, iEntity, iModel, vecOrigin, bitsFlags, flScale);
	return p->m_iEngineIndex;
}

bool CL_RemoveCustomDecal(short iEngineIndex)
{
	return CTempDecal::Delete(iEngineIndex);
}

decaltexture_t * Draw_DecalTexture( int textureIndex )
{
	CTempDecal *p = CTempDecal::s_pRoot;
	while (p)
	{
		if (textureIndex == p->m_iEngineIndex)
			return p->m_pTextureData;

		p = p->m_pNext;
	}

	return g_pfnDraw_DecalTexture( textureIndex );
}

void DecalFuncs_InstallHook(void)
{
	// initilize.
	memset(g_pCustomDecals,	NULL,	sizeof(g_pCustomDecals));

	// dont need to inline hook this.
	*(void **)&g_pfnR_DecalShoot_ = g_pMetaHookAPI->SearchPattern((void *)g_dwEngineBase, g_dwEngineSize, R_DecalShoot__SIG, sizeof(R_DecalShoot__SIG) - 1);

	// we need to replace this.
	*(void **)&g_pfnDraw_DecalTexture = g_pMetaHookAPI->SearchPattern((void *)g_dwEngineBase, g_dwEngineSize, Draw_DecalTexture_SIG, sizeof(Draw_DecalTexture_SIG) - 1);

	if (g_pfnDraw_DecalTexture)
	{
		g_pMetaHookAPI->InlineHook(g_pfnDraw_DecalTexture, Draw_DecalTexture, (void *&)g_pfnDraw_DecalTexture);
	}
}