#pragma once
#ifndef _MH_PLUGINS_H_

extern DWORD g_dwEngineBase, g_dwEngineSize;
extern DWORD g_dwEngineBuildnum;

#endif // !_MH_PLUGINS_H_
