#pragma once
#ifndef _KEYBINDS_H_
#define _KEYBINDS_H_

#define	Key_NameForBinding_SIG	"\x55\x8B\xEC\x8D\x45\x08\x56\x50\xFF\x15\x2A\x2A\x2A\x2A\x83\xC4\x04"

void KeyBinds_InstallHook(void);

extern const char *(*g_pfnKey_NameForBinding)(const char *pBinding);

#endif // _KEYBINDS_H_
