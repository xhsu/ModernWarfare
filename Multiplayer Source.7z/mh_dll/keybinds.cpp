#include <metahook.h>
#include "keybinds.h"

const char *(*g_pfnKey_NameForBinding)(const char *pBinding);

void KeyBinds_InstallHook(void)
{
	*(void **)&g_pfnKey_NameForBinding = g_pMetaHookAPI->SearchPattern((void *)g_pMetaHookAPI->GetEngineBase(), g_pMetaHookAPI->GetEngineSize(), Key_NameForBinding_SIG, sizeof(Key_NameForBinding_SIG) - 1);
}