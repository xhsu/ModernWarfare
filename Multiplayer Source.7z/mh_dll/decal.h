#pragma once
#ifndef _DECAL_H_
#define _DECAL_H_

#define R_DecalShoot__SIG		"\x55\x8b\xEC\x83\xEC\x30\xA1\x2A\x2A\x2A\x2A\x85\xC0\x74\x2A\x8B\x45\x08\x85\xC0\x74\x2A\x68\x2A\x2A\x2A\x2A\x50\xE8\x2A\x2A\x2A\x2A"
#define Draw_DecalTexture_SIG	"\x55\x8B\xEC\x8B\x4D\x08\x56\x85\xC9\x57\x7D\x2A\x83\xC8\xFF\x2B\xC1\x8D\x0C\xC0\x8D\x14\x88\xC1\xE2\x04\x8B\x8A"

typedef struct decaltexture_s
{
    char			name[16];
    unsigned int	width, height;
    unsigned int	gl_texturenum;
    void			*texturechain;
    int				anim_total;
    int				anim_min, anim_max;
    void			*anim_next;
    void			*alternate_anims;
    unsigned int	offsets[4];
    void			*pPal;
} decaltexture_t;

typedef void				(*FUNC_R_DecalShoot_)		( decaltexture_t *ptexture, int textureIndex, int entity, int modelIndex, float *position, int flags, float scale );
typedef decaltexture_t *	(*FUNC_Draw_DecalTexture)	( int textureIndex );

#define MIN_DECAL_TEXTURE_INDEX	10000
#define MAX_DECAL_TEXTURE_INDEX 32767

void DecalFuncs_InstallHook(void);

int CL_RegisterDecal(decaltexture_t *pData);
int CL_AllocateDecal(unsigned idGLTexture, int iWidth, int iHeight);
short CL_DrawCustomDecal(int index, int iEntity, int iModel, float *vecOrigin, int bitsFlags, float flScale);
bool CL_RemoveCustomDecal(short iEngineIndex);

// FLAGS for decals
#define FDECAL_NONE			0x00
#define FDECAL_PERMANENT	0x01	// This decal should not be removed in favor of any new decals
#define FDECAL_REFERENCE	0x02	// This is a decal that's been moved from another level
#define FDECAL_CUSTOM		0x04	// This is a custom clan logo and should not be saved/restored
#define FDECAL_HFLIP		0x08	// Flip horizontal (U/S) axis
#define FDECAL_VFLIP		0x10	// Flip vertical (V/T) axis
#define FDECAL_CLIPTEST		0x20	// Decal needs to be clip-tested
#define FDECAL_NOCLIP		0x40	// Decal is not clipped by containing ploygon

// these are used in client.dll and metahook.dll
// nothing to do with engine(hw.dll)

typedef class CTempDecal
{
public:
	void *operator new(size_t size)
	{
		return calloc(1, size);
	}
	void operator delete(void *ptr)
	{
		free(ptr);
	}
	CTempDecal(void);
	~CTempDecal(void);

	short		m_iEngineIndex;
	int			m_iMHIndex;
	decaltexture_t	*m_pTextureData;
	CTempDecal	*m_pNext;

	static	CTempDecal	*s_pRoot;
	static	short		s_iUsedEngineIndex;

	static	short		AllocEngineIndex	( void );
	static	CTempDecal	*Create				( int iMHIndex );
	static	bool		Delete				( short iEngineIndex);

} decal_temp_db_t;

extern int	g_iCustomDecals;











































#endif