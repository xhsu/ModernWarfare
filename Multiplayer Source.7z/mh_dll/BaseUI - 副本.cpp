
#include <metahook.h>
#include <IBaseUI.h>
#include <keydefs.h>
#include "imgui/imgui.h"
#include "imgui_impl_gl.h"

IBaseUI *g_pBaseUI = NULL;

void(__fastcall *g_pfnCBaseUI_Initialize)(void *pthis, int edx, CreateInterfaceFn *factories, int count) = NULL;
void(__fastcall *g_pfnCBaseUI_Start)(void *pthis, int edx, struct cl_enginefuncs_s *engineFuncs, int interfaceVersion) = NULL;
void(__fastcall *g_pfnCBaseUI_Shutdown)(void *pthis, int edx) = NULL;
int(__fastcall *g_pfnCBaseUI_Key_Event)(void *pthis, int edx, int down, int keynum, const char *pszCurrentBinding) = NULL;
void(__fastcall *g_pfnCBaseUI_CallEngineSurfaceProc)(void *pthis, int edx, void *hwnd, unsigned int msg, unsigned int wparam, long lparam) = NULL;
void(__fastcall *g_pfnCBaseUI_Paint)(void *pthis, int edx, int x, int y, int right, int bottom) = NULL;
void(__fastcall *g_pfnCBaseUI_HideGameUI)(void *pthis, int edx) = NULL;
void(__fastcall *g_pfnCBaseUI_ActivateGameUI)(void *pthis, int edx) = NULL;
bool(__fastcall *g_pfnCBaseUI_IsGameUIVisible)(void *pthis, int edx) = NULL;
void(__fastcall *g_pfnCBaseUI_HideConsole)(void *pthis, int edx) = NULL;
void(__fastcall *g_pfnCBaseUI_ShowConsole)(void *pthis, int edx) = NULL;

class CBaseUI : public IBaseUI
{
public:
	void Initialize(CreateInterfaceFn *factories, int count);
	void Start(struct cl_enginefuncs_s *engineFuncs, int interfaceVersion);
	void Shutdown(void);
	int Key_Event(int down, int keynum, const char *pszCurrentBinding);
	void CallEngineSurfaceProc(void *hwnd, unsigned int msg, unsigned int wparam, long lparam);
	void Paint(int x, int y, int right, int bottom);
	void HideGameUI(void);
	void ActivateGameUI(void);
	bool IsGameUIVisible(void);
	void HideConsole(void);
	void ShowConsole(void);
};

void CBaseUI::Initialize(CreateInterfaceFn *factories, int count)
{
	g_pfnCBaseUI_Initialize(this, 0, factories, count);

	// IMGUI
	ImGui_ImplGL_Init();
}

// UNUSED
void CBaseUI::Start(struct cl_enginefuncs_s *engineFuncs, int interfaceVersion)
{
	return g_pfnCBaseUI_Start(this, 0, engineFuncs, interfaceVersion);
}

void CBaseUI::Shutdown(void)
{
	// IMGUI
	ImGui_ImplGL_Shutdown();

	g_pfnCBaseUI_Shutdown(this, 0);
}

int CBaseUI::Key_Event(int down, int keynum, const char *pszCurrentBinding)
{
	int r = g_pfnCBaseUI_Key_Event(this, 0, down, keynum, pszCurrentBinding);

	// IMGUI input
	switch (keynum)
	{
	case K_MWHEELDOWN:
		ImGui_ImplGL_ScrollCallback(0, -1.0);
		break;
	case K_MWHEELUP:
		ImGui_ImplGL_ScrollCallback(0, 1.0);
		break;
	default:
		ImGui_ImplGL_KeyCallback(keynum, down);
		break;
	}

	return r;
}

#include <queue>

std::queue<BYTE> gCharQueue;
BYTE gCharHiByte;
BYTE gCharLoByte;


void CBaseUI::CallEngineSurfaceProc(void *hwnd, unsigned int msg, unsigned int wparam, long lparam)
{
	g_pfnCBaseUI_CallEngineSurfaceProc(this, 0, hwnd, msg, wparam, lparam);

	// PREMISE: 
	// THE GAME WINDOW IS NON-UNICODE

	// 
	// The character input message with IME
	// 
	// WM_IME_CHAR(wParam:C4E3)
	// WM_IME_CHAR(wParam:BAC3)
	// WM_CHAR(wParam:C4)
	// WM_CHAR(wParam:E3)
	// WM_CHAR(wParam:BA)
	// WM_CHAR(wParam:C3)
	// 

	// IMGUI character input
	switch (msg)
	{
	case WM_IME_CHAR:
		{
			// character from IME
			gCharQueue.push(wparam > 0x7f ? 2 : 0);
			break;
		}
	case WM_CHAR:
		{
			if (!gCharQueue.empty()) {
				// This character is from IME
				BYTE& count = gCharQueue.front();
				if (count == 2) {
					// Hold the high byte of the multi byte character
					count--;
					gCharHiByte = (BYTE)wparam;
				}
				else if (count == 1) {
					gCharQueue.pop();
					// Hold the low byte of the multi byte character
					gCharLoByte = (BYTE)wparam;
					// Get a complete multi byte character
					CHAR szMultiByteChar[4] = { (CHAR)gCharHiByte, (CHAR)gCharLoByte, NULL, NULL };
					WCHAR szWideChar[4] = { NULL, NULL, NULL, NULL };
					// Convert to unicode character
					int nLen = MultiByteToWideChar(CP_ACP, 0, szMultiByteChar, -1, szWideChar, 4);
					if (nLen > 1) {		// Included NULL terminated character
						ImGui_ImplGL_CharCallback(szWideChar[0]);
					}
				}
				else {
					// This character is from IME, but don't need convertsion.
					gCharQueue.pop();
					ImGui_ImplGL_CharCallback(wparam);
				}
			}
			else {
				// This character is from keyboard
				ImGui_ImplGL_CharCallback(wparam);
			}

			break;
		}
	}
}

void CBaseUI::Paint(int x, int y, int right, int bottom)
{
	g_pfnCBaseUI_Paint(this, 0, x, y, right, bottom);

	// IMGUI test
	ImGui_ImplGL_NewFrame();

	static float f = 0.0f;
	static ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);
	static bool show_demo_window = true;
	static bool show_another_window = false;
	ImGui::Text("Hello, world!");
	ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
	ImGui::ColorEdit3("clear color", (float*)&clear_color);
	if (ImGui::Button("Demo Window"))
		show_demo_window ^= 1;
	if (ImGui::Button("Another Window"))
		show_another_window ^= 1;
	ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);

	if (show_another_window)
	{
		ImGui::Begin("Another Window", &show_another_window);
		ImGui::Text("Hello from another window!");
		ImGui::End();
	}
	if (show_demo_window)
	{
		ImGui::SetNextWindowPos(ImVec2(650, 20), ImGuiCond_FirstUseEver);
		ImGui::ShowDemoWindow(&show_demo_window);
	}

	ImGui_ImplGL_Render();
}

// UNUSED
void CBaseUI::HideGameUI(void)
{
	return g_pfnCBaseUI_HideGameUI(this, 0);
}

// UNUSED
void CBaseUI::ActivateGameUI(void)
{
	return g_pfnCBaseUI_ActivateGameUI(this, 0);
}

// UNUSED
bool CBaseUI::IsGameUIVisible(void)
{
	return g_pfnCBaseUI_IsGameUIVisible(this, 0);
}

// UNUSED
void CBaseUI::HideConsole(void)
{
	return g_pfnCBaseUI_HideConsole(this, 0);
}

// UNUSED
void CBaseUI::ShowConsole(void)
{
	return g_pfnCBaseUI_ShowConsole(this, 0);
}

void BaseUI_InstallHook(void)
{
	CreateInterfaceFn EngineCreateInterface = g_pMetaHookAPI->GetEngineFactory();
	g_pBaseUI = (IBaseUI *)EngineCreateInterface(BASEUI_INTERFACE_VERSION, 0);

	CBaseUI ins;
	DWORD *pVFTable = *(DWORD **)&ins;

	g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 1, (void *)pVFTable[1], (void *&)g_pfnCBaseUI_Initialize);
	//g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 2, (void *)pVFTable[2], (void *&)g_pfnCBaseUI_Start);
	g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 3, (void *)pVFTable[3], (void *&)g_pfnCBaseUI_Shutdown);
	g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 4, (void *)pVFTable[4], (void *&)g_pfnCBaseUI_Key_Event);
	g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 5, (void *)pVFTable[5], (void *&)g_pfnCBaseUI_CallEngineSurfaceProc);
	g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 6, (void *)pVFTable[6], (void *&)g_pfnCBaseUI_Paint);
	//g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 7, (void *)pVFTable[7], (void *&)g_pfnCBaseUI_HideGameUI);
	//g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 8, (void *)pVFTable[8], (void *&)g_pfnCBaseUI_ActivateGameUI);
	//g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 9, (void *)pVFTable[9], (void *&)g_pfnCBaseUI_IsGameUIVisible);
	//g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 10, (void *)pVFTable[10], (void *&)g_pfnCBaseUI_HideConsole);
	//g_pMetaHookAPI->VFTHook(g_pBaseUI, 0, 11, (void *)pVFTable[11], (void *&)g_pfnCBaseUI_ShowConsole);
}
