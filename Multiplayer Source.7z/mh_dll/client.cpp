#include <metahook.h>
#include "client.h"
#include "cl_api.h"
#include "big_texture.h"	// for load tga.
#include "decal.h"	// for custom decal funcs.
#include "keybinds.h"	// for keybind funcs.



extern "C" 
{
bool	DLLEXPORT CL_GetAPI ( mw_mh_apis_t *pFuncSetReturn );
}



bool	DLLEXPORT CL_GetAPI ( mw_mh_apis_t *pFuncSetReturn )
{
	if (!pFuncSetReturn)
		return false;

	mw_mh_apis_t gClSharedFunc = 
	{
		MW_MH_API_CURRENT_VERSION,

		g_pfnLoadTGA,
		CL_RegisterDecal,
		CL_AllocateDecal,
		CL_DrawCustomDecal,
		CL_RemoveCustomDecal,
		g_pfnKey_NameForBinding,
	};

	memcpy_s(pFuncSetReturn, sizeof(mw_mh_apis_t), &gClSharedFunc, sizeof(gClSharedFunc));
	return true;
}
