#include <metahook.h>
#include "imgui_impl_gl.h"

cl_enginefunc_t gEngfuncs;

int Initialize(struct cl_enginefuncs_s *pEnginefuncs, int iVersion)
{
	memcpy(&gEngfuncs, pEnginefuncs, sizeof(gEngfuncs));
	return gExportfuncs.Initialize(pEnginefuncs, iVersion);
}

void HUD_Init(void)
{
	gExportfuncs.HUD_Init();
	//ImGui_ImplGL_Init();
}

void HUD_Shutdown(void)
{
	gExportfuncs.HUD_Shutdown();
	//ImGui_ImplGL_Shutdown();
}

int HUD_Redraw(float time, int intermission)
{
	return gExportfuncs.HUD_Redraw(time, intermission);
}

#define MOUSE_BUTTON_COUNT 3

int	mouseoldbuttonstate = 0;

void IN_MouseEvent(int mstate)
{
	// IMGUI mouse input
	for (int i = 0; i < MOUSE_BUTTON_COUNT; ++i)
	{
		if ((mstate & (1 << i)) && !(mouseoldbuttonstate & (1 << i)))
		{
			ImGui_ImplGL_MouseButtonCallback(i, 1);
		}
		if (!(mstate & (1 << i)) && (mouseoldbuttonstate & (1 << i)))
		{
			ImGui_ImplGL_MouseButtonCallback(i, 0);
		}
	}

	mouseoldbuttonstate = mstate;

	gExportfuncs.IN_MouseEvent(mstate);
}

int HUD_Key_Event(int down, int keynum, const char *pszCurrentBinding)
{
	//ImGui_ImplGL_KeyCallback(keynum, down);
	return gExportfuncs.HUD_Key_Event(down, keynum, pszCurrentBinding);
}
