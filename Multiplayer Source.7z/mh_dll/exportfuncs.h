extern cl_enginefunc_t gEngfuncs;

int Initialize(struct cl_enginefuncs_s *pEnginefuncs, int iVersion);
void HUD_Init(void);
void HUD_Shutdown(void);
int HUD_Redraw(float time, int intermission);
void IN_MouseEvent(int mstate);
int HUD_Key_Event(int down, int keynum, const char *pszCurrentBinding);